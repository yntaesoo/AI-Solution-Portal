﻿const fs = require('fs');

const file = fs.readFileSync('lib/i18n/translations.ts', 'utf8');

// Simple parser for translations object
const koMatch = file.match(/ko:\s*\{([\s\S]*?)\},\s*en:/);
const enMatch = file.match(/en:\s*\{([\s\S]*?)\}\s*\};/);

if (!koMatch || !enMatch) {
  console.error("Could not parse translations.ts");
  process.exit(1);
}

function extractKeys(block) {
  const keys = [];
  const lines = block.split('\n');
  for (const line of lines) {
    const m = line.match(/"([^"]+)":/);
    if (m) {
      keys.push(m[1]);
    }
  }
  return keys;
}

const koKeys = extractKeys(koMatch[1]);
const enKeys = extractKeys(enMatch[1]);

console.log("Total KO Keys:", koKeys.length);
console.log("Total EN Keys:", enKeys.length);

const missingInEn = koKeys.filter(k => !enKeys.includes(k));
const missingInKo = enKeys.filter(k => !koKeys.includes(k));

if (missingInEn.length > 0) {
  console.error("Missing in EN:", missingInEn);
} else {
  console.log("✓ No keys missing in EN!");
}

if (missingInKo.length > 0) {
  console.error("Missing in KO:", missingInKo);
} else {
  console.log("✓ No keys missing in KO!");
}

if (missingInEn.length === 0 && missingInKo.length === 0) {
  console.log("🎉 ALL TRANSLATION KEYS PERFECTLY MATCH 1:1!");
}
