import * as dotenv from 'dotenv';
dotenv.config();
process.env.DATABASE_URL = "file:./dev.db";
import { PrismaClient } from '@prisma/client';
import { PrismaBetterSqlite3 } from '@prisma/adapter-better-sqlite3';
// @ts-ignore
import Database from 'better-sqlite3';
import xlsx from 'xlsx';
import * as bcrypt from 'bcryptjs';

const adapter = new PrismaBetterSqlite3({ url: process.env.DATABASE_URL });
const prisma = new PrismaClient({ adapter });

async function main() {
  console.log('Seeding database...');
  
  // 1. Create Admin
  const adminPassword = await bcrypt.hash('admin123', 10);
  await prisma.user.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      password: adminPassword,
      name: 'Administrator',
      role: 'ADMIN',
    },
  });
  console.log('Admin user created (username: admin, password: admin123)');

  // 2. Read Excel
  const workbook = xlsx.readFile('h:/Create with Codex/창업관련/유학생창업동아리/2026 유학생 창업동아리 운영 현황.xlsx');
  const sheet = workbook.Sheets['창업경진대회 참가'];
  const data = xlsx.utils.sheet_to_json(sheet, { header: 1 }) as any[][];
  
  // Skip header row
  const rows = data.slice(1);
  let currentClub = '';

  for (const row of rows) {
    if (row.length === 0) continue;
    
    // Some rows might only have student info and empty club name (merging)
    const clubName = row[3] || currentClub;
    if (clubName) currentClub = clubName;
    
    const studentName = row[7];
    const isLeader = row[11] === '팀장';
    
    if (clubName && studentName) {
      // Upsert Club
      let club = await prisma.club.findUnique({ where: { name: clubName } });
      if (!club) {
        club = await prisma.club.create({
          data: {
            name: clubName,
            budget: 1000000, // mock initial budget
            personnelCount: 0,
          }
        });
      }

      // Generate a mock username
      const username = studentName.replace(/\s+/g, '').toLowerCase() + Math.floor(Math.random() * 1000);
      const password = await bcrypt.hash('student123', 10);
      
      // Check if user exists
      let user = await prisma.user.findFirst({ where: { name: studentName } });
      if (!user) {
        await prisma.user.create({
          data: {
            username,
            password,
            name: studentName,
            role: 'STUDENT',
            clubId: club.id
          }
        });
      }
    }
  }

  // Update personnel counts
  const clubs = await prisma.club.findMany({ include: { users: true } });
  for (const club of clubs) {
    await prisma.club.update({
      where: { id: club.id },
      data: { personnelCount: club.users.length }
    });
    console.log(`Club: ${club.name}, Members: ${club.users.length}`);
  }
  
  console.log('Seeding finished.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
