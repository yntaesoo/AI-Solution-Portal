"use client";

import { useState } from "react";
import { updateMembers } from "@/app/actions";

export default function EditableMemberTable({ initialMembers, canEdit }: { initialMembers: any[], canEdit: boolean }) {
  const [members, setMembers] = useState(initialMembers);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState("");

  const handleChange = (index: number, field: string, value: string) => {
    const updated = [...members];
    updated[index] = { ...updated[index], [field]: value };
    setMembers(updated);
  };

  const handleSave = async () => {
    setIsSaving(true);
    setMessage("");
    try {
      await updateMembers(members);
      setMessage("저장되었습니다.");
    } catch (e) {
      setMessage("저장에 실패했습니다.");
    } finally {
      setIsSaving(false);
      setTimeout(() => setMessage(""), 3000);
    }
  };

  return (
    <div>
      {canEdit && (
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '1rem', alignItems: 'center', gap: '1rem' }}>
          {message && <span style={{ color: 'var(--primary)', fontWeight: 'bold' }}>{message}</span>}
          <button 
            onClick={handleSave} 
            disabled={isSaving} 
            className="btn btn-primary"
            style={{ padding: '0.5rem 1rem' }}
          >
            {isSaving ? "저장 중..." : "수정 사항 저장"}
          </button>
        </div>
      )}
      <div style={{ 
        maxHeight: '450px', 
        overflowY: 'auto', 
        overflowX: 'auto', 
        border: '1px solid #e5e7eb', 
        borderRadius: '8px',
        background: '#fff',
        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)'
      }}>
        <table style={{ minWidth: '1600px', borderCollapse: 'separate', borderSpacing: 0, width: '100%' }}>
          <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
            <tr>
              {[
                "이름", "영어 이름", "역할(팀장/팀원)", "단과대학", "학과/전공", 
                "학년", "학번", "이메일", "연락처", "재학여부", "지도교수"
              ].map((header, idx) => (
                <th 
                  key={idx} 
                  style={{ 
                    background: '#f9fafb', 
                    color: '#374151', 
                    fontWeight: 600, 
                    padding: '0.75rem', 
                    borderBottom: '2px solid #e5e7eb', 
                    borderRight: '1px solid #e5e7eb', 
                    textAlign: 'left',
                    fontSize: '0.875rem',
                    whiteSpace: 'nowrap'
                  }}
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {members.map((member, i) => {
              const cellStyle = { 
                borderBottom: '1px solid #e5e7eb', 
                borderRight: '1px solid #e5e7eb',
                padding: 0,
                background: '#fff'
              };
              const inputStyle = {
                width: '100%',
                border: 'none',
                outline: 'none',
                padding: '0.6rem 0.8rem',
                fontSize: '0.875rem',
                background: 'transparent',
                transition: 'all 0.15s'
              };

              return (
                <tr key={member.id} style={{ transition: 'background-color 0.1s' }} onMouseEnter={e => e.currentTarget.style.backgroundColor = '#f9fafb'} onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}>
                  <td style={{ ...cellStyle, fontWeight: 'bold', padding: '0.6rem 0.8rem', fontSize: '0.875rem', background: '#f9fafb', whiteSpace: 'nowrap', borderRight: '2px solid #e5e7eb' }}>
                    {member.name}
                  </td>
                  <td style={cellStyle}>
                    {canEdit ? (
                      <input 
                        type="text" 
                        value={member.englishName || ""} 
                        onChange={e => handleChange(i, 'englishName', e.target.value)} 
                        style={inputStyle}
                        onFocus={e => e.target.style.background = '#fff'}
                        onBlur={e => e.target.style.background = 'transparent'}
                      />
                    ) : (
                      <div style={{ padding: '0.6rem 0.8rem', fontSize: '0.875rem', whiteSpace: 'nowrap' }}>{member.englishName || "-"}</div>
                    )}
                  </td>
                  <td style={cellStyle}>
                    {canEdit ? (
                      <input 
                        type="text" 
                        value={member.clubRole || ""} 
                        onChange={e => handleChange(i, 'clubRole', e.target.value)} 
                        style={inputStyle}
                        onFocus={e => e.target.style.background = '#fff'}
                        onBlur={e => e.target.style.background = 'transparent'}
                      />
                    ) : (
                      <div style={{ padding: '0.6rem 0.8rem', fontSize: '0.875rem', whiteSpace: 'nowrap' }}>{member.clubRole || "-"}</div>
                    )}
                  </td>
                  <td style={cellStyle}>
                    {canEdit ? (
                      <input 
                        type="text" 
                        value={member.college || ""} 
                        onChange={e => handleChange(i, 'college', e.target.value)} 
                        style={inputStyle}
                        onFocus={e => e.target.style.background = '#fff'}
                        onBlur={e => e.target.style.background = 'transparent'}
                      />
                    ) : (
                      <div style={{ padding: '0.6rem 0.8rem', fontSize: '0.875rem', whiteSpace: 'nowrap' }}>{member.college || "-"}</div>
                    )}
                  </td>
                  <td style={cellStyle}>
                    {canEdit ? (
                      <input 
                        type="text" 
                        value={member.department || ""} 
                        onChange={e => handleChange(i, 'department', e.target.value)} 
                        style={inputStyle}
                        onFocus={e => e.target.style.background = '#fff'}
                        onBlur={e => e.target.style.background = 'transparent'}
                      />
                    ) : (
                      <div style={{ padding: '0.6rem 0.8rem', fontSize: '0.875rem', whiteSpace: 'nowrap' }}>{member.department || "-"}</div>
                    )}
                  </td>
                  <td style={cellStyle}>
                    {canEdit ? (
                      <input 
                        type="text" 
                        value={member.grade || ""} 
                        onChange={e => handleChange(i, 'grade', e.target.value)} 
                        style={{ ...inputStyle, textAlign: 'center' }}
                        onFocus={e => e.target.style.background = '#fff'}
                        onBlur={e => e.target.style.background = 'transparent'}
                      />
                    ) : (
                      <div style={{ padding: '0.6rem 0.8rem', fontSize: '0.875rem', whiteSpace: 'nowrap', textAlign: 'center' }}>{member.grade || "-"}</div>
                    )}
                  </td>
                  <td style={cellStyle}>
                    {canEdit ? (
                      <input 
                        type="text" 
                        value={member.studentId || ""} 
                        onChange={e => handleChange(i, 'studentId', e.target.value)} 
                        style={inputStyle}
                        onFocus={e => e.target.style.background = '#fff'}
                        onBlur={e => e.target.style.background = 'transparent'}
                      />
                    ) : (
                      <div style={{ padding: '0.6rem 0.8rem', fontSize: '0.875rem', whiteSpace: 'nowrap' }}>{member.studentId || "-"}</div>
                    )}
                  </td>
                  <td style={cellStyle}>
                    {canEdit ? (
                      <input 
                        type="email" 
                        value={member.email || ""} 
                        onChange={e => handleChange(i, 'email', e.target.value)} 
                        style={inputStyle}
                        onFocus={e => e.target.style.background = '#fff'}
                        onBlur={e => e.target.style.background = 'transparent'}
                      />
                    ) : (
                      <div style={{ padding: '0.6rem 0.8rem', fontSize: '0.875rem', whiteSpace: 'nowrap' }}>{member.email || "-"}</div>
                    )}
                  </td>
                  <td style={cellStyle}>
                    {canEdit ? (
                      <input 
                        type="text" 
                        value={member.phone || ""} 
                        onChange={e => handleChange(i, 'phone', e.target.value)} 
                        style={inputStyle}
                        onFocus={e => e.target.style.background = '#fff'}
                        onBlur={e => e.target.style.background = 'transparent'}
                      />
                    ) : (
                      <div style={{ padding: '0.6rem 0.8rem', fontSize: '0.875rem', whiteSpace: 'nowrap' }}>{member.phone || "-"}</div>
                    )}
                  </td>
                  <td style={cellStyle}>
                    {canEdit ? (
                      <input 
                        type="text" 
                        value={member.enrollmentStatus || ""} 
                        onChange={e => handleChange(i, 'enrollmentStatus', e.target.value)} 
                        style={inputStyle}
                        onFocus={e => e.target.style.background = '#fff'}
                        onBlur={e => e.target.style.background = 'transparent'}
                      />
                    ) : (
                      <div style={{ padding: '0.6rem 0.8rem', fontSize: '0.875rem', whiteSpace: 'nowrap' }}>{member.enrollmentStatus || "-"}</div>
                    )}
                  </td>
                  <td style={cellStyle}>
                    {canEdit ? (
                      <input 
                        type="text" 
                        value={member.advisor || ""} 
                        onChange={e => handleChange(i, 'advisor', e.target.value)} 
                        style={inputStyle}
                        onFocus={e => e.target.style.background = '#fff'}
                        onBlur={e => e.target.style.background = 'transparent'}
                      />
                    ) : (
                      <div style={{ padding: '0.6rem 0.8rem', fontSize: '0.875rem', whiteSpace: 'nowrap' }}>{member.advisor || "-"}</div>
                    )}
                  </td>
                </tr>
              );
            })}
            {members.length === 0 && (
              <tr>
                <td colSpan={11} style={{ textAlign: 'center', padding: '2rem' }}>등록된 팀원이 없습니다.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
