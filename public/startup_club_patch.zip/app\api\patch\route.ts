import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export async function GET() {
  const filePath = path.join(process.cwd(), "patches", "startup_club_patch.zip");
  if (!fs.existsSync(filePath)) {
    return new NextResponse("Patch file not found", { status: 404 });
  }

  const fileBuffer = fs.readFileSync(filePath);
  return new NextResponse(fileBuffer, {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": 'attachment; filename="startup_club_patch.zip"',
    },
  });
}
