"use client";

import { SessionProvider } from "next-auth/react";
import { LanguageProvider } from "@/lib/i18n/LanguageContext";

export default function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider basePath="/StartupClub/api/auth">
      <LanguageProvider>
        {children}
      </LanguageProvider>
    </SessionProvider>
  );
}
