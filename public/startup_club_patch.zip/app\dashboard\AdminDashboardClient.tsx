"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { createClub, addActivityAdvanced } from "@/app/actions";
import BudgetSpreadsheet from "./BudgetSpreadsheet";
import MentorAssignmentSpreadsheet from "./MentorAssignmentSpreadsheet";
import SupportProgramManager from "./SupportProgramManager";
import SatisfactionSurveyManager from "./SatisfactionSurveyManager";
import CertificateGenerator from "./CertificateGenerator";
import { useLanguage } from "@/lib/i18n/LanguageContext";

interface Activity {
  id: string;
  clubId: string;
  club: {
    name: string;
  };
  type: string;
  status: string;
  description: string | null;
  createdAt: Date | string;
}

interface Club {
  id: string;
  name: string;
  budget: number;
  requestedBudget: number;
  spentBudget: number;
  remainingBudget: number;
  personnelCount: number;
  type: string | null;
  itemName: string | null;
  itemSummary: string | null;
  advisor: string | null;
  users: any[];
  activities: any[];
}

export default function AdminDashboardClient({
  initialClubs,
  mentors,
  allActivities,
  initialPrograms,
  initialSurveys
}: {
  initialClubs: Club[];
  mentors: any[];
  allActivities: Activity[];
  initialPrograms?: any[];
  initialSurveys?: any[];
}) {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<
    "general" | "manage" | "analysis" | "programs" | "surveys" | "certificates"
  >("general");
  const [clubs, setClubs] = useState<Club[]>(initialClubs);
  const [activities, setActivities] = useState<Activity[]>(allActivities);
  const [programs, setPrograms] = useState<any[]>(initialPrograms || []);
  const [surveys, setSurveys] = useState<any[]>(initialSurveys || []);

  useEffect(() => {
    if (initialSurveys) setSurveys(initialSurveys);
  }, [initialSurveys]);

  useEffect(() => {
    if (initialPrograms) setPrograms(initialPrograms);
  }, [initialPrograms]);
  
  // Activity modal form states
  const [isActivityModalOpen, setIsActivityModalOpen] = useState(false);
  const [selectedClubId, setSelectedClubId] = useState("");
  const [actType, setActType] = useState("창업교육");
  const [actStatus, setActStatus] = useState("진행중");
  
  // Specific activity fields
  const [eduName, setEduName] = useState("");
  const [eduDate, setEduDate] = useState("");
  const [eduAttended, setEduAttended] = useState(false);
  const [campName, setCampName] = useState("");
  const [campDate, setCampDate] = useState("");
  const [campAttended, setCampAttended] = useState(false);
  const [contestName, setContestName] = useState("");
  const [contestDate, setContestDate] = useState("");
  const [contestAward, setContestAward] = useState("");
  const [patentTitle, setPatentTitle] = useState("");
  const [patentStatus, setPatentStatus] = useState("출원");
  const [designName, setDesignName] = useState("");
  const [protoName, setProtoName] = useState("");
  const [protoStatus, setProtoStatus] = useState("진행중");
  const [startupHope, setStartupHope] = useState("희망");
  
  // Stats
  const totalClubs = clubs.length;
  const totalStudents = clubs.reduce((acc, club) => acc + club.users.length, 0);
  const totalBudget = clubs.reduce((acc, club) => acc + club.budget, 0);
  const totalSpent = clubs.reduce((acc, club) => acc + club.spentBudget, 0);
  const totalRemaining = clubs.reduce((acc, club) => acc + club.remainingBudget, 0);

  // Analysis tabs
  const [analysisTab, setAnalysisTab] = useState<"activities" | "burnRate" | "awards">("activities");
  const [filterClubId, setFilterClubId] = useState("all");
  const [filterType, setFilterType] = useState("all");

  // Activity submit handler
  const handleAddActivity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClubId || !actType) {
      alert("동아리와 활동 유형을 선택해 주세요.");
      return;
    }

    let detailsObj = {};
    let status = actStatus;

    if (actType === "창업교육") {
      detailsObj = { educationName: eduName, date: eduDate, attended: eduAttended };
      status = eduAttended ? "완료" : "진행중";
    } else if (actType === "창업캠프") {
      detailsObj = { campName: campName, date: campDate, attended: campAttended };
      status = campAttended ? "완료" : "진행중";
    } else if (actType === "창업경진대회") {
      detailsObj = { contestName, date: contestDate, award: contestAward };
      status = contestAward ? "완료" : "진행중";
    } else if (actType === "지식재산권") {
      detailsObj = { patentTitle, status: patentStatus, designName };
      status = patentStatus === "등록" ? "완료" : "진행중";
    } else if (actType === "시제품제작") {
      detailsObj = { prototypeName: protoName, status: protoStatus };
      status = protoStatus;
    } else if (actType === "실제창업") {
      detailsObj = { hopeStatus: startupHope };
      status = startupHope === "희망" ? "진행중" : "완료";
    }

    try {
      await addActivityAdvanced(selectedClubId, actType, status, JSON.stringify(detailsObj));
      alert("활동 내역이 성공적으로 등록되었습니다.");
      setIsActivityModalOpen(false);
      window.location.reload(); // Reload to refresh activity feeds
    } catch (err) {
      alert("활동 저장 중 오류가 발생했습니다.");
    }
  };

  const renderDescription = (act: Activity) => {
    if (!act.description) return "-";
    try {
      const d = JSON.parse(act.description);
      if (act.type === "창업교육") {
        return `교육명: ${d.educationName || "-"} | 일시: ${d.date || "-"} | 참석여부: ${d.attended ? "참석" : "미참석"}`;
      } else if (act.type === "창업캠프") {
        return `캠프명: ${d.campName || "-"} | 일시: ${d.date || "-"} | 참석여부: ${d.attended ? "참석" : "미참석"}`;
      } else if (act.type === "창업경진대회") {
        return `대회명: ${d.contestName || "-"} | 일시: ${d.date || "-"} | 수상내역: ${d.award || "없음"}`;
      } else if (act.type === "지식재산권") {
        return `특허제목: ${d.patentTitle || "-"} (${d.status || "출원"}) | 디자인등록: ${d.designName || "-"}`;
      } else if (act.type === "시제품제작") {
        return `시제품명: ${d.prototypeName || "-"} | 상태: ${d.status || "-"}`;
      } else if (act.type === "실제창업") {
        return `창업 희망 여부: ${d.hopeStatus || "-"}`;
      }
      return act.description;
    } catch (e) {
      return act.description;
    }
  };

  // Filter activities
  const filteredActivities = activities.filter(act => {
    if (filterClubId !== "all" && act.clubId !== filterClubId) return false;
    if (filterType !== "all" && act.type !== filterType) return false;
    return true;
  });

  // Filter awards
  const awardsActivities = activities.filter(act => {
    if (act.type !== "창업경진대회") return false;
    try {
      const d = JSON.parse(act.description || "{}");
      return !!d.award && d.award.trim() !== "";
    } catch (e) {
      return false;
    }
  });

  // Sort clubs by spentBudget burn rate
  const clubsByBurnRate = [...clubs].sort((a, b) => {
    const rateA = a.budget > 0 ? (a.spentBudget / a.budget) : 0;
    const rateB = b.budget > 0 ? (b.spentBudget / b.budget) : 0;
    return rateB - rateA; // Descending
  });

  return (
    <>
    <div className="dashboard-layout" style={{ display: 'flex', gap: '1.5rem', minHeight: 'calc(100vh - 120px)', alignItems: 'flex-start' }}>
      {/* -------------------- LEFT SIDEBAR NAV -------------------- */}
      <aside
        className="dashboard-sidebar"
        style={{
          width: '240px',
          flexShrink: 0,
          background: '#ffffff',
          borderRadius: '16px',
          border: '1px solid #e2e8f0',
          padding: '1.25rem 0.85rem',
          boxShadow: '0 4px 16px rgba(0,0,0,0.03)',
          display: 'flex',
          flexDirection: 'column',
          gap: '1.5rem',
          position: 'sticky',
          top: '80px'
        }}
      >
        <div style={{ padding: '0 0.5rem' }}>
          <h3 style={{ fontSize: '1rem', fontWeight: 800, margin: 0, color: '#1e3a8a' }}>
            {t("admin.sidebar.portal")}
          </h3>
          <p style={{ fontSize: '0.75rem', color: '#64748b', margin: '0.2rem 0 0 0' }}>
            {t("admin.sidebar.subtitle")}
          </p>
        </div>

        {/* Section 1: 동아리 운영 및 분석 */}
        <div>
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#94a3b8', letterSpacing: '0.5px', marginBottom: '0.5rem', padding: '0 0.5rem' }}>
            {t("admin.sidebar.section1")}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
            <button
              onClick={() => setActiveTab('general')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.6rem',
                width: '100%',
                padding: '0.65rem 0.85rem',
                borderRadius: '10px',
                border: 'none',
                background: activeTab === 'general' ? '#2563eb' : 'transparent',
                color: activeTab === 'general' ? '#ffffff' : '#334155',
                fontWeight: activeTab === 'general' ? 700 : 500,
                fontSize: '0.875rem',
                cursor: 'pointer',
                textAlign: 'left'
              }}
            >
              {t("admin.sidebar.tab.general")}
            </button>

            <button
              onClick={() => setActiveTab('manage')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.6rem',
                width: '100%',
                padding: '0.65rem 0.85rem',
                borderRadius: '10px',
                border: 'none',
                background: activeTab === 'manage' ? '#2563eb' : 'transparent',
                color: activeTab === 'manage' ? '#ffffff' : '#334155',
                fontWeight: activeTab === 'manage' ? 700 : 500,
                fontSize: '0.875rem',
                cursor: 'pointer',
                textAlign: 'left'
              }}
            >
              {t("admin.sidebar.tab.manage")}
            </button>

            <button
              onClick={() => setActiveTab('analysis')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.6rem',
                width: '100%',
                padding: '0.65rem 0.85rem',
                borderRadius: '10px',
                border: 'none',
                background: activeTab === 'analysis' ? '#2563eb' : 'transparent',
                color: activeTab === 'analysis' ? '#ffffff' : '#334155',
                fontWeight: activeTab === 'analysis' ? 700 : 500,
                fontSize: '0.875rem',
                cursor: 'pointer',
                textAlign: 'left'
              }}
            >
              {t("admin.sidebar.tab.analysis")}
            </button>
          </div>
        </div>

        {/* Section 2: 프로그램 및 설문/수료증 관리 */}
        <div>
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#94a3b8', letterSpacing: '0.5px', marginBottom: '0.5rem', padding: '0 0.5rem' }}>
            {t("admin.sidebar.section2")}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
            <button
              onClick={() => setActiveTab('programs')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.6rem',
                width: '100%',
                padding: '0.65rem 0.85rem',
                borderRadius: '10px',
                border: 'none',
                background: activeTab === 'programs' ? '#2563eb' : 'transparent',
                color: activeTab === 'programs' ? '#ffffff' : '#334155',
                fontWeight: activeTab === 'programs' ? 700 : 500,
                fontSize: '0.875rem',
                cursor: 'pointer',
                textAlign: 'left'
              }}
            >
              {t("admin.sidebar.tab.programs")}
            </button>

            <button
              onClick={() => setActiveTab('surveys')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.6rem',
                width: '100%',
                padding: '0.65rem 0.85rem',
                borderRadius: '10px',
                border: 'none',
                background: activeTab === 'surveys' ? '#2563eb' : 'transparent',
                color: activeTab === 'surveys' ? '#ffffff' : '#334155',
                fontWeight: activeTab === 'surveys' ? 700 : 500,
                fontSize: '0.875rem',
                cursor: 'pointer',
                textAlign: 'left'
              }}
            >
              {t("admin.sidebar.tab.surveys")}
            </button>

            <button
              onClick={() => setActiveTab('certificates')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.6rem',
                width: '100%',
                padding: '0.65rem 0.85rem',
                borderRadius: '10px',
                border: 'none',
                background: activeTab === 'certificates' ? '#2563eb' : 'transparent',
                color: activeTab === 'certificates' ? '#ffffff' : '#334155',
                fontWeight: activeTab === 'certificates' ? 700 : 500,
                fontSize: '0.875rem',
                cursor: 'pointer',
                textAlign: 'left'
              }}
            >
              {t("admin.sidebar.tab.certificates")}
            </button>
          </div>
        </div>
      </aside>

      {/* -------------------- RIGHT MAIN CONTENT -------------------- */}
      <main className="dashboard-content" style={{ flex: 1, minWidth: 0 }}>

      {/* -------------------- TAB 1: 일반 현황 -------------------- */}
      {activeTab === "general" && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.5rem' }}>
            <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', fontWeight: 500 }}>{t("admin.stat.totalClubs")}</span>
              <span style={{ fontSize: '2.25rem', fontWeight: 800, marginTop: '0.5rem', color: 'var(--primary)' }}>{totalClubs} {t("admin.unit.clubs")}</span>
            </div>
            <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', fontWeight: 500 }}>{t("admin.stat.totalStudents")}</span>
              <span style={{ fontSize: '2.25rem', fontWeight: 800, marginTop: '0.5rem', color: '#0f766e' }}>{totalStudents} {t("admin.unit.persons")}</span>
            </div>
            <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', fontWeight: 500 }}>{t("admin.stat.totalBudget")}</span>
              <span style={{ fontSize: '1.75rem', fontWeight: 800, marginTop: '0.5rem', color: '#1e3a8a' }}>{totalBudget.toLocaleString()} {t("admin.unit.won")}</span>
            </div>
            <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', fontWeight: 500 }}>{t("admin.stat.totalSpent")}</span>
              <span style={{ fontSize: '1.75rem', fontWeight: 800, marginTop: '0.5rem', color: '#b91c1c' }}>{totalSpent.toLocaleString()} {t("admin.unit.won")}</span>
            </div>
            <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', fontWeight: 500 }}>{t("admin.stat.totalRemaining")}</span>
              <span style={{ fontSize: '1.75rem', fontWeight: 800, marginTop: '0.5rem', color: '#15803d' }}>{totalRemaining.toLocaleString()} {t("admin.unit.won")}</span>
            </div>
          </div>

          <div className="glass-card">
            <h2 style={{ marginBottom: '1.25rem' }}>{t("admin.manage.newClub")}</h2>
            <form action={createClub} style={{ display: 'flex', gap: '1rem', alignItems: 'center', flexWrap: 'wrap' }}>
              <input type="text" name="name" placeholder={t("admin.manage.clubNamePlaceholder")} className="input-field" required style={{ maxWidth: '300px' }} />
              <input type="number" name="budget" placeholder={t("admin.manage.budgetPlaceholder")} className="input-field" style={{ maxWidth: '200px' }} />
              <button type="submit" className="btn btn-primary" style={{ padding: '0.75rem 1.5rem' }}>{t("admin.manage.btnAdd")}</button>
            </form>
          </div>
        </div>
      )}

      {/* -------------------- TAB 2: 동아리 관리 -------------------- */}
      {activeTab === "manage" && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          {/* 동아리 운영 현황 기본 목록 */}
          <div className="glass-card">
            <h2 style={{ marginBottom: '1rem' }}>{t("admin.manage.table.title")}</h2>
            <div className="table-container">
              <table style={{ minWidth: '850px', width: '100%', tableLayout: 'auto' }}>
                <thead>
                  <tr>
                    <th style={{ width: '180px', whiteSpace: 'nowrap' }}>{t("admin.table.clubName")}</th>
                    <th style={{ width: '120px', whiteSpace: 'nowrap' }}>{t("admin.table.advisor")}</th>
                    <th style={{ width: '120px', whiteSpace: 'nowrap' }}>{t("admin.table.type")}</th>
                    <th style={{ width: '100px', whiteSpace: 'nowrap' }}>{t("admin.table.studentCount")}</th>
                    <th style={{ minWidth: '220px', whiteSpace: 'nowrap' }}>{t("admin.table.itemName")}</th>
                    <th style={{ width: '110px', whiteSpace: 'nowrap' }}>{t("admin.table.action")}</th>
                  </tr>
                </thead>
                <tbody>
                  {clubs.map((club) => (
                    <tr key={club.id}>
                      <td style={{ fontWeight: 600, whiteSpace: 'nowrap' }}>{club.name}</td>
                      <td style={{ whiteSpace: 'nowrap' }}>{club.advisor || t("admin.table.unassigned")}</td>
                      <td style={{ whiteSpace: 'nowrap' }}>
                        {club.type ? (
                          <span className="badge" style={{ background: '#f3f4f6', color: '#374151', whiteSpace: 'nowrap' }}>{club.type}</span>
                        ) : t("admin.table.unassigned")}
                      </td>
                      <td style={{ whiteSpace: 'nowrap' }}>{club.users.length} {t("admin.unit.persons")}</td>
                      <td style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', wordBreak: 'keep-all' }}>{club.itemName || t("admin.table.unregistered")}</td>
                      <td style={{ whiteSpace: 'nowrap' }}>
                        <Link href={`/club/${club.id}`}>
                          <button className="btn btn-primary" style={{ padding: '0.35rem 0.85rem', fontSize: '0.8rem', whiteSpace: 'nowrap', display: 'inline-flex', alignItems: 'center' }}>{t("admin.btn.detail")}</button>
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* 예산 현황 스프레드시트 */}
          <BudgetSpreadsheet initialClubs={clubs} />

          {/* 멘토 배정 스프레드시트 */}
          <MentorAssignmentSpreadsheet initialMentors={mentors} clubs={clubs} />
        </div>
      )}

      {/* -------------------- TAB 3: 동아리 운영현황 분석 -------------------- */}
      {activeTab === "analysis" && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          {/* Analysis Menu Tabs */}
          <div style={{ display: 'flex', gap: '1rem', borderBottom: '1px solid #e5e7eb', paddingBottom: '0.5rem', flexWrap: 'wrap' }}>
            <button 
              onClick={() => setAnalysisTab("activities")}
              style={{ background: 'none', border: 'none', padding: '0.5rem 1rem', fontSize: '1rem', fontWeight: 600, color: analysisTab === 'activities' ? 'var(--primary)' : 'var(--text-secondary)', borderBottom: analysisTab === 'activities' ? '3px solid var(--primary)' : 'none', cursor: 'pointer' }}
            >
              {t("admin.analysis.tab.activities")}
            </button>
            <button 
              onClick={() => setAnalysisTab("burnRate")}
              style={{ background: 'none', border: 'none', padding: '0.5rem 1rem', fontSize: '1rem', fontWeight: 600, color: analysisTab === 'burnRate' ? 'var(--primary)' : 'var(--text-secondary)', borderBottom: analysisTab === 'burnRate' ? '3px solid var(--primary)' : 'none', cursor: 'pointer' }}
            >
              {t("admin.analysis.tab.burnRate")}
            </button>
            <button 
              onClick={() => setAnalysisTab("awards")}
              style={{ background: 'none', border: 'none', padding: '0.5rem 1rem', fontSize: '1rem', fontWeight: 600, color: analysisTab === 'awards' ? 'var(--primary)' : 'var(--text-secondary)', borderBottom: analysisTab === 'awards' ? '3px solid var(--primary)' : 'none', cursor: 'pointer' }}
            >
              {t("admin.analysis.tab.awards")}
            </button>
          </div>

          {/* 1. 활동 내역 리스트 및 등록 */}
          {analysisTab === "activities" && (
            <div className="glass-card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
                <h3 style={{ margin: 0 }}>{t("admin.analysis.activities.count", { count: filteredActivities.length })}</h3>
                
                <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
                  {/* Filters */}
                  <select 
                    className="input-field" 
                    value={filterClubId} 
                    onChange={e => setFilterClubId(e.target.value)}
                    style={{ width: 'auto', padding: '0.5rem' }}
                  >
                    <option value="all">{t("admin.analysis.filter.allClubs")}</option>
                    {clubs.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>

                  <select 
                    className="input-field" 
                    value={filterType} 
                    onChange={e => setFilterType(e.target.value)}
                    style={{ width: 'auto', padding: '0.5rem' }}
                  >
                    <option value="all">{t("admin.analysis.filter.allTypes")}</option>
                    <option value="창업교육">창업교육</option>
                    <option value="창업캠프">창업캠프</option>
                    <option value="창업경진대회">창업경진대회</option>
                    <option value="지식재산권">지식재산권</option>
                    <option value="시제품제작">시제품제작</option>
                    <option value="실제창업">실제창업</option>
                  </select>

                  <button 
                    onClick={() => {
                      if(clubs.length === 0) {
                        alert("먼저 동아리를 등록하세요.");
                        return;
                      }
                      setSelectedClubId(clubs[0].id);
                      setActType("창업교육");
                      setIsActivityModalOpen(true);
                    }}
                    className="btn btn-primary"
                    style={{ padding: '0.5rem 1rem' }}
                  >
                    {t("admin.analysis.btn.addActivity")}
                  </button>
                </div>
              </div>

              <div className="table-container">
                <table style={{ minWidth: '850px', width: '100%' }}>
                  <thead>
                    <tr>
                      <th style={{ width: '180px', whiteSpace: 'nowrap' }}>{t("admin.table.clubName")}</th>
                      <th style={{ width: '120px', whiteSpace: 'nowrap' }}>{t("admin.analysis.table.type")}</th>
                      <th style={{ width: '100px', whiteSpace: 'nowrap' }}>{t("admin.analysis.table.status")}</th>
                      <th style={{ minWidth: '300px', whiteSpace: 'nowrap' }}>{t("admin.analysis.table.desc")}</th>
                      <th style={{ width: '120px', whiteSpace: 'nowrap' }}>{t("admin.analysis.table.date")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredActivities.length === 0 ? (
                      <tr>
                        <td colSpan={5} style={{ textAlign: 'center', color: 'var(--text-secondary)', padding: '2rem' }}>{t("admin.analysis.emptyActivities")}</td>
                      </tr>
                    ) : (
                      filteredActivities.map(act => (
                        <tr key={act.id}>
                          <td style={{ fontWeight: 600 }}>{act.club.name}</td>
                          <td>
                            <span className="badge" style={{ background: '#e0e7ff', color: '#4338ca' }}>{act.type}</span>
                          </td>
                          <td>
                            <span className="badge" style={{ 
                              background: act.status === '완료' ? '#dcfce7' : act.status === '진행중' ? '#fef9c3' : '#f3f4f6',
                              color: act.status === '완료' ? '#15803d' : act.status === '진행중' ? '#a16207' : '#374151'
                            }}>
                              {act.status}
                            </span>
                          </td>
                          <td style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{renderDescription(act)}</td>
                          <td suppressHydrationWarning style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>{new Date(act.createdAt).toLocaleDateString()}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 2. 예산 소진 순위 */}
          {analysisTab === "burnRate" && (
            <div className="glass-card">
              <h3 style={{ marginBottom: '1.5rem' }}>{t("admin.analysis.burnTitle")}</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                {clubsByBurnRate.map((club, index) => {
                  const burnRate = club.budget > 0 ? (club.spentBudget / club.budget) * 100 : 0;
                  const progressColor = burnRate > 80 ? '#ef4444' : burnRate > 50 ? '#f97316' : '#22c55e';
                  const bgProgressColor = burnRate > 80 ? 'rgba(239, 68, 68, 0.1)' : burnRate > 50 ? 'rgba(249, 115, 22, 0.1)' : 'rgba(34, 197, 94, 0.1)';

                  return (
                    <div key={club.id} style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', borderBottom: '1px solid #f3f4f6', paddingBottom: '1rem' }}>
                      <div style={{ width: '40px', height: '40px', background: bgProgressColor, color: progressColor, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', fontSize: '1.1rem', flexShrink: 0 }}>
                        {index + 1}
                      </div>
                      <div style={{ flexGrow: 1 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                          <span style={{ fontWeight: 600, fontSize: '1.05rem' }}>{club.name}</span>
                          <span style={{ fontWeight: 'bold', color: progressColor }}>{t("admin.analysis.burn.spent", { rate: burnRate.toFixed(1) })}</span>
                        </div>
                        <div style={{ width: '100%', height: '10px', background: '#e5e7eb', borderRadius: '5px', overflow: 'hidden' }}>
                          <div style={{ width: `${Math.min(burnRate, 100)}%`, height: '100%', background: progressColor, transition: 'width 0.5s ease-out' }}></div>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '0.4rem' }}>
                          <span>{t("admin.analysis.burn.budget", { budget: club.budget.toLocaleString() })}</span>
                          <span>{t("admin.analysis.burn.spentAmount", { spent: club.spentBudget.toLocaleString(), remaining: club.remainingBudget.toLocaleString() })}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 3. 수상 내역 리스트 */}
          {analysisTab === "awards" && (
            <div className="glass-card">
              <h3 style={{ marginBottom: '1.5rem' }}>{t("admin.analysis.awardsTitle")}</h3>
              <div className="table-container">
                <table style={{ minWidth: '800px', width: '100%' }}>
                  <thead>
                    <tr>
                      <th style={{ width: '180px', whiteSpace: 'nowrap' }}>{t("admin.table.clubName")}</th>
                      <th style={{ minWidth: '220px', whiteSpace: 'nowrap' }}>{t("admin.analysis.table.contest")}</th>
                      <th style={{ width: '180px', whiteSpace: 'nowrap' }}>{t("admin.analysis.table.award")}</th>
                      <th style={{ width: '130px', whiteSpace: 'nowrap' }}>{t("admin.analysis.table.contestDate")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {awardsActivities.length === 0 ? (
                      <tr>
                        <td colSpan={4} style={{ textAlign: 'center', color: 'var(--text-secondary)', padding: '2rem' }}>{t("admin.analysis.emptyAwards")}</td>
                      </tr>
                    ) : (
                      awardsActivities.map(act => {
                        let contest = "-";
                        let award = "-";
                        let date = "-";
                        try {
                          const d = JSON.parse(act.description || "{}");
                          contest = d.contestName || "-";
                          award = d.award || "-";
                          date = d.date || "-";
                        } catch(e) {}

                        return (
                          <tr key={act.id}>
                            <td style={{ fontWeight: 600 }}>{act.club.name}</td>
                            <td style={{ fontWeight: 500 }}>{contest}</td>
                            <td>
                              <span className="badge" style={{ background: '#fef3c7', color: '#d97706', fontSize: '0.85rem', padding: '0.35rem 0.75rem', fontWeight: 'bold', border: '1px solid #f59e0b' }}>
                                🏆 {award}
                              </span>
                            </td>
                            <td style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{date}</td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

        {/* -------------------- TAB 4: 지원프로그램 관리 -------------------- */}
        <div style={{ display: activeTab === "programs" ? "block" : "none" }}>
          <SupportProgramManager 
            initialPrograms={programs} 
            availableSurveys={surveys} 
          />
        </div>

        {/* -------------------- TAB 5: 만족도 설문지 관리 -------------------- */}
        <div style={{ display: activeTab === "surveys" ? "block" : "none" }}>
          <SatisfactionSurveyManager 
            initialSurveys={surveys}
            onSurveysChange={setSurveys}
            availablePrograms={programs?.map((p: any) => ({ id: p.id, title: p.title })) || []}
          />
        </div>

        {/* -------------------- TAB 6: 수료증 생성 및 발급 -------------------- */}
        {activeTab === "certificates" && <CertificateGenerator clubs={clubs} />}
      </main>
    </div>

      {/* -------------------- ACTIVITY ADD MODAL -------------------- */}
      {isActivityModalOpen && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: '1.5rem' }}>
          <div className="glass-card" style={{ width: '100%', maxWidth: '550px', background: 'white', border: '1px solid #e5e7eb', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.15)', display: 'flex', flexDirection: 'column', maxHeight: '90vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #eee', paddingBottom: '1rem', marginBottom: '1.5rem' }}>
              <h3 style={{ margin: 0 }}>{t("admin.analysis.modal.title")}</h3>
              <button 
                onClick={() => setIsActivityModalOpen(false)}
                style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: 'var(--text-secondary)' }}
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleAddActivity} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {/* Select Club */}
              <div>
                <label style={{ display: 'block', fontSize: '0.9rem', fontWeight: 600, marginBottom: '0.4rem' }}>{t("admin.analysis.modal.club")}</label>
                <select 
                  className="input-field" 
                  value={selectedClubId} 
                  onChange={e => setSelectedClubId(e.target.value)}
                  required
                >
                  {clubs.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>

              {/* Select Type */}
              <div>
                <label style={{ display: 'block', fontSize: '0.9rem', fontWeight: 600, marginBottom: '0.4rem' }}>{t("admin.analysis.modal.type")}</label>
                <select 
                  className="input-field" 
                  value={actType} 
                  onChange={e => setActType(e.target.value)}
                  required
                >
                  <option value="창업교육">창업교육</option>
                  <option value="창업캠프">창업캠프</option>
                  <option value="창업경진대회">창업경진대회</option>
                  <option value="지식재산권">지식재산권</option>
                  <option value="시제품제작">시제품제작</option>
                  <option value="실제창업">실제창업</option>
                </select>
              </div>

              {/* Form components depending on type */}
              {actType === "창업교육" && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', background: '#f9fafb', padding: '1rem', borderRadius: '8px', border: '1px solid #eee' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>창업교육명</label>
                    <input type="text" placeholder="예: 비즈니스 모델 고도화" className="input-field" value={eduName} onChange={e => setEduName(e.target.value)} required />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>일시</label>
                    <input type="text" placeholder="예: 2026.04.10" className="input-field" value={eduDate} onChange={e => setEduDate(e.target.value)} />
                  </div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', fontSize: '0.85rem', fontWeight: 600 }}>
                    <input type="checkbox" checked={eduAttended} onChange={e => setEduAttended(e.target.checked)} />
                    교육 수료/참가 완료 여부
                  </label>
                </div>
              )}

              {actType === "창업캠프" && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', background: '#f9fafb', padding: '1rem', borderRadius: '8px', border: '1px solid #eee' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>창업캠프명</label>
                    <input type="text" placeholder="예: 유학생 RISE 창업스쿨 캠프" className="input-field" value={campName} onChange={e => setCampName(e.target.value)} required />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>일시</label>
                    <input type="text" placeholder="예: 2026.05.12" className="input-field" value={campDate} onChange={e => setCampDate(e.target.value)} />
                  </div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', fontSize: '0.85rem', fontWeight: 600 }}>
                    <input type="checkbox" checked={campAttended} onChange={e => setCampAttended(e.target.checked)} />
                    캠프 참가 완료 여부
                  </label>
                </div>
              )}

              {actType === "창업경진대회" && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', background: '#f9fafb', padding: '1rem', borderRadius: '8px', border: '1px solid #eee' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>경진대회명</label>
                    <input type="text" placeholder="예: RISE 전국 유학생 창업경진대회" className="input-field" value={contestName} onChange={e => setContestName(e.target.value)} required />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>일시</label>
                    <input type="text" placeholder="예: 2026.06.18" className="input-field" value={contestDate} onChange={e => setContestDate(e.target.value)} />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>수상 내역 (기록 가능)</label>
                    <input type="text" placeholder="예: 대상 / 최우수상 / 수상내역 없음" className="input-field" value={contestAward} onChange={e => setContestAward(e.target.value)} />
                  </div>
                </div>
              )}

              {actType === "지식재산권" && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', background: '#f9fafb', padding: '1rem', borderRadius: '8px', border: '1px solid #eee' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>특허 제목</label>
                    <input type="text" placeholder="예: 모바일 게임을 활용한 반려동물 훈련 모델" className="input-field" value={patentTitle} onChange={e => setPatentTitle(e.target.value)} />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>특허 상태</label>
                    <select className="input-field" value={patentStatus} onChange={e => setPatentStatus(e.target.value)}>
                      <option value="출원">출원</option>
                      <option value="등록">등록</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>디자인 등록명</label>
                    <input type="text" placeholder="예: 캐릭터 마스코트 디자인" className="input-field" value={designName} onChange={e => setDesignName(e.target.value)} />
                  </div>
                </div>
              )}

              {actType === "시제품제작" && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', background: '#f9fafb', padding: '1rem', borderRadius: '8px', border: '1px solid #eee' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>시제품 제작명</label>
                    <input type="text" placeholder="예: 반려견 훈련앱 MVP 모바일 페이지" className="input-field" value={protoName} onChange={e => setProtoName(e.target.value)} required />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>상태</label>
                    <select className="input-field" value={protoStatus} onChange={e => setProtoStatus(e.target.value)}>
                      <option value="진행중">진행중</option>
                      <option value="완료">완료</option>
                    </select>
                  </div>
                </div>
              )}

              {actType === "실제창업" && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', background: '#f9fafb', padding: '1rem', borderRadius: '8px', border: '1px solid #eee' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.3rem' }}>실제 창업 여부</label>
                    <select className="input-field" value={startupHope} onChange={e => setStartupHope(e.target.value)}>
                      <option value="희망">희망</option>
                      <option value="비희망">비희망</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Submit button */}
              <button 
                type="submit" 
                className="btn btn-primary"
                style={{ width: '100%', padding: '0.8rem', marginTop: '1rem' }}
              >
                {t("admin.analysis.modal.btnSubmit")}
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
