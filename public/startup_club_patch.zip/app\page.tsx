import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import LandingClient from "./LandingClient";

export default async function LandingPage() {
  const session = await getServerSession(authOptions);
  
  const stats = await prisma.club.aggregate({
    _count: { id: true },
    _sum: { personnelCount: true, budget: true }
  });

  return (
    <LandingClient
      session={session}
      stats={{
        count: stats._count.id || 0,
        students: stats._sum.personnelCount || 0
      }}
    />
  );
}
