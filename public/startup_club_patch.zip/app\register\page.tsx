import { prisma } from "@/lib/prisma";
import RegisterClient from "./RegisterClient";

export default async function RegisterPage() {
  const clubs = await prisma.club.findMany();

  return <RegisterClient clubs={clubs} />;
}
