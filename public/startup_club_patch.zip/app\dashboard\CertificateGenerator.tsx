"use client";

import { useState } from "react";

interface CertificateGeneratorProps {
  clubs: any[];
}

export default function CertificateGenerator({ clubs }: CertificateGeneratorProps) {
  const [selectedProgram, setSelectedProgram] = useState("2026 RISE 창업동아리 원스톱 상담창구");
  const [selectedClubId, setSelectedClubId] = useState(clubs[0]?.id || "");
  const [recipientName, setRecipientName] = useState("윤태수");
  const [certType, setCertType] = useState("창업동아리 수료증");
  const [certNo, setCertNo] = useState("DSU-2026-RISE-001");
  const [issueDate, setIssueDate] = useState("2026년 10월 30일");
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  const selectedClub = clubs.find(c => c.id === selectedClubId) || clubs[0];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2 style={{ fontSize: "1.5rem", fontWeight: 700, margin: 0, color: "#1e293b" }}>
          수료증 생성 및 발급
        </h2>
        <span style={{ fontSize: "0.85rem", color: "#64748b" }}>수료증 생성 관리</span>
      </div>

      {/* Generator Control Card */}
      <div style={{ background: "#ffffff", padding: "1.5rem", borderRadius: "12px", border: "1px solid #e2e8f0", boxShadow: "0 2px 8px rgba(0,0,0,0.02)" }}>
        <h3 style={{ fontSize: "1.1rem", fontWeight: 700, margin: "0 0 1.25rem 0", color: "#1e293b" }}>
          📜 수료증 발급 설정
        </h3>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "1.25rem", marginBottom: "1.5rem" }}>
          <div>
            <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, color: "#334155", marginBottom: "0.3rem" }}>
              지원프로그램 선택
            </label>
            <select
              value={selectedProgram}
              onChange={e => setSelectedProgram(e.target.value)}
              style={{ width: "100%", padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.9rem" }}
            >
              <option value="2026 RISE 창업동아리 원스톱 상담창구">2026 RISE 창업동아리 원스톱 상담창구</option>
              <option value="2026 글로벌 유학생 창업캠프">2026 글로벌 유학생 창업캠프</option>
              <option value="2026 창업경진대회">2026 창업경진대회</option>
            </select>
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, color: "#334155", marginBottom: "0.3rem" }}>
              대상 동아리 선택
            </label>
            <select
              value={selectedClubId}
              onChange={e => {
                setSelectedClubId(e.target.value);
                const club = clubs.find(c => c.id === e.target.value);
                if (club && club.users && club.users.length > 0) {
                  setRecipientName(club.users[0].name || "참여학생");
                }
              }}
              style={{ width: "100%", padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.9rem" }}
            >
              {clubs.map(c => (
                <option key={c.id} value={c.id}>{c.name} ({c.itemName || "미등록"})</option>
              ))}
            </select>
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, color: "#334155", marginBottom: "0.3rem" }}>
              수령인 (학생 성명)
            </label>
            <input
              type="text"
              value={recipientName}
              onChange={e => setRecipientName(e.target.value)}
              placeholder="학생 성명"
              style={{ width: "100%", padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.9rem" }}
            />
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, color: "#334155", marginBottom: "0.3rem" }}>
              증서 서식 종류
            </label>
            <select
              value={certType}
              onChange={e => setCertType(e.target.value)}
              style={{ width: "100%", padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.9rem" }}
            >
              <option value="창업동아리 수료증">창업동아리 수료증</option>
              <option value="창업캠프 이수증">창업캠프 이수증</option>
              <option value="우수 창업팀 상장">우수 창업팀 상장</option>
            </select>
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, color: "#334155", marginBottom: "0.3rem" }}>
              발급 번호
            </label>
            <input
              type="text"
              value={certNo}
              onChange={e => setCertNo(e.target.value)}
              style={{ width: "100%", padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.9rem" }}
            />
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, color: "#334155", marginBottom: "0.3rem" }}>
              발급 일자
            </label>
            <input
              type="text"
              value={issueDate}
              onChange={e => setIssueDate(e.target.value)}
              style={{ width: "100%", padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.9rem" }}
            />
          </div>
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", gap: "1rem" }}>
          <button
            onClick={() => setIsPrintModalOpen(true)}
            style={{ background: "#2563eb", color: "#ffffff", border: "none", padding: "0.75rem 1.75rem", borderRadius: "8px", fontWeight: 600, fontSize: "0.95rem", cursor: "pointer", display: "flex", alignItems: "center", gap: "0.5rem", boxShadow: "0 4px 12px rgba(37,99,235,0.2)" }}
          >
            🖨️ 수료증 미리보기 및 출력 / PDF 저장
          </button>
        </div>
      </div>

      {/* Real-time Certificate Canvas Preview (A4 Certificate Canvas) */}
      <div style={{ background: "#ffffff", padding: "2rem", borderRadius: "12px", border: "1px solid #e2e8f0", boxShadow: "0 2px 8px rgba(0,0,0,0.02)" }}>
        <h3 style={{ fontSize: "1.1rem", fontWeight: 700, margin: "0 0 1.5rem 0", color: "#1e293b" }}>
          👁️ 실시간 발급 미리보기
        </h3>

        <div style={{ display: "flex", justifyContent: "center" }}>
          <div
            style={{
              width: "700px",
              height: "980px",
              border: "12px double #1e3a8a",
              padding: "3rem",
              boxSizing: "border-box",
              background: "#fafafa",
              position: "relative",
              fontFamily: "'Inter', 'serif', sans-serif",
              boxShadow: "0 10px 25px rgba(0,0,0,0.1)",
              textAlign: "center",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between"
            }}
          >
            {/* Certificate Header */}
            <div>
              <div style={{ fontSize: "0.9rem", color: "#64748b", textAlign: "left", fontWeight: 600 }}>
                제 {certNo} 호
              </div>
              <h1 style={{ fontSize: "3rem", fontWeight: 900, color: "#1e3a8a", letterSpacing: "8px", margin: "2rem 0 1rem 0" }}>
                {certType}
              </h1>
              <div style={{ width: "100px", height: "3px", background: "#1e3a8a", margin: "0 auto 2rem" }}></div>
            </div>

            {/* Recipient Details */}
            <div style={{ textAlign: "left", padding: "0 2rem", fontSize: "1.1rem", lineHeight: 2.2, color: "#1e293b" }}>
              <p><strong>성 명:</strong> {recipientName} 학생</p>
              <p><strong>소속 동아리:</strong> {selectedClub?.name || "동아리"} ({selectedClub?.itemName || "창업아이템"})</p>
              <p><strong>참여 프로그램:</strong> {selectedProgram}</p>
            </div>

            {/* Main Statement */}
            <div style={{ fontSize: "1.2rem", lineHeight: 2.2, color: "#1e293b", margin: "2rem 0" }}>
              위 학생은 동서대학교 RISE 창업지원단에서 주관하는<br />
              <strong>[{selectedProgram}]</strong> 과정을 성실히 완료하였으므로<br />
              이 수료증을 수여합니다.
            </div>

            {/* Footer Date & Sign */}
            <div style={{ marginBottom: "1rem" }}>
              <div style={{ fontSize: "1.25rem", fontWeight: 700, color: "#334155", marginBottom: "2.5rem" }}>
                {issueDate}
              </div>

              <div style={{ position: "relative", display: "inline-block" }}>
                <h2 style={{ fontSize: "1.8rem", fontWeight: 900, color: "#0f172a", margin: 0 }}>
                  동서대학교 RISE 창업지원단장
                </h2>
                <div
                  style={{
                    position: "absolute",
                    right: "-50px",
                    top: "-20px",
                    width: "80px",
                    height: "80px",
                    borderRadius: "50%",
                    border: "3px solid #ef4444",
                    color: "#ef4444",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontWeight: 900,
                    fontSize: "0.85rem",
                    transform: "rotate(-15deg)",
                    background: "rgba(239, 68, 68, 0.05)"
                  }}
                >
                  직인생략
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Print Modal Overlay */}
      {isPrintModalOpen && (
        <div style={{ position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh", background: "rgba(0, 0, 0, 0.7)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 2000, padding: "1rem" }}>
          <div style={{ background: "#ffffff", padding: "2rem", borderRadius: "12px", maxWidth: "800px", width: "100%", maxHeight: "95vh", overflowY: "auto", textAlign: "center" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.5rem" }}>
              <h3 style={{ margin: 0, fontSize: "1.25rem" }}>수료증 인쇄 및 저장</h3>
              <button onClick={() => setIsPrintModalOpen(false)} style={{ background: "none", border: "none", fontSize: "1.5rem", cursor: "pointer" }}>✕</button>
            </div>

            <p style={{ color: "#64748b", marginBottom: "1.5rem" }}>
              '인쇄하기' 버튼을 누르면 브라우저 인쇄 창이 열려 PDF 저장이 가능합니다.
            </p>

            <button
              onClick={handlePrint}
              style={{ background: "#2563eb", color: "#fff", border: "none", padding: "0.75rem 2rem", borderRadius: "8px", fontWeight: 700, fontSize: "1rem", cursor: "pointer" }}
            >
              🖨️ 인쇄하기 (PDF 저장)
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
