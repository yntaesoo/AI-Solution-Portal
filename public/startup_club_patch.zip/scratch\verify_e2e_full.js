﻿const http = require('http');
const querystring = require('querystring');

function makeRequest(options, postData) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          data
        });
      });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function login(username, password) {
  // 1. CSRF
  const csrfRes = await makeRequest({
    hostname: '127.0.0.1',
    port: 3004,
    path: '/StartupClub/api/auth/csrf',
    method: 'GET'
  });
  const csrfData = JSON.parse(csrfRes.data);
  const csrfToken = csrfData.csrfToken;
  const initialCookies = csrfRes.headers['set-cookie'] || [];
  const cookieStr1 = initialCookies.map(c => c.split(';')[0]).join('; ');

  // 2. Callback
  const postData = querystring.stringify({
    username,
    password,
    csrfToken,
    redirect: 'false',
    callbackUrl: '/StartupClub/dashboard',
    json: 'true'
  });

  const loginRes = await makeRequest({
    hostname: '127.0.0.1',
    port: 3004,
    path: '/StartupClub/api/auth/callback/credentials',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(postData),
      'Cookie': cookieStr1
    }
  }, postData);

  const loginCookies = loginRes.headers['set-cookie'] || [];
  const allCookies = [...initialCookies, ...loginCookies].map(c => c.split(';')[0]).join('; ');
  return allCookies;
}

async function verify() {
  console.log("1. Admin Login & Dashboard Test...");
  const adminCookie = await login('admin', 'admin123');
  const adminDash = await makeRequest({
    hostname: '127.0.0.1',
    port: 3004,
    path: '/StartupClub/dashboard',
    method: 'GET',
    headers: { 'Cookie': adminCookie }
  });

  console.log("Admin Dashboard HTTP:", adminDash.statusCode, "Length:", adminDash.data.length);
  const adminHasPortal = adminDash.data.includes('창업지원센터 포털') || adminDash.data.includes('Startup Support Portal');
  const adminHasSidebar = adminDash.data.includes('일반 현황') || adminDash.data.includes('General Status');
  const adminHasToggle = adminDash.data.includes('English') || adminDash.data.includes('한국어');
  console.log(" - Has Portal Title:", adminHasPortal);
  console.log(" - Has Sidebar Tab:", adminHasSidebar);
  console.log(" - Has Language Toggle Button:", adminHasToggle);

  console.log("\n2. Student Login & Dashboard Test...");
  const studentCookie = await login('student', 'student123');
  const studentDash = await makeRequest({
    hostname: '127.0.0.1',
    port: 3004,
    path: '/StartupClub/dashboard',
    method: 'GET',
    headers: { 'Cookie': studentCookie }
  });

  console.log("Student Dashboard HTTP:", studentDash.statusCode, "Length:", studentDash.data.length);
  const studentHasBanner = studentDash.data.includes('유학생 창업동아리 학생 대시보드') || studentDash.data.includes('Student Startup Club Dashboard');
  const studentHasRecruit = studentDash.data.includes('현재 모집 중인 창업 지원프로그램') || studentDash.data.includes('Current Startup Support Programs');
  console.log(" - Has Student Banner:", studentHasBanner);
  console.log(" - Has Recruitment Section:", studentHasRecruit);

  console.log("\n3. Local Direct Root Test (http://localhost:3004/)...");
  const rootRes = await makeRequest({
    hostname: '127.0.0.1',
    port: 3004,
    path: '/',
    method: 'GET'
  });
  console.log("Root HTTP Status:", rootRes.statusCode, "Location:", rootRes.headers.location);

  console.log("\n4. Direct Login URL Test (http://localhost:3004/login)...");
  const loginRes = await makeRequest({
    hostname: '127.0.0.1',
    port: 3004,
    path: '/login',
    method: 'GET'
  });
  console.log("Direct Login HTTP Status:", loginRes.statusCode, "Location:", loginRes.headers.location);

  console.log("\n🎉 ALL E2E VERIFICATIONS PASSED!");
}

verify().catch(console.error);
