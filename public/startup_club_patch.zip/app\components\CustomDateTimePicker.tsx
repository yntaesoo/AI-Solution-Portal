"use client";

import React, { useState, useRef, useEffect } from "react";

interface CustomDateTimePickerProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  label?: string;
  required?: boolean;
}

export default function CustomDateTimePicker({
  value,
  onChange,
  placeholder = "YYYY-MM-DD HH:mm:ss",
  label,
  required = false
}: CustomDateTimePickerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Parse existing datetime or default
  const parseDateTime = (str: string) => {
    const defaultDate = new Date(2026, 4, 1, 0, 0, 0); // Default May 1, 2026
    if (!str) return { year: 2026, month: 4, day: 1, hours: "00", minutes: "00", seconds: "00" };

    const parts = str.trim().split(" ");
    const dateParts = parts[0] ? parts[0].split("-") : [];
    const timeParts = parts[1] ? parts[1].split(":") : ["00", "00", "00"];

    const year = parseInt(dateParts[0], 10) || 2026;
    const month = (parseInt(dateParts[1], 10) || 5) - 1; // 0-indexed
    const day = parseInt(dateParts[2], 10) || 1;

    const hours = (timeParts[0] || "00").padStart(2, "0");
    const minutes = (timeParts[1] || "00").padStart(2, "0");
    const seconds = (timeParts[2] || "00").padStart(2, "0");

    return { year, month, day, hours, minutes, seconds };
  };

  const parsed = parseDateTime(value);
  const [viewYear, setViewYear] = useState(parsed.year);
  const [viewMonth, setViewMonth] = useState(parsed.month); // 0-indexed
  const [selYear, setSelYear] = useState(parsed.year);
  const [selMonth, setSelMonth] = useState(parsed.month);
  const [selDay, setSelDay] = useState(parsed.day);
  const [hours, setHours] = useState(parsed.hours);
  const [minutes, setMinutes] = useState(parsed.minutes);
  const [seconds, setSeconds] = useState(parsed.seconds);
  const [showTimePicker, setShowTimePicker] = useState(false);

  // Sync internal state when value prop changes externally
  useEffect(() => {
    const p = parseDateTime(value);
    setViewYear(p.year);
    setViewMonth(p.month);
    setSelYear(p.year);
    setSelMonth(p.month);
    setSelDay(p.day);
    setHours(p.hours);
    setMinutes(p.minutes);
    setSeconds(p.seconds);
  }, [value]);

  // Close popover when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handlePrevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear(prev => prev - 1);
    } else {
      setViewMonth(prev => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear(prev => prev + 1);
    } else {
      setViewMonth(prev => prev + 1);
    }
  };

  const handleSelectDay = (y: number, m: number, d: number) => {
    setSelYear(y);
    setSelMonth(m);
    setSelDay(d);
  };

  const formattedSelected = `${selYear}-${String(selMonth + 1).padStart(2, "0")}-${String(selDay).padStart(2, "0")} ${hours}:${minutes}:${seconds}`;

  const handleConfirm = () => {
    onChange(formattedSelected);
    setIsOpen(false);
  };

  // Calendar Calculation
  const firstDayOfWeek = new Date(viewYear, viewMonth, 1).getDay(); // 0 = Sun
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  const prevMonthDays = new Date(viewYear, viewMonth, 0).getDate();

  const calendarDays: Array<{ year: number; month: number; day: number; isCurrentMonth: boolean }> = [];

  // Prev month trailing days
  for (let i = firstDayOfWeek - 1; i >= 0; i--) {
    const pMonth = viewMonth === 0 ? 11 : viewMonth - 1;
    const pYear = viewMonth === 0 ? viewYear - 1 : viewYear;
    calendarDays.push({
      year: pYear,
      month: pMonth,
      day: prevMonthDays - i,
      isCurrentMonth: false
    });
  }

  // Current month days
  for (let d = 1; d <= daysInMonth; d++) {
    calendarDays.push({
      year: viewYear,
      month: viewMonth,
      day: d,
      isCurrentMonth: true
    });
  }

  // Next month leading days (fill up to 35 or 42 cells)
  const totalCells = calendarDays.length > 35 ? 42 : 35;
  const remaining = totalCells - calendarDays.length;
  for (let d = 1; d <= remaining; d++) {
    const nMonth = viewMonth === 11 ? 0 : viewMonth + 1;
    const nYear = viewMonth === 11 ? viewYear + 1 : viewYear;
    calendarDays.push({
      year: nYear,
      month: nMonth,
      day: d,
      isCurrentMonth: false
    });
  }

  return (
    <div ref={containerRef} style={{ position: "relative", width: "100%" }}>
      {label && (
        <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, marginBottom: "0.3rem", color: "#334155" }}>
          {label} {required && <span style={{ color: "#ef4444" }}>*</span>}
        </label>
      )}

      {/* Input Field with Calendar Icon */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        style={{
          display: "flex",
          alignItems: "center",
          gap: "0.5rem",
          background: "#ffffff",
          border: isOpen ? "2px solid #2563eb" : "1px solid #cbd5e1",
          borderRadius: "6px",
          padding: "0.55rem 0.75rem",
          cursor: "pointer",
          boxShadow: isOpen ? "0 0 0 3px rgba(37,99,235,0.15)" : "none",
          transition: "all 0.15s ease"
        }}
      >
        <span style={{ fontSize: "1rem", color: "#64748b" }}>📅</span>
        <input
          type="text"
          readOnly
          value={value || ""}
          placeholder={placeholder}
          style={{
            border: "none",
            outline: "none",
            width: "100%",
            fontSize: "0.85rem",
            color: "#1e293b",
            background: "transparent",
            cursor: "pointer",
            fontWeight: 500
          }}
        />
      </div>

      {/* Popover Calendar Modal (Matching Screenshot Exactly) */}
      {isOpen && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 8px)",
            left: 0,
            zIndex: 1500,
            width: "310px",
            background: "#ffffff",
            borderRadius: "12px",
            boxShadow: "0 10px 25px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.08)",
            border: "1px solid #e2e8f0",
            padding: "1.25rem 1rem 1rem 1rem",
            fontFamily: "Inter, system-ui, sans-serif"
          }}
        >
          {/* Top Triangle Pointer Arrow */}
          <div
            style={{
              position: "absolute",
              top: "-6px",
              left: "24px",
              width: "12px",
              height: "12px",
              background: "#ffffff",
              borderTop: "1px solid #cbd5e1",
              borderLeft: "1px solid #cbd5e1",
              transform: "rotate(45deg)"
            }}
          />

          {/* Month/Year Header */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem", padding: "0 0.5rem" }}>
            <button
              type="button"
              onClick={handlePrevMonth}
              style={{ background: "none", border: "none", fontSize: "1.1rem", color: "#64748b", cursor: "pointer", padding: "0.2rem 0.5rem" }}
            >
              ❮
            </button>
            <span style={{ fontWeight: 700, fontSize: "1rem", color: "#1e293b" }}>
              {viewMonth + 1}월 &nbsp;&nbsp;&nbsp;&nbsp; {viewYear}
            </span>
            <button
              type="button"
              onClick={handleNextMonth}
              style={{ background: "none", border: "none", fontSize: "1.1rem", color: "#64748b", cursor: "pointer", padding: "0.2rem 0.5rem" }}
            >
              ❯
            </button>
          </div>

          {/* Day of Week Header */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", textAlign: "center", fontWeight: 700, fontSize: "0.85rem", marginBottom: "0.5rem" }}>
            <span style={{ color: "#ef4444" }}>일</span>
            <span style={{ color: "#334155" }}>월</span>
            <span style={{ color: "#334155" }}>화</span>
            <span style={{ color: "#334155" }}>수</span>
            <span style={{ color: "#334155" }}>목</span>
            <span style={{ color: "#334155" }}>금</span>
            <span style={{ color: "#2563eb" }}>토</span>
          </div>

          {/* Days Grid */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: "0.2rem", textAlign: "center", fontSize: "0.85rem", marginBottom: "1rem" }}>
            {calendarDays.map((item, idx) => {
              const isSelected =
                item.year === selYear && item.month === selMonth && item.day === selDay;

              return (
                <div
                  key={idx}
                  onClick={() => handleSelectDay(item.year, item.month, item.day)}
                  style={{
                    height: "36px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    borderRadius: "8px",
                    cursor: "pointer",
                    fontWeight: isSelected ? 700 : 400,
                    background: isSelected ? "#2563eb" : "transparent",
                    color: isSelected
                      ? "#ffffff"
                      : item.isCurrentMonth
                      ? "#1e293b"
                      : "#cbd5e1",
                    transition: "all 0.1s ease"
                  }}
                >
                  {item.day}
                </div>
              );
            })}
          </div>

          {/* Time Picker Bar / Clock Selector */}
          {showTimePicker && (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "0.5rem", background: "#f8fafc", padding: "0.5rem", borderRadius: "8px", marginBottom: "0.75rem", border: "1px solid #e2e8f0" }}>
              <span style={{ fontSize: "0.8rem", color: "#64748b", fontWeight: 600 }}>시간:</span>
              <input
                type="number"
                min="0"
                max="23"
                value={hours}
                onChange={e => setHours(e.target.value.padStart(2, "0"))}
                style={{ width: "45px", padding: "0.2rem", textAlign: "center", border: "1px solid #cbd5e1", borderRadius: "4px", fontSize: "0.85rem" }}
              />
              :
              <input
                type="number"
                min="0"
                max="59"
                value={minutes}
                onChange={e => setMinutes(e.target.value.padStart(2, "0"))}
                style={{ width: "45px", padding: "0.2rem", textAlign: "center", border: "1px solid #cbd5e1", borderRadius: "4px", fontSize: "0.85rem" }}
              />
              :
              <input
                type="number"
                min="0"
                max="59"
                value={seconds}
                onChange={e => setSeconds(e.target.value.padStart(2, "0"))}
                style={{ width: "45px", padding: "0.2rem", textAlign: "center", border: "1px solid #cbd5e1", borderRadius: "4px", fontSize: "0.85rem" }}
              />
            </div>
          )}

          {/* Footer Control Bar (Matching Screenshot bottom row) */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: "1px solid #f1f5f9", paddingTop: "0.75rem" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}>
              <button
                type="button"
                onClick={() => setShowTimePicker(!showTimePicker)}
                style={{ background: "none", border: "none", fontSize: "1.1rem", cursor: "pointer", color: showTimePicker ? "#2563eb" : "#64748b", padding: "0" }}
                title="시간 설정"
              >
                🕒
              </button>
              <span style={{ fontSize: "0.75rem", color: "#475569", fontWeight: 600 }}>
                {formattedSelected}
              </span>
            </div>

            <div style={{ display: "flex", gap: "0.4rem" }}>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                style={{
                  background: "#f1f5f9",
                  border: "1px solid #cbd5e1",
                  color: "#475569",
                  padding: "0.35rem 0.75rem",
                  borderRadius: "6px",
                  fontSize: "0.8rem",
                  fontWeight: 600,
                  cursor: "pointer"
                }}
              >
                취소
              </button>
              <button
                type="button"
                onClick={handleConfirm}
                style={{
                  background: "#2563eb",
                  border: "none",
                  color: "#ffffff",
                  padding: "0.35rem 0.85rem",
                  borderRadius: "6px",
                  fontSize: "0.8rem",
                  fontWeight: 600,
                  cursor: "pointer"
                }}
              >
                확인
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
