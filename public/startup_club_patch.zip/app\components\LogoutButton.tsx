"use client";

export default function LogoutButton() {
  const handleLogout = async () => {
    try {
      // 1. Call custom signout API to invalidate all session cookies
      await fetch("/StartupClub/api/logout", { method: "POST" });
    } catch (err) {
      console.error("Logout API error:", err);
    } finally {
      // 2. Clear non-httpOnly cookies on client if any
      try {
        document.cookie.split(";").forEach((c) => {
          document.cookie = c
            .replace(/^ +/, "")
            .replace(/=.*/, "=;expires=" + new Date(0).toUTCString() + ";path=/");
          document.cookie = c
            .replace(/^ +/, "")
            .replace(/=.*/, "=;expires=" + new Date(0).toUTCString() + ";path=/StartupClub");
        });
      } catch (e) {
        console.error("Client cookie clear error:", e);
      }

      // 3. Force hard browser redirect to login
      window.location.href = "/StartupClub/login";
    }
  };

  return (
    <button
      type="button"
      onClick={handleLogout}
      className="btn"
      style={{
        background: '#f3f4f6',
        cursor: 'pointer',
        padding: '0.5rem 1rem',
        borderRadius: '6px',
        border: '1px solid #d1d5db',
        fontSize: '0.875rem'
      }}
    >
      로그아웃
    </button>
  );
}
