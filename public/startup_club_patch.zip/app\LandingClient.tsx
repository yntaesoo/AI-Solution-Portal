"use client";

import Link from "next/link";
import { useLanguage } from "@/lib/i18n/LanguageContext";

interface LandingClientProps {
  session: any;
  stats: {
    count: number;
    students: number;
  };
}

export default function LandingClient({ session, stats }: LandingClientProps) {
  const { t } = useLanguage();

  return (
    <div style={{ paddingBottom: '4rem' }}>
      {/* Hero Section */}
      <section style={{ textAlign: 'center', padding: '6rem 1rem', background: 'linear-gradient(135deg, rgba(79, 70, 229, 0.1) 0%, rgba(255, 255, 255, 0) 100%)', borderRadius: '0 0 40px 40px', marginBottom: '4rem' }}>
        <p style={{ color: 'var(--primary)', fontWeight: 'bold', letterSpacing: '2px', marginBottom: '1rem', fontSize: '0.875rem' }}>
          {t("landing.badge")}
        </p>
        <h1 style={{ fontSize: '3.5rem', fontWeight: 800, color: 'var(--navy)', marginBottom: '1.5rem', lineHeight: 1.2 }}>
          {t("landing.hero.title1")}<br />
          <em style={{ fontStyle: 'normal', color: 'var(--primary)' }}>{t("landing.hero.title2")}</em>
        </h1>
        <p style={{ fontSize: '1.25rem', color: 'var(--text-secondary)', marginBottom: '2.5rem', maxWidth: '600px', margin: '0 auto 2.5rem' }}>
          {t("landing.hero.desc1")}<br />
          {t("landing.hero.desc2")}
        </p>
        <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
          {session ? (
            <Link
              href="/dashboard"
              className="btn btn-primary"
              style={{ padding: '1rem 2rem', fontSize: '1.125rem', display: 'inline-flex', alignItems: 'center', textDecoration: 'none' }}
            >
              {t("landing.btn.dashboard")}
            </Link>
          ) : (
            <>
              <Link
                href="/register"
                className="btn btn-primary"
                style={{ padding: '1rem 2rem', fontSize: '1.125rem', borderRadius: '30px', display: 'inline-flex', alignItems: 'center', textDecoration: 'none' }}
              >
                {t("landing.btn.register")}
              </Link>
              <Link
                href="/login"
                className="btn"
                style={{ padding: '1rem 2rem', fontSize: '1.125rem', background: '#fff', border: '1px solid #e5e7eb', borderRadius: '30px', display: 'inline-flex', alignItems: 'center', textDecoration: 'none' }}
              >
                {t("landing.btn.login")}
              </Link>
            </>
          )}
        </div>

        {/* Stats */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '3rem', marginTop: '4rem', padding: '2rem', background: 'rgba(255,255,255,0.8)', backdropFilter: 'blur(10px)', borderRadius: '20px', maxWidth: '800px', margin: '4rem auto 0', border: '1px solid rgba(255,255,255,0.5)', boxShadow: '0 10px 30px rgba(0,0,0,0.05)' }}>
          <div>
            <div style={{ fontSize: '2rem', fontWeight: 800, color: 'var(--navy)' }}>
              {stats.count || 0}{t("landing.unit.count")}
            </div>
            <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
              {t("landing.stat.clubs")}
            </div>
          </div>
          <div>
            <div style={{ fontSize: '2rem', fontWeight: 800, color: 'var(--navy)' }}>
              {stats.students || 0}{t("landing.unit.person")}
            </div>
            <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
              {t("landing.stat.students")}
            </div>
          </div>
          <div>
            <div style={{ fontSize: '2rem', fontWeight: 800, color: 'var(--primary)' }}>4.9/5.0</div>
            <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
              {t("landing.stat.satisfaction")}
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section style={{ maxWidth: '1000px', margin: '0 auto', padding: '0 1.5rem' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', fontWeight: 'bold', letterSpacing: '1px' }}>
            {t("landing.how.subtitle")}
          </p>
          <h2 style={{ fontSize: '2rem', color: 'var(--navy)' }}>
            {t("landing.how.title")}
          </h2>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
          {[
            { step: '01', title: t("landing.how.step1.title"), desc: t("landing.how.step1.desc") },
            { step: '02', title: t("landing.how.step2.title"), desc: t("landing.how.step2.desc") },
            { step: '03', title: t("landing.how.step3.title"), desc: t("landing.how.step3.desc") },
            { step: '04', title: t("landing.how.step4.title"), desc: t("landing.how.step4.desc") }
          ].map((item, i) => (
            <div key={i} className="glass-card" style={{ position: 'relative', overflow: 'hidden' }}>
              <div style={{ fontSize: '3rem', fontWeight: 900, color: 'rgba(79, 70, 229, 0.1)', position: 'absolute', top: '1rem', right: '1rem' }}>
                {item.step}
              </div>
              <h3 style={{ fontSize: '1.25rem', marginTop: '2rem', marginBottom: '1rem', color: 'var(--navy)' }}>{item.title}</h3>
              <p style={{ color: 'var(--text-secondary)', lineHeight: 1.6, fontSize: '0.95rem' }}>
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
