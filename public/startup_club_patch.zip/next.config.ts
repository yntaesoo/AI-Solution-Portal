import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  basePath: '/StartupClub',
  allowedDevOrigins: ['portal.arfab.kr', 'club.arfab.kr', 'startupclub.arfab.kr', 'localhost:3004'],
  async redirects() {
    return [
      {
        source: '/',
        destination: '/StartupClub',
        basePath: false,
        permanent: false,
      },
    ];
  },
};

export default nextConfig;
