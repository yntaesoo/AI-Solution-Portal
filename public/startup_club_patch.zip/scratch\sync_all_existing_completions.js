const { PrismaClient } = require('@prisma/client');
const { PrismaBetterSqlite3 } = require('@prisma/adapter-better-sqlite3');
const adapter = new PrismaBetterSqlite3({ url: "file:./dev.db" });
const prisma = new PrismaClient({ adapter });

async function main() {
  console.log('--- SYNCING ALL COMPLETED PROGRAM APPLICATIONS TO CLUB ACTIVITIES ---');

  const completedApps = await prisma.programApplication.findMany({
    where: { status: '이수' },
    include: { user: true, program: true }
  });

  console.log(`Found ${completedApps.length} completed applications:`);

  for (const app of completedApps) {
    console.log(`- App [${app.id}] User: ${app.user.name} (${app.user.username}), Prog: ${app.program.title}, Club: ${app.user.clubId}`);
    if (!app.user.clubId) {
      console.log(`  WARNING: User ${app.user.name} has no clubId!`);
      continue;
    }

    const clubId = app.user.clubId;
    const progTitle = app.program.title;

    let actType = "창업교육";
    if (progTitle.includes("캠프")) actType = "창업캠프";
    else if (progTitle.includes("경진대회") || progTitle.includes("Festival")) actType = "창업경진대회";

    const descriptionData = JSON.stringify({
      programId: app.programId,
      applicationId: app.id,
      name: progTitle,
      studentName: app.user.name,
      date: app.program.operateEndDate || new Date().toISOString().split("T")[0],
      autoSynced: true
    });

    const existingAct = await prisma.activity.findFirst({
      where: {
        clubId: clubId,
        description: { contains: app.programId }
      }
    });

    if (existingAct) {
      await prisma.activity.update({
        where: { id: existingAct.id },
        data: {
          type: actType,
          status: "완료",
          description: descriptionData
        }
      });
      console.log(`  Updated existing activity [${existingAct.id}] for ${actType}`);
    } else {
      const newAct = await prisma.activity.create({
        data: {
          clubId: clubId,
          type: actType,
          status: "완료",
          description: descriptionData,
          date: new Date()
        }
      });
      console.log(`  Created NEW activity [${newAct.id}] for ${actType}`);
    }
  }

  const allActs = await prisma.activity.findMany({ include: { club: true } });
  console.log('\n--- ALL DB ACTIVITIES AFTER SYNC ---');
  allActs.forEach(a => {
    console.log(`Act ID: ${a.id} | Club: ${a.club.name} | Type: ${a.type} | Status: ${a.status} | Desc: ${a.description}`);
  });
}

main().catch(console.error).finally(() => prisma.$disconnect());
