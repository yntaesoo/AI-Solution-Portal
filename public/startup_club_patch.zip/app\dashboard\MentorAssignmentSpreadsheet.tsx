"use client";

import { useState } from "react";
import { updateMentorAssignments } from "@/app/actions";

export default function MentorAssignmentSpreadsheet({ 
  initialMentors, 
  clubs 
}: { 
  initialMentors: any[]; 
  clubs: any[]; 
}) {
  const [mentors, setMentors] = useState(
    initialMentors.map(m => ({
      ...m,
      assignedClubIds: m.mentorAssignments ? m.mentorAssignments.map((a: any) => a.clubId) : []
    }))
  );
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [openMentorIndex, setOpenMentorIndex] = useState<number | null>(null);

  const handleMentorClubToggle = (index: number, clubId: string) => {
    const updated = [...mentors];
    const current = updated[index].assignedClubIds || [];
    if (current.includes(clubId)) {
      updated[index].assignedClubIds = current.filter((id: string) => id !== clubId);
    } else {
      updated[index].assignedClubIds = [...current, clubId];
    }
    setMentors(updated);
  };

  const handleSave = async () => {
    setIsSaving(true);
    setMessage("");
    try {
      await updateMentorAssignments(mentors);
      setMessage("멘토별 담당 동아리 배정이 저장되었습니다.");
    } catch (e) {
      setMessage("저장에 실패했습니다.");
    } finally {
      setIsSaving(false);
      setTimeout(() => setMessage(""), 3000);
    }
  };

  return (
    <div className="glass-card" style={{ marginTop: '2rem', marginBottom: '4rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
        <h2>멘토별 담당 동아리 배정 관리 (스프레드시트)</h2>
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
          {message && <span style={{ color: 'var(--primary)', fontWeight: 'bold', fontSize: '0.9rem' }}>{message}</span>}
          <button 
            onClick={handleSave} 
            disabled={isSaving} 
            className="btn btn-primary"
            style={{ padding: '0.6rem 1.2rem' }}
          >
            {isSaving ? "저장 중..." : "배정 변경사항 저장"}
          </button>
        </div>
      </div>

      <div style={{ 
        maxHeight: '650px', 
        minHeight: '350px', 
        overflowY: 'auto', 
        overflowX: 'auto', 
        border: '1px solid #e5e7eb', 
        borderRadius: '8px',
        background: '#fff',
        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)'
      }}>
        <table style={{ minWidth: '800px', borderCollapse: 'separate', borderSpacing: 0, width: '100%' }}>
          <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
            <tr>
              {[
                "멘토 아이디 (Username)", "멘토 성명 (이름)", "담당 동아리 지정 (다중 배정)"
              ].map((header, idx) => (
                <th 
                  key={idx} 
                  style={{ 
                    background: '#f9fafb', 
                    color: '#374151', 
                    fontWeight: 600, 
                    padding: '0.75rem', 
                    borderBottom: '2px solid #e5e7eb', 
                    borderRight: '1px solid #e5e7eb', 
                    textAlign: 'left',
                    fontSize: '0.875rem',
                    whiteSpace: 'nowrap'
                  }}
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {mentors.map((mentor, i) => {
              const cellStyle = { 
                borderBottom: '1px solid #e5e7eb', 
                borderRight: '1px solid #e5e7eb',
                padding: 0,
                background: '#fff',
                position: 'relative' as const
              };

              return (
                <tr key={mentor.id} style={{ transition: 'background-color 0.1s' }} onMouseEnter={e => e.currentTarget.style.backgroundColor = '#f9fafb'} onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}>
                  <td style={{ ...cellStyle, padding: '0.6rem 0.8rem', fontSize: '0.875rem', whiteSpace: 'nowrap' }}>
                    {mentor.username}
                  </td>
                  <td style={{ ...cellStyle, fontWeight: 'bold', padding: '0.6rem 0.8rem', fontSize: '0.875rem', whiteSpace: 'nowrap' }}>
                    {mentor.name}
                  </td>
                  <td style={cellStyle}>
                    <div style={{ position: 'relative', padding: '0.3rem 0.8rem' }}>
                      <button 
                        type="button" 
                        onClick={() => setOpenMentorIndex(openMentorIndex === i ? null : i)}
                        className="btn"
                        style={{ padding: '0.4rem 0.8rem', background: '#f3f4f6', border: '1px solid #d1d5db', fontSize: '0.825rem', borderRadius: '4px', cursor: 'pointer', display: 'inline-flex', justifyContent: 'space-between', alignItems: 'center', width: '100%', minWidth: '220px' }}
                      >
                        <span>배정 동아리 ({(mentor.assignedClubIds || []).length}개)</span>
                        <span style={{ marginLeft: '0.5rem', fontSize: '0.75rem' }}>▼</span>
                      </button>
                      {openMentorIndex === i && (
                        <div style={{ position: 'absolute', top: '100%', left: '8px', zIndex: 100, background: '#fff', border: '1px solid #e5e7eb', borderRadius: '6px', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -2px rgba(0,0,0,0.05)', padding: '0.75rem', width: '300px', maxHeight: '350px', overflowY: 'auto' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontWeight: 600, fontSize: '0.8rem', color: '#4b5563', marginBottom: '0.5rem', borderBottom: '1px solid #f3f4f6', paddingBottom: '0.3rem' }}>
                            <span>동아리 다중 배정</span>
                            <button type="button" onClick={() => setOpenMentorIndex(null)} style={{ background: 'none', border: 'none', color: '#9ca3af', cursor: 'pointer', fontWeight: 'bold' }}>×</button>
                          </div>
                          {clubs.map(c => {
                            const isChecked = (mentor.assignedClubIds || []).includes(c.id);
                            return (
                              <label key={c.id} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.3rem 0', cursor: 'pointer', fontSize: '0.85rem', borderBottom: '1px solid #f9fafb' }}>
                                <input 
                                  type="checkbox" 
                                  checked={isChecked}
                                  onChange={() => handleMentorClubToggle(i, c.id)}
                                />
                                <span>{c.name}</span>
                              </label>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
            {mentors.length === 0 && (
              <tr>
                <td colSpan={3} style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>가입된 멘토 회원이 없습니다.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
