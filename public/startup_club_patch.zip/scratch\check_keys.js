﻿const { translations } = require('./lib/i18n/translations.ts');
