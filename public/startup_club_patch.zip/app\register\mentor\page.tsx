import { prisma } from "@/lib/prisma";
import MentorRegisterClient from "./MentorRegisterClient";

export default async function MentorRegisterPage() {
  const clubs = await prisma.club.findMany();

  return <MentorRegisterClient clubs={clubs} />;
}
