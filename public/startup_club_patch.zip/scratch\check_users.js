﻿const Database = require('better-sqlite3');
const db = new Database('./dev.db');
const users = db.prepare('SELECT id, username, role, clubId FROM User').all();
console.log('Users in DB:', users);
