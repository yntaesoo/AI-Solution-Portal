"use client";

import { useState } from "react";
import { addMentorLog } from "@/app/actions";

interface MentorLog {
  id: string;
  mentor: {
    name: string;
  };
  content: string;
  sessionNumber: string | null;
  consultationDate: string | null;
  menteeNames: string | null;
  nextSteps: string | null;
  createdAt: Date | string;
}

export default function MentorLogSection({ 
  clubId, 
  mentorId, 
  logs, 
  isMentor 
}: { 
  clubId: string; 
  mentorId: string; 
  logs: MentorLog[]; 
  isMentor: boolean;
}) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [content, setContent] = useState("");
  const [sessionNumber, setSessionNumber] = useState("1차 자문");
  const [consultationDate, setConsultationDate] = useState("");
  const [menteeNames, setMenteeNames] = useState("");
  const [nextSteps, setNextSteps] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content) return;

    setIsSubmitting(true);
    try {
      await addMentorLog(
        clubId, 
        mentorId, 
        content, 
        sessionNumber, 
        consultationDate, 
        menteeNames, 
        nextSteps
      );
      // Reset form
      setContent("");
      setSessionNumber("1차 자문");
      setConsultationDate("");
      setMenteeNames("");
      setNextSteps("");
    } catch (error) {
      alert("멘토 일지 저장 중 오류가 발생했습니다.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="glass-card" style={{ background: 'rgba(79, 70, 229, 0.03)' }}>
      <h2>멘토 일지 (상담 및 자문 이력관리)</h2>
      
      {isMentor && (
        <form onSubmit={handleSubmit} style={{ background: '#fff', padding: '1.5rem', borderRadius: '10px', border: '1px solid #eee', marginBottom: '2rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <h3 style={{ fontSize: '1.1rem', margin: 0, color: 'var(--navy)' }}>신규 멘토링 자문 기록 작성</h3>
          
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
            <div>
              <label style={{ display: 'block', marginBottom: '0.4rem', fontWeight: 600, fontSize: '0.9rem' }}>자문 회차</label>
              <select 
                value={sessionNumber} 
                onChange={e => setSessionNumber(e.target.value)} 
                className="input-field"
                required
              >
                <option value="1차 자문">1차 자문</option>
                <option value="2차 자문">2차 자문</option>
                <option value="3차 자문">3차 자문</option>
                <option value="4차 자문">4차 자문</option>
                <option value="5차 자문">5차 자문</option>
                <option value="수시 자문">수시 자문</option>
              </select>
            </div>
            
            <div>
              <label style={{ display: 'block', marginBottom: '0.4rem', fontWeight: 600, fontSize: '0.9rem' }}>자문 일시</label>
              <input 
                type="text" 
                placeholder="예: 2026-08-01 14:00" 
                value={consultationDate} 
                onChange={e => setConsultationDate(e.target.value)} 
                className="input-field"
                required
              />
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '0.4rem', fontWeight: 600, fontSize: '0.9rem' }}>자문 대상자</label>
              <input 
                type="text" 
                placeholder="예: 팀 전원, 혹은 홍길동 외 2명" 
                value={menteeNames} 
                onChange={e => setMenteeNames(e.target.value)} 
                className="input-field"
                required
              />
            </div>
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: '0.4rem', fontWeight: 600, fontSize: '0.9rem' }}>상담 / 자문 내용</label>
            <textarea 
              rows={4} 
              placeholder="자문 의견 및 기술 지도 내용을 기록해주세요..." 
              value={content} 
              onChange={e => setContent(e.target.value)} 
              className="input-field"
              required
            ></textarea>
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: '0.4rem', fontWeight: 600, fontSize: '0.9rem' }}>향후 조치 및 계획 (건의사항)</label>
            <textarea 
              rows={2} 
              placeholder="다음 자문 일정이나 보완 계획을 작성해주세요..." 
              value={nextSteps} 
              onChange={e => setNextSteps(e.target.value)} 
              className="input-field"
            ></textarea>
          </div>

          <button 
            type="submit" 
            disabled={isSubmitting} 
            className="btn btn-primary"
            style={{ alignSelf: 'flex-end', padding: '0.6rem 1.5rem' }}
          >
            {isSubmitting ? "저장 중..." : "자문 일지 저장"}
          </button>
        </form>
      )}

      {/* Logs Feed */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        {logs.map(log => (
          <div key={log.id} style={{ background: '#fff', padding: '1.5rem', borderRadius: '10px', border: '1px solid #e5e7eb', boxShadow: '0 2px 4px rgba(0,0,0,0.02)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #eee', paddingBottom: '0.8rem', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.5rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <span className="badge" style={{ background: 'var(--primary)', color: '#fff', fontSize: '0.85rem', padding: '0.3rem 0.6rem' }}>
                  {log.sessionNumber || "자문"}
                </span>
                <strong style={{ fontSize: '1.05rem' }}>{log.mentor.name} 멘토</strong>
              </div>
              <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
                일시: {log.consultationDate || new Date(log.createdAt).toLocaleString()}
              </div>
            </div>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <strong style={{ fontSize: '0.9rem', color: 'var(--text-secondary)' }}>자문 대상:</strong>
                <span style={{ marginLeft: '0.5rem', fontWeight: 500 }}>{log.menteeNames || "미기재"}</span>
              </div>

              <div>
                <strong style={{ display: 'block', fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: '0.3rem' }}>자문 내용:</strong>
                <p style={{ margin: 0, whiteSpace: 'pre-wrap', lineHeight: 1.6, background: '#f9fafb', padding: '1rem', borderRadius: '8px', border: '1px solid #eee' }}>
                  {log.content}
                </p>
              </div>

              {log.nextSteps && (
                <div>
                  <strong style={{ display: 'block', fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: '0.3rem' }}>향후 계획 및 건의사항:</strong>
                  <p style={{ margin: 0, whiteSpace: 'pre-wrap', lineHeight: 1.5, background: 'rgba(79, 70, 229, 0.02)', padding: '0.8rem 1rem', borderRadius: '8px', border: '1px dashed rgba(79, 70, 229, 0.2)', color: 'var(--primary)' }}>
                    {log.nextSteps}
                  </p>
                </div>
              )}
            </div>
          </div>
        ))}
        {logs.length === 0 && (
          <p style={{ color: 'var(--text-secondary)', textAlign: 'center', padding: '2rem' }}>
            작성된 멘토 일지가 없습니다.
          </p>
        )}
      </div>
    </div>
  );
}
