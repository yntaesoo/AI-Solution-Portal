"use client";

import { useState } from "react";
import CustomDateTimePicker from "@/app/components/CustomDateTimePicker";
import {
  updateApplicationCompletionStatus,
  saveProgramAction,
  deleteProgramAction,
  updateProgramStatusAction
} from "@/app/actions";

export interface ProgramApplicant {
  id: string;
  userId: string;
  userName: string;
  clubName: string;
  appliedAt: string;
  status: "진행" | "이수" | "미이수";
  surveyDone: boolean;
}

export interface ProgramItem {
  id: string;
  type: "MYDEX" | "창업지원단";
  title: string;
  status: "임시저장" | "진행" | "완료" | "취소";
  operateStartDate: string;
  operateEndDate: string;
  applyStartDate: string;
  applyEndDate: string;
  surveyStartDate?: string;
  surveyEndDate?: string;
  manager: string;
  applyType: string;
  applyTarget: string;
  applyCategory: string;
  maxRecruit: number;
  currentRecruit: number;
  maxPoint: number;
  mydexUrl: string;
  posterUrl: string;
  attachedFile: string;
  notice: string;
  content: string;
  surveyId?: string | null;
  applications?: ProgramApplicant[];
}

const initialPrograms: ProgramItem[] = [
  {
    id: "1",
    type: "MYDEX",
    title: "원스톱 상담창구",
    status: "진행",
    operateStartDate: "2026-05-01 00:00",
    operateEndDate: "2026-10-30 00:00",
    applyStartDate: "2026-04-28 00:00",
    applyEndDate: "2026-10-25 00:00",
    surveyStartDate: "2026-10-01 00:00",
    surveyEndDate: "2026-10-31 00:00",
    manager: "이동진 담당자",
    applyType: "온라인",
    applyTarget: "유학생 동아리",
    applyCategory: "팀",
    maxRecruit: 20,
    currentRecruit: 12,
    maxPoint: 100,
    mydexUrl: "https://mydex.dongseo.ac.kr/loadPage.do?jspPage=/PORTAL/STUD/C/A/SSCA020_01S&menuID=00118&PGM_ID=20260239",
    posterUrl: "https://placehold.co/300x420/4f46e5/ffffff?text=2026+RISE+StartUp+Club",
    attachedFile: "창업동아리 포스터 (1).jpg",
    notice: "멘토님과 팀별 연락하여 멘토링 일정 및 장소 조율 바랍니다.",
    content: "● 프로그램명: 원스톱 상담창구\n● 내용:\n- 멘토님이 팀별 연락하여 멘토링 일정 및 장소 조율\n- 창업 관련 모든 내용 멘토링 진행, 외부 경진대회 신청 가능\n- 필요 시 추가 멘토링 가능\n- 창업 캠프 참여하지 않은 RISE 창업동아리 참여 필수\n- 일정: 5월 1일(월)부터 10월 30일(금) 중 조율\n- 장소: 동서대학교 드림e밸리 A202호, 조율 가능",
    applications: [
      { id: "app-1", userId: "u1", userName: "윤태수_학생", clubName: "Global Tech", appliedAt: "2026-05-02 10:30", status: "진행", surveyDone: false },
      { id: "app-2", userId: "u2", userName: "김철수_학생", clubName: "AI Innovators", appliedAt: "2026-05-03 14:15", status: "이수", surveyDone: true },
      { id: "app-3", userId: "u3", userName: "이영희_학생", clubName: "Smart Biz", appliedAt: "2026-05-04 11:20", status: "미이수", surveyDone: false }
    ]
  },
  {
    id: "2",
    type: "창업지원단",
    title: "2026 유학생 창업 캠프 및 아이디어 경진대회",
    status: "완료",
    operateStartDate: "2026-06-10 09:00",
    operateEndDate: "2026-06-12 18:00",
    applyStartDate: "2026-05-15 00:00",
    applyEndDate: "2026-06-01 23:59",
    manager: "김창업 팀장",
    applyType: "오프라인/캠프",
    applyTarget: "전체 유학생",
    applyCategory: "팀(2~5인)",
    maxRecruit: 50,
    currentRecruit: 48,
    maxPoint: 200,
    mydexUrl: "https://mydex.dongseo.ac.kr/camp",
    posterUrl: "https://placehold.co/300x420/0284c7/ffffff?text=Global+Startup+Camp",
    attachedFile: "2026_창업캠프_세부일정.pdf",
    notice: "숙박 및 식사가 제공됩니다.",
    content: "● 글로벌 유학생 창업 비즈니스 모델 구체화 및 시제품 제작 가이드 제공 캠프"
  }
];

export default function SupportProgramManager({
  initialPrograms: propPrograms,
  availableSurveys = []
}: {
  initialPrograms?: ProgramItem[];
  availableSurveys?: any[];
} = {}) {
  const [programs, setPrograms] = useState<ProgramItem[]>(
    propPrograms && propPrograms.length > 0 ? propPrograms : initialPrograms
  );
  const [searchCategory, setSearchCategory] = useState("전체");
  const [searchKeyword, setSearchKeyword] = useState("");
  const [typeFilter, setTypeFilter] = useState<"MYDEX" | "창업지원단" | "ALL">("ALL");
  const [statusFilter, setStatusFilter] = useState<"임시저장" | "진행" | "완료" | "취소" | "ALL">("ALL");

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProgram, setEditingProgram] = useState<ProgramItem | null>(null);
  const [activeApplicantsProg, setActiveApplicantsProg] = useState<ProgramItem | null>(null);
  const [finalizedProgs, setFinalizedProgs] = useState<Record<string, boolean>>({});

  const handleCompletionStatusChange = async (programId: string, appId: string, newStatus: "진행" | "이수" | "미이수") => {
    try {
      await updateApplicationCompletionStatus(appId, newStatus);
    } catch (e) {}

    setPrograms(prev => prev.map(p => {
      if (p.id !== programId) return p;
      const updatedApps = (p.applications || []).map(a => a.id === appId ? { ...a, status: newStatus } : a);
      return { ...p, applications: updatedApps };
    }));

    if (activeApplicantsProg && activeApplicantsProg.id === programId) {
      setActiveApplicantsProg(prev => {
        if (!prev) return null;
        const updatedApps = (prev.applications || []).map(a => a.id === appId ? { ...a, status: newStatus } : a);
        return { ...prev, applications: updatedApps };
      });
    }
  };

  // Form Field States
  const [formType, setFormType] = useState<"MYDEX" | "창업지원단">("MYDEX");
  const [formStatus, setFormStatus] = useState<"임시저장" | "진행" | "완료" | "취소">("진행");
  const [formTitle, setFormTitle] = useState("");
  const [formOpStart, setFormOpStart] = useState("");
  const [formOpEnd, setFormOpEnd] = useState("");
  const [formAppStart, setFormAppStart] = useState("");
  const [formAppEnd, setFormAppEnd] = useState("");
  const [formSurStart, setFormSurStart] = useState("");
  const [formSurEnd, setFormSurEnd] = useState("");
  const [formSurveyId, setFormSurveyId] = useState("");
  const [formManager, setFormManager] = useState("");
  const [formApplyType, setFormApplyType] = useState("");
  const [formApplyTarget, setFormApplyTarget] = useState("");
  const [formApplyCategory, setFormApplyCategory] = useState("");
  const [formMaxPoint, setFormMaxPoint] = useState(100);
  const [formMaxRecruit, setFormMaxRecruit] = useState(20);
  const [formMydexUrl, setFormMydexUrl] = useState("");
  const [formAttachedFile, setFormAttachedFile] = useState("");
  const [formNotice, setFormNotice] = useState("");
  const [formContent, setFormContent] = useState("");

  const openNewModal = () => {
    setEditingProgram(null);
    setFormType("MYDEX");
    setFormStatus("임시저장");
    setFormTitle("");
    setFormOpStart("2026-05-01 00:00");
    setFormOpEnd("2026-10-30 00:00");
    setFormAppStart("2026-04-28 00:00");
    setFormAppEnd("2026-10-25 00:00");
    setFormSurStart("");
    setFormSurEnd("");
    setFormSurveyId("");
    setFormManager("");
    setFormApplyType("");
    setFormApplyTarget("");
    setFormApplyCategory("");
    setFormMaxPoint(100);
    setFormMaxRecruit(20);
    setFormMydexUrl("");
    setFormAttachedFile("창업동아리 안내문.pdf");
    setFormNotice("");
    setFormContent("");
    setIsModalOpen(true);
  };

  const openEditModal = (prog: ProgramItem) => {
    setEditingProgram(prog);
    setFormType(prog.type);
    setFormStatus(prog.status);
    setFormTitle(prog.title);
    setFormOpStart(prog.operateStartDate);
    setFormOpEnd(prog.operateEndDate);
    setFormAppStart(prog.applyStartDate);
    setFormAppEnd(prog.applyEndDate);
    setFormSurStart(prog.surveyStartDate || "");
    setFormSurEnd(prog.surveyEndDate || "");
    setFormSurveyId(prog.surveyId || "");
    setFormManager(prog.manager);
    setFormApplyType(prog.applyType);
    setFormApplyTarget(prog.applyTarget);
    setFormApplyCategory(prog.applyCategory);
    setFormMaxPoint(prog.maxPoint);
    setFormMaxRecruit(prog.maxRecruit);
    setFormMydexUrl(prog.mydexUrl);
    setFormAttachedFile(prog.attachedFile);
    setFormNotice(prog.notice);
    setFormContent(prog.content);
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      alert("프로그램명을 입력해 주세요.");
      return;
    }

    const payload = {
      id: editingProgram?.id,
      type: formType,
      status: formStatus,
      title: formTitle,
      operateStartDate: formOpStart,
      operateEndDate: formOpEnd,
      applyStartDate: formAppStart,
      applyEndDate: formAppEnd,
      surveyStartDate: formSurStart,
      surveyEndDate: formSurEnd,
      surveyId: formSurveyId || null,
      manager: formManager,
      applyType: formApplyType,
      applyTarget: formApplyTarget,
      applyCategory: formApplyCategory,
      maxPoint: Number(formMaxPoint),
      maxRecruit: Number(formMaxRecruit),
      mydexUrl: formMydexUrl,
      attachedFile: formAttachedFile,
      notice: formNotice,
      content: formContent
    };

    try {
      await saveProgramAction(payload);
    } catch (err) {
      console.error(err);
    }

    if (editingProgram) {
      setPrograms(prev => prev.map(p => p.id === editingProgram.id ? {
        ...p,
        type: formType,
        status: formStatus,
        title: formTitle,
        operateStartDate: formOpStart,
        operateEndDate: formOpEnd,
        applyStartDate: formAppStart,
        applyEndDate: formAppEnd,
        surveyStartDate: formSurStart,
        surveyEndDate: formSurEnd,
        surveyId: formSurveyId || null,
        manager: formManager,
        applyType: formApplyType,
        applyTarget: formApplyTarget,
        applyCategory: formApplyCategory,
        maxPoint: Number(formMaxPoint),
        maxRecruit: Number(formMaxRecruit),
        mydexUrl: formMydexUrl,
        attachedFile: formAttachedFile,
        notice: formNotice,
        content: formContent
      } : p));
      alert("지원프로그램 정보가 수정되었습니다.");
    } else {
      const newProg: ProgramItem = {
        id: String(Date.now()),
        type: formType,
        status: formStatus,
        title: formTitle,
        operateStartDate: formOpStart,
        operateEndDate: formOpEnd,
        applyStartDate: formAppStart,
        applyEndDate: formAppEnd,
        surveyStartDate: formSurStart,
        surveyEndDate: formSurEnd,
        manager: formManager || "관리자",
        applyType: formApplyType || "오프라인",
        applyTarget: formApplyTarget || "전체",
        applyCategory: formApplyCategory || "팀",
        maxRecruit: Number(formMaxRecruit),
        currentRecruit: 0,
        maxPoint: Number(formMaxPoint),
        mydexUrl: formMydexUrl,
        posterUrl: "https://placehold.co/300x420/2563eb/ffffff?text=New+Program",
        attachedFile: formAttachedFile || "안내문.pdf",
        notice: formNotice,
        content: formContent,
        surveyId: formSurveyId || null,
        applications: []
      };
      setPrograms(prev => [newProg, ...prev]);
      alert("신규 지원프로그램이 등록되었습니다.");
    }
    setIsModalOpen(false);
  };

  const handleStatusChange = (id: string) => {
    setPrograms(prev => prev.map(p => {
      if (p.id === id) {
        const nextStatus: ProgramItem["status"] = p.status === "진행" ? "완료" : p.status === "완료" ? "취소" : "진행";
        return { ...p, status: nextStatus };
      }
      return p;
    }));
  };

  const filteredPrograms = programs.filter(p => {
    if (typeFilter !== "ALL" && p.type !== typeFilter) return false;
    if (statusFilter !== "ALL" && p.status !== statusFilter) return false;
    if (searchKeyword.trim()) {
      const kw = searchKeyword.toLowerCase();
      return p.title.toLowerCase().includes(kw) || p.manager.toLowerCase().includes(kw);
    }
    return true;
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
      {/* Top Header Title */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h2 style={{ fontSize: "1.5rem", fontWeight: 700, margin: 0, color: "#1e293b" }}>
            지원프로그램 관리
          </h2>
        </div>
        <span style={{ fontSize: "0.85rem", color: "#64748b" }}>지원프로그램 관리</span>
      </div>

      {/* Filter & Search Bar Box (Matching Screenshot 1) */}
      <div style={{ background: "#ffffff", padding: "1.25rem 1.5rem", borderRadius: "12px", border: "1px solid #e2e8f0", boxShadow: "0 2px 8px rgba(0,0,0,0.02)", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem", flexWrap: "wrap" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", flex: 1, minWidth: "300px" }}>
          <select
            value={searchCategory}
            onChange={e => setSearchCategory(e.target.value)}
            style={{ padding: "0.6rem 1rem", border: "1px solid #cbd5e1", borderRadius: "8px", background: "#fff", fontSize: "0.9rem", color: "#334155" }}
          >
            <option value="전체">전체</option>
            <option value="MYDEX">MYDEX</option>
            <option value="창업지원단">창업지원단</option>
          </select>

          <input
            type="text"
            placeholder="검색어를 입력해주세요."
            value={searchKeyword}
            onChange={e => setSearchKeyword(e.target.value)}
            style={{ flex: 1, padding: "0.6rem 1rem", border: "1px solid #cbd5e1", borderRadius: "8px", fontSize: "0.9rem", minWidth: "200px" }}
          />

          <button
            onClick={() => {}}
            style={{ background: "#2563eb", color: "#ffffff", border: "none", padding: "0.6rem 1.25rem", borderRadius: "8px", fontWeight: 600, fontSize: "0.9rem", display: "flex", alignItems: "center", gap: "0.4rem", cursor: "pointer" }}
          >
            🔍 검색
          </button>
          
          <button
            onClick={() => { setSearchKeyword(""); setTypeFilter("ALL"); setStatusFilter("ALL"); }}
            style={{ background: "#f1f5f9", color: "#475569", border: "1px solid #cbd5e1", padding: "0.6rem 1.25rem", borderRadius: "8px", fontWeight: 500, fontSize: "0.9rem", display: "flex", alignItems: "center", gap: "0.4rem", cursor: "pointer" }}
          >
            🔄 초기화
          </button>

          <span style={{ fontSize: "0.875rem", color: "#64748b", marginLeft: "0.5rem" }}>
            총 <strong style={{ color: "#2563eb" }}>{filteredPrograms.length}</strong>건 검색되었습니다.
          </span>
        </div>

        <button
          onClick={openNewModal}
          style={{ background: "#2563eb", color: "#ffffff", border: "none", padding: "0.65rem 1.25rem", borderRadius: "30px", fontWeight: 600, fontSize: "0.9rem", display: "flex", alignItems: "center", gap: "0.4rem", cursor: "pointer", boxShadow: "0 4px 12px rgba(37,99,235,0.2)" }}
        >
          ➕ 신규등록
        </button>
      </div>

      {/* Main Table Card (Matching Screenshot 1) */}
      <div style={{ background: "#ffffff", padding: "1.5rem", borderRadius: "12px", border: "1px solid #e2e8f0", boxShadow: "0 2px 8px rgba(0,0,0,0.02)" }}>
        <h3 style={{ fontSize: "1.1rem", fontWeight: 700, margin: "0 0 1rem 0", color: "#1e293b", display: "flex", alignItems: "center", gap: "0.5rem" }}>
          📋 지원프로그램 목록
        </h3>

        {/* Filter Pills */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem", marginBottom: "1.25rem", flexWrap: "wrap" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <button
              onClick={() => setTypeFilter(typeFilter === "MYDEX" ? "ALL" : "MYDEX")}
              style={{ padding: "0.4rem 1rem", borderRadius: "20px", fontSize: "0.85rem", fontWeight: 600, border: "none", cursor: "pointer", background: typeFilter === "MYDEX" ? "#2563eb" : "#e2e8f0", color: typeFilter === "MYDEX" ? "#fff" : "#475569" }}
            >
              MYDEX
            </button>
            <button
              onClick={() => setTypeFilter(typeFilter === "창업지원단" ? "ALL" : "창업지원단")}
              style={{ padding: "0.4rem 1rem", borderRadius: "20px", fontSize: "0.85rem", fontWeight: 600, border: "none", cursor: "pointer", background: typeFilter === "창업지원단" ? "#2563eb" : "#e2e8f0", color: typeFilter === "창업지원단" ? "#fff" : "#475569" }}
            >
              창업지원단
            </button>
            <span style={{ color: "#cbd5e1" }}>|</span>
            <button
              onClick={() => setStatusFilter(statusFilter === "임시저장" ? "ALL" : "임시저장")}
              style={{ padding: "0.4rem 0.85rem", borderRadius: "20px", fontSize: "0.85rem", border: "none", cursor: "pointer", background: statusFilter === "임시저장" ? "#2563eb" : "#f1f5f9", color: statusFilter === "임시저장" ? "#fff" : "#64748b" }}
            >
              임시저장
            </button>
            <button
              onClick={() => setStatusFilter(statusFilter === "진행" ? "ALL" : "진행")}
              style={{ padding: "0.4rem 0.85rem", borderRadius: "20px", fontSize: "0.85rem", border: "none", cursor: "pointer", background: statusFilter === "진행" ? "#2563eb" : "#f1f5f9", color: statusFilter === "진행" ? "#fff" : "#64748b" }}
            >
              진행
            </button>
            <button
              onClick={() => setStatusFilter(statusFilter === "완료" ? "ALL" : "완료")}
              style={{ padding: "0.4rem 0.85rem", borderRadius: "20px", fontSize: "0.85rem", border: "none", cursor: "pointer", background: statusFilter === "완료" ? "#2563eb" : "#f1f5f9", color: statusFilter === "완료" ? "#fff" : "#64748b" }}
            >
              완료
            </button>
            <button
              onClick={() => setStatusFilter(statusFilter === "취소" ? "ALL" : "취소")}
              style={{ padding: "0.4rem 0.85rem", borderRadius: "20px", fontSize: "0.85rem", border: "none", cursor: "pointer", background: statusFilter === "취소" ? "#2563eb" : "#f1f5f9", color: statusFilter === "취소" ? "#fff" : "#64748b" }}
            >
              취소
            </button>
          </div>
          
          <span style={{ fontSize: "0.8rem", color: "#94a3b8", marginLeft: "auto" }}>
            * 프로그램 유형에 따라 별도의 기능을 제공합니다. 자세한 내용은 메뉴얼을 참고하시기 바랍니다.
          </span>
        </div>

        {/* Table */}
        <div style={{ overflowX: "auto", borderTop: "2px solid #2563eb" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.85rem", textAlign: "center" }}>
            <thead>
              <tr style={{ background: "#fafafa", borderBottom: "1px solid #e2e8f0", color: "#1e293b", fontWeight: 700, whiteSpace: "nowrap" }}>
                <th style={{ padding: "0.75rem 0.5rem", width: "50px" }}>No.</th>
                <th style={{ padding: "0.75rem 0.5rem", width: "60px" }}>미리보기</th>
                <th style={{ padding: "0.75rem 0.5rem", width: "100px" }}>프로그램 유형</th>
                <th style={{ padding: "0.75rem 0.75rem", textAlign: "left", minWidth: "150px" }}>지원프로그램 명</th>
                <th style={{ padding: "0.75rem 0.5rem", width: "140px" }}>운영일시</th>
                <th style={{ padding: "0.75rem 0.5rem", width: "140px" }}>신청일시</th>
                <th style={{ padding: "0.75rem 0.5rem", width: "80px" }}>담당자</th>
                <th style={{ padding: "0.75rem 0.5rem", width: "80px" }}>신청형태</th>
                <th style={{ padding: "0.75rem 0.5rem", width: "80px" }}>신청대상</th>
                <th style={{ padding: "0.75rem 0.5rem", width: "80px" }}>신청구분</th>
                <th style={{ padding: "0.75rem 0.5rem", width: "70px" }}>모집인원</th>
                <th style={{ padding: "0.75rem 0.5rem", width: "70px" }}>첨부파일</th>
                <th style={{ padding: "0.75rem 0.5rem", width: "85px" }}>관리</th>
                <th style={{ padding: "0.75rem 0.5rem", width: "85px" }}>진행</th>
              </tr>
            </thead>
            <tbody>
              {filteredPrograms.length === 0 ? (
                <tr>
                  <td colSpan={14} style={{ padding: "3rem", color: "#94a3b8" }}>
                    조회된 지원프로그램 내역이 없습니다.
                  </td>
                </tr>
              ) : (
                filteredPrograms.map((prog, idx) => {
                  const formatShort = (dtStr: string) => {
                    if (!dtStr) return "-";
                    // convert '2026-05-01 00:00:00' -> '26-05-01 00:00'
                    return dtStr.replace(/^20/, '').slice(0, 14);
                  };

                  return (
                    <tr key={prog.id} style={{ borderBottom: "1px solid #f1f5f9", background: idx % 2 === 0 ? "#ffffff" : "#f8fafc", whiteSpace: "nowrap" }}>
                      <td style={{ padding: "0.65rem 0.5rem", fontWeight: 500 }}>{idx + 1}</td>
                      <td style={{ padding: "0.65rem 0.5rem" }}>
                        <img
                          src={prog.posterUrl}
                          alt="poster"
                          style={{ width: "36px", height: "48px", objectFit: "cover", borderRadius: "4px", border: "1px solid #cbd5e1" }}
                        />
                      </td>
                      <td style={{ padding: "0.65rem 0.5rem" }}>
                        <span style={{ color: "#2563eb", fontWeight: 600 }}>{prog.type}</span>
                      </td>
                      <td style={{ padding: "0.65rem 0.75rem", textAlign: "left", fontWeight: 600, color: "#1e293b", whiteSpace: "normal" }}>
                        <div>{prog.title}</div>
                        {prog.surveyId && (
                          <div style={{ marginTop: "0.3rem" }}>
                            <span style={{ background: "#ecfdf5", color: "#059669", border: "1px solid #a7f3d0", padding: "0.15rem 0.5rem", borderRadius: "10px", fontSize: "0.75rem", fontWeight: 600, display: "inline-flex", alignItems: "center", gap: "0.25rem" }}>
                              📋 설문: {availableSurveys.find((s: any) => s.id === prog.surveyId)?.title || "지정 설문"}
                            </span>
                          </div>
                        )}
                      </td>
                      <td style={{ padding: "0.65rem 0.5rem", fontSize: "0.8rem", color: "#475569", lineHeight: 1.35 }}>
                        {formatShort(prog.operateStartDate)}<br />~ {formatShort(prog.operateEndDate)}
                      </td>
                      <td style={{ padding: "0.65rem 0.5rem", fontSize: "0.8rem", color: "#475569", lineHeight: 1.35 }}>
                        {formatShort(prog.applyStartDate)}<br />~ {formatShort(prog.applyEndDate)}
                      </td>
                      <td style={{ padding: "0.65rem 0.5rem" }}>{prog.manager || "-"}</td>
                      <td style={{ padding: "0.65rem 0.5rem" }}>{prog.applyType || "-"}</td>
                      <td style={{ padding: "0.65rem 0.5rem" }}>{prog.applyTarget || "-"}</td>
                      <td style={{ padding: "0.65rem 0.5rem" }}>{prog.applyCategory || "-"}</td>
                      <td style={{ padding: "0.65rem 0.5rem", fontWeight: 600 }}>{prog.maxRecruit}</td>
                      <td style={{ padding: "0.65rem 0.5rem" }}>
                        {prog.attachedFile ? (
                          <span title={prog.attachedFile} style={{ color: "#2563eb", cursor: "pointer", fontSize: "1rem" }}>📄</span>
                        ) : "-"}
                      </td>
                      <td style={{ padding: "0.65rem 0.5rem" }}>
                        <div style={{ display: "flex", flexDirection: "column", gap: "0.3rem", alignItems: "center" }}>
                          <button
                            onClick={() => openEditModal(prog)}
                            style={{ background: "#ffffff", border: "1px solid #2563eb", color: "#2563eb", padding: "0.25rem 0.6rem", borderRadius: "16px", fontSize: "0.75rem", fontWeight: 600, cursor: "pointer" }}
                          >
                            ⚙️ 관리
                          </button>
                          <button
                            onClick={() => setActiveApplicantsProg(prog)}
                            style={{ background: "#eff6ff", border: "1px solid #93c5fd", color: "#1d4ed8", padding: "0.25rem 0.6rem", borderRadius: "16px", fontSize: "0.75rem", fontWeight: 700, cursor: "pointer" }}
                          >
                            👥 참여자({prog.applications?.length || 0})
                          </button>
                        </div>
                      </td>
                      <td style={{ padding: "0.65rem 0.5rem" }}>
                        <button
                          onClick={() => handleStatusChange(prog.id)}
                          style={{ background: "#ffffff", border: "1px solid #cbd5e1", color: "#2563eb", padding: "0.3rem 0.7rem", borderRadius: "16px", fontSize: "0.78rem", fontWeight: 600, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: "0.2rem" }}
                        >
                          ▶️ {prog.status}
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer info & Pagination */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "1.25rem", flexWrap: "wrap", gap: "1rem" }}>
          <span style={{ fontSize: "0.8rem", color: "#94a3b8" }}>
            * 좌우로 스크롤시 더 많은 정보를 확인 할 수 있습니다.
          </span>
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <select style={{ padding: "0.35rem 0.75rem", border: "1px solid #cbd5e1", borderRadius: "16px", fontSize: "0.8rem" }}>
              <option>20 개씩 보기</option>
              <option>50 개씩 보기</option>
            </select>
            <div style={{ display: "flex", gap: "0.25rem" }}>
              <button style={{ border: "1px solid #cbd5e1", background: "#fff", padding: "0.35rem 0.6rem", borderRadius: "4px", fontSize: "0.8rem" }}>«</button>
              <button style={{ border: "1px solid #cbd5e1", background: "#fff", padding: "0.35rem 0.6rem", borderRadius: "4px", fontSize: "0.8rem" }}>‹</button>
              <button style={{ border: "none", background: "#2563eb", color: "#fff", padding: "0.35rem 0.65rem", borderRadius: "4px", fontSize: "0.8rem", fontWeight: 700 }}>1</button>
              <button style={{ border: "1px solid #cbd5e1", background: "#fff", padding: "0.35rem 0.6rem", borderRadius: "4px", fontSize: "0.8rem" }}>›</button>
              <button style={{ border: "1px solid #cbd5e1", background: "#fff", padding: "0.35rem 0.6rem", borderRadius: "4px", fontSize: "0.8rem" }}>»</button>
            </div>
          </div>
        </div>
      </div>

      {/* Edit / New Program Modal (Matching Screenshot 4) */}
      {isModalOpen && (
        <div style={{ position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh", background: "rgba(15, 23, 42, 0.6)", backdropFilter: "blur(4px)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 1000, padding: "1rem" }}>
          <div style={{ background: "#ffffff", borderRadius: "16px", width: "100%", maxWidth: "1000px", maxHeight: "90vh", overflowY: "auto", boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)" }}>
            
            {/* Modal Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "1.25rem 1.5rem", borderBottom: "1px solid #e2e8f0" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
                <h3 style={{ fontSize: "1.25rem", fontWeight: 700, margin: 0, color: "#1e293b" }}>
                  {editingProgram ? "지원프로그램 정보 수정" : "지원프로그램 신규 등록"}
                </h3>
                <select
                  value={formStatus}
                  onChange={e => setFormStatus(e.target.value as any)}
                  style={{ padding: "0.35rem 0.75rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.85rem", fontWeight: 600, color: "#2563eb" }}
                >
                  <option value="임시저장">임시저장</option>
                  <option value="진행">진행</option>
                  <option value="완료">완료</option>
                  <option value="취소">취소</option>
                </select>
              </div>
              
              <button
                onClick={() => setIsModalOpen(false)}
                style={{ background: "none", border: "none", fontSize: "1.5rem", color: "#64748b", cursor: "pointer" }}
              >
                ✕
              </button>
            </div>

            {/* Modal Form Body */}
            <form onSubmit={handleSave} style={{ padding: "1.5rem" }}>
              
              {/* Type Radio Header */}
              <div style={{ background: "#f8fafc", padding: "1rem", borderRadius: "8px", border: "1px solid #e2e8f0", marginBottom: "1.5rem", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ display: "flex", gap: "1.5rem", alignItems: "center" }}>
                  <label style={{ display: "flex", alignItems: "center", gap: "0.4rem", fontWeight: 600, cursor: "pointer", color: "#2563eb" }}>
                    <input type="radio" name="progType" checked={formType === "MYDEX"} onChange={() => setFormType("MYDEX")} />
                    MYDEX
                  </label>
                  <label style={{ display: "flex", alignItems: "center", gap: "0.4rem", fontWeight: 600, cursor: "pointer" }}>
                    <input type="radio" name="progType" checked={formType === "창업지원단"} onChange={() => setFormType("창업지원단")} />
                    창업지원단
                  </label>
                </div>
                <span style={{ fontSize: "0.8rem", color: "#64748b" }}>
                  * 프로그램 유형이 MYDEX인 경우에, 입력한 URL로 이동됩니다.
                </span>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "240px 1fr", gap: "1.5rem", marginBottom: "1.5rem" }}>
                
                {/* Left Poster Upload Box */}
                <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "8px", padding: "1rem", textAlign: "center", display: "flex", flexDirection: "column", gap: "0.75rem" }}>
                  <span style={{ fontSize: "0.85rem", fontWeight: 600, color: "#334155" }}>미리보기</span>
                  <div style={{ border: "1px solid #cbd5e1", borderRadius: "6px", overflow: "hidden", background: "#fff" }}>
                    <img
                      src={editingProgram?.posterUrl || "https://placehold.co/300x420/2563eb/ffffff?text=Poster+Preview"}
                      alt="poster preview"
                      style={{ width: "100%", height: "260px", objectFit: "cover" }}
                    />
                  </div>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: "0.75rem", color: "#64748b", border: "1px solid #cbd5e1", padding: "0.4rem 0.6rem", borderRadius: "4px", background: "#fff" }}>
                    <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{formAttachedFile || "포스터.jpg"}</span>
                    <span>🗑️</span>
                  </div>
                  <button type="button" style={{ background: "#475569", color: "#fff", border: "none", padding: "0.4rem", borderRadius: "4px", fontSize: "0.8rem", cursor: "pointer" }}>
                    파일다운로드 ⬇️
                  </button>
                </div>

                {/* Right Input Fields */}
                <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                  <div>
                    <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, marginBottom: "0.3rem", color: "#334155" }}>
                      지원프로그램명 <span style={{ color: "#ef4444" }}>*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={formTitle}
                      onChange={e => setFormTitle(e.target.value)}
                      placeholder="지원프로그램명을 입력하세요."
                      style={{ width: "100%", padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.9rem" }}
                    />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                    <div>
                      <CustomDateTimePicker
                        label="접수 시작일"
                        required
                        value={formAppStart}
                        onChange={setFormAppStart}
                        placeholder="2026-04-28 00:00:00"
                      />
                    </div>
                    <div>
                      <CustomDateTimePicker
                        label="접수 종료일"
                        required
                        value={formAppEnd}
                        onChange={setFormAppEnd}
                        placeholder="2026-10-25 00:00:00"
                      />
                    </div>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                    <div>
                      <CustomDateTimePicker
                        label="운영 시작일"
                        required
                        value={formOpStart}
                        onChange={setFormOpStart}
                        placeholder="2026-05-01 00:00:00"
                      />
                    </div>
                    <div>
                      <CustomDateTimePicker
                        label="운영 종료일"
                        required
                        value={formOpEnd}
                        onChange={setFormOpEnd}
                        placeholder="2026-10-30 00:00:00"
                      />
                    </div>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                    <div>
                      <CustomDateTimePicker
                        label="만족도 실시 시작일시"
                        value={formSurStart}
                        onChange={setFormSurStart}
                        placeholder="만족도 실시 시작일시"
                      />
                    </div>
                    <div>
                      <CustomDateTimePicker
                        label="만족도 실시 종료일시"
                        value={formSurEnd}
                        onChange={setFormSurEnd}
                        placeholder="만족도 실시 종료일시"
                      />
                    </div>
                  </div>

                  {/* Linked Satisfaction Survey Selector */}
                  <div>
                    <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, marginBottom: "0.3rem", color: "#334155" }}>
                      연계 만족도설문지 지정 <span style={{ fontSize: "0.75rem", color: "#2563eb" }}>(프로그램 이수 학생에게 제공될 설문지)</span>
                    </label>
                    <div style={{ display: "flex", gap: "0.75rem", alignItems: "center" }}>
                      <select
                        value={formSurveyId}
                        onChange={e => setFormSurveyId(e.target.value)}
                        style={{ flex: 1, padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.85rem", background: "#fff" }}
                      >
                        <option value="">(연계 설문지 없음 - 기본 설문 사용)</option>
                        {availableSurveys.map((s: any) => (
                          <option key={s.id} value={s.id}>
                            {s.title} ({s.questions?.length || 0}문항)
                          </option>
                        ))}
                      </select>
                      {formSurveyId ? (
                        <span style={{ fontSize: "0.8rem", color: "#16a34a", fontWeight: 700, whiteSpace: "nowrap" }}>
                          ✓ 설문 연계됨
                        </span>
                      ) : (
                        <span style={{ fontSize: "0.8rem", color: "#94a3b8", whiteSpace: "nowrap" }}>
                          미연계 (기본 설문)
                        </span>
                      )}
                    </div>
                  </div>

                  <div>
                    <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, marginBottom: "0.3rem", color: "#334155" }}>
                      MYDEX 프로그램 URL <span style={{ color: "#ef4444" }}>*</span>
                    </label>
                    <input
                      type="text"
                      value={formMydexUrl}
                      onChange={e => setFormMydexUrl(e.target.value)}
                      placeholder="https://mydex.dongseo.ac.kr/..."
                      style={{ width: "100%", padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.85rem" }}
                    />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0.75rem" }}>
                    <div>
                      <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 600, marginBottom: "0.2rem" }}>신청형태</label>
                      <input
                        type="text"
                        value={formApplyType}
                        onChange={e => setFormApplyType(e.target.value)}
                        placeholder="신청형태 입력"
                        style={{ width: "100%", padding: "0.5rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.85rem" }}
                      />
                    </div>
                    <div>
                      <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 600, marginBottom: "0.2rem" }}>신청대상</label>
                      <input
                        type="text"
                        value={formApplyTarget}
                        onChange={e => setFormApplyTarget(e.target.value)}
                        placeholder="신청대상 입력"
                        style={{ width: "100%", padding: "0.5rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.85rem" }}
                      />
                    </div>
                    <div>
                      <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 600, marginBottom: "0.2rem" }}>신청구분</label>
                      <input
                        type="text"
                        value={formApplyCategory}
                        onChange={e => setFormApplyCategory(e.target.value)}
                        placeholder="신청구분 입력"
                        style={{ width: "100%", padding: "0.5rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.85rem" }}
                      />
                    </div>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1.5fr", gap: "0.75rem" }}>
                    <div>
                      <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 600, marginBottom: "0.2rem" }}>최대학습포인트</label>
                      <input
                        type="number"
                        value={formMaxPoint}
                        onChange={e => setFormMaxPoint(Number(e.target.value))}
                        style={{ width: "100%", padding: "0.5rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.85rem" }}
                      />
                    </div>
                    <div>
                      <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 600, marginBottom: "0.2rem" }}>모집인원</label>
                      <input
                        type="number"
                        value={formMaxRecruit}
                        onChange={e => setFormMaxRecruit(Number(e.target.value))}
                        style={{ width: "100%", padding: "0.5rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.85rem" }}
                      />
                    </div>
                    <div>
                      <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 600, marginBottom: "0.2rem" }}>프로그램 담당자</label>
                      <input
                        type="text"
                        value={formManager}
                        onChange={e => setFormManager(e.target.value)}
                        placeholder="담당자명 입력"
                        style={{ width: "100%", padding: "0.5rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.85rem" }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Full Width Content Editor Area */}
              <div style={{ border: "1px solid #e2e8f0", borderRadius: "8px", overflow: "hidden", marginBottom: "1.5rem" }}>
                <div style={{ background: "#f8fafc", padding: "0.6rem 1rem", borderBottom: "1px solid #e2e8f0", fontWeight: 600, fontSize: "0.85rem", color: "#334155" }}>
                  내용
                </div>
                <textarea
                  rows={6}
                  value={formContent}
                  onChange={e => setFormContent(e.target.value)}
                  placeholder="프로그램 세부 안내 내용을 입력하세요."
                  style={{ width: "100%", padding: "1rem", border: "none", fontSize: "0.9rem", resize: "vertical", outline: "none" }}
                />
              </div>

              {/* Modal Action Buttons */}
              <div style={{ display: "flex", justifyContent: "center", gap: "1rem" }}>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  style={{ background: "#f1f5f9", color: "#475569", border: "1px solid #cbd5e1", padding: "0.65rem 2rem", borderRadius: "6px", fontWeight: 600, cursor: "pointer" }}
                >
                  취소
                </button>
                <button
                  type="submit"
                  style={{ background: "#2563eb", color: "#ffffff", border: "none", padding: "0.65rem 2rem", borderRadius: "6px", fontWeight: 600, cursor: "pointer", boxShadow: "0 4px 12px rgba(37,99,235,0.2)" }}
                >
                  {editingProgram ? "수정" : "등록"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* -------------------- PARTICIPANTS & COMPLETION EVALUATION MODAL -------------------- */}
      {activeApplicantsProg && (
        <div style={{ position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh", background: "rgba(0, 0, 0, 0.5)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 2000, padding: "1rem" }}>
          <div style={{ background: "#ffffff", borderRadius: "12px", maxWidth: "780px", width: "100%", maxHeight: "90vh", overflowY: "auto", padding: "1.75rem", boxShadow: "0 10px 30px rgba(0,0,0,0.2)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #e2e8f0", paddingBottom: "1rem", marginBottom: "1.25rem" }}>
              <div>
                <h3 style={{ margin: 0, fontSize: "1.2rem", fontWeight: 800, color: "#1e293b" }}>
                  👥 [{activeApplicantsProg.title}] 신청 및 참여자 리스트
                </h3>
                <p style={{ margin: "0.2rem 0 0 0", fontSize: "0.8rem", color: "#64748b" }}>
                  참여자의 이수결과(진행/이수/미이수)를 체크하면 학생회원의 신청내역 화면에 실시간으로 표시됩니다.
                </p>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", flexWrap: "wrap" }}>
                {/* Final Confirmation Button */}
                {finalizedProgs[activeApplicantsProg.id] ? (
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm("이수평가 최종확정을 해제하시겠습니까?")) {
                        setFinalizedProgs(prev => ({ ...prev, [activeApplicantsProg.id]: false }));
                      }
                    }}
                    style={{
                      background: "#10b981",
                      color: "#ffffff",
                      border: "none",
                      padding: "0.5rem 0.9rem",
                      borderRadius: "6px",
                      fontWeight: 700,
                      fontSize: "0.8rem",
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      gap: "0.3rem"
                    }}
                  >
                    ✅ 최종확정 완료 (클릭 시 해제)
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm("이 지원프로그램의 이수평가를 최종 확정하시겠습니까?\n확정 완료 후 더 이상 수정사항이 없음을 알립니다.")) {
                        setFinalizedProgs(prev => ({ ...prev, [activeApplicantsProg.id]: true }));
                        alert("이수평가가 최종 확정 처리되었습니다.");
                      }
                    }}
                    style={{
                      background: "#475569",
                      color: "#ffffff",
                      border: "none",
                      padding: "0.5rem 0.9rem",
                      borderRadius: "6px",
                      fontWeight: 700,
                      fontSize: "0.8rem",
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      gap: "0.3rem"
                    }}
                  >
                    🔒 최종확정 (수정 마감)
                  </button>
                )}

                {/* Print Sign-in Sheet Button */}
                <button
                  type="button"
                  onClick={() => {
                    const printWindow = window.open("", "_blank");
                    if (!printWindow) return;
                    const rows = (activeApplicantsProg.applications || []).map((app, i) => `
                      <tr style="height: 50px;">
                        <td style="border: 1px solid #000; text-align: center; font-weight: bold;">${i + 1}</td>
                        <td style="border: 1px solid #000; text-align: center;">${app.clubName || "창업동아리"}</td>
                        <td style="border: 1px solid #000; text-align: center; font-weight: bold;">${app.userName}</td>
                        <td style="border: 1px solid #000; text-align: center; font-size: 0.85rem;">${app.appliedAt}</td>
                        <td style="border: 1px solid #000; text-align: center;"></td>
                      </tr>
                    `).join("");

                    printWindow.document.write(`
                      <!DOCTYPE html>
                      <html>
                      <head>
                        <title>참가자 서명 방명록 대장 - ${activeApplicantsProg.title}</title>
                        <style>
                          body { font-family: 'Pretendard', sans-serif; padding: 2rem; color: #000; }
                          h1 { text-align: center; font-size: 1.8rem; margin-bottom: 0.5rem; text-decoration: underline; }
                          .subtitle { text-align: center; font-size: 1.1rem; margin-bottom: 1.5rem; color: #333; }
                          .info-box { border: 2px solid #000; padding: 1rem; margin-bottom: 1.5rem; font-size: 0.95rem; line-height: 1.6; }
                          table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
                          th { border: 1px solid #000; background: #f0f0f0; padding: 0.75rem; font-size: 0.95rem; }
                          .footer { margin-top: 3rem; text-align: right; font-size: 1.1rem; font-weight: bold; }
                        </style>
                      </head>
                      <body>
                        <h1>오프라인 참가자 서명 방명록 대장</h1>
                        <div class="subtitle">[ ${activeApplicantsProg.title} ]</div>
                        <div class="info-box">
                          <div>• <strong>운영기간:</strong> ${activeApplicantsProg.operateStartDate} ~ ${activeApplicantsProg.operateEndDate}</div>
                          <div>• <strong>담당자:</strong> ${activeApplicantsProg.manager || "동서대학교 RISE 창업지원단"}</div>
                          <div>• <strong>총 신청인원:</strong> ${(activeApplicantsProg.applications || []).length}명</div>
                        </div>
                        <table>
                          <thead>
                            <tr>
                              <th style="width: 50px;">No</th>
                              <th style="width: 180px;">소속 (동아리)</th>
                              <th style="width: 150px;">성명 (이름)</th>
                              <th style="width: 180px;">신청 일시</th>
                              <th>참가자 서명 (Signature)</th>
                            </tr>
                          </thead>
                          <tbody>
                            ${rows || '<tr><td colSpan="5" style="border: 1px solid #000; text-align: center; padding: 2rem;">신청자가 없습니다.</td></tr>'}
                          </tbody>
                        </table>
                        <div class="footer">
                          동서대학교 RISE 창업지원단장 (직인)
                        </div>
                        <script>
                          window.onload = function() { window.print(); }
                        </script>
                      </body>
                      </html>
                    `);
                    printWindow.document.close();
                  }}
                  style={{
                    background: "#059669",
                    color: "#ffffff",
                    border: "none",
                    padding: "0.5rem 0.9rem",
                    borderRadius: "6px",
                    fontWeight: 700,
                    fontSize: "0.8rem",
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: "0.3rem",
                    boxShadow: "0 2px 8px rgba(5,150,105,0.2)"
                  }}
                >
                  ✍️ 방명록/서명 대장 출력
                </button>

                {/* Print Application List Button */}
                <button
                  type="button"
                  onClick={() => window.print()}
                  style={{
                    background: "#2563eb",
                    color: "#ffffff",
                    border: "none",
                    padding: "0.5rem 0.9rem",
                    borderRadius: "6px",
                    fontWeight: 700,
                    fontSize: "0.8rem",
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: "0.3rem",
                    boxShadow: "0 2px 8px rgba(37,99,235,0.2)"
                  }}
                >
                  🖨️ 명단 출력
                </button>
                <button onClick={() => setActiveApplicantsProg(null)} style={{ background: "none", border: "none", fontSize: "1.4rem", cursor: "pointer", color: "#64748b", marginLeft: "0.2rem" }}>✕</button>
              </div>
            </div>

            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.85rem", textAlign: "center" }}>
                <thead>
                  <tr style={{ background: "#f8fafc", borderBottom: "2px solid #cbd5e1", color: "#1e293b", fontWeight: 700 }}>
                    <th style={{ padding: "0.75rem 0.5rem", width: "45px" }}>No</th>
                    <th style={{ padding: "0.75rem 0.5rem" }}>학생 성명</th>
                    <th style={{ padding: "0.75rem 0.5rem" }}>소속 동아리</th>
                    <th style={{ padding: "0.75rem 0.5rem" }}>신청 일시</th>
                    <th style={{ padding: "0.75rem 0.5rem" }}>설문 제출</th>
                    <th style={{ padding: "0.75rem 0.5rem", width: "210px" }}>이수결과 체크 (클릭)</th>
                  </tr>
                </thead>
                <tbody>
                  {(!activeApplicantsProg.applications || activeApplicantsProg.applications.length === 0) ? (
                    <tr>
                      <td colSpan={6} style={{ padding: "3rem", color: "#94a3b8" }}>
                        현재 신청한 학생이 없습니다.
                      </td>
                    </tr>
                  ) : (
                    activeApplicantsProg.applications.map((app, i) => (
                      <tr key={app.id} style={{ borderBottom: "1px solid #f1f5f9", height: "55px" }}>
                        <td>{i + 1}</td>
                        <td style={{ fontWeight: 700, color: "#1e293b" }}>{app.userName}</td>
                        <td>{app.clubName}</td>
                        <td style={{ color: "#64748b", fontSize: "0.8rem" }}>{app.appliedAt}</td>
                        <td>
                          {app.surveyDone ? (
                            <span style={{ background: "#dcfce7", color: "#16a34a", padding: "0.2rem 0.6rem", borderRadius: "12px", fontWeight: 700, fontSize: "0.75rem" }}>✓ 제출완료</span>
                          ) : (
                            <span style={{ color: "#94a3b8", fontSize: "0.75rem" }}>미제출</span>
                          )}
                        </td>
                        <td>
                          <div style={{ display: "flex", justifyContent: "center", gap: "0.3rem" }}>
                            <button
                              onClick={() => handleCompletionStatusChange(activeApplicantsProg.id, app.id, "진행")}
                              style={{ background: app.status === "진행" ? "#475569" : "#ffffff", color: app.status === "진행" ? "#ffffff" : "#475569", border: "1px solid #cbd5e1", padding: "0.3rem 0.65rem", borderRadius: "4px", fontSize: "0.78rem", fontWeight: 600, cursor: "pointer" }}
                            >
                              진행
                            </button>
                            <button
                              onClick={() => handleCompletionStatusChange(activeApplicantsProg.id, app.id, "이수")}
                              style={{ background: app.status === "이수" ? "#16a34a" : "#ffffff", color: app.status === "이수" ? "#ffffff" : "#16a34a", border: "1px solid #16a34a", padding: "0.3rem 0.65rem", borderRadius: "4px", fontSize: "0.78rem", fontWeight: 700, cursor: "pointer" }}
                            >
                              ✓ 이수
                            </button>
                            <button
                              onClick={() => handleCompletionStatusChange(activeApplicantsProg.id, app.id, "미이수")}
                              style={{ background: app.status === "미이수" ? "#ef4444" : "#ffffff", color: app.status === "미이수" ? "#ffffff" : "#ef4444", border: "1px solid #ef4444", padding: "0.3rem 0.65rem", borderRadius: "4px", fontSize: "0.78rem", fontWeight: 700, cursor: "pointer" }}
                            >
                              ✕ 미이수
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
