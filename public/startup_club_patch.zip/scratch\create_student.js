﻿const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const db = new Database('./dev.db');
const club = db.prepare("SELECT id FROM Club LIMIT 1").get();
const hashedPassword = bcrypt.hashSync('student123', 10);
const id = crypto.randomUUID();
const now = new Date().toISOString();

db.prepare(`
  INSERT INTO User (id, name, username, password, role, clubId, clubRole, enrollmentStatus, createdAt, updatedAt)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`).run(id, '김유학', 'student', hashedPassword, 'STUDENT', club.id, '팀원', '재학', now, now);

console.log('Created student user successfully with clubId:', club.id);
