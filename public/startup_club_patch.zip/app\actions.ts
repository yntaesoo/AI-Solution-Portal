"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";

export async function createClub(formData: FormData) {
  const name = formData.get("name") as string;
  const budget = parseFloat(formData.get("budget") as string) || 0;
  
  if (name) {
    await prisma.club.create({
      data: { name, budget }
    });
    revalidatePath("/");
  }
}

export async function updateClubBudget(clubId: string, budget: number) {
  await prisma.club.update({
    where: { id: clubId },
    data: { budget }
  });
  revalidatePath("/");
}

export async function addActivity(formData: FormData) {
  const clubId = formData.get("clubId") as string;
  const type = formData.get("type") as string;
  const status = formData.get("status") as string;
  const description = formData.get("description") as string;

  await prisma.activity.create({
    data: { clubId, type, status, description }
  });
  revalidatePath(`/club/${clubId}`);
  revalidatePath("/");
}

export async function addMentorLog(
  clubId: string,
  mentorId: string,
  content: string,
  sessionNumber?: string,
  consultationDate?: string,
  menteeNames?: string,
  nextSteps?: string
) {
  await prisma.mentorLog.create({
    data: {
      clubId,
      mentorId,
      content,
      sessionNumber: sessionNumber || null,
      consultationDate: consultationDate || null,
      menteeNames: menteeNames || null,
      nextSteps: nextSteps || null
    }
  });
  revalidatePath(`/club/${clubId}`);
}

export async function syncClubsFromExcel() {
  const xlsx = require('xlsx');
  const workbook = xlsx.readFile('h:/Create with Codex/창업관련/유학생창업동아리/2026 유학생 창업동아리 운영 현황.xlsx');
  const sheet = workbook.Sheets['운영 현황'];
  const data = xlsx.utils.sheet_to_json(sheet, { header: 1 });
  const rows = data.slice(5);

  for (const row of rows) {
    if (row.length === 0) continue;
    const clubName = row[2];
    if (clubName && clubName.trim() !== '' && clubName !== '운영비') {
      let requestedBudget = typeof row[21] === 'number' ? row[21] : parseFloat(String(row[21] || '0').replace(/,/g, '')) || 0;
      let budget = typeof row[22] === 'number' ? row[22] : parseFloat(String(row[22] || '0').replace(/,/g, '')) || 0;
      let spentBudget = typeof row[23] === 'number' ? row[23] : parseFloat(String(row[23] || '0').replace(/,/g, '')) || 0;
      let remainingBudget = typeof row[24] === 'number' ? row[24] : parseFloat(String(row[24] || '0').replace(/,/g, '')) || 0;

      await prisma.club.update({
        where: { name: clubName },
        data: {
          requestedBudget,
          budget,
          spentBudget,
          remainingBudget
        }
      });
    }
  }
  revalidatePath("/dashboard");
  revalidatePath("/");
}

export async function syncClubsFromUploadedExcel(formData: FormData) {
  const file = formData.get("file") as File;
  if (!file) throw new Error("No file uploaded");

  const arrayBuffer = await file.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);

  const xlsx = require('xlsx');
  const workbook = xlsx.read(buffer, { type: 'buffer' });
  const sheet = workbook.Sheets['운영 현황'];
  if (!sheet) throw new Error("운영 현황 시트를 찾을 수 없습니다.");

  const data = xlsx.utils.sheet_to_json(sheet, { header: 1 });
  const rows = data.slice(5);

  for (const row of rows) {
    if (row.length === 0) continue;
    const clubName = row[2];
    const trimmedName = clubName ? String(clubName).trim() : '';
    
    if (trimmedName !== '' && trimmedName !== '운영비' && trimmedName !== '동아리명') {
      // Only process the row containing the budget information (usually row[22] is defined)
      if (row[22] !== undefined) {
        let requestedBudget = typeof row[22] === 'number' ? row[22] : parseFloat(String(row[22] || '0').replace(/,/g, '')) || 0;
        let budget = typeof row[23] === 'number' ? row[23] : parseFloat(String(row[23] || '0').replace(/,/g, '')) || 0;
        let spentBudget = typeof row[24] === 'number' ? row[24] : parseFloat(String(row[24] || '0').replace(/,/g, '')) || 0;
        let remainingBudget = typeof row[25] === 'number' ? row[25] : parseFloat(String(row[25] || '0').replace(/,/g, '')) || 0;

        const existingClub = await prisma.club.findUnique({
          where: { name: trimmedName }
        });

        if (existingClub) {
          await prisma.club.update({
            where: { id: existingClub.id },
            data: {
              requestedBudget,
              budget,
              spentBudget,
              remainingBudget
            }
          });
        } else {
          console.warn(`Club not found during Excel sync: ${trimmedName}`);
        }
      }
    }
  }
  revalidatePath("/dashboard");
  revalidatePath("/");
}

export async function updateClubBudgets(clubs: any[]) {
  for (const club of clubs) {
    await prisma.club.update({
      where: { id: club.id },
      data: {
        requestedBudget: Number(club.requestedBudget) || 0,
        budget: Number(club.budget) || 0,
        spentBudget: Number(club.spentBudget) || 0,
        remainingBudget: Number(club.remainingBudget) || 0
      }
    });
  }
  revalidatePath("/dashboard");
  revalidatePath("/");
}

export async function addActivityAdvanced(clubId: string, type: string, status: string, details: string) {
  await prisma.activity.create({
    data: {
      clubId,
      type,
      status,
      description: details
    }
  });
  revalidatePath(`/club/${clubId}`);
  revalidatePath("/");
}

export async function registerUser(formData: FormData) {
  const username = formData.get("username") as string;
  const password = formData.get("password") as string;
  const name = formData.get("name") as string;
  const clubId = formData.get("clubId") as string;
  const role = formData.get("role") as string || "STUDENT";
  
  if (!username || !password || !name) return { error: "필수 항목을 입력하세요." };
  
  const existing = await prisma.user.findUnique({ where: { username } });
  if (existing) return { error: "이미 존재하는 아이디입니다." };

  const bcrypt = require("bcryptjs");
  const hashedPassword = await bcrypt.hash(password, 10);

  await prisma.user.create({
    data: {
      username,
      password: hashedPassword,
      name,
      role,
      clubId: clubId || null,
      isGraduated: false,
    }
  });

  return { success: true };
}

export async function updateMentorAssignments(mentors: any[]) {
  for (const m of mentors) {
    const existing = await prisma.mentorAssignment.findMany({
      where: { mentorId: m.id }
    });
    const existingClubIds = existing.map(e => e.clubId);
    const targetClubIds = m.assignedClubIds || [];

    // Add new assignments
    const toAdd = targetClubIds.filter((cid: string) => !existingClubIds.includes(cid));
    for (const cid of toAdd) {
      await prisma.mentorAssignment.create({
        data: {
          mentorId: m.id,
          clubId: cid
        }
      });
    }

    // Delete removed assignments
    const toDelete = existingClubIds.filter((cid: string) => !targetClubIds.includes(cid));
    if (toDelete.length > 0) {
      await prisma.mentorAssignment.deleteMany({
        where: {
          mentorId: m.id,
          clubId: { in: toDelete }
        }
      });
    }
  }
  revalidatePath("/dashboard");
  revalidatePath("/");
}

export async function updateMembers(members: any[]) {
  for (const member of members) {
    await prisma.user.update({
      where: { id: member.id },
      data: {
        department: member.department,
        college: member.college,
        grade: member.grade,
        englishName: member.englishName,
        studentId: member.studentId,
        email: member.email,
        phone: member.phone,
        enrollmentStatus: member.enrollmentStatus,
        clubRole: member.clubRole,
        advisor: member.advisor,
      }
    });
  }
  if (members.length > 0 && members[0].clubId) {
    revalidatePath(`/club/${members[0].clubId}`);
  }
}

export async function applyProgramAction(programId: string, userId: string) {
  const existing = await prisma.programApplication.findFirst({
    where: { programId, userId }
  });
  if (existing) {
    return { success: false, message: "이미 신청한 프로그램입니다." };
  }
  await prisma.programApplication.create({
    data: {
      programId,
      userId,
      status: "진행"
    }
  });
  revalidatePath("/dashboard");
  return { success: true };
}

export async function cancelProgramApplicationAction(applicationId: string) {
  await prisma.programApplication.delete({
    where: { id: applicationId }
  });
  revalidatePath("/dashboard");
  return { success: true };
}

export async function updateApplicationCompletionStatus(applicationId: string, status: string) {
  try {
    const existing = await prisma.programApplication.findUnique({
      where: { id: applicationId },
      include: {
        user: true,
        program: true
      }
    });

    if (existing) {
      await prisma.programApplication.update({
        where: { id: applicationId },
        data: { status }
      });

      // Synchronize with Club Activity History (의무 활동 내역)
      if (existing.user?.clubId) {
        const clubId = existing.user.clubId;
        const progTitle = existing.program.title;

        let actType = "창업교육";
        if (progTitle.includes("캠프")) actType = "창업캠프";
        else if (progTitle.includes("경진대회") || progTitle.includes("Festival")) actType = "창업경진대회";

        const descriptionData = JSON.stringify({
          programId: existing.programId,
          applicationId: existing.id,
          name: progTitle,
          studentName: existing.user.name,
          date: existing.program.operateEndDate || new Date().toISOString().split("T")[0],
          autoSynced: true
        });

        if (status === "이수") {
          const existingAct = await prisma.activity.findFirst({
            where: {
              clubId: clubId,
              description: { contains: existing.programId }
            }
          });

          if (existingAct) {
            await prisma.activity.update({
              where: { id: existingAct.id },
              data: {
                status: "완료",
                description: descriptionData
              }
            });
          } else {
            await prisma.activity.create({
              data: {
                clubId: clubId,
                type: actType,
                status: "완료",
                description: descriptionData,
                date: new Date()
              }
            });
          }
        } else {
          const existingAct = await prisma.activity.findFirst({
            where: {
              clubId: clubId,
              description: { contains: existing.programId }
            }
          });
          if (existingAct) {
            await prisma.activity.update({
              where: { id: existingAct.id },
              data: { status: "진행중" }
            });
          }
        }
      }
    }
  } catch (err) {
    console.error("updateApplicationCompletionStatus error:", err);
  }

  revalidatePath("/dashboard");
  revalidatePath("/");
  return { success: true };
}

export async function saveProgramAction(data: {
  id?: string;
  type: string;
  title: string;
  status: string;
  operateStartDate: string;
  operateEndDate: string;
  applyStartDate: string;
  applyEndDate: string;
  surveyStartDate?: string;
  surveyEndDate?: string;
  manager?: string;
  applyType?: string;
  applyTarget?: string;
  applyCategory?: string;
  maxRecruit?: number;
  maxPoint?: number;
  mydexUrl?: string;
  posterUrl?: string;
  attachedFile?: string;
  notice?: string;
  content?: string;
  surveyId?: string | null;
}) {
  if (data.id && data.id.length > 10) {
    await prisma.program.update({
      where: { id: data.id },
      data: {
        type: data.type,
        title: data.title,
        status: data.status,
        operateStartDate: data.operateStartDate,
        operateEndDate: data.operateEndDate,
        applyStartDate: data.applyStartDate,
        applyEndDate: data.applyEndDate,
        surveyStartDate: data.surveyStartDate || null,
        surveyEndDate: data.surveyEndDate || null,
        manager: data.manager || null,
        applyType: data.applyType || null,
        applyTarget: data.applyTarget || null,
        applyCategory: data.applyCategory || null,
        maxRecruit: data.maxRecruit || 20,
        maxPoint: data.maxPoint || 100,
        mydexUrl: data.mydexUrl || null,
        posterUrl: data.posterUrl || null,
        attachedFile: data.attachedFile || null,
        content: data.content || null,
        surveyId: data.surveyId || null
      }
    });

    if (data.surveyId) {
      await prisma.survey.updateMany({
        where: { id: data.surveyId },
        data: { programId: data.id }
      });
    }
  } else {
    const created = await prisma.program.create({
      data: {
        type: data.type,
        title: data.title,
        status: data.status,
        operateStartDate: data.operateStartDate,
        operateEndDate: data.operateEndDate,
        applyStartDate: data.applyStartDate,
        applyEndDate: data.applyEndDate,
        surveyStartDate: data.surveyStartDate || null,
        surveyEndDate: data.surveyEndDate || null,
        manager: data.manager || "관리자",
        applyType: data.applyType || "오프라인",
        applyTarget: data.applyTarget || "전체",
        applyCategory: data.applyCategory || "팀",
        maxRecruit: data.maxRecruit || 20,
        maxPoint: data.maxPoint || 100,
        mydexUrl: data.mydexUrl || null,
        posterUrl: data.posterUrl || "https://placehold.co/300x420/2563eb/ffffff?text=Program",
        attachedFile: data.attachedFile || "안내문.pdf",
        content: data.content || null,
        surveyId: data.surveyId || null
      }
    });

    if (data.surveyId) {
      await prisma.survey.updateMany({
        where: { id: data.surveyId },
        data: { programId: created.id }
      });
    }
  }
  revalidatePath("/dashboard");
  revalidatePath("/");
  return { success: true };
}

export async function deleteProgramAction(programId: string) {
  await prisma.program.delete({
    where: { id: programId }
  });
  revalidatePath("/dashboard");
  revalidatePath("/");
  return { success: true };
}

export async function updateProgramStatusAction(programId: string, status: string) {
  await prisma.program.update({
    where: { id: programId },
    data: { status }
  });
  revalidatePath("/dashboard");
  revalidatePath("/");
  return { success: true };
}

// -------------------- SATISFACTION SURVEY ACTIONS --------------------

export async function saveSurveyAction(data: {
  id?: string;
  programId?: string | null;
  respondentType: "동아리" | "멘토" | "학생";
  title: string;
  description?: string;
  status: "사용" | "사용안함";
  author?: string;
  questions: Array<{ id: number; type: string; text: string }>;
}) {
  const questionsJson = JSON.stringify(data.questions || []);

  if (data.id) {
    const existing = await prisma.survey.findUnique({ where: { id: data.id } });
    if (existing) {
      await prisma.survey.update({
        where: { id: data.id },
        data: {
          programId: data.programId || null,
          respondentType: data.respondentType,
          title: data.title,
          description: data.description || null,
          status: data.status,
          author: data.author || "라이즈사업단",
          questions: questionsJson
        }
      });

      if (data.programId) {
        await prisma.program.updateMany({
          where: { id: data.programId },
          data: { surveyId: data.id }
        });
      }

      revalidatePath("/dashboard");
      return { success: true, id: data.id };
    }
  }

  const created = await prisma.survey.create({
    data: {
      programId: data.programId || null,
      respondentType: data.respondentType,
      title: data.title,
      description: data.description || null,
      status: data.status,
      author: data.author || "라이즈사업단",
      questions: questionsJson
    }
  });

  if (data.programId) {
    await prisma.program.updateMany({
      where: { id: data.programId },
      data: { surveyId: created.id }
    });
  }

  revalidatePath("/dashboard");
  return { success: true, id: created.id };
}

export async function deleteSurveyAction(surveyId: string) {
  // Disconnect from any program using this survey
  await prisma.program.updateMany({
    where: { surveyId },
    data: { surveyId: null }
  });

  await prisma.survey.delete({
    where: { id: surveyId }
  });

  revalidatePath("/dashboard");
  return { success: true };
}

export async function linkProgramSurveyAction(programId: string, surveyId: string | null) {
  await prisma.program.update({
    where: { id: programId },
    data: { surveyId }
  });

  if (surveyId) {
    await prisma.survey.update({
      where: { id: surveyId },
      data: { programId }
    });
  }

  revalidatePath("/dashboard");
  return { success: true };
}

export async function submitSurveyAction(
  applicationId: string,
  rating: number,
  feedback: string,
  surveyId?: string,
  answers?: any
) {
  const application = await prisma.programApplication.findUnique({
    where: { id: applicationId },
    include: { program: true }
  });

  if (!application) {
    throw new Error("신청 정보를 찾을 수 없습니다.");
  }

  const effectiveSurveyId = surveyId || application.program.surveyId;

  if (effectiveSurveyId) {
    const survey = await prisma.survey.findUnique({ where: { id: effectiveSurveyId } });
    if (survey) {
      await prisma.surveyResponse.create({
        data: {
          surveyId: effectiveSurveyId,
          userId: application.userId,
          programId: application.programId,
          applicationId: application.id,
          answers: JSON.stringify(answers || { rating, feedback })
        }
      });
    }
  }

  await prisma.programApplication.update({
    where: { id: applicationId },
    data: {
      surveyDone: true
    }
  });

  revalidatePath("/dashboard");
  return { success: true };
}

