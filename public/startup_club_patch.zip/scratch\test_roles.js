﻿const http = require('http');

async function loginAndGetCookie(username, password) {
  // 1. Get csrf token
  const csrfRes = await fetch('http://localhost:3004/StartupClub/api/auth/csrf');
  const csrfData = await csrfRes.json();
  const csrfToken = csrfData.csrfToken;
  const cookieHeader = csrfRes.headers.get('set-cookie');

  // 2. Post credentials
  const params = new URLSearchParams();
  params.append('username', username);
  params.append('password', password);
  params.append('csrfToken', csrfToken);
  params.append('callbackUrl', 'http://localhost:3004/StartupClub/dashboard');
  params.append('json', 'true');

  const signinRes = await fetch('http://localhost:3004/StartupClub/api/auth/callback/credentials', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Cookie': cookieHeader || ''
    },
    body: params.toString(),
    redirect: 'manual'
  });

  const sessionCookie = signinRes.headers.get('set-cookie');
  return sessionCookie || cookieHeader;
}

async function fetchWithCookie(url, cookie) {
  const res = await fetch(url, {
    headers: {
      'Cookie': cookie || ''
    }
  });
  const text = await res.text();
  return { status: res.status, text };
}

async function testRoles() {
  console.log("=== Testing Admin Flow ===");
  const adminCookie = await loginAndGetCookie('admin', 'admin123');
  console.log("Admin logged in. Fetching /dashboard ...");
  const adminDash = await fetchWithCookie('http://localhost:3004/StartupClub/dashboard', adminCookie);
  console.log("Admin Dashboard status:", adminDash.status, "Length:", adminDash.text.length);
  
  const hasAdminPortal = adminDash.text.includes('창업지원센터 포털') || adminDash.text.includes('Startup Support Portal');
  const hasLangToggle = adminDash.text.includes('English') || adminDash.text.includes('한국어');
  console.log("Admin Dashboard has portal title:", hasAdminPortal);
  console.log("Admin Dashboard has LangToggle:", hasLangToggle);

  console.log("\n=== Testing Student Flow ===");
  const studentCookie = await loginAndGetCookie('student', 'student123');
  console.log("Student logged in. Fetching /dashboard ...");
  const studentDash = await fetchWithCookie('http://localhost:3004/StartupClub/dashboard', studentCookie);
  console.log("Student Dashboard status:", studentDash.status, "Length:", studentDash.text.length);

  const hasStudentBanner = studentDash.text.includes('학생 대시보드') || studentDash.text.includes('Student Startup Club Dashboard');
  console.log("Student Dashboard has banner:", hasStudentBanner);

  console.log("\n=== Testing Club Detail Page ===");
  // Find a club ID from DB or fetch
  const { PrismaClient } = require('@prisma/client');
  const prisma = new PrismaClient();
  const firstClub = await prisma.club.findFirst();
  if (firstClub) {
    console.log("Testing club detail for club:", firstClub.name, `(${firstClub.id})`);
    const clubRes = await fetchWithCookie(`http://localhost:3004/StartupClub/club/${firstClub.id}`, adminCookie);
    console.log("Club Page status:", clubRes.status, "Length:", clubRes.text.length);
    const hasBackLink = clubRes.text.includes('대시보드로 돌아가기') || clubRes.text.includes('Back to Dashboard');
    console.log("Club Page has back link:", hasBackLink);
  }
  await prisma.$disconnect();

  console.log("\n✅ ALL ROLE FLOWS TESTED SUCCESSFULLY!");
}

testRoles().catch(err => console.error("Test failed:", err));
