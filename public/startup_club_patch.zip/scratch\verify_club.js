﻿const http = require('http');
const querystring = require('querystring');
const Database = require('better-sqlite3');

function makeRequest(options, postData) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          data
        });
      });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function login(username, password) {
  const csrfRes = await makeRequest({
    hostname: '127.0.0.1',
    port: 3004,
    path: '/StartupClub/api/auth/csrf',
    method: 'GET'
  });
  const csrfData = JSON.parse(csrfRes.data);
  const csrfToken = csrfData.csrfToken;
  const initialCookies = csrfRes.headers['set-cookie'] || [];
  const cookieStr1 = initialCookies.map(c => c.split(';')[0]).join('; ');

  const postData = querystring.stringify({
    username,
    password,
    csrfToken,
    redirect: 'false',
    callbackUrl: '/StartupClub/dashboard',
    json: 'true'
  });

  const loginRes = await makeRequest({
    hostname: '127.0.0.1',
    port: 3004,
    path: '/StartupClub/api/auth/callback/credentials',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(postData),
      'Cookie': cookieStr1
    }
  }, postData);

  const loginCookies = loginRes.headers['set-cookie'] || [];
  return [...initialCookies, ...loginCookies].map(c => c.split(';')[0]).join('; ');
}

async function verifyClub() {
  const adminCookie = await login('admin', 'admin123');
  const db = new Database('./dev.db');
  const club = db.prepare("SELECT id, name FROM Club LIMIT 1").get();
  console.log("Testing Club Detail for:", club.name, `(${club.id})`);

  const clubRes = await makeRequest({
    hostname: '127.0.0.1',
    port: 3004,
    path: `/StartupClub/club/${club.id}`,
    method: 'GET',
    headers: { 'Cookie': adminCookie }
  });

  console.log("Club Page HTTP:", clubRes.statusCode, "Length:", clubRes.data.length);
  const hasBackLink = clubRes.data.includes('대시보드로 돌아가기') || clubRes.data.includes('Back to Dashboard');
  const hasClubName = clubRes.data.includes(club.name);
  const hasMemberCard = clubRes.data.includes('소속 팀원') || clubRes.data.includes('Team Members');
  const hasPlanCard = clubRes.data.includes('사업계획서 및 아이템 정보') || clubRes.data.includes('Business Plan');

  console.log(" - Has Back Link:", hasBackLink);
  console.log(" - Has Club Name:", hasClubName);
  console.log(" - Has Member Card:", hasMemberCard);
  console.log(" - Has Plan Card:", hasPlanCard);

  if (clubRes.statusCode === 200 && hasBackLink && hasClubName && hasMemberCard && hasPlanCard) {
    console.log("🎉 CLUB DETAIL PAGE VERIFICATION PASSED!");
  } else {
    console.error("❌ CLUB DETAIL PAGE VERIFICATION FAILED");
  }
}

verifyClub().catch(console.error);
