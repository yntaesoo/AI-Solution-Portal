﻿const Database = require('better-sqlite3');
const db = new Database('./dev.db');
const cols = db.prepare("PRAGMA table_info(User)").all();
console.log('User columns:', cols.map(c => c.name));
