import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { prisma } from "./prisma";

export const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
  },
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        username: { label: "Username", type: "text", placeholder: "student123" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        if (!credentials?.username || !credentials?.password) {
          return null;
        }

        const cleanUsername = credentials.username.trim();
        const cleanPassword = credentials.password.trim();

        const user = await prisma.user.findFirst({
          where: {
            OR: [
              { username: cleanUsername },
              { username: cleanUsername.toLowerCase() }
            ]
          }
        });

        if (!user) {
          return null;
        }

        const isPasswordValid = await bcrypt.compare(cleanPassword, user.password);

        if (!isPasswordValid) {
          return null;
        }

        return {
          id: user.id,
          name: user.name,
          username: user.username,
          role: user.role,
          clubId: user.clubId
        };
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = (user as any).role;
        token.clubId = (user as any).clubId;
      }
      return token;
    },
    async session({ session, token }) {
      if (token) {
        session.user = {
          ...session.user,
          id: token.id as string,
          role: token.role as string,
          clubId: token.clubId as string | null
        };
      }
      return session;
    },
    async redirect({ url, baseUrl }) {
      const baseWithPrefix = baseUrl.endsWith('/StartupClub') ? baseUrl : `${baseUrl}/StartupClub`;
      if (url.startsWith('/')) {
        const cleanPath = url.startsWith('/StartupClub') ? url.slice('/StartupClub'.length) : url;
        return `${baseWithPrefix}${cleanPath}`;
      }
      try {
        const u = new URL(url);
        const b = new URL(baseUrl);
        if (u.origin === b.origin) {
          return url;
        }
      } catch {}
      return `${baseWithPrefix}/dashboard`;
    }
  },
  pages: {
    signIn: '/StartupClub/login',
  }
};
