const http = require("http");
const fs = require("fs");
const path = require("path");

const filePath = path.join(__dirname, "..", "patches", "startup_club_patch.zip");

const server = http.createServer((req, res) => {
  if (req.url === "/startup_club_patch.zip" || req.url === "/") {
    if (!fs.existsSync(filePath)) {
      res.writeHead(404, { "Content-Type": "text/plain" });
      res.end("File not found");
      return;
    }
    const stat = fs.statSync(filePath);
    res.writeHead(200, {
      "Content-Type": "application/zip",
      "Content-Length": stat.size,
      "Content-Disposition": 'attachment; filename="startup_club_patch.zip"'
    });
    fs.createReadStream(filePath).pipe(res);
  } else {
    res.writeHead(404);
    res.end();
  }
});

server.listen(8099, "0.0.0.0", () => {
  console.log("Patch Download Server running on port 8099");
});
