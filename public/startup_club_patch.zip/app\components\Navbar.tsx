"use client";

import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { useLanguage } from "@/lib/i18n/LanguageContext";

export default function Navbar() {
  const { data: session, status } = useSession();
  const { locale, toggleLanguage, t } = useLanguage();

  const handleLogout = async () => {
    try {
      // 1. Call custom logout API to invalidate all server cookies
      await fetch("/StartupClub/api/logout", { method: "POST" });
    } catch (e) {
      console.error("Logout API error:", e);
    } finally {
      // 2. Clear client document cookies
      try {
        document.cookie.split(";").forEach((c) => {
          document.cookie = c
            .replace(/^ +/, "")
            .replace(/=.*/, "=;expires=" + new Date(0).toUTCString() + ";path=/");
          document.cookie = c
            .replace(/^ +/, "")
            .replace(/=.*/, "=;expires=" + new Date(0).toUTCString() + ";path=/StartupClub");
        });
      } catch (err) {
        console.error("Client cookie cleanup error:", err);
      }

      // 3. Inform NextAuth client of signout
      await signOut({ callbackUrl: "/StartupClub/login", redirect: false });

      // 4. Perform hard redirect with cache buster
      window.location.href = "/StartupClub/login?t=" + Date.now();
    }
  };

  const isLoading = status === "loading";
  const user = session?.user;

  const roleText = (role?: string) => {
    if (role === "ADMIN") return t("nav.role.admin");
    if (role === "MENTOR") return t("nav.role.mentor");
    return t("nav.role.student");
  };

  return (
    <nav style={{ background: "#fff", borderBottom: "1px solid #e5e7eb", padding: "1rem" }}>
      <div
        className="container"
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "0 1.5rem",
          margin: "0 auto",
        }}
      >
        <div style={{ fontWeight: 700, color: "var(--primary)", fontSize: "1.25rem" }}>
          <Link href="/" style={{ textDecoration: "none", color: "inherit" }}>
            {t("nav.title")}
          </Link>
        </div>
        <div style={{ display: "flex", gap: "1rem", alignItems: "center" }}>
          {user ? (
            <>
              <Link
                href="/dashboard"
                style={{ fontSize: "0.875rem", color: "var(--primary)", fontWeight: 600, textDecoration: "none" }}
              >
                {t("nav.dashboard")}
              </Link>
              <span style={{ fontSize: "0.875rem", color: "var(--text-secondary)" }}>
                {user.name} ({roleText(user.role)})
              </span>
              <button
                type="button"
                onClick={handleLogout}
                className="btn"
                style={{
                  background: "#f3f4f6",
                  cursor: "pointer",
                  padding: "0.5rem 1rem",
                  borderRadius: "6px",
                  border: "1px solid #d1d5db",
                  fontSize: "0.875rem",
                }}
              >
                {t("nav.logout")}
              </button>
            </>
          ) : (
            <>
              <Link
                href="/register"
                style={{ fontSize: "0.875rem", color: "var(--text-secondary)", textDecoration: "none" }}
              >
                {t("nav.register.student")}
              </Link>
              <Link
                href="/register/mentor"
                style={{ fontSize: "0.875rem", color: "var(--text-secondary)", textDecoration: "none" }}
              >
                {t("nav.register.mentor")}
              </Link>
              <Link
                href="/login"
                style={{ fontSize: "0.875rem", color: "var(--primary)", fontWeight: 600, textDecoration: "none" }}
              >
                {t("nav.login")}
              </Link>
            </>
          )}

          {/* 🌐 Language Switcher Button */}
          <button
            type="button"
            onClick={toggleLanguage}
            title={locale === "ko" ? "Switch to English" : "한국어로 전환"}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "0.4rem",
              padding: "0.4rem 0.85rem",
              borderRadius: "20px",
              border: "1.5px solid #3b82f6",
              background: "#eff6ff",
              color: "#1e40af",
              fontWeight: 700,
              fontSize: "0.825rem",
              cursor: "pointer",
              transition: "all 0.2s ease",
              boxShadow: "0 2px 6px rgba(59,130,246,0.15)",
              flexShrink: 0
            }}
          >
            <span>🌐</span>
            <span>{locale === "ko" ? "English" : "한국어"}</span>
          </button>
        </div>
      </div>
    </nav>
  );
}
