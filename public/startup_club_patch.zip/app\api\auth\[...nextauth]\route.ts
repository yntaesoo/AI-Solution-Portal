import NextAuth from "next-auth";
import { authOptions } from "@/lib/auth";
import { NextRequest } from "next/server";

async function handler(req: NextRequest, ctx: any) {
  const host = req.headers.get("x-forwarded-host") || req.headers.get("host") || "localhost:3004";
  const proto = req.headers.get("x-forwarded-proto") || "http";
  process.env.NEXTAUTH_URL = `${proto}://${host}/StartupClub`;

  return NextAuth(req as any, ctx as any, authOptions);
}

export { handler as GET, handler as POST };

