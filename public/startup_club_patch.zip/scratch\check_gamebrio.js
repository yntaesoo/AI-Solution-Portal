const { PrismaClient } = require('@prisma/client');
const { PrismaBetterSqlite3 } = require('@prisma/adapter-better-sqlite3');
const adapter = new PrismaBetterSqlite3({ url: "file:./dev.db" });
const prisma = new PrismaClient({ adapter });

async function main() {
  const users = await prisma.user.findMany();
  console.log('Total users:', users.length);
  const student = users.find(u => u.username === 'gamebrio' || u.name.includes('gamebrio'));
  console.log('Found gamebrio user:', student);

  const programs = await prisma.program.findMany();
  console.log('Total Programs in DB:', programs.length);
  console.log('Programs:', programs);
}

main().catch(console.error).finally(() => prisma.$disconnect());
