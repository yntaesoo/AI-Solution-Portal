"use client";

import { useState } from "react";
import Link from "next/link";
import { applyProgramAction, cancelProgramApplicationAction, submitSurveyAction } from "@/app/actions";
import { useLanguage } from "@/lib/i18n/LanguageContext";

interface Program {
  id: string;
  type: string;
  title: string;
  status: string;
  operateStartDate: string;
  operateEndDate: string;
  applyStartDate: string;
  applyEndDate: string;
  applyType?: string | null;
  manager?: string | null;
  maxRecruit?: number;
  posterUrl?: string | null;
  surveyId?: string | null;
}

interface Application {
  id: string;
  programId: string;
  program: Program;
  status: string; // "진행", "이수", "미이수"
  surveyDone: boolean;
  appliedAt: Date | string;
}

interface StudentDashboardClientProps {
  user: {
    id: string;
    name: string;
    clubId?: string | null;
    clubName?: string | null;
  };
  programs: Program[];
  initialApplications: Application[];
  surveys?: any[];
}

export default function StudentDashboardClient({
  user,
  programs,
  initialApplications,
  surveys = []
}: StudentDashboardClientProps) {
  const { t } = useLanguage();
  const [applications, setApplications] = useState<Application[]>(initialApplications);
  const [searchKeyword, setSearchKeyword] = useState("");
  const [selectedType, setSelectedType] = useState("전체");
  const [activeSurveyApp, setActiveSurveyApp] = useState<Application | null>(null);
  const [surveyScore, setSurveyScore] = useState(5);
  const [surveyComment, setSurveyComment] = useState("");
  const [dynamicAnswers, setDynamicAnswers] = useState<Record<number, any>>({});

  // Check if student applied to program
  const isApplied = (programId: string) => {
    return applications.some(a => a.programId === programId);
  };

  const handleApply = async (programId: string) => {
    const res = await applyProgramAction(programId, user.id);
    if (!res.success) {
      alert(res.message);
      return;
    }
    alert("지원프로그램 신청이 완료되었습니다!");
    // Optimistic refresh
    const targetProg = programs.find(p => p.id === programId);
    if (targetProg) {
      const newApp: Application = {
        id: String(Date.now()),
        programId: targetProg.id,
        program: targetProg,
        status: "진행",
        surveyDone: false,
        appliedAt: new Date().toISOString()
      };
      setApplications(prev => [newApp, ...prev]);
    }
  };

  const handleCancel = async (applicationId: string) => {
    if (!confirm("정말 이 지원프로그램 신청을 취소하시겠습니까?")) return;
    await cancelProgramApplicationAction(applicationId);
    setApplications(prev => prev.filter(a => a.id !== applicationId));
    alert("신청이 취소되었습니다.");
  };

  const openSurveyModal = (app: Application) => {
    setActiveSurveyApp(app);
    setSurveyScore(5);
    setSurveyComment("");

    const linkedSurvey = surveys.find((s: any) =>
      (app.program.surveyId && s.id === app.program.surveyId) ||
      s.programId === app.programId
    );

    const initialDyn: Record<number, any> = {};
    if (linkedSurvey && linkedSurvey.questions) {
      linkedSurvey.questions.forEach((q: any) => {
        if (q.type === "평가형") initialDyn[q.id] = 5;
        else if (q.type === "객관식") initialDyn[q.id] = "매우 만족";
        else if (q.type === "주관식") initialDyn[q.id] = "";
      });
    }
    setDynamicAnswers(initialDyn);
  };

  const handleSurveySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSurveyApp) return;

    const linkedSurvey = surveys.find((s: any) =>
      (activeSurveyApp.program.surveyId && s.id === activeSurveyApp.program.surveyId) ||
      s.programId === activeSurveyApp.programId
    );

    try {
      await submitSurveyAction(
        activeSurveyApp.id,
        surveyScore,
        surveyComment,
        linkedSurvey?.id,
        dynamicAnswers
      );
    } catch (err) {
      console.error(err);
    }
    setApplications(prev => prev.map(a => a.id === activeSurveyApp.id ? { ...a, surveyDone: true } : a));
    alert("만족도 조사가 성공적으로 제출되었습니다. 감사합니다!");
    setActiveSurveyApp(null);
  };

  // Filter applications
  const filteredApps = applications.filter(app => {
    const matchKeyword = app.program.title.toLowerCase().includes(searchKeyword.toLowerCase());
    const matchType = selectedType === "전체" || app.program.applyType === selectedType || app.program.type === selectedType;
    return matchKeyword && matchType;
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "2rem", paddingBottom: "3rem" }}>
      
      {/* -------------------- HERO / TOP HEADER BANNER -------------------- */}
      <div
        style={{
          background: "linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)",
          borderRadius: "16px",
          padding: "2rem",
          color: "#ffffff",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: "1.5rem",
          boxShadow: "0 10px 25px rgba(37,99,235,0.15)"
        }}
      >
        <div>
          <div style={{ display: "inline-block", background: "rgba(255,255,255,0.2)", padding: "0.3rem 0.8rem", borderRadius: "20px", fontSize: "0.8rem", fontWeight: 700, marginBottom: "0.75rem", backdropFilter: "blur(4px)" }}>
            {t("student.banner.badge")}
          </div>
          <h1 style={{ fontSize: "2rem", fontWeight: 800, margin: 0, color: "#ffffff" }}>
            {user.name} {t("student.banner.welcome")}
          </h1>
          <p style={{ margin: "0.5rem 0 0 0", opacity: 0.9, fontSize: "0.95rem" }}>
            {t("student.banner.club")} <strong>{user.clubName || "창업동아리"}</strong> | {t("student.banner.desc")}
          </p>
        </div>

        {/* Go to My Club Page Navigation Button */}
        <div>
          {user.clubId ? (
            <Link
              href={`/club/${user.clubId}`}
              style={{
                background: "#ffffff",
                color: "#1e3a8a",
                border: "none",
                padding: "0.85rem 1.75rem",
                borderRadius: "30px",
                fontWeight: 800,
                fontSize: "1rem",
                textDecoration: "none",
                display: "inline-flex",
                alignItems: "center",
                gap: "0.6rem",
                boxShadow: "0 4px 15px rgba(0,0,0,0.15)",
                transition: "transform 0.15s ease"
              }}
            >
              {t("student.banner.btnMyClub")}
            </Link>
          ) : (
            <span style={{ background: "rgba(255,255,255,0.2)", padding: "0.6rem 1.25rem", borderRadius: "8px", fontSize: "0.9rem" }}>
              {t("student.banner.noClub")}
            </span>
          )}
        </div>
      </div>

      {/* -------------------- SECTION 1: ONGOING PROGRAMS ANNOUNCEMENT -------------------- */}
      <div style={{ background: "#ffffff", padding: "1.75rem", borderRadius: "16px", border: "1px solid #e2e8f0", boxShadow: "0 4px 16px rgba(0,0,0,0.02)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.5rem" }}>
          <div>
            <h2 style={{ fontSize: "1.3rem", fontWeight: 800, margin: 0, color: "#1e293b", display: "flex", alignItems: "center", gap: "0.5rem" }}>
              {t("student.section1.title")}
            </h2>
            <p style={{ margin: "0.2rem 0 0 0", fontSize: "0.85rem", color: "#64748b" }}>
              {t("student.section1.desc")}
            </p>
          </div>
          <span style={{ fontSize: "0.85rem", fontWeight: 600, color: "#2563eb" }}>
            {t("student.section1.totalRecruit", { count: programs.length })}
          </span>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: "1.25rem" }}>
          {programs.map(prog => {
            const applied = isApplied(prog.id);
            return (
              <div
                key={prog.id}
                style={{
                  border: "1px solid #e2e8f0",
                  borderRadius: "12px",
                  padding: "1.25rem",
                  background: "#fafafa",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "space-between",
                  transition: "all 0.15s ease",
                  boxShadow: "0 2px 8px rgba(0,0,0,0.01)"
                }}
              >
                <div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "0.75rem" }}>
                    <span style={{ background: prog.type === "MYDEX" ? "#eff6ff" : "#f0fdf4", color: prog.type === "MYDEX" ? "#2563eb" : "#16a34a", padding: "0.3rem 0.75rem", borderRadius: "20px", fontSize: "0.78rem", fontWeight: 700, border: `1px solid ${prog.type === "MYDEX" ? "#bfdbfe" : "#bbf7d0"}` }}>
                      {prog.type} ({prog.applyType || "오프라인"})
                    </span>
                    <span style={{ fontSize: "0.8rem", color: "#64748b", fontWeight: 600 }}>
                      {t("student.card.recruitCount", { count: prog.maxRecruit || 20 })}
                    </span>
                  </div>

                  <h3 style={{ fontSize: "1.05rem", fontWeight: 700, color: "#1e293b", margin: "0 0 0.75rem 0", lineHeight: 1.4 }}>
                    {prog.title}
                  </h3>

                  <div style={{ fontSize: "0.825rem", color: "#475569", display: "flex", flexDirection: "column", gap: "0.3rem", background: "#ffffff", padding: "0.75rem", borderRadius: "8px", border: "1px solid #f1f5f9" }}>
                    <div><strong>{t("student.card.applyPeriod")}</strong> {prog.applyStartDate} ~ {prog.applyEndDate}</div>
                    <div><strong>{t("student.card.operatePeriod")}</strong> {prog.operateStartDate} ~ {prog.operateEndDate}</div>
                    <div><strong>{t("student.card.manager")}</strong> {prog.manager || "창업지원단"}</div>
                  </div>
                </div>

                <div style={{ marginTop: "1.25rem" }}>
                  {applied ? (
                    <button
                      disabled
                      style={{ width: "100%", padding: "0.65rem", background: "#e2e8f0", color: "#64748b", border: "none", borderRadius: "8px", fontWeight: 700, fontSize: "0.9rem", cursor: "not-allowed" }}
                    >
                      {t("student.btn.applied")}
                    </button>
                  ) : (
                    <button
                      onClick={() => handleApply(prog.id)}
                      style={{ width: "100%", padding: "0.65rem", background: "#2563eb", color: "#ffffff", border: "none", borderRadius: "8px", fontWeight: 700, fontSize: "0.9rem", cursor: "pointer", boxShadow: "0 4px 12px rgba(37,99,235,0.2)" }}
                    >
                      {t("student.btn.apply")}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* -------------------- SECTION 2: APPLICATION HISTORY -------------------- */}
      <div style={{ background: "#ffffff", padding: "2rem", borderRadius: "16px", border: "1px solid #e2e8f0", boxShadow: "0 4px 16px rgba(0,0,0,0.02)" }}>
        
        {/* Title */}
        <h2 style={{ textAlign: "center", fontSize: "1.8rem", fontWeight: 900, color: "#1e293b", margin: "0 0 2rem 0", letterSpacing: "1px" }}>
          {t("student.section2.title")}
        </h2>

        {/* Filter and Search Bar */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.25rem", flexWrap: "wrap", gap: "1rem" }}>
          
          {/* Total Badge Pill */}
          <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", padding: "0.4rem 1.2rem", borderRadius: "30px", fontSize: "0.9rem", fontWeight: 600, boxShadow: "0 2px 6px rgba(0,0,0,0.02)" }}>
            {t("student.filter.total")} <strong style={{ color: "#ef4444" }}>{filteredApps.length}</strong>
          </div>

          {/* Category Dropdown & Search Input */}
          <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
            <select
              value={selectedType}
              onChange={e => setSelectedType(e.target.value)}
              style={{ padding: "0.55rem 1rem", border: "1px solid #cbd5e1", borderRadius: "30px", fontSize: "0.875rem", background: "#ffffff", color: "#334155", outline: "none" }}
            >
              <option value="전체">{t("student.filter.all")}</option>
              <option value="오프라인">{t("student.filter.offline")}</option>
              <option value="온라인">{t("student.filter.online")}</option>
              <option value="MYDEX">MYDEX</option>
            </select>

            <div style={{ position: "relative", width: "260px" }}>
              <input
                type="text"
                placeholder={t("student.search.placeholder")}
                value={searchKeyword}
                onChange={e => setSearchKeyword(e.target.value)}
                style={{ width: "100%", padding: "0.55rem 2.5rem 0.55rem 1rem", border: "1px solid #cbd5e1", borderRadius: "30px", fontSize: "0.875rem", outline: "none" }}
              />
              <span style={{ position: "absolute", right: "12px", top: "50%", transform: "translateY(-50%)", color: "#64748b", fontSize: "1rem" }}>
                🔍
              </span>
            </div>
          </div>
        </div>

        {/* Application History Table */}
        <div className="table-container" style={{ overflowX: "auto", borderTop: "2px solid #1e3a8a" }}>
          <table style={{ minWidth: "960px", width: "100%", borderCollapse: "collapse", fontSize: "0.9rem", textAlign: "center" }}>
            <thead>
              <tr style={{ background: "#f8fafc", borderBottom: "1px solid #e2e8f0", color: "#1e293b", fontWeight: 700, height: "50px" }}>
                <th style={{ width: "60px", whiteSpace: "nowrap" }}>{t("student.table.no")}</th>
                <th style={{ width: "110px", whiteSpace: "nowrap" }}>{t("student.table.type")}</th>
                <th style={{ textAlign: "center", padding: "0 1rem", minWidth: "220px", whiteSpace: "nowrap" }}>{t("student.table.title")}</th>
                <th style={{ width: "240px", whiteSpace: "nowrap" }}>{t("student.table.period")}</th>
                <th style={{ width: "120px", whiteSpace: "nowrap" }}>{t("student.table.result")}</th>
                <th style={{ width: "130px", whiteSpace: "nowrap" }}>{t("student.table.survey")}</th>
                <th style={{ width: "90px", whiteSpace: "nowrap" }}>{t("student.table.cancel")}</th>
              </tr>
            </thead>
            <tbody>
              {filteredApps.length === 0 ? (
                <tr>
                  <td colSpan={7} style={{ padding: "3rem", color: "#94a3b8" }}>
                    {t("student.table.empty")}
                  </td>
                </tr>
              ) : (
                filteredApps.map((app, idx) => {
                  const isCompleted = app.status === "이수";
                  const isIncomplete = app.status === "미이수";

                  return (
                    <tr key={app.id} style={{ borderBottom: "1px solid #f1f5f9", height: "65px", color: "#334155" }}>
                      {/* No */}
                      <td style={{ fontWeight: 500 }}>{idx + 1}</td>

                      {/* 유형 */}
                      <td>{app.program.applyType || app.program.type || "오프라인"}</td>

                      {/* 프로그램명 */}
                      <td style={{ textAlign: "center", fontWeight: 600, color: "#1e293b", padding: "0 1rem" }}>
                        {app.program.title}
                      </td>

                      {/* 교육기간 */}
                      <td style={{ fontSize: "0.825rem", color: "#475569", textAlign: "left", paddingLeft: "1rem" }}>
                        <div>시작 : {app.program.operateStartDate}</div>
                        <div>종료 : {app.program.operateEndDate}</div>
                      </td>

                      {/* 이수결과 */}
                      <td>
                        <span
                          style={{
                            display: "inline-block",
                            padding: "0.3rem 0.85rem",
                            borderRadius: "4px",
                            border: `1px solid ${isCompleted ? "#16a34a" : isIncomplete ? "#ef4444" : "#94a3b8"}`,
                            background: isCompleted ? "#f0fdf4" : isIncomplete ? "#fef2f2" : "#ffffff",
                            color: isCompleted ? "#16a34a" : isIncomplete ? "#ef4444" : "#475569",
                            fontSize: "0.85rem",
                            fontWeight: 700
                          }}
                        >
                          {isCompleted ? t("student.status.completed") : app.status}
                        </span>
                      </td>

                      {/* 만족도조사 */}
                      <td>
                        <button
                          onClick={() => openSurveyModal(app)}
                          style={{
                            background: app.surveyDone ? "#f1f5f9" : "#ffffff",
                            border: "1px solid #cbd5e1",
                            color: app.surveyDone ? "#94a3b8" : "#475569",
                            padding: "0.4rem 0.85rem",
                            borderRadius: "4px",
                            fontSize: "0.825rem",
                            fontWeight: 500,
                            cursor: "pointer",
                            display: "inline-flex",
                            alignItems: "center",
                            gap: "0.3rem"
                          }}
                        >
                          {app.surveyDone ? t("student.btn.surveyDone") : t("student.btn.surveyWrite")}
                        </button>
                      </td>

                      {/* 취소 */}
                      <td>
                        <button
                          onClick={() => handleCancel(app.id)}
                          style={{
                            background: "#ffffff",
                            border: "1px solid #fca5a5",
                            color: "#ef4444",
                            padding: "0.4rem 0.85rem",
                            borderRadius: "4px",
                            fontSize: "0.825rem",
                            fontWeight: 600,
                            cursor: "pointer"
                          }}
                        >
                          {t("student.btn.cancelAction")}
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar (Matching Screenshot 2 bottom pagination) */}
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "0.5rem", marginTop: "1.75rem" }}>
          <button style={{ background: "#e2e8f0", border: "none", borderRadius: "6px", width: "32px", height: "32px", cursor: "pointer", fontSize: "0.9rem", color: "#64748b" }}>
            ❮
          </button>
          <button style={{ background: "#1e3a8a", color: "#ffffff", border: "none", borderRadius: "6px", width: "32px", height: "32px", fontWeight: 700, fontSize: "0.9rem" }}>
            1
          </button>
          <button style={{ background: "#e2e8f0", border: "none", borderRadius: "6px", width: "32px", height: "32px", cursor: "pointer", fontSize: "0.9rem", color: "#64748b" }}>
            ❯
          </button>
        </div>

      </div>

      {/* -------------------- SATISFACTION SURVEY MODAL -------------------- */}
      {activeSurveyApp && (() => {
        const linkedSurvey = surveys.find((s: any) =>
          (activeSurveyApp.program.surveyId && s.id === activeSurveyApp.program.surveyId) ||
          s.programId === activeSurveyApp.programId
        );
        const hasCustomQuestions = linkedSurvey && linkedSurvey.questions && linkedSurvey.questions.length > 0;

        return (
          <div style={{ position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh", background: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 2000, padding: "1rem" }}>
            <div style={{ background: "#ffffff", borderRadius: "12px", maxWidth: "600px", width: "100%", maxHeight: "90vh", display: "flex", flexDirection: "column", boxShadow: "0 10px 30px rgba(0,0,0,0.2)" }}>
              {/* Header */}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #e2e8f0", padding: "1.25rem 1.5rem" }}>
                <div>
                  <h3 style={{ margin: 0, fontSize: "1.15rem", fontWeight: 700, color: "#1e293b" }}>
                    📝 {linkedSurvey ? linkedSurvey.title : t("survey.modal.title")}
                  </h3>
                  <p style={{ margin: "0.25rem 0 0 0", fontSize: "0.85rem", color: "#64748b" }}>
                    {linkedSurvey?.description || t("survey.modal.subtitle")}
                  </p>
                </div>
                <button onClick={() => setActiveSurveyApp(null)} style={{ background: "none", border: "none", fontSize: "1.4rem", cursor: "pointer", color: "#64748b" }}>✕</button>
              </div>

              {/* Form Content (Scrollable) */}
              <form onSubmit={handleSurveySubmit} style={{ padding: "1.5rem", overflowY: "auto", display: "flex", flexDirection: "column", gap: "1.25rem", flex: 1 }}>
                <div style={{ background: "#f8fafc", padding: "0.75rem 1rem", borderRadius: "8px", border: "1px solid #e2e8f0" }}>
                  <label style={{ display: "block", fontSize: "0.8rem", color: "#64748b", marginBottom: "0.2rem" }}>{t("student.table.title")}</label>
                  <div style={{ fontWeight: 700, fontSize: "0.95rem", color: "#1e293b" }}>{activeSurveyApp.program.title}</div>
                </div>

                {hasCustomQuestions ? (
                  linkedSurvey.questions.map((q: any, idx: number) => (
                    <div key={q.id || idx} style={{ borderBottom: "1px solid #f1f5f9", paddingBottom: "1rem" }}>
                      <label style={{ display: "block", fontSize: "0.9rem", fontWeight: 600, color: "#334155", marginBottom: "0.6rem" }}>
                        {idx + 1}. {q.text}
                      </label>

                      {q.type === "평가형" && (
                        <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
                          {[1, 2, 3, 4, 5].map(score => (
                            <button
                              key={score}
                              type="button"
                              onClick={() => {
                                setDynamicAnswers(prev => ({ ...prev, [q.id]: score }));
                                if (idx === 0) setSurveyScore(score);
                              }}
                              style={{
                                fontSize: "1.5rem",
                                background: "none",
                                border: "none",
                                cursor: "pointer",
                                color: (dynamicAnswers[q.id] !== undefined ? dynamicAnswers[q.id] : 5) >= score ? "#f59e0b" : "#cbd5e1"
                              }}
                            >
                              ★
                            </button>
                          ))}
                          <span style={{ fontSize: "0.9rem", fontWeight: 700, color: "#f59e0b", marginLeft: "0.5rem" }}>
                            {dynamicAnswers[q.id] !== undefined ? dynamicAnswers[q.id] : 5} / 5
                          </span>
                        </div>
                      )}

                      {q.type === "객관식" && (
                        <div style={{ display: "flex", flexDirection: "column", gap: "0.4rem" }}>
                          {["매우 만족", "만족", "보통", "불만족", "매우 불만족"].map(opt => (
                            <label key={opt} style={{ display: "flex", alignItems: "center", gap: "0.5rem", fontSize: "0.875rem", color: "#475569", cursor: "pointer" }}>
                              <input
                                type="radio"
                                name={`q_${q.id}`}
                                value={opt}
                                checked={dynamicAnswers[q.id] === opt}
                                onChange={() => setDynamicAnswers(prev => ({ ...prev, [q.id]: opt }))}
                              />
                              {opt}
                            </label>
                          ))}
                        </div>
                      )}

                      {q.type === "주관식" && (
                        <textarea
                          rows={3}
                          value={dynamicAnswers[q.id] || ""}
                          onChange={e => {
                            setDynamicAnswers(prev => ({ ...prev, [q.id]: e.target.value }));
                            setSurveyComment(e.target.value);
                          }}
                          placeholder={t("survey.modal.commentPlaceholder")}
                          style={{ width: "100%", padding: "0.75rem", border: "1px solid #cbd5e1", borderRadius: "8px", fontSize: "0.875rem", outline: "none", boxSizing: "border-box" }}
                        />
                      )}
                    </div>
                  ))
                ) : (
                  <>
                    <div>
                      <label style={{ display: "block", fontSize: "0.9rem", fontWeight: 600, color: "#334155", marginBottom: "0.5rem" }}>
                        1. {t("survey.modal.score")}
                      </label>
                      <div style={{ display: "flex", gap: "0.5rem" }}>
                        {[1, 2, 3, 4, 5].map(star => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setSurveyScore(star)}
                            style={{ fontSize: "1.5rem", background: "none", border: "none", cursor: "pointer", color: star <= surveyScore ? "#f59e0b" : "#cbd5e1" }}
                          >
                            ★
                          </button>
                        ))}
                        <span style={{ fontSize: "0.9rem", fontWeight: 700, color: "#f59e0b", alignSelf: "center", marginLeft: "0.5rem" }}>
                          {surveyScore} / 5
                        </span>
                      </div>
                    </div>

                    <div>
                      <label style={{ display: "block", fontSize: "0.9rem", fontWeight: 600, color: "#334155", marginBottom: "0.5rem" }}>
                        2. {t("survey.modal.comment")}
                      </label>
                      <textarea
                        rows={4}
                        value={surveyComment}
                        onChange={e => setSurveyComment(e.target.value)}
                        placeholder={t("survey.modal.commentPlaceholder")}
                        style={{ width: "100%", padding: "0.75rem", border: "1px solid #cbd5e1", borderRadius: "8px", fontSize: "0.875rem", outline: "none", boxSizing: "border-box" }}
                      />
                    </div>
                  </>
                )}

                <div style={{ display: "flex", justifyContent: "flex-end", gap: "0.75rem", marginTop: "1rem", borderTop: "1px solid #e2e8f0", paddingTop: "1rem" }}>
                  <button
                    type="button"
                    onClick={() => setActiveSurveyApp(null)}
                    style={{ background: "#f1f5f9", color: "#475569", border: "1px solid #cbd5e1", padding: "0.6rem 1.25rem", borderRadius: "6px", fontWeight: 600, fontSize: "0.9rem", cursor: "pointer" }}
                  >
                    {t("survey.modal.btnClose")}
                  </button>
                  <button
                    type="submit"
                    style={{ background: "#2563eb", color: "#ffffff", border: "none", padding: "0.6rem 1.5rem", borderRadius: "6px", fontWeight: 700, fontSize: "0.9rem", cursor: "pointer" }}
                  >
                    {t("survey.modal.btnSubmit")}
                  </button>
                </div>
              </form>
            </div>
          </div>
        );
      })()}

    </div>
  );
}
