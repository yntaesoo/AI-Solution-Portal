"use client";

import { registerUser } from "@/app/actions";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useLanguage } from "@/lib/i18n/LanguageContext";

export default function RegisterForm({ clubs }: { clubs: { id: string, name: string }[] }) {
  const [error, setError] = useState("");
  const router = useRouter();
  const { t } = useLanguage();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");
    const formData = new FormData(e.currentTarget);
    formData.append("role", "STUDENT"); // Force STUDENT role
    
    const res = await registerUser(formData);
    if (res.error) {
      setError(res.error);
    } else {
      router.push("/login");
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      {error && <div style={{ color: 'red', fontSize: '0.875rem', textAlign: 'center' }}>{error}</div>}
      
      <div>
        <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>{t("register.name")}</label>
        <input name="name" type="text" className="input-field" placeholder="Full Name" required />
      </div>
      <div>
        <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>{t("register.username")}</label>
        <input name="username" type="text" className="input-field" placeholder="student123" required />
      </div>
      <div>
        <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>{t("register.password")}</label>
        <input name="password" type="password" className="input-field" placeholder="••••••••" required />
      </div>
      <div>
        <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>{t("register.club")}</label>
        <select name="clubId" className="input-field" required>
          <option value="">{t("register.club")}</option>
          {clubs.map(c => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>
      
      <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '0.75rem', marginTop: '0.5rem', fontSize: '1rem' }}>
        {t("register.btn.submit")}
      </button>
    </form>
  );
}
