import { NextResponse } from "next/server";

export async function POST() {
  const response = NextResponse.json({ success: true });

  const cookieNames = [
    "next-auth.session-token",
    "__Secure-next-auth.session-token",
    "next-auth.csrf-token",
    "__Host-next-auth.csrf-token",
    "next-auth.callback-url"
  ];

  const paths = ["/", "/StartupClub", "/StartupClub/"];

  for (const name of cookieNames) {
    for (const path of paths) {
      response.cookies.set(name, "", {
        path: path,
        expires: new Date(0),
        maxAge: 0,
      });
    }
  }

  return response;
}

export async function GET() {
  return POST();
}
