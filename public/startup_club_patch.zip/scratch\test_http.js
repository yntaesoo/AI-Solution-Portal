﻿const http = require('http');

const pages = [
  '/',
  '/StartupClub',
  '/login',
  '/StartupClub/login',
  '/register',
  '/StartupClub/register',
  '/register/mentor',
  '/StartupClub/register/mentor'
];

async function testPage(path) {
  return new Promise((resolve) => {
    const req = http.get({
      hostname: 'localhost',
      port: 3004,
      path: path,
      headers: { 'Accept': 'text/html' }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        resolve({
          path,
          statusCode: res.statusCode,
          location: res.headers.location,
          dataLength: data.length,
          hasLangToggle: data.includes('English') || data.includes('한국어') || data.includes('toggleLanguage')
        });
      });
    });
    req.on('error', (e) => resolve({ path, error: e.message }));
  });
}

async function run() {
  console.log("Testing pages on http://localhost:3004 ...");
  for (const p of pages) {
    const result = await testPage(p);
    console.log(`[${result.statusCode || 'ERR'}] ${result.path} => Length: ${result.dataLength || 0}, Location: ${result.location || '-'}`);
  }
}

run();
