const { PrismaClient } = require('@prisma/client');
const { PrismaBetterSqlite3 } = require('@prisma/adapter-better-sqlite3');
const adapter = new PrismaBetterSqlite3({ url: "file:./dev.db" });
const prisma = new PrismaClient({ adapter });

async function seed() {
  console.log('Seeding initial programs...');

  const student = await prisma.user.findFirst({ where: { username: 'gamebrio' } });
  console.log('Student gamebrio found:', student?.name);

  // 1. Create Program 1: 원스톱 상담창구
  const p1 = await prisma.program.upsert({
    where: { id: 'prog-onestop-2026' },
    update: {
      status: '진행'
    },
    create: {
      id: 'prog-onestop-2026',
      type: 'MYDEX',
      title: '2026 RISE 창업동아리 원스톱 상담창구',
      status: '진행',
      operateStartDate: '2026-05-01 00:00:00',
      operateEndDate: '2026-10-30 00:00:00',
      applyStartDate: '2026-04-28 00:00:00',
      applyEndDate: '2026-10-25 00:00:00',
      surveyStartDate: '2026-10-01 00:00:00',
      surveyEndDate: '2026-10-31 00:00:00',
      manager: '이동진 담당자',
      applyType: '온라인',
      applyTarget: '유학생 창업동아리 팀원/팀장',
      applyCategory: '팀/개인',
      maxRecruit: 30,
      maxPoint: 100,
      mydexUrl: 'https://mydex.dongseo.ac.kr/loadPage.do?jspPage=/PORTAL/STUD/C/A/SSCA020_01S&menuID=00118&PGM_ID=20260239',
      posterUrl: 'https://placehold.co/300x420/2563eb/ffffff?text=2026+One-Stop+Consulting',
      attachedFile: '2026 RISE 창업동아리 원스톱 상담창구 안내문.pdf',
      content: '● 프로그램명: 2026 RISE 창업동아리 원스톱 상담창구\n● 내용:\n- 멘토님이 팀별 연락하여 멘토링 일정 및 장소 조율\n- 창업 관련 모든 내용 멘토링 진행, 외부 경진대회 신청 가능\n- 필요 시 추가 멘토링 가능\n- 창업 캠프 참여하지 않은 RISE 창업동아리 참여 필수\n- 일정: 5월 1일(월)부터 10월 30일(금) 중 조율'
    }
  });

  // 2. Create Program 2: B-Contents Festival
  const p2 = await prisma.program.upsert({
    where: { id: 'prog-bcontents-2025' },
    update: {
      status: '진행'
    },
    create: {
      id: 'prog-bcontents-2025',
      type: '오프라인',
      title: '2025 부산 RISE 사업단 대학협력기반 거점구축과제 B-Contents Festival 행사',
      status: '진행',
      operateStartDate: '2026-01-29 00:00:00',
      operateEndDate: '2026-01-30 00:00:00',
      applyStartDate: '2026-01-01 00:00:00',
      applyEndDate: '2026-01-25 00:00:00',
      manager: '이동진',
      applyType: '오프라인',
      applyTarget: '전체 유학생',
      applyCategory: '개인',
      maxRecruit: 40,
      maxPoint: 50,
      posterUrl: 'https://placehold.co/300x420/1e3a8a/ffffff?text=B-Contents+Festival',
      attachedFile: 'B-Contents_Festival_행사안내.pdf',
      content: '2025 부산 RISE 사업단 대학협력기반 거점구축과제 B-Contents Festival 행사에 창업동아리 학생 여러분을 초대합니다.'
    }
  });

  // 3. Create Program 3: RISE 창업스쿨 창업캠프
  const p3 = await prisma.program.upsert({
    where: { id: 'prog-camp-2026' },
    update: {
      status: '진행'
    },
    create: {
      id: 'prog-camp-2026',
      type: '오프라인',
      title: 'RISE 창업스쿨 창업캠프 참여모집',
      status: '진행',
      operateStartDate: '2026-02-06 00:00:00',
      operateEndDate: '2026-02-07 00:00:00',
      applyStartDate: '2026-01-15 00:00:00',
      applyEndDate: '2026-02-01 00:00:00',
      manager: '김창업 팀장',
      applyType: '오프라인/캠프',
      applyTarget: '전체 유학생',
      applyCategory: '팀',
      maxRecruit: 50,
      maxPoint: 80,
      posterUrl: 'https://placehold.co/300x420/16a34a/ffffff?text=RISE+StartUp+Camp',
      attachedFile: 'RISE_창업스쿨_창업캠프_모집요강.pdf',
      content: '유학생 창업역량 강화를 위한 몰입형 2일 창업 캠프 프로그램입니다.'
    }
  });

  // 4. Create sample application for student gamebrio
  if (student) {
    await prisma.programApplication.upsert({
      where: { id: 'app-gamebrio-1' },
      update: {},
      create: {
        id: 'app-gamebrio-1',
        programId: p2.id,
        userId: student.id,
        status: '진행',
        surveyDone: false
      }
    });

    await prisma.programApplication.upsert({
      where: { id: 'app-gamebrio-2' },
      update: {},
      create: {
        id: 'app-gamebrio-2',
        programId: p3.id,
        userId: student.id,
        status: '진행',
        surveyDone: false
      }
    });
  }

  console.log('Programs seeded successfully!');
}

seed().catch(console.error).finally(() => prisma.$disconnect());
