import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { redirect } from "next/navigation";
import AdminDashboardClient from "./AdminDashboardClient";
import StudentDashboardClient from "./StudentDashboardClient";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect("/login");
  }

  const role = session.user?.role;

  if (role === "STUDENT") {
    const user = await prisma.user.findUnique({
      where: { id: session.user!.id },
      include: { club: true }
    });

    const programs = await prisma.program.findMany({
      where: { status: { in: ["진행", "임시저장"] } },
      orderBy: { createdAt: "desc" }
    });

    const applications = await prisma.programApplication.findMany({
      where: { userId: session.user!.id },
      include: { program: true },
      orderBy: { appliedAt: "desc" }
    });

    const mockPrograms = programs.length > 0 ? programs : [
      {
        id: "p1",
        type: "오프라인",
        title: "2025 부산 RISE 사업단 대학협력기반 거점구축과제 B-Contents Festival 행사",
        status: "진행",
        operateStartDate: "2026-01-29 00:00:00",
        operateEndDate: "2026-01-30 00:00:00",
        applyStartDate: "2026-01-01 00:00:00",
        applyEndDate: "2026-01-25 00:00:00",
        applyType: "오프라인",
        manager: "이동진",
        maxRecruit: 30
      },
      {
        id: "p2",
        type: "오프라인",
        title: "RISE 창업스쿨 창업캠프 참여모집",
        status: "진행",
        operateStartDate: "2026-02-06 00:00:00",
        operateEndDate: "2026-02-07 00:00:00",
        applyStartDate: "2026-01-15 00:00:00",
        applyEndDate: "2026-02-01 00:00:00",
        applyType: "오프라인",
        manager: "김창업",
        maxRecruit: 50
      }
    ];

    const mockApplications = applications.length > 0 ? applications : [
      {
        id: "app1",
        programId: "p1",
        program: mockPrograms[0],
        status: "진행",
        surveyDone: false,
        appliedAt: new Date().toISOString()
      },
      {
        id: "app2",
        programId: "p2",
        program: mockPrograms[1],
        status: "진행",
        surveyDone: false,
        appliedAt: new Date().toISOString()
      }
    ];

    const dbSurveys = await prisma.survey.findMany({
      include: { program: true },
      orderBy: { createdAt: "desc" }
    });

    const formattedSurveys = dbSurveys.map(s => {
      let parsedQuestions = [];
      try {
        parsedQuestions = s.questions ? JSON.parse(s.questions) : [];
      } catch (e) {
        parsedQuestions = [];
      }
      return {
        id: s.id,
        programId: s.programId,
        programTitle: s.program?.title || null,
        respondentType: s.respondentType as any,
        title: s.title,
        description: s.description || "",
        status: s.status as any,
        createdAt: new Date(s.createdAt).toISOString().split("T")[0],
        author: s.author || "라이즈사업단",
        questions: parsedQuestions
      };
    });

    return (
      <StudentDashboardClient
        user={{
          id: session.user!.id,
          name: session.user?.name || "학생",
          clubId: user?.clubId || session.user?.clubId,
          clubName: user?.club?.name || "동아리"
        }}
        programs={mockPrograms as any}
        initialApplications={mockApplications as any}
        surveys={formattedSurveys}
      />
    );
  }

  if (role === "MENTOR") {
    const assignments = await prisma.mentorAssignment.findMany({
      where: { mentorId: session.user!.id },
      include: { club: true }
    });

    return (
      <div className="glass-card" style={{ marginTop: '4rem' }}>
        <h2 style={{ textAlign: 'center', marginBottom: '1.5rem' }}>환영합니다, {session.user?.name} 멘토님!</h2>
        <h3 style={{ marginBottom: '1.5rem', color: 'var(--text-secondary)', borderBottom: '1px solid #e5e7eb', paddingBottom: '0.5rem' }}>배정된 담당 창업동아리 목록 ({assignments.length}개)</h3>
        
        {assignments.length > 0 ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem' }}>
            {assignments.map(a => (
              <div key={a.club.id} className="glass-card mentor-club-card" style={{ padding: '1.5rem', background: '#f9fafb', border: '1px solid #e5e7eb', cursor: 'pointer' }}>
                <h4 style={{ margin: '0 0 0.5rem 0', color: 'var(--primary)', fontSize: '1.1rem' }}>{a.club.name}</h4>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', margin: '0 0 1.25rem 0', lineHeight: 1.5 }}>
                  <strong>아이템:</strong> {a.club.itemName || "미등록"}<br/>
                  <strong>지도교수:</strong> {a.club.advisor || "미배정"}
                </p>
                <Link href={`/club/${a.club.id}`}>
                  <button className="btn btn-primary" style={{ width: '100%', fontSize: '0.875rem', padding: '0.5rem' }}>
                     동아리 상세 정보 및 자문 일지 &rarr;
                  </button>
                </Link>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ textAlign: 'center', color: 'var(--text-secondary)', padding: '2rem' }}>
            아직 배정된 담당 동아리가 없습니다. 관리자에게 문의하세요.
          </p>
        )}
      </div>
    );
  }

  // Admin View
  const clubs = await prisma.club.findMany({
    include: {
      users: true,
      activities: true,
    }
  });

  const mentors = await prisma.user.findMany({
    where: { role: "MENTOR" },
    include: {
      mentorAssignments: true
    },
    orderBy: { name: 'asc' }
  });

  const activities = await prisma.activity.findMany({
    include: {
      club: {
        select: {
          name: true
        }
      }
    },
    orderBy: {
      createdAt: 'desc'
    }
  });

  const dbPrograms = await prisma.program.findMany({
    include: {
      applications: {
        include: {
          user: {
            include: {
              club: true
            }
          }
        }
      }
    },
    orderBy: { createdAt: 'desc' }
  });

  const dbSurveys = await prisma.survey.findMany({
    include: { program: true },
    orderBy: { createdAt: "desc" }
  });

  const formattedSurveys = dbSurveys.map(s => {
    let parsedQuestions = [];
    try {
      parsedQuestions = s.questions ? JSON.parse(s.questions) : [];
    } catch (e) {
      parsedQuestions = [];
    }
    return {
      id: s.id,
      programId: s.programId,
      programTitle: s.program?.title || null,
      respondentType: s.respondentType as any,
      title: s.title,
      description: s.description || "",
      status: s.status as any,
      createdAt: new Date(s.createdAt).toISOString().split("T")[0],
      author: s.author || "라이즈사업단",
      questions: parsedQuestions
    };
  });

  const formattedPrograms = dbPrograms.map(p => ({
    id: p.id,
    type: p.type as any,
    title: p.title,
    status: p.status as any,
    operateStartDate: p.operateStartDate,
    operateEndDate: p.operateEndDate,
    applyStartDate: p.applyStartDate,
    applyEndDate: p.applyEndDate,
    surveyStartDate: p.surveyStartDate || "",
    surveyEndDate: p.surveyEndDate || "",
    manager: p.manager || "이동진 담당자",
    applyType: p.applyType || "온라인",
    applyTarget: p.applyTarget || "유학생 동아리",
    applyCategory: p.applyCategory || "팀",
    maxRecruit: p.maxRecruit || 20,
    currentRecruit: p.applications.length,
    maxPoint: p.maxPoint || 100,
    mydexUrl: p.mydexUrl || "",
    posterUrl: p.posterUrl || "https://placehold.co/300x420/4f46e5/ffffff?text=Program",
    attachedFile: p.attachedFile || "안내문.pdf",
    notice: (p as any).notice || "",
    content: p.content || "",
    surveyId: p.surveyId || "",
    applications: p.applications.map(app => ({
      id: app.id,
      userId: app.userId,
      userName: app.user.name,
      clubName: app.user.club?.name || "동아리",
      appliedAt: new Date(app.appliedAt).toISOString().replace("T", " ").substring(0, 16),
      status: app.status as any,
      surveyDone: app.surveyDone
    }))
  }));

  return (
    <AdminDashboardClient 
      initialClubs={clubs}
      mentors={mentors}
      allActivities={activities}
      initialPrograms={formattedPrograms}
      initialSurveys={formattedSurveys}
    />
  );
}
