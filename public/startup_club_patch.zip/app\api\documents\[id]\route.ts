import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import fs from "fs";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const doc = await prisma.document.findUnique({ where: { id } });
    if (!doc) {
      return new NextResponse("Document Not Found", { status: 404 });
    }

    if (!fs.existsSync(doc.path)) {
      return new NextResponse("File Not Found on Disk", { status: 404 });
    }

    const fileBuffer = fs.readFileSync(doc.path);
    return new Response(fileBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="${encodeURIComponent(doc.filename)}"`,
      },
    });
  } catch (error) {
    console.error("Error streaming document:", error);
    return new NextResponse("Internal Server Error", { status: 500 });
  }
}
