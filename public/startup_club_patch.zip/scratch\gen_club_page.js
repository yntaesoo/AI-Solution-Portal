﻿const fs = require('fs');

const pageCode = `import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { redirect } from "next/navigation";
import ClubDetailClient from "./ClubDetailClient";
import Link from "next/link";

export default async function ClubPage({ params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions);
  
  if (!session) {
    redirect("/login");
  }

  const role = session.user?.role;
  const clubId = (await params).id;

  if (role === "MENTOR") {
    const isAssigned = await prisma.mentorAssignment.findFirst({
      where: {
        mentorId: session.user!.id,
        clubId: clubId
      }
    });
    if (!isAssigned) {
      return (
        <div className="glass-card" style={{ marginTop: '4rem', textAlign: 'center', padding: '2.5rem' }}>
          <h2>권한이 없습니다. / Access Denied</h2>
          <p style={{ color: 'var(--text-secondary)', marginTop: '0.5rem' }}>이 동아리의 배정된 담당 멘토가 아닙니다. / You are not an assigned mentor for this club.</p>
          <Link href="/dashboard" style={{ display: 'inline-block', marginTop: '1.5rem', color: 'var(--primary)', textDecoration: 'none', fontWeight: 600 }}>&larr; 대시보드로 돌아가기 / Back to Dashboard</Link>
        </div>
      );
    }
  } else if (role !== "ADMIN" && session.user?.clubId !== clubId) {
    return (
      <div className="glass-card" style={{ marginTop: '4rem', textAlign: 'center', padding: '2.5rem' }}>
        <h2>권한이 없습니다. / Access Denied</h2>
        <p style={{ color: 'var(--text-secondary)', marginTop: '0.5rem' }}>이 동아리의 소속 학생이 아닙니다. / You are not a member of this club.</p>
        <Link href="/dashboard" style={{ display: 'inline-block', marginTop: '1.5rem', color: 'var(--primary)', textDecoration: 'none', fontWeight: 600 }}>&larr; 대시보드로 돌아가기 / Back to Dashboard</Link>
      </div>
    );
  }

  const currentUser = await prisma.user.findUnique({ where: { id: session.user?.id } });
  const isLeader = currentUser?.clubRole === "팀장";
  const canEditMembers = role === "ADMIN" || isLeader;

  const club = await prisma.club.findUnique({
    where: { id: clubId },
    include: {
      users: true,
      activities: { orderBy: { createdAt: 'desc' } },
      mentorLogs: { include: { mentor: true }, orderBy: { createdAt: 'desc' } },
      documents: true,
    }
  });

  if (!club) return <div>동아리를 찾을 수 없습니다. / Club not found.</div>;

  return (
    <ClubDetailClient 
      club={club}
      role={role}
      canEditMembers={canEditMembers}
      userId={session.user!.id}
    />
  );
}
`;

fs.writeFileSync('app/club/[id]/page.tsx', pageCode, 'utf8');
console.log('app/club/[id]/page.tsx updated!');
