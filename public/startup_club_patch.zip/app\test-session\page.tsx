import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { cookies } from "next/headers";

export default async function TestSessionPage() {
  const session = await getServerSession(authOptions);
  const cookieList = await cookies();
  const allCookies = cookieList.getAll().map(c => `${c.name}=${c.value}`);

  return (
    <div style={{ padding: '2rem', fontFamily: 'monospace' }}>
      <h1>Session Diagnostic</h1>
      <h2>Session Data:</h2>
      <pre style={{ background: '#f4f4f4', padding: '1rem', borderRadius: '4px' }}>
        {JSON.stringify(session, null, 2)}
      </pre>

      <h2>Cookies:</h2>
      <pre style={{ background: '#f4f4f4', padding: '1rem', borderRadius: '4px' }}>
        {JSON.stringify(allCookies, null, 2)}
      </pre>
    </div>
  );
}
