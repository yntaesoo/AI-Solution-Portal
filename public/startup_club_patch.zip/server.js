const { createServer } = require('http');
const { parse } = require('url');
const next = require('next');

const dev = process.env.NODE_ENV !== 'production';
const hostname = '0.0.0.0';
const port = parseInt(process.env.PORT || '3004', 10);

const app = next({ dev, hostname, port });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  createServer((req, res) => {
    const parsedUrl = parse(req.url, true);
    const { pathname, search } = parsedUrl;

    // 루트(/) 또는 basePath(/StartupClub) 없이 들어온 경로 자동 포워딩/리다이렉트
    if (pathname === '/' || pathname === '') {
      res.writeHead(307, { Location: '/StartupClub' + (search || '') });
      res.end();
      return;
    }

    if (
      !pathname.toLowerCase().startsWith('/startupclub') &&
      !pathname.startsWith('/_next') &&
      !pathname.startsWith('/favicon')
    ) {
      res.writeHead(307, { Location: '/StartupClub' + pathname + (search || '') });
      res.end();
      return;
    }

    handle(req, res, parsedUrl);
  }).listen(port, hostname, (err) => {
    if (err) throw err;
    console.log(`> Ready on http://localhost:${port} and http://localhost:${port}/StartupClub`);
  });
});
