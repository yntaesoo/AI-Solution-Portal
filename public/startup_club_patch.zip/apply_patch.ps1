$ErrorActionPreference = "Stop"
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "[유학생 창업동아리] 원격 컴퓨터 패치 적용 및 무결성 검증기" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

$targetDir = $PSScriptRoot

# 1. 3004번 포트 프로세스 확인 및 종료
Write-Host "[1/6] 기존 실행 중인 3004 포트 프로세스 종료 중..." -ForegroundColor Yellow
$pids = Get-NetTCPConnection -LocalPort 3004 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique
foreach ($p in $pids) {
    if ($p -and $p -ne 0) {
        Write-Host "  -> 프로세스 PID $p 강제 종료..."
        cmd /c "taskkill /f /pid $p /t >nul 2>&1"
    }
}

# 2. 백업 생성 (원격지의 기존 데이터 및 소스코드 100% 보존)
Write-Host "[2/6] 기존 원격 소스코드 및 데이터베이스 전체 백업 중..." -ForegroundColor Yellow
$backupDir = Join-Path $targetDir "_patch_backup"
if (!(Test-Path $backupDir)) {
    New-Item -ItemType Directory -Path $backupDir | Out-Null
}
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$currBackup = Join-Path $backupDir "backup_$timestamp"
New-Item -ItemType Directory -Path $currBackup | Out-Null

if (Test-Path (Join-Path $targetDir "dev.db")) {
    Copy-Item (Join-Path $targetDir "dev.db") (Join-Path $currBackup "dev.db") -Force
    Write-Host "  -> 기존 dev.db 백업 완료"
}
if (Test-Path (Join-Path $targetDir "app")) {
    Copy-Item (Join-Path $targetDir "app") (Join-Path $currBackup "app") -Recurse -Force
}
if (Test-Path (Join-Path $targetDir "lib")) {
    Copy-Item (Join-Path $targetDir "lib") (Join-Path $currBackup "lib") -Recurse -Force
}
if (Test-Path (Join-Path $targetDir "prisma")) {
    Copy-Item (Join-Path $targetDir "prisma") (Join-Path $currBackup "prisma") -Recurse -Force
}
if (Test-Path (Join-Path $targetDir ".env")) {
    Copy-Item (Join-Path $targetDir ".env") (Join-Path $currBackup ".env") -Force
}

# 3. DB 파일 무결성 보장
Write-Host "[3/6] 데이터베이스(SQLite) 상태 확인 및 스키마 검증..." -ForegroundColor Yellow
$dbPath = Join-Path $targetDir "dev.db"
$templateDb = Join-Path $targetDir "dev_template.db"

if (!(Test-Path $dbPath) -and (Test-Path $templateDb)) {
    Copy-Item $templateDb $dbPath -Force
    Write-Host "  -> 신규 dev.db 생성됨"
}

# 4. Prisma 클라이언트 생성 및 DB 스키마 안전 동기화 (기존 데이터 유지)
Write-Host "[4/6] Prisma Client 생성 및 DB 마이그레이션 적용 중..." -ForegroundColor Yellow
cmd /c "cd /d `"$targetDir`" && npx prisma generate"
cmd /c "cd /d `"$targetDir`" && npx prisma db push"

# 초기 설문 데이터 확인 및 보정
if (Test-Path (Join-Path $targetDir "scratch\seed_surveys.js")) {
    Write-Host "  -> 기본 설문지 데이터 무결성 체크..."
    cmd /c "cd /d `"$targetDir`" && node scratch/seed_surveys.js"
}

# 5. 캐시 정리 및 프로덕션 빌드
Write-Host "[5/6] 기존 빌드 캐시 정리 및 최신 프로덕션 빌드..." -ForegroundColor Yellow
$nextDir = Join-Path $targetDir ".next"
if (Test-Path $nextDir) {
    Remove-Item $nextDir -Recurse -Force -ErrorAction SilentlyContinue
}

$buildRes = cmd /c "cd /d `"$targetDir`" && npm run build"
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "[치명적 오류] 프로덕션 빌드에 실패하였습니다!" -ForegroundColor Red
    Write-Host "백업 위치: $currBackup" -ForegroundColor Yellow
    Write-Host "원상 복구 명령: Copy-Item '$currBackup\*' '$targetDir' -Recurse -Force"
    exit 1
}

# 6. 최종 헬스체크 검증
Write-Host "[6/6] 배포 무결성 검증 (Health Check)..." -ForegroundColor Yellow
$checkOutput = cmd /c "node -e `"const Database = require('better-sqlite3'); const db = new Database('dev.db'); const c = db.prepare('SELECT count(*) as count FROM Survey').get(); console.log(c.count);`""
Write-Host "  -> 데이터베이스 내 등록된 설문지 수: $checkOutput 건 정상 확인"

Write-Host ""
Write-Host "========================================================" -ForegroundColor Green
Write-Host "✔ [성공] 원격 패치 및 빌드 검증이 100% 완료되었습니다!" -ForegroundColor Green
Write-Host " - 백업 생성됨: $currBackup"
Write-Host " - 빌드 상태:   정상 (Next.js 16.3 Production Ready)"
Write-Host " - 데이터베이스: 정상 (Survey 테이블 및 프로그램 연계 완료)"
Write-Host "========================================================" -ForegroundColor Green

# 7. 포털 및 백그라운드 3004 서비스 자동 재기동
Write-Host "[7/7] 포털 백그라운드 서비스(3004 포트) 자동 재실행..." -ForegroundColor Yellow
Start-Process -FilePath "cmd.exe" -ArgumentList "/c npm run start" -WorkingDirectory $targetDir -WindowStyle Hidden

Start-Sleep -Seconds 3
$checkPort = Get-NetTCPConnection -LocalPort 3004 -ErrorAction SilentlyContinue
if ($checkPort) {
    Write-Host "🎉 3004 포트 서비스가 백그라운드에서 정상 실행되었습니다!" -ForegroundColor Green
    Write-Host "   -> 포털(http://portal.arfab.kr/startupclub/dashboard)에서 바로 접속 가능합니다." -ForegroundColor Cyan
} else {
    Write-Host "포털 서비스 대기 중입니다. 잠시 후 브라우저를 새로고침하십시오." -ForegroundColor Yellow
}