"use client";

import { useState } from "react";
import { addActivityAdvanced } from "@/app/actions";

interface Activity {
  id: string;
  type: string;
  status: string;
  description: string | null;
  createdAt: Date | string;
}

export default function ActivitySection({ 
  clubId, 
  activities, 
  canEdit 
}: { 
  clubId: string; 
  activities: Activity[]; 
  canEdit: boolean;
}) {
  const [selectedCategory, setSelectedCategory] = useState("ALL");
  const [type, setType] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form states
  const [eduName, setEduName] = useState("");
  const [eduDate, setEduDate] = useState("");
  const [eduAttended, setEduAttended] = useState(false);

  const [campName, setCampName] = useState("");
  const [campDate, setCampDate] = useState("");
  const [campAttended, setCampAttended] = useState(false);

  const [contestName, setContestName] = useState("");
  const [contestDate, setContestDate] = useState("");
  const [contestAward, setContestAward] = useState("");

  const [patentTitle, setPatentTitle] = useState("");
  const [patentStatus, setPatentStatus] = useState("출원");
  const [designName, setDesignName] = useState("");

  const [protoName, setProtoName] = useState("");
  const [protoStatus, setProtoStatus] = useState("진행중");

  const [startupHope, setStartupHope] = useState("희망");

  // Calculate statistics
  const getAttendedCount = (actType: string) => {
    return activities.filter(act => {
      if (act.type !== actType) return false;
      try {
        const details = JSON.parse(act.description || "{}");
        return details.attended === true || act.status === "완료";
      } catch (e) {
        return act.status === "완료";
      }
    }).length;
  };

  const eduCount = getAttendedCount("창업교육");
  const campCount = getAttendedCount("창업캠프");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!type) return;

    setIsSubmitting(true);
    let detailsObj = {};
    let status = "진행중";

    if (type === "창업교육") {
      detailsObj = { educationName: eduName, date: eduDate, attended: eduAttended };
      status = eduAttended ? "완료" : "진행중";
    } else if (type === "창업캠프") {
      detailsObj = { campName: campName, date: campDate, attended: campAttended };
      status = campAttended ? "완료" : "진행중";
    } else if (type === "창업경진대회") {
      detailsObj = { contestName, date: contestDate, award: contestAward };
      status = contestAward ? "완료" : "진행중";
    } else if (type === "지식재산권") {
      detailsObj = { patentTitle, status: patentStatus, designName };
      status = patentStatus === "등록" ? "완료" : "진행중";
    } else if (type === "시제품제작") {
      detailsObj = { prototypeName: protoName, status: protoStatus };
      status = protoStatus;
    } else if (type === "실제창업") {
      detailsObj = { hopeStatus: startupHope };
      status = startupHope === "희망" ? "진행중" : "완료";
    }

    try {
      await addActivityAdvanced(clubId, type, status, JSON.stringify(detailsObj));
      // Reset form
      setType("");
      setEduName("");
      setEduDate("");
      setEduAttended(false);
      setCampName("");
      setCampDate("");
      setCampAttended(false);
      setContestName("");
      setContestDate("");
      setContestAward("");
      setPatentTitle("");
      setPatentStatus("출원");
      setDesignName("");
      setProtoName("");
      setProtoStatus("진행중");
      setStartupHope("희망");
    } catch (error) {
      alert("활동 저장 중 오류가 발생했습니다.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Helper to render activity description beautifully
  const renderDescription = (act: Activity) => {
    if (!act.description) return act.description || "-";
    try {
      const d = JSON.parse(act.description);
      if (d.autoSynced) {
        return `[지원프로그램 이수] ${d.name || "-"} | 이수자: ${d.studentName || "-"} | 이주일자: ${d.date || "-"}`;
      }
      if (act.type === "창업교육") {
        return `교육명: ${d.educationName || d.name || "-"} | 일시: ${d.date || "-"} | 참석여부: ${d.attended || d.autoSynced ? "참석" : "미참석"}`;
      } else if (act.type === "창업캠프") {
        return `캠프명: ${d.campName || d.name || "-"} | 일시: ${d.date || "-"} | 참석여부: ${d.attended || d.autoSynced ? "참석" : "미참석"}`;
      } else if (act.type === "창업경진대회") {
        return `대회명: ${d.contestName || d.name || "-"} | 일시: ${d.date || "-"} | 수상내역: ${d.award || "이수완료"}`;
      } else if (act.type === "지식재산권") {
        return `특허제목: ${d.patentTitle || "-"} (${d.status || "출원"}) | 디자인등록: ${d.designName || "-"}`;
      } else if (act.type === "시제품제작") {
        return `시제품명: ${d.prototypeName || "-"} | 상태: ${d.status || "-"}`;
      } else if (act.type === "실제창업") {
        return `창업 희망 여부: ${d.hopeStatus || "-"}`;
      }
      return act.description;
    } catch (e) {
      return act.description;
    }
  };

  return (
    <div className="glass-card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
        <h2>의무 활동 내역</h2>
        
        {/* Stat indicators */}
        <div style={{ display: 'flex', gap: '1rem' }}>
          <div className="badge" style={{ background: eduCount >= 2 ? 'rgba(34, 197, 94, 0.1)' : 'rgba(239, 68, 68, 0.1)', color: eduCount >= 2 ? '#15803d' : '#b91c1c', border: '1px solid currentColor' }}>
            창업교육 참석: {eduCount}회 / 2회 의무 {eduCount >= 2 ? "✓" : ""}
          </div>
          <div className="badge" style={{ background: campCount >= 2 ? 'rgba(34, 197, 94, 0.1)' : 'rgba(239, 68, 68, 0.1)', color: campCount >= 2 ? '#15803d' : '#b91c1c', border: '1px solid currentColor' }}>
            창업캠프 참석: {campCount}회 / 2회 의무 {campCount >= 2 ? "✓" : ""}
          </div>
        </div>
      </div>

      {/* -------------------- ACTIVITY SPREADSHEET GRID CONCEPT TABLE -------------------- */}
      {/* Category Filter Chips Bar */}
      <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap', marginBottom: '1.25rem', background: '#f8fafc', padding: '0.5rem', borderRadius: '10px', border: '1px solid #e2e8f0' }}>
        {[
          { id: "ALL", label: "전체 활동", icon: "📊" },
          { id: "창업교육", label: "창업교육", icon: "🎓" },
          { id: "창업캠프", label: "창업캠프", icon: "🏕️" },
          { id: "창업경진대회", label: "창업경진대회", icon: "🏆" },
          { id: "지식재산권", label: "지식재산권", icon: "💡" },
          { id: "시제품제작", label: "시제품제작", icon: "🛠️" },
          { id: "실제창업", label: "실제창업", icon: "🚀" },
        ].map(cat => {
          const count = cat.id === "ALL" ? activities.length : activities.filter(a => a.type === cat.id).length;
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => {
                setSelectedCategory(cat.id);
                if (cat.id !== "ALL") setType(cat.id);
                else setType("");
              }}
              style={{
                background: isSelected ? "#1e3a8a" : "#ffffff",
                color: isSelected ? "#ffffff" : "#475569",
                border: `1px solid ${isSelected ? "#1e3a8a" : "#cbd5e1"}`,
                padding: "0.4rem 0.85rem",
                borderRadius: "6px",
                fontSize: "0.825rem",
                fontWeight: isSelected ? 700 : 500,
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "0.35rem"
              }}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
              <span style={{
                background: isSelected ? "rgba(255,255,255,0.25)" : "#f1f5f9",
                color: isSelected ? "#ffffff" : "#64748b",
                padding: "0.1rem 0.4rem",
                borderRadius: "10px",
                fontSize: "0.75rem",
                fontWeight: 700
              }}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {canEdit && (
        <form onSubmit={handleSubmit} style={{ background: 'rgba(255,255,255,0.4)', padding: '1.25rem', borderRadius: '10px', marginBottom: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem', border: '1px solid #e5e7eb' }}>
          {type === "" && (
            <div style={{ color: "#64748b", fontSize: "0.85rem", fontStyle: "italic" }}>
              💡 위 가로 메뉴에서 신규 등록할 활동 유형(창업교육, 창업캠프 등)을 선택하시면 입력창이 나타납니다.
            </div>
          )}

          {/* Dynamic Forms */}
          {type === "창업교육" && (
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
              <strong style={{ color: "#1e3a8a" }}>🎓 [창업교육] 신규 활동 등록:</strong>
              <input type="text" placeholder="창업교육명" className="input-field" value={eduName} onChange={e => setEduName(e.target.value)} required style={{ flex: 1, minWidth: '200px' }} />
              <input type="text" placeholder="일시 (예: 2026.08.01)" className="input-field" value={eduDate} onChange={e => setEduDate(e.target.value)} required style={{ width: '180px' }} />
              <label style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                <input type="checkbox" checked={eduAttended} onChange={e => setEduAttended(e.target.checked)} />
                참석 완료
              </label>
            </div>
          )}

          {type === "창업캠프" && (
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
              <strong style={{ color: "#1e3a8a" }}>🏕️ [창업캠프] 신규 활동 등록:</strong>
              <input type="text" placeholder="창업캠프 명" className="input-field" value={campName} onChange={e => setCampName(e.target.value)} required style={{ flex: 1, minWidth: '200px' }} />
              <input type="text" placeholder="일시 (예: 2026.08.01)" className="input-field" value={campDate} onChange={e => setCampDate(e.target.value)} required style={{ width: '180px' }} />
              <label style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                <input type="checkbox" checked={campAttended} onChange={e => setCampAttended(e.target.checked)} />
                참석 완료
              </label>
            </div>
          )}

          {type === "창업경진대회" && (
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
              <strong style={{ color: "#1e3a8a" }}>🏆 [창업경진대회] 신규 활동 등록:</strong>
              <input type="text" placeholder="경진대회명" className="input-field" value={contestName} onChange={e => setContestName(e.target.value)} required style={{ flex: 1, minWidth: '200px' }} />
              <input type="text" placeholder="일시" className="input-field" value={contestDate} onChange={e => setContestDate(e.target.value)} required style={{ width: '150px' }} />
              <input type="text" placeholder="수상내역 (예: 대상, 우수상, 혹은 없음)" className="input-field" value={contestAward} onChange={e => setContestAward(e.target.value)} required style={{ width: '250px' }} />
            </div>
          )}

          {type === "지식재산권" && (
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
              <strong style={{ color: "#1e3a8a" }}>💡 [지식재산권] 신규 활동 등록:</strong>
              <input type="text" placeholder="특허 제목" className="input-field" value={patentTitle} onChange={e => setPatentTitle(e.target.value)} style={{ flex: 1, minWidth: '180px' }} />
              <select value={patentStatus} onChange={e => setPatentStatus(e.target.value)} className="input-field" style={{ width: '100px' }}>
                <option value="출원">출원</option>
                <option value="등록">등록</option>
              </select>
              <input type="text" placeholder="디자인 등록 명" className="input-field" value={designName} onChange={e => setDesignName(e.target.value)} style={{ flex: 1, minWidth: '180px' }} />
            </div>
          )}

          {type === "시제품제작" && (
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
              <strong style={{ color: "#1e3a8a" }}>🛠️ [시제품제작] 신규 활동 등록:</strong>
              <input type="text" placeholder="시제품 제작 명" className="input-field" value={protoName} onChange={e => setProtoName(e.target.value)} required style={{ flex: 1, minWidth: '200px' }} />
              <select value={protoStatus} onChange={e => setProtoStatus(e.target.value)} className="input-field" style={{ width: '120px' }}>
                <option value="진행중">진행중</option>
                <option value="완료">완료</option>
              </select>
            </div>
          )}

          {type === "실제창업" && (
            <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'center' }}>
              <strong style={{ color: "#1e3a8a" }}>🚀 [실제창업] 신규 활동 등록:</strong>
              <span>창업 희망 여부:</span>
              <label style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                <input type="radio" name="startupHope" value="희망" checked={startupHope === "희망"} onChange={() => setStartupHope("희망")} />
                희망
              </label>
              <label style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                <input type="radio" name="startupHope" value="비희망" checked={startupHope === "비희망"} onChange={() => setStartupHope("비희망")} />
                비희망
              </label>
            </div>
          )}

          {type && (
            <button 
              type="submit" 
              disabled={isSubmitting} 
              className="btn btn-primary" 
              style={{ alignSelf: 'flex-end', padding: '0.6rem 1.5rem' }}
            >
              {isSubmitting ? "저장 중..." : "활동 등록하기"}
            </button>
          )}
        </form>
      )}

      {/* Spreadsheet Container */}
      <div style={{
        maxHeight: '520px',
        overflowY: 'auto',
        overflowX: 'auto',
        border: '1px solid #cbd5e1',
        borderRadius: '8px',
        background: '#fff',
        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)'
      }}>
        <table style={{ minWidth: '950px', borderCollapse: 'separate', borderSpacing: 0, width: '100%', fontSize: '0.85rem' }}>
          <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
            <tr>
              {[
                { name: "No", width: "50px" },
                { name: "활동 유형", width: "130px" },
                { name: "의무조건 / 구분", width: "140px" },
                { name: "활동 / 교육 / 이수 상세 내용", width: "auto" },
                { name: "진행 / 이수 상태", width: "120px" },
                { name: "등록일자", width: "110px" }
              ].map((col, idx) => (
                <th
                  key={idx}
                  style={{
                    background: '#f8fafc',
                    color: '#1e293b',
                    fontWeight: 700,
                    padding: '0.75rem 0.85rem',
                    borderBottom: '2px solid #cbd5e1',
                    borderRight: '1px solid #e2e8f0',
                    textAlign: idx === 0 || idx === 4 || idx === 5 ? 'center' : 'left',
                    width: col.width,
                    whiteSpace: 'nowrap'
                  }}
                >
                  {col.name}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {activities
              .filter(a => selectedCategory === "ALL" || a.type === selectedCategory)
              .map((act, i) => {
                const cellStyle = {
                  borderBottom: '1px solid #e2e8f0',
                  borderRight: '1px solid #e2e8f0',
                  padding: '0.6rem 0.85rem',
                  fontSize: '0.85rem'
                };

                const isEduOrCamp = act.type === "창업교육" || act.type === "창업캠프";

                return (
                  <tr
                    key={act.id}
                    style={{ transition: 'background-color 0.1s' }}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = '#f1f5f9'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}
                  >
                    {/* No */}
                    <td style={{ ...cellStyle, textAlign: 'center', fontWeight: 600, color: '#64748b', background: '#fafafa', borderRight: '2px solid #e2e8f0' }}>
                      {i + 1}
                    </td>

                    {/* 활동 유형 */}
                    <td style={{ ...cellStyle, fontWeight: 700, color: '#1e293b' }}>
                      {act.type === "창업교육" && "🎓 "}
                      {act.type === "창업캠프" && "🏕️ "}
                      {act.type === "창업경진대회" && "🏆 "}
                      {act.type === "지식재산권" && "💡 "}
                      {act.type === "시제품제작" && "🛠️ "}
                      {act.type === "실제창업" && "🚀 "}
                      {act.type}
                    </td>

                    {/* 의무조건 / 구분 */}
                    <td style={cellStyle}>
                      {isEduOrCamp ? (
                        <span style={{ background: '#eff6ff', color: '#1e40af', padding: '0.2rem 0.5rem', borderRadius: '4px', border: '1px solid #bfdbfe', fontWeight: 700, fontSize: '0.78rem' }}>
                          2회 의무 참석
                        </span>
                      ) : (
                        <span style={{ color: '#64748b', fontSize: '0.8rem' }}>자율 선택</span>
                      )}
                    </td>

                    {/* 상세 내역 */}
                    <td style={{ ...cellStyle, color: '#334155' }}>
                      {renderDescription(act)}
                    </td>

                    {/* 진행 / 이수 상태 */}
                    <td style={{ ...cellStyle, textAlign: 'center' }}>
                      <span
                        style={{
                          display: 'inline-block',
                          padding: '0.25rem 0.65rem',
                          borderRadius: '4px',
                          border: `1px solid ${act.status === "완료" ? "#86efac" : "#cbd5e1"}`,
                          background: act.status === "완료" ? "#f0fdf4" : "#ffffff",
                          color: act.status === "완료" ? "#16a34a" : "#475569",
                          fontWeight: 700,
                          fontSize: '0.78rem'
                        }}
                      >
                        {act.status === "완료" ? "✓ 완료(이수)" : act.status}
                      </span>
                    </td>

                    {/* 등록일자 */}
                    <td style={{ ...cellStyle, textAlign: 'center', color: '#64748b', fontSize: '0.8rem' }}>
                      {new Date(act.createdAt).toLocaleDateString()}
                    </td>
                  </tr>
                );
              })}

            {activities.filter(a => selectedCategory === "ALL" || a.type === selectedCategory).length === 0 && (
              <tr>
                <td colSpan={6} style={{ padding: '2.5rem', textAlign: 'center', color: '#94a3b8', fontSize: '0.875rem' }}>
                  등록되거나 이수 완료된 활동 내역이 없습니다.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
