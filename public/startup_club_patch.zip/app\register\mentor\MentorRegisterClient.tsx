"use client";

import MentorRegisterForm from "../MentorRegisterForm";
import Link from "next/link";
import { useLanguage } from "@/lib/i18n/LanguageContext";

export default function MentorRegisterClient({ clubs }: { clubs: { id: string, name: string }[] }) {
  const { t } = useLanguage();

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh' }}>
      <div className="glass-card" style={{ maxWidth: '400px', width: '100%', padding: '2.5rem' }}>
        <h1 style={{ textAlign: 'center', marginBottom: '0.5rem' }}>{t("register.mentor.title")}</h1>
        <p style={{ textAlign: 'center', color: 'var(--text-secondary)', marginBottom: '2rem' }}>
          {t("register.mentor.subtitle")}
        </p>

        <MentorRegisterForm clubs={clubs} />
        
        <div style={{ marginTop: '1.5rem', textAlign: 'center', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          <Link href="/register" style={{ fontSize: '0.875rem', color: 'var(--primary)', textDecoration: 'none', fontWeight: 600 }}>
            {t("register.mentor.link.toStudent")}
          </Link>
          <Link href="/login" style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', textDecoration: 'none' }}>
            {t("register.link.toLogin")}
          </Link>
        </div>
      </div>
    </div>
  );
}
