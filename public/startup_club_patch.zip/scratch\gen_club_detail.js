﻿const fs = require('fs');

const code = `"use client";

import Link from "next/link";
import EditableMemberTable from "./EditableMemberTable";
import ActivitySection from "./ActivitySection";
import MentorLogSection from "./MentorLogSection";
import { useLanguage } from "@/lib/i18n/LanguageContext";

interface ClubDetailClientProps {
  club: any;
  role?: string;
  canEditMembers: boolean;
  userId: string;
}

export default function ClubDetailClient({
  club,
  role,
  canEditMembers,
  userId,
}: ClubDetailClientProps) {
  const { t } = useLanguage();

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', paddingBottom: '4rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Link href="/dashboard" style={{ color: 'var(--text-secondary)', textDecoration: 'none', fontSize: '0.875rem' }}>
            {t("club.backToDashboard")}
          </Link>
          <h1 style={{ marginBottom: 0, marginTop: '0.5rem' }}>{club.name}</h1>
          <div style={{ color: 'var(--text-secondary)', fontSize: '0.95rem', marginTop: '0.25rem' }}>
            <strong>{t("club.advisor")}</strong> {club.advisor || t("club.unassigned")} &nbsp;|&nbsp; <strong>{t("club.type")}</strong> {club.type || t("club.unassigned")}
          </div>
        </div>
        {role === "ADMIN" && (
          <div className="badge" style={{ fontSize: '1rem', padding: '0.5rem 1rem' }}>
            {t("club.budget")} {club.budget.toLocaleString()} {t("admin.unit.won")}
          </div>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
        <div className="glass-card" style={{ gridColumn: '1 / -1' }}>
          <h2>{t("club.membersTitle", { count: club.users.length })}</h2>
          <EditableMemberTable key={JSON.stringify(club.users)} initialMembers={club.users} canEdit={canEditMembers} />
        </div>

        <div className="glass-card" style={{ gridColumn: '1 / -1' }}>
          <h2>{t("club.planTitle")}</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', marginTop: '1rem' }}>
            <div>
              <strong style={{ fontSize: '1.05rem', color: 'var(--navy)' }}>{t("club.itemName")}</strong>
              <p style={{ margin: '0.5rem 0 0 0', padding: '1rem', background: 'rgba(255,255,255,0.6)', border: '1px solid #e5e7eb', borderRadius: '8px', fontWeight: 600 }}>
                {club.itemName || t("club.noItem")}
              </p>
            </div>
            <div>
              <strong style={{ fontSize: '1.05rem', color: 'var(--navy)' }}>{t("club.itemSummary")}</strong>
              <p className="scrollable-item-summary" style={{ margin: '0.5rem 0 0 0' }}>
                {club.itemSummary || t("club.noSummary")}
              </p>
            </div>
            <div style={{ borderTop: '1px solid #eee', paddingTop: '1.5rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              <strong style={{ fontSize: '1.05rem', color: 'var(--navy)' }}>{t("club.attachedFile")}</strong>
              {club.documents.length === 0 ? (
                <p style={{ color: 'var(--text-secondary)', margin: 0 }}>{t("club.noFiles")}</p>
              ) : (
                <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginTop: '0.25rem' }}>
                  {club.documents.map((doc) => (
                    <a
                      key={doc.id}
                      href={'/api/documents/' + doc.id}
                      target="_blank"
                      rel="noreferrer"
                      className="btn"
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.5rem',
                        background: '#fff',
                        border: '1px solid #e5e7eb',
                        padding: '0.6rem 1.2rem',
                        textDecoration: 'none',
                        color: 'var(--primary)',
                        fontWeight: 'bold',
                        borderRadius: '8px',
                        boxShadow: '0 2px 4px rgba(0,0,0,0.02)',
                        transition: 'all 0.2s'
                      }}
                    >
                      📄 {doc.filename}
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <ActivitySection 
        clubId={club.id} 
        activities={club.activities} 
        canEdit={role === "ADMIN" || role === "STUDENT"} 
      />

      <MentorLogSection 
        clubId={club.id} 
        mentorId={userId} 
        logs={club.mentorLogs} 
        isMentor={role === "MENTOR" || role === "ADMIN"} 
      />
    </div>
  );
}
`;

fs.writeFileSync('app/club/[id]/ClubDetailClient.tsx', code, 'utf8');
console.log('ClubDetailClient.tsx created successfully!');
