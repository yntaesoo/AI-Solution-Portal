"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { saveSurveyAction, deleteSurveyAction } from "@/app/actions";

export interface SurveyQuestion {
  id: number;
  type: "평가형" | "주관식" | "객관식";
  text: string;
}

export interface SurveyItem {
  id: string;
  programId?: string | null;
  programTitle?: string | null;
  respondentType: "동아리" | "멘토" | "학생";
  title: string;
  description: string;
  status: "사용" | "사용안함";
  createdAt: string;
  author: string;
  questions: SurveyQuestion[];
}

export default function SatisfactionSurveyManager({
  initialSurveys = [],
  availablePrograms = [],
  onSurveysChange
}: {
  initialSurveys?: SurveyItem[];
  availablePrograms?: Array<{ id: string; title: string }>;
  onSurveysChange?: (surveys: SurveyItem[]) => void;
}) {
  const router = useRouter();
  const [surveys, setSurveys] = useState<SurveyItem[]>(initialSurveys);

  useEffect(() => {
    if (initialSurveys && initialSurveys.length > 0) {
      setSurveys(initialSurveys);
    }
  }, [initialSurveys]);
  const [searchCategory, setSearchCategory] = useState("전체");
  const [searchKeyword, setSearchKeyword] = useState("");
  const [statusFilter, setStatusFilter] = useState<"사용" | "사용안함" | "ALL">("ALL");

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSurvey, setEditingSurvey] = useState<SurveyItem | null>(null);

  // Form Fields
  const [formTitle, setFormTitle] = useState("");
  const [formProgramId, setFormProgramId] = useState<string>("");
  const [formType, setFormType] = useState<"동아리" | "멘토" | "학생">("동아리");
  const [formDesc, setFormDesc] = useState("");
  const [formStatus, setFormStatus] = useState<"사용" | "사용안함">("사용");
  const [formQuestions, setFormQuestions] = useState<SurveyQuestion[]>([]);

  // New Question Row State
  const [newQType, setNewQType] = useState<"평가형" | "주관식" | "객관식">("평가형");
  const [newQText, setNewQText] = useState("");

  const openNewModal = () => {
    setEditingSurvey(null);
    setFormTitle("");
    setFormProgramId("");
    setFormType("동아리");
    setFormDesc("");
    setFormStatus("사용");
    setFormQuestions([
      { id: 1, type: "평가형", text: "나는 이 수업에 전체적으로 만족한다" },
      { id: 2, type: "평가형", text: "창업에 대한 다양한 지식과 기술을 습득하였다" }
    ]);
    setNewQType("평가형");
    setNewQText("");
    setIsModalOpen(true);
  };

  const openEditModal = (survey: SurveyItem) => {
    setEditingSurvey(survey);
    setFormTitle(survey.title);
    setFormProgramId(survey.programId || "");
    setFormType(survey.respondentType);
    setFormDesc(survey.description);
    setFormStatus(survey.status);
    setFormQuestions([...survey.questions]);
    setNewQType("평가형");
    setNewQText("");
    setIsModalOpen(true);
  };

  const handleAddQuestion = () => {
    if (!newQText.trim()) {
      alert("질문 내용을 입력하세요.");
      return;
    }
    const newQ: SurveyQuestion = {
      id: formQuestions.length + 1,
      type: newQType,
      text: newQText
    };
    setFormQuestions(prev => [...prev, newQ]);
    setNewQText("");
  };

  const handleRemoveQuestion = (id: number) => {
    setFormQuestions(prev => prev.filter(q => q.id !== id).map((q, idx) => ({ ...q, id: idx + 1 })));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      alert("설문지 제목을 입력해 주세요.");
      return;
    }

    try {
      const res = await saveSurveyAction({
        id: editingSurvey ? editingSurvey.id : undefined,
        programId: formProgramId || null,
        title: formTitle,
        respondentType: formType,
        description: formDesc,
        status: formStatus,
        author: "라이즈사업단",
        questions: formQuestions
      });

      const matchedProgram = availablePrograms.find(p => p.id === formProgramId);
      const programTitle = matchedProgram ? matchedProgram.title : null;

      if (editingSurvey) {
        const updated = surveys.map(s => s.id === editingSurvey.id ? {
          ...s,
          programId: formProgramId || null,
          programTitle: programTitle,
          title: formTitle,
          respondentType: formType,
          description: formDesc,
          status: formStatus,
          questions: formQuestions
        } : s);
        setSurveys(updated);
        onSurveysChange?.(updated);
        alert("설문지가 데이터베이스에 수정 저장되었습니다.");
      } else {
        const newS: SurveyItem = {
          id: (res as any).id || String(Date.now()),
          programId: formProgramId || null,
          programTitle: programTitle,
          title: formTitle,
          respondentType: formType,
          description: formDesc,
          status: formStatus,
          createdAt: new Date().toISOString().replace("T", " ").slice(0, 19),
          author: "라이즈사업단",
          questions: formQuestions
        };
        const updated = [newS, ...surveys];
        setSurveys(updated);
        onSurveysChange?.(updated);
        alert("신규 설문지가 데이터베이스에 영구 저장되었습니다.");
      }
      setIsModalOpen(false);
      router.refresh();
    } catch (error) {
      console.error(error);
      alert("설문지 저장 중 오류가 발생했습니다.");
    }
  };

  const handleDeleteSurvey = async (id: string) => {
    if (confirm("정말 삭제하시겠습니까?")) {
      try {
        await deleteSurveyAction(id);
        const updated = surveys.filter(s => s.id !== id);
        setSurveys(updated);
        onSurveysChange?.(updated);
        router.refresh();
        alert("설문지가 삭제되었습니다.");
      } catch (error) {
        alert("설문지 삭제 중 오류가 발생했습니다.");
      }
    }
  };

  const filteredSurveys = surveys.filter(s => {
    if (statusFilter !== "ALL" && s.status !== statusFilter) return false;
    if (searchKeyword.trim()) {
      const kw = searchKeyword.toLowerCase();
      return s.title.toLowerCase().includes(kw) || s.author.toLowerCase().includes(kw);
    }
    return true;
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2 style={{ fontSize: "1.5rem", fontWeight: 700, margin: 0, color: "#1e293b" }}>
          만족도설문지 관리
        </h2>
        <span style={{ fontSize: "0.85rem", color: "#64748b" }}>만족도설문지 관리</span>
      </div>

      {/* Filter & Search Bar Box (Matching Screenshot 2) */}
      <div style={{ background: "#ffffff", padding: "1.25rem 1.5rem", borderRadius: "12px", border: "1px solid #e2e8f0", boxShadow: "0 2px 8px rgba(0,0,0,0.02)", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem", flexWrap: "wrap" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", flex: 1, minWidth: "300px" }}>
          <select
            value={searchCategory}
            onChange={e => setSearchCategory(e.target.value)}
            style={{ padding: "0.6rem 1rem", border: "1px solid #cbd5e1", borderRadius: "8px", background: "#fff", fontSize: "0.9rem", color: "#334155" }}
          >
            <option value="전체">전체</option>
          </select>

          <input
            type="text"
            placeholder="검색어를 입력해주세요."
            value={searchKeyword}
            onChange={e => setSearchKeyword(e.target.value)}
            style={{ flex: 1, padding: "0.6rem 1rem", border: "1px solid #cbd5e1", borderRadius: "8px", fontSize: "0.9rem", minWidth: "200px" }}
          />

          <button
            onClick={() => {}}
            style={{ background: "#2563eb", color: "#ffffff", border: "none", padding: "0.6rem 1.25rem", borderRadius: "8px", fontWeight: 600, fontSize: "0.9rem", display: "flex", alignItems: "center", gap: "0.4rem", cursor: "pointer" }}
          >
            🔍 검색
          </button>
          
          <button
            onClick={() => { setSearchKeyword(""); setStatusFilter("ALL"); }}
            style={{ background: "#f1f5f9", color: "#475569", border: "1px solid #cbd5e1", padding: "0.6rem 1.25rem", borderRadius: "8px", fontWeight: 500, fontSize: "0.9rem", display: "flex", alignItems: "center", gap: "0.4rem", cursor: "pointer" }}
          >
            🔄 초기화
          </button>

          <span style={{ fontSize: "0.875rem", color: "#64748b", marginLeft: "0.5rem" }}>
            총 <strong style={{ color: "#2563eb" }}>{filteredSurveys.length}</strong>건 검색되었습니다.
          </span>
        </div>

        <button
          onClick={openNewModal}
          style={{ background: "#2563eb", color: "#ffffff", border: "none", padding: "0.65rem 1.25rem", borderRadius: "30px", fontWeight: 600, fontSize: "0.9rem", display: "flex", alignItems: "center", gap: "0.4rem", cursor: "pointer", boxShadow: "0 4px 12px rgba(37,99,235,0.2)" }}
        >
          ➕ 신규등록
        </button>
      </div>

      {/* Main Survey Table Container (Matching Screenshot 2) */}
      <div style={{ background: "#ffffff", padding: "1.5rem", borderRadius: "12px", border: "1px solid #e2e8f0", boxShadow: "0 2px 8px rgba(0,0,0,0.02)" }}>
        <h3 style={{ fontSize: "1.1rem", fontWeight: 700, margin: "0 0 1rem 0", color: "#1e293b", display: "flex", alignItems: "center", gap: "0.5rem" }}>
          📋 만족도 설문지 목록
        </h3>

        {/* Status Filter Pills */}
        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "1.25rem" }}>
          <button
            onClick={() => setStatusFilter(statusFilter === "사용" ? "ALL" : "사용")}
            style={{ padding: "0.4rem 1.25rem", borderRadius: "20px", fontSize: "0.85rem", fontWeight: 600, border: "none", cursor: "pointer", background: statusFilter === "사용" ? "#2563eb" : "#e2e8f0", color: statusFilter === "사용" ? "#fff" : "#475569" }}
          >
            사용
          </button>
          <button
            onClick={() => setStatusFilter(statusFilter === "사용안함" ? "ALL" : "사용안함")}
            style={{ padding: "0.4rem 1.25rem", borderRadius: "20px", fontSize: "0.85rem", fontWeight: 600, border: "none", cursor: "pointer", background: statusFilter === "사용안함" ? "#2563eb" : "#e2e8f0", color: statusFilter === "사용안함" ? "#fff" : "#475569" }}
          >
            사용안함
          </button>
        </div>

        {/* Table */}
        <div style={{ overflowX: "auto", borderTop: "2px solid #2563eb" }}>
          <table style={{ width: "100%", minWidth: "1000px", borderCollapse: "collapse", fontSize: "0.875rem", textAlign: "center", tableLayout: "auto" }}>
            <thead>
              <tr style={{ background: "#fafafa", borderBottom: "1px solid #e2e8f0", color: "#1e293b", fontWeight: 700, whiteSpace: "nowrap" }}>
                <th style={{ padding: "0.75rem 0.6rem", width: "50px", whiteSpace: "nowrap" }}>No.</th>
                <th style={{ padding: "0.75rem 0.6rem", width: "100px", whiteSpace: "nowrap" }}>응답자유형</th>
                <th style={{ padding: "0.75rem 0.8rem", textAlign: "left", minWidth: "280px", whiteSpace: "nowrap" }}>설문지 이름</th>
                <th style={{ padding: "0.75rem 0.6rem", width: "180px", whiteSpace: "nowrap" }}>연계 지원프로그램</th>
                <th style={{ padding: "0.75rem 0.6rem", width: "100px", whiteSpace: "nowrap" }}>만족도항목</th>
                <th style={{ padding: "0.75rem 0.6rem", width: "130px", whiteSpace: "nowrap" }}>등록일</th>
                <th style={{ padding: "0.75rem 0.6rem", width: "110px", whiteSpace: "nowrap" }}>작성자</th>
                <th style={{ padding: "0.75rem 0.6rem", width: "90px", whiteSpace: "nowrap" }}>관리</th>
                <th style={{ padding: "0.75rem 0.6rem", width: "60px", whiteSpace: "nowrap" }}>삭제</th>
              </tr>
            </thead>
            <tbody>
              {filteredSurveys.length === 0 ? (
                <tr>
                  <td colSpan={9} style={{ padding: "3rem", color: "#94a3b8" }}>
                    등록된 만족도 설문지가 없습니다.
                  </td>
                </tr>
              ) : (
                filteredSurveys.map((survey, idx) => {
                  const linkedProgTitle = survey.programTitle || availablePrograms.find(p => p.id === survey.programId)?.title;
                  return (
                    <tr key={survey.id} style={{ borderBottom: "1px solid #f1f5f9", background: idx % 2 === 0 ? "#ffffff" : "#f8fafc" }}>
                      <td style={{ padding: "0.75rem 0.6rem", fontWeight: 500, whiteSpace: "nowrap" }}>{idx + 1}</td>
                      <td style={{ padding: "0.75rem 0.6rem", whiteSpace: "nowrap" }}>
                        <span style={{ background: "#f1f5f9", color: "#334155", padding: "0.2rem 0.5rem", borderRadius: "4px", fontSize: "0.8rem", fontWeight: 600 }}>
                          {survey.respondentType}
                        </span>
                      </td>
                      <td style={{ padding: "0.75rem 0.8rem", textAlign: "left", fontWeight: 600, color: "#1e293b", minWidth: "280px", wordBreak: "keep-all", lineHeight: 1.5 }}>
                        {survey.title}
                      </td>
                      <td style={{ padding: "0.75rem 0.6rem", whiteSpace: "nowrap" }}>
                        {linkedProgTitle ? (
                          <span style={{ background: "#eff6ff", color: "#1d4ed8", border: "1px solid #bfdbfe", padding: "0.25rem 0.65rem", borderRadius: "10px", fontSize: "0.8rem", fontWeight: 600, display: "inline-block", maxWidth: "200px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={linkedProgTitle}>
                            🎯 {linkedProgTitle}
                          </span>
                        ) : (
                          <span style={{ color: "#94a3b8", fontSize: "0.8rem" }}>공통 설문</span>
                        )}
                      </td>
                      <td style={{ padding: "0.75rem 0.6rem", whiteSpace: "nowrap" }}>
                        <span style={{ background: "#dcfce7", color: "#15803d", border: "1px solid #bbf7d0", padding: "0.2rem 0.6rem", borderRadius: "12px", fontWeight: 700, fontSize: "0.8rem", display: "inline-flex", alignItems: "center", gap: "0.3rem" }}>
                          📋 {survey.questions.length}
                        </span>
                      </td>
                      <td style={{ padding: "0.75rem 0.6rem", color: "#64748b", fontSize: "0.825rem", whiteSpace: "nowrap" }}>{survey.createdAt}</td>
                      <td style={{ padding: "0.75rem 0.6rem", whiteSpace: "nowrap", fontSize: "0.825rem" }}>{survey.author}</td>
                      <td style={{ padding: "0.75rem 0.6rem", whiteSpace: "nowrap" }}>
                        <button
                          onClick={() => openEditModal(survey)}
                          style={{ background: "#2563eb", border: "none", color: "#ffffff", padding: "0.4rem 0.85rem", borderRadius: "6px", fontSize: "0.8rem", fontWeight: 600, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: "0.3rem", whiteSpace: "nowrap" }}
                        >
                          ⚙️ 관리
                        </button>
                      </td>
                      <td style={{ padding: "0.75rem 0.6rem", whiteSpace: "nowrap" }}>
                        <button
                          onClick={() => handleDeleteSurvey(survey.id)}
                          style={{ background: "none", border: "none", color: "#64748b", cursor: "pointer", fontSize: "1.1rem", padding: "0.2rem" }}
                          title="설문지 삭제"
                        >
                          🗑️
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer info & Pagination */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "1.25rem", flexWrap: "wrap", gap: "1rem" }}>
          <span style={{ fontSize: "0.8rem", color: "#94a3b8" }}>
            * 좌우로 스크롤시 더 많은 정보를 확인 할 수 있습니다.
          </span>
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <select style={{ padding: "0.35rem 0.75rem", border: "1px solid #cbd5e1", borderRadius: "16px", fontSize: "0.8rem" }}>
              <option>20 개씩 보기</option>
            </select>
            <div style={{ display: "flex", gap: "0.25rem" }}>
              <button style={{ border: "1px solid #cbd5e1", background: "#fff", padding: "0.35rem 0.6rem", borderRadius: "4px", fontSize: "0.8rem" }}>«</button>
              <button style={{ border: "1px solid #cbd5e1", background: "#fff", padding: "0.35rem 0.6rem", borderRadius: "4px", fontSize: "0.8rem" }}>‹</button>
              <button style={{ border: "none", background: "#2563eb", color: "#fff", padding: "0.35rem 0.65rem", borderRadius: "4px", fontSize: "0.8rem", fontWeight: 700 }}>1</button>
              <button style={{ border: "1px solid #cbd5e1", background: "#fff", padding: "0.35rem 0.6rem", borderRadius: "4px", fontSize: "0.8rem" }}>›</button>
              <button style={{ border: "1px solid #cbd5e1", background: "#fff", padding: "0.35rem 0.6rem", borderRadius: "4px", fontSize: "0.8rem" }}>»</button>
            </div>
          </div>
        </div>
      </div>

      {/* Edit / New Survey Modal (Matching Screenshot 3) */}
      {isModalOpen && (
        <div style={{ position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh", background: "rgba(15, 23, 42, 0.6)", backdropFilter: "blur(4px)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 1000, padding: "1rem" }}>
          <div style={{ background: "#ffffff", borderRadius: "16px", width: "100%", maxWidth: "900px", maxHeight: "90vh", overflowY: "auto", boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1)" }}>
            
            {/* Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "1.25rem 1.5rem", borderBottom: "1px solid #e2e8f0" }}>
              <h3 style={{ fontSize: "1.25rem", fontWeight: 700, margin: 0, color: "#1e293b" }}>
                {editingSurvey ? "만족도 설문지 수정" : "만족도 설문지 신규 등록"}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                style={{ background: "none", border: "none", fontSize: "1.5rem", color: "#64748b", cursor: "pointer" }}
              >
                ✕
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSave} style={{ padding: "1.5rem", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
              
              {/* Section 1: 기본정보 */}
              <div>
                <h4 style={{ fontSize: "1rem", fontWeight: 700, color: "#1e293b", margin: "0 0 0.75rem 0", display: "flex", alignItems: "center", gap: "0.4rem" }}>
                  📋 기본정보
                </h4>
                <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "8px", padding: "1.25rem", display: "flex", flexDirection: "column", gap: "1rem" }}>
                  <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "1rem" }}>
                    <div>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.3rem" }}>
                        <label style={{ fontSize: "0.85rem", fontWeight: 600, color: "#334155" }}>
                          설문지 제목 <span style={{ color: "#ef4444" }}>*</span>
                        </label>
                        <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>{formTitle.length}/50</span>
                      </div>
                      <input
                        type="text"
                        required
                        value={formTitle}
                        onChange={e => setFormTitle(e.target.value)}
                        placeholder="설문지 제목을 입력하세요."
                        style={{ width: "100%", padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.9rem" }}
                      />
                    </div>
                    <div>
                      <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, marginBottom: "0.3rem", color: "#334155" }}>
                        응답자 유형 <span style={{ color: "#ef4444" }}>*</span>
                      </label>
                      <select
                        value={formType}
                        onChange={e => setFormType(e.target.value as any)}
                        style={{ width: "100%", padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.9rem" }}
                      >
                        <option value="동아리">동아리</option>
                        <option value="멘토">멘토</option>
                        <option value="학생">학생</option>
                      </select>
                    </div>
                  </div>

                  {/* Program Link Field */}
                  <div>
                    <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 600, marginBottom: "0.3rem", color: "#334155" }}>
                      연계 지원프로그램 <span style={{ fontSize: "0.75rem", color: "#64748b" }}>(선택 시 해당 프로그램 신청 학생에게 이 설문이 제공됩니다)</span>
                    </label>
                    <select
                      value={formProgramId}
                      onChange={e => setFormProgramId(e.target.value)}
                      style={{ width: "100%", padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.9rem", background: "#fff" }}
                    >
                      <option value="">(연계 프로그램 없음 - 공통/자율 설문)</option>
                      {availablePrograms.map(p => (
                        <option key={p.id} value={p.id}>{p.title}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.3rem" }}>
                      <label style={{ fontSize: "0.85rem", fontWeight: 600, color: "#334155" }}>
                        설문지 설명 <span style={{ color: "#ef4444" }}>*</span>
                      </label>
                      <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>{formDesc.length}/50</span>
                    </div>
                    <textarea
                      rows={2}
                      value={formDesc}
                      onChange={e => setFormDesc(e.target.value)}
                      placeholder="설문지 설명을 입력하세요."
                      style={{ width: "100%", padding: "0.6rem", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "0.9rem", resize: "vertical" }}
                    />
                  </div>
                </div>
              </div>

              {/* Section 2: 문항목록 */}
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.75rem" }}>
                  <h4 style={{ fontSize: "1rem", fontWeight: 700, color: "#1e293b", margin: 0, display: "flex", alignItems: "center", gap: "0.4rem" }}>
                    📝 문항목록
                  </h4>
                  <span style={{ fontSize: "0.8rem", color: "#64748b" }}>
                    Total <strong style={{ color: "#2563eb" }}>{formQuestions.length}</strong>
                    &nbsp;&nbsp;&nbsp;&nbsp;* 모든 문항은 254자 이내로 적어주시길 바라며, 주관식 체크 시 답변란이 표시됩니다.
                  </span>
                </div>

                <div style={{ border: "1px solid #e2e8f0", borderRadius: "8px", overflow: "hidden" }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.85rem" }}>
                    <thead>
                      <tr style={{ background: "#f8fafc", borderBottom: "1px solid #e2e8f0", textAlign: "center" }}>
                        <th style={{ padding: "0.6rem", width: "60px" }}>순번</th>
                        <th style={{ padding: "0.6rem", width: "110px" }}>질문유형</th>
                        <th style={{ padding: "0.6rem", textAlign: "left" }}>질문내용</th>
                        <th style={{ padding: "0.6rem", width: "60px" }}>관리</th>
                      </tr>
                    </thead>
                    <tbody>
                      {formQuestions.map((q) => (
                        <tr key={q.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                          <td style={{ padding: "0.6rem", textAlign: "center", fontWeight: 600 }}>{q.id}</td>
                          <td style={{ padding: "0.6rem", textAlign: "center" }}>{q.type}</td>
                          <td style={{ padding: "0.6rem" }}>
                            <input
                              type="text"
                              value={q.text}
                              onChange={e => {
                                const val = e.target.value;
                                setFormQuestions(prev => prev.map(item => item.id === q.id ? { ...item, text: val } : item));
                              }}
                              style={{ width: "100%", padding: "0.4rem 0.6rem", border: "1px solid #e2e8f0", borderRadius: "4px", fontSize: "0.85rem" }}
                            />
                          </td>
                          <td style={{ padding: "0.6rem", textAlign: "center" }}>
                            <button
                              type="button"
                              onClick={() => handleRemoveQuestion(q.id)}
                              style={{ background: "#ef4444", color: "#fff", border: "none", width: "24px", height: "24px", borderRadius: "4px", cursor: "pointer", fontWeight: 700 }}
                            >
                              ✕
                            </button>
                          </td>
                        </tr>
                      ))}

                      {/* Add Row */}
                      <tr style={{ background: "#f8fafc" }}>
                        <td style={{ padding: "0.6rem", textAlign: "center" }}>0</td>
                        <td style={{ padding: "0.6rem" }}>
                          <select
                            value={newQType}
                            onChange={e => setNewQType(e.target.value as any)}
                            style={{ width: "100%", padding: "0.4rem", border: "1px solid #cbd5e1", borderRadius: "4px", fontSize: "0.85rem" }}
                          >
                            <option value="평가형">평가형</option>
                            <option value="주관식">주관식</option>
                            <option value="객관식">객관식</option>
                          </select>
                        </td>
                        <td style={{ padding: "0.6rem" }}>
                          <input
                            type="text"
                            placeholder="질문내용 입력"
                            value={newQText}
                            onChange={e => setNewQText(e.target.value)}
                            onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); handleAddQuestion(); } }}
                            style={{ width: "100%", padding: "0.4rem 0.6rem", border: "1px solid #cbd5e1", borderRadius: "4px", fontSize: "0.85rem" }}
                          />
                        </td>
                        <td style={{ padding: "0.6rem", textAlign: "center" }}>
                          <button
                            type="button"
                            onClick={handleAddQuestion}
                            style={{ background: "#2563eb", color: "#fff", border: "none", width: "24px", height: "24px", borderRadius: "4px", cursor: "pointer", fontWeight: 700 }}
                          >
                            ➕
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Action Buttons */}
              <div style={{ display: "flex", justifyContent: "center", gap: "1rem", marginTop: "1rem" }}>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  style={{ background: "#f1f5f9", color: "#475569", border: "1px solid #cbd5e1", padding: "0.65rem 2rem", borderRadius: "6px", fontWeight: 600, cursor: "pointer" }}
                >
                  취소
                </button>
                <button
                  type="submit"
                  style={{ background: "#2563eb", color: "#ffffff", border: "none", padding: "0.65rem 2rem", borderRadius: "6px", fontWeight: 600, cursor: "pointer", boxShadow: "0 4px 12px rgba(37,99,235,0.2)" }}
                >
                  {editingSurvey ? "수정" : "등록"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
