const { PrismaClient } = require('@prisma/client');
const { PrismaBetterSqlite3 } = require('@prisma/adapter-better-sqlite3');
const xlsx = require('xlsx');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');

const adapter = new PrismaBetterSqlite3({ url: "file:./dev.db" });
const prisma = new PrismaClient({ adapter });

async function main() {
  console.log('Seeding database...');
  
  // 1. Clear existing data and create Admin
  await prisma.activity.deleteMany();
  await prisma.mentorLog.deleteMany();
  await prisma.document.deleteMany();
  await prisma.user.deleteMany({ where: { role: { not: 'ADMIN' } } });
  await prisma.club.deleteMany();

  const adminPassword = await bcrypt.hash('admin123', 10);
  await prisma.user.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      password: adminPassword,
      name: 'Administrator',
      role: 'ADMIN',
    },
  });
  console.log('Admin user created (username: admin, password: admin123)');

  // 2. Read Excel
  const workbook = xlsx.readFile('h:/Create with Codex/창업관련/유학생창업동아리/2026 유학생 창업동아리 운영 현황.xlsx');
  const sheet = workbook.Sheets['운영 현황'];
  const data = xlsx.utils.sheet_to_json(sheet, { header: 1 });
  
  const rows = data.slice(5); // Data starts at row 6 (index 5)
  let currentClub = null;

  for (const row of rows) {
    if (row.length === 0) continue;
    
    const clubName = row[2];
    if (clubName && clubName.trim() !== '') {
      const trimmedName = clubName.trim();
      if (trimmedName !== '운영비' && trimmedName !== '동아리명') {
        const type = row[3] ? String(row[3]).trim() : null;
        const itemName = row[4] ? String(row[4]).trim() : null;
        const itemSummary = row[5] ? String(row[5]).trim() : null;
        const advisor = row[6] ? String(row[6]).trim() : null;

        let club = await prisma.club.findUnique({ where: { name: trimmedName } });
        if (!club) {
          let requestedBudget = typeof row[22] === 'number' ? row[22] : parseFloat(String(row[22] || '0').replace(/,/g, '')) || 0;
          let budget = typeof row[23] === 'number' ? row[23] : parseFloat(String(row[23] || '0').replace(/,/g, '')) || 0;
          let spentBudget = typeof row[24] === 'number' ? row[24] : parseFloat(String(row[24] || '0').replace(/,/g, '')) || 0;
          let remainingBudget = typeof row[25] === 'number' ? row[25] : parseFloat(String(row[25] || '0').replace(/,/g, '')) || 0;

          club = await prisma.club.create({
            data: {
              name: trimmedName,
              budget,
              requestedBudget,
              spentBudget,
              remainingBudget,
              personnelCount: 0,
              type,
              itemName,
              itemSummary,
              advisor
            }
          });
        } else {
          const updateData = {
            type: type || club.type,
            itemName: itemName || club.itemName,
            itemSummary: itemSummary || club.itemSummary,
            advisor: advisor || club.advisor
          };
          if (row[22] !== undefined) {
            Object.assign(updateData, {
              requestedBudget: typeof row[22] === 'number' ? row[22] : parseFloat(String(row[22] || '0').replace(/,/g, '')) || 0,
              budget: typeof row[23] === 'number' ? row[23] : parseFloat(String(row[23] || '0').replace(/,/g, '')) || 0,
              spentBudget: typeof row[24] === 'number' ? row[24] : parseFloat(String(row[24] || '0').replace(/,/g, '')) || 0,
              remainingBudget: typeof row[25] === 'number' ? row[25] : parseFloat(String(row[25] || '0').replace(/,/g, '')) || 0,
            });
          }
          club = await prisma.club.update({
            where: { id: club.id },
            data: updateData
          });
        }
        currentClub = club;

        // Match and attach PDF business plan document
        const fs = require('fs');
        const path = require('path');
        const pdf = require('pdf-parse');
        const pdfDir = 'h:/Create with Codex/창업관련/유학생창업동아리/2026 RISE Startup School - Startup Club Application Form';
        if (fs.existsSync(pdfDir)) {
          const files = fs.readdirSync(pdfDir);
          const matchedFile = files.find(f => {
            const fLower = f.toLowerCase();
            const clubNameLower = trimmedName.toLowerCase();
            if (fLower.includes(`(${clubNameLower})`)) return true;
            const nameNoSpaces = clubNameLower.replace(/\s+/g, '');
            const fNoSpaces = fLower.replace(/\s+/g, '');
            if (fNoSpaces.includes(`(${nameNoSpaces})`)) return true;
            return false;
          });
          if (matchedFile) {
            const absPath = path.join(pdfDir, matchedFile);
            const existingDoc = await prisma.document.findFirst({
              where: { clubId: club.id, filename: matchedFile }
            });
            if (!existingDoc) {
              await prisma.document.create({
                data: {
                  clubId: club.id,
                  filename: matchedFile,
                  path: absPath
                }
              });
              console.log(`Attached PDF: ${matchedFile} to Club: ${trimmedName}`);
            }

            // Extract summary from PDF and update
            try {
              const dataBuffer = fs.readFileSync(absPath);
              const uint8 = new Uint8Array(dataBuffer);
              const parser = new pdf.PDFParse(uint8);
              const result = await parser.getText();
              const text = result.text;
              if (text.trim().length >= 500) {
                let index3 = text.indexOf('3 창업동아리 아이템 개발 계획');
                if (index3 === -1) index3 = text.indexOf('창업동아리 아이템 개발 계획');
                if (index3 === -1) index3 = text.indexOf('Item Development Plan');

                let index4 = text.indexOf('4 창업동아리 활동 계획');
                if (index4 === -1) index4 = text.indexOf('창업동아리 활동 계획');
                if (index4 === -1) index4 = text.indexOf('4 창업동아리 활동계획');
                if (index4 === -1) index4 = text.indexOf('Startup Club Activity Plan');
                if (index4 === -1) index4 = text.indexOf('4 ');

                if (index3 !== -1) {
                  const sliceEnd = (index4 !== -1 && index4 > index3) ? index4 : index3 + 8000;
                  let section3Text = text.slice(index3, sliceEnd).trim();
                  section3Text = section3Text.replace(/^-- \d+ of \d+ --$/gm, '');
                  section3Text = section3Text.replace(/\n{3,}/g, '\n\n');
                  section3Text = section3Text.trim();
                  
                  if (section3Text) {
                    await prisma.club.update({
                      where: { id: club.id },
                      data: { itemSummary: section3Text }
                    });
                    console.log(`Extracted & updated PDF summary for: ${trimmedName}`);
                  }
                }
              } else {
                // Scanned PDF note
                const note = `*(스캔 이미지 형식의 사업계획서이므로 텍스트 자동 추출이 불가능합니다. 하단의 첨부파일을 열어 확인해 주세요.)\n\n[요약]: ${club.itemSummary || itemSummary || ""}`;
                await prisma.club.update({
                  where: { id: club.id },
                  data: { itemSummary: note }
                });
                console.log(`Skipped scanned PDF text extraction for: ${trimmedName}`);
              }
            } catch (err) {
              console.error(`Error parsing PDF for ${trimmedName}:`, err.message);
            }
          }
        }
      }
    }

    if (!currentClub) continue;

    // row[10] or row[11] is Student Name
    const nameVal = row[10] ? String(row[10]).trim() : null;
    const englishName = row[11] ? String(row[11]).trim() : null;
    const studentName = nameVal || englishName;
    const isLeader = row[17] === '팀장'; // row[17] is 구분 (팀장/팀원)
    
    if (!studentName || studentName === '이름' || studentName === '이름(학생 작성)') continue;

    if (studentName && typeof studentName === 'string' && studentName.trim() !== '') {
      const studentId = row[13] ? String(row[13]).trim() : null;
      const isIdValid = studentId && /^\d{8}$/.test(studentId);
      
      let baseUsername = isIdValid ? studentId : studentName.replace(/\s+/g, '').toLowerCase();
      let username = baseUsername;
      
      // Ensure uniqueness of username
      let count = 1;
      while (await prisma.user.findUnique({ where: { username } })) {
        username = `${baseUsername}${count}`;
        count++;
      }

      const password = await bcrypt.hash('student123', 10);
      
      const advisor = row[6] ? String(row[6]).trim() : null;
      const college = row[8] ? String(row[8]).trim() : null;
      const department = row[9] ? String(row[9]).trim() : null;
      const grade = row[12] ? String(row[12]).trim() : null;
      const email = row[14] && String(row[14]).trim() !== 'undefined' ? String(row[14]).trim() : null;
      const phone = row[15] ? String(row[15]).trim() : null;
      const enrollmentStatus = row[16] ? String(row[16]).trim() : null;
      const clubRole = row[17] ? String(row[17]).trim() : null;

      let user = await prisma.user.findFirst({ where: { name: studentName, clubId: currentClub.id } });
      if (!user) {
        await prisma.user.create({
          data: {
            username,
            password,
            name: studentName,
            englishName,
            role: 'STUDENT',
            clubId: currentClub.id,
            advisor,
            college,
            department,
            grade,
            studentId,
            email,
            phone,
            enrollmentStatus,
            clubRole,
          }
        });
      }
    }
  }

  // Update personnel counts
  const clubs = await prisma.club.findMany({ include: { users: true } });
  for (const club of clubs) {
    await prisma.club.update({
      where: { id: club.id },
      data: { personnelCount: club.users.length }
    });
    console.log(`Club: ${club.name}, Members: ${club.users.length}`);
  }
  
  console.log('Seeding finished.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
