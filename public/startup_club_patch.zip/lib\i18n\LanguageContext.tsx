"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { Locale, translations } from "./translations";

interface LanguageContextType {
  locale: Locale;
  toggleLanguage: () => void;
  setLocale: (l: Locale) => void;
  t: (key: string, variables?: Record<string, string | number>) => string;
}

const LanguageContext = createContext<LanguageContextType>({
  locale: "ko",
  toggleLanguage: () => {},
  setLocale: () => {},
  t: (key: string) => key,
});

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>("ko");

  useEffect(() => {
    try {
      const saved = localStorage.getItem("app_locale") as Locale;
      if (saved === "ko" || saved === "en") {
        setLocaleState(saved);
      }
    } catch (e) {
      // Ignore localStorage errors
    }
  }, []);

  const setLocale = (newLocale: Locale) => {
    setLocaleState(newLocale);
    try {
      localStorage.setItem("app_locale", newLocale);
    } catch (e) {}
  };

  const toggleLanguage = () => {
    const next = locale === "ko" ? "en" : "ko";
    setLocale(next);
  };

  const t = (key: string, variables?: Record<string, string | number>): string => {
    const dict = translations[locale] as Record<string, string>;
    let text = dict[key] || (translations.ko as Record<string, string>)[key] || key;
    if (variables) {
      Object.entries(variables).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\\{${k}\\}`, "g"), String(v));
      });
    }
    return text;
  };

  return (
    <LanguageContext.Provider value={{ locale, toggleLanguage, setLocale, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
