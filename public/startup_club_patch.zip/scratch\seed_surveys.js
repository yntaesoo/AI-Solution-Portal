const { PrismaClient } = require('@prisma/client');
const { PrismaBetterSqlite3 } = require('@prisma/adapter-better-sqlite3');
const adapter = new PrismaBetterSqlite3({ url: "file:./dev.db" });
const prisma = new PrismaClient({ adapter });

async function main() {
  console.log('--- SEEDING DEFAULT SURVEYS IF EMPTY ---');

  const count = await prisma.survey.count();
  console.log(`Current surveys in DB: ${count}`);

  if (count === 0) {
    const onestopProg = await prisma.program.findFirst({
      where: { title: { contains: "원스톱" } }
    });

    const s1 = await prisma.survey.create({
      data: {
        id: "survey-onestop-2026",
        programId: onestopProg ? onestopProg.id : null,
        respondentType: "동아리",
        title: "2026 프로그램 만족 설문지 (원스톱 상담창구)",
        description: "본 설문은 대학 내에서 시행하고 있는 창업교육 강좌에 대한 만족도를 조사하는 설문입니다",
        status: "사용",
        author: "라이즈사업단",
        questions: JSON.stringify([
          { id: 1, type: "평가형", text: "나는 이 수업에 전체적으로 만족한다" },
          { id: 2, type: "평가형", text: "창업에 대한 다양한 지식과 기술을 습득하였다" },
          { id: 3, type: "평가형", text: "이 수업을 통해 창업에 대한 관심과 의지가 높아졌다" },
          { id: 4, type: "평가형", text: "우리 대학은 나에게 창업 준비 및 시작에 풍부한 기회를 제공한다" },
          { id: 5, type: "주관식", text: "창업교육 강좌와 관련하여 바라는 점이나 개선사항은 무엇입니까? 무엇이든 좋으니 자유롭게 기술해주십시오" }
        ])
      }
    });
    console.log(`Created survey 1: ${s1.title} (${s1.id})`);

    if (onestopProg) {
      await prisma.program.update({
        where: { id: onestopProg.id },
        data: { surveyId: s1.id }
      });
      console.log(`Linked survey 1 to program ${onestopProg.title}`);
    }

    const s2 = await prisma.survey.create({
      data: {
        id: "survey-mentor-2026",
        programId: null,
        respondentType: "멘토",
        title: "2026 창업 멘토링 프로그램 평가 설문지",
        description: "창업 멘토링 자문 활동에 대한 멘토 및 동아리 상호 만족도 평가입니다.",
        status: "사용",
        author: "창업지원단",
        questions: JSON.stringify([
          { id: 1, type: "평가형", text: "멘토링 일정이 원활히 조율되고 준수되었다." },
          { id: 2, type: "평가형", text: "멘토의 자문 내용이 창업 아이템 고도화에 실질적 도움이 되었다." },
          { id: 3, type: "주관식", text: "추후 보완되었으면 하는 멘토링 분야를 기술해 주세요." }
        ])
      }
    });
    console.log(`Created survey 2: ${s2.title} (${s2.id})`);
  } else {
    // If programs exist without surveyId, link onestop if needed
    const onestopProg = await prisma.program.findFirst({
      where: { title: { contains: "원스톱" } }
    });
    const firstSurvey = await prisma.survey.findFirst();
    if (onestopProg && !onestopProg.surveyId && firstSurvey) {
      await prisma.program.update({
        where: { id: onestopProg.id },
        data: { surveyId: firstSurvey.id }
      });
      await prisma.survey.update({
        where: { id: firstSurvey.id },
        data: { programId: onestopProg.id }
      });
      console.log(`Linked existing survey ${firstSurvey.id} to onestop program`);
    }
  }

  const allSurveys = await prisma.survey.findMany({ include: { program: true } });
  console.log('All surveys:', allSurveys.map(s => ({ id: s.id, title: s.title, prog: s.program?.title })));
}

main().catch(console.error).finally(() => prisma.$disconnect());
