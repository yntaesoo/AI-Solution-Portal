const { PrismaClient } = require('@prisma/client');
const { PrismaBetterSqlite3 } = require('@prisma/adapter-better-sqlite3');
const adapter = new PrismaBetterSqlite3({ url: "file:./dev.db" });
const prisma = new PrismaClient({ adapter });

async function main() {
  const app = await prisma.programApplication.findFirst({
    where: {
      user: { username: 'gamebrio' },
      program: { id: 'prog-onestop-2026' }
    },
    include: { user: true, program: true }
  });

  console.log('Target Application:', app);

  if (app) {
    // 1. Update status to 이수
    await prisma.programApplication.update({
      where: { id: app.id },
      data: { status: '이수' }
    });
    console.log('Updated application status to 이수');

    // 2. Create/Update Activity
    const descriptionData = JSON.stringify({
      programId: app.programId,
      applicationId: app.id,
      name: app.program.title,
      studentName: app.user.name,
      date: app.program.operateEndDate || new Date().toISOString().split("T")[0],
      autoSynced: true
    });

    const existingAct = await prisma.activity.findFirst({
      where: {
        clubId: app.user.clubId,
        description: { contains: app.programId }
      }
    });

    if (existingAct) {
      await prisma.activity.update({
        where: { id: existingAct.id },
        data: { status: '완료', description: descriptionData }
      });
      console.log('Updated existing activity');
    } else {
      const newAct = await prisma.activity.create({
        data: {
          clubId: app.user.clubId,
          type: '창업교육',
          status: '완료',
          description: descriptionData
        }
      });
      console.log('Created new Activity record:', newAct);
    }

    // 3. Verify activities for user's club
    const clubActs = await prisma.activity.findMany({ where: { clubId: app.user.clubId } });
    console.log('Club Activities after sync:', clubActs);
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
