﻿const Database = require('better-sqlite3');
const db = new Database('./dev.db');
const student = db.prepare("SELECT * FROM User WHERE username = 'student'").get();
console.log('Student user:', student);
