const { PrismaClient } = require('@prisma/client');
const { PrismaBetterSqlite3 } = require('@prisma/adapter-better-sqlite3');
const adapter = new PrismaBetterSqlite3({ url: "file:./dev.db" });
const prisma = new PrismaClient({ adapter });

async function main() {
  const student = await prisma.user.findFirst({ where: { username: 'gamebrio' } });
  console.log('Student:', student?.id, student?.name);

  const programs = await prisma.program.findMany({
    include: {
      applications: {
        include: {
          user: true
        }
      }
    }
  });

  console.log('--- ALL PROGRAMS AND APPLICATIONS IN DB ---');
  programs.forEach(p => {
    console.log(`Program [${p.id}] ${p.title}:`);
    p.applications.forEach(a => {
      console.log(`   - App ID: ${a.id}, User: ${a.user.name} (${a.userId}), Status: ${a.status}`);
    });
  });

  const allApps = await prisma.programApplication.findMany({ include: { user: true, program: true } });
  console.log('\n--- TOTAL DB APPLICATIONS:', allApps.length);
  allApps.forEach(a => {
    console.log(`App ID: ${a.id} | Prog: ${a.program.title} | User: ${a.user.name} (${a.user.username}) | Status: ${a.status}`);
  });
}

main().catch(console.error).finally(() => prisma.$disconnect());
