"use client";

import { useState } from "react";
import { updateClubBudgets, syncClubsFromUploadedExcel } from "@/app/actions";

export default function BudgetSpreadsheet({ initialClubs }: { initialClubs: any[] }) {
  const [clubs, setClubs] = useState(initialClubs);
  const [isSaving, setIsSaving] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [message, setMessage] = useState("");

  const handleChange = (index: number, field: string, value: string) => {
    const updated = [...clubs];
    const numericVal = parseFloat(value) || 0;
    updated[index] = { ...updated[index], [field]: numericVal };
    
    // Automatically calculate remainingBudget = budget - spentBudget
    if (field === 'budget' || field === 'spentBudget') {
      const budget = field === 'budget' ? numericVal : updated[index].budget;
      const spentBudget = field === 'spentBudget' ? numericVal : updated[index].spentBudget;
      updated[index].remainingBudget = budget - spentBudget;
    }
    
    setClubs(updated);
  };

  const handleSave = async () => {
    setIsSaving(true);
    setMessage("");
    try {
      await updateClubBudgets(clubs);
      setMessage("예산 정보가 성공적으로 저장되었습니다.");
    } catch (e) {
      setMessage("예산 저장에 실패했습니다.");
    } finally {
      setIsSaving(false);
      setTimeout(() => setMessage(""), 3000);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (!confirm(`선택한 엑셀 파일 (${file.name})로부터 예산 데이터를 읽어 동기화하시겠습니까?`)) {
      return;
    }
    setIsSyncing(true);
    setMessage("");
    try {
      const formData = new FormData();
      formData.append("file", file);
      await syncClubsFromUploadedExcel(formData);
      setMessage("엑셀 데이터와 동기화가 완료되었습니다. 페이지를 새로고침합니다.");
      window.location.reload();
    } catch (e) {
      setMessage("엑셀 동기화 중 오류가 발생했습니다.");
    } finally {
      setIsSyncing(false);
      setTimeout(() => setMessage(""), 3000);
    }
  };

  return (
    <div className="glass-card" style={{ marginTop: '2rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
        <h2>동아리 예산 현황 관리 (스프레드시트)</h2>
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
          {message && <span style={{ color: 'var(--primary)', fontWeight: 'bold', fontSize: '0.9rem' }}>{message}</span>}
          <label 
            className="btn"
            style={{ padding: '0.6rem 1.2rem', background: '#22c55e', color: '#fff', border: 'none', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer', display: 'inline-flex', alignItems: 'center' }}
          >
            {isSyncing ? "동기화 중..." : "엑셀 파일 선택 및 동기화"}
            <input 
              type="file" 
              accept=".xlsx, .xls" 
              onChange={handleFileChange} 
              disabled={isSyncing || isSaving}
              style={{ display: 'none' }} 
            />
          </label>
          <button 
            onClick={handleSave}
            disabled={isSaving || isSyncing}
            className="btn btn-primary"
            style={{ padding: '0.6rem 1.2rem' }}
          >
            {isSaving ? "저장 중..." : "예산 수정사항 저장"}
          </button>
        </div>
      </div>

      <div style={{ 
        maxHeight: '450px', 
        overflowY: 'auto', 
        overflowX: 'auto', 
        border: '1px solid #e5e7eb', 
        borderRadius: '8px',
        background: '#fff',
        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)'
      }}>
        <table style={{ minWidth: '1000px', borderCollapse: 'separate', borderSpacing: 0, width: '100%' }}>
          <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
            <tr>
              {[
                "동아리명", "신청 예산액 (원)", "지원 예산액 (원)", "집행액 (원)", "잔액 (원)"
              ].map((header, idx) => (
                <th 
                  key={idx} 
                  style={{ 
                    background: '#f9fafb', 
                    color: '#374151', 
                    fontWeight: 600, 
                    padding: '0.75rem', 
                    borderBottom: '2px solid #e5e7eb', 
                    borderRight: '1px solid #e5e7eb', 
                    textAlign: 'left',
                    fontSize: '0.875rem',
                    whiteSpace: 'nowrap'
                  }}
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {clubs.map((club, i) => {
              const cellStyle = { 
                borderBottom: '1px solid #e5e7eb', 
                borderRight: '1px solid #e5e7eb',
                padding: 0,
                background: '#fff'
              };
              const inputStyle = {
                width: '100%',
                border: 'none',
                outline: 'none',
                padding: '0.6rem 0.8rem',
                fontSize: '0.875rem',
                background: 'transparent',
                transition: 'all 0.15s',
                textAlign: 'right' as const
              };

              return (
                <tr key={club.id} style={{ transition: 'background-color 0.1s' }} onMouseEnter={e => e.currentTarget.style.backgroundColor = '#f9fafb'} onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}>
                  <td style={{ ...cellStyle, fontWeight: 'bold', padding: '0.6rem 0.8rem', fontSize: '0.875rem', background: '#f9fafb', whiteSpace: 'nowrap', borderRight: '2px solid #e5e7eb' }}>
                    {club.name}
                  </td>
                  <td style={cellStyle}>
                    <input 
                      type="number" 
                      value={club.requestedBudget ?? 0} 
                      onChange={e => handleChange(i, 'requestedBudget', e.target.value)} 
                      style={inputStyle}
                      onFocus={e => e.target.style.background = '#fff'}
                      onBlur={e => e.target.style.background = 'transparent'}
                    />
                  </td>
                  <td style={cellStyle}>
                    <input 
                      type="number" 
                      value={club.budget ?? 0} 
                      onChange={e => handleChange(i, 'budget', e.target.value)} 
                      style={inputStyle}
                      onFocus={e => e.target.style.background = '#fff'}
                      onBlur={e => e.target.style.background = 'transparent'}
                    />
                  </td>
                  <td style={cellStyle}>
                    <input 
                      type="number" 
                      value={club.spentBudget ?? 0} 
                      onChange={e => handleChange(i, 'spentBudget', e.target.value)} 
                      style={inputStyle}
                      onFocus={e => e.target.style.background = '#fff'}
                      onBlur={e => e.target.style.background = 'transparent'}
                    />
                  </td>
                  <td style={{ ...cellStyle, background: '#f9fafb', textAlign: 'right', padding: '0.6rem 0.8rem', fontSize: '0.875rem', fontWeight: 600, color: (club.remainingBudget ?? 0) < 0 ? 'red' : 'inherit' }}>
                    {(club.remainingBudget ?? 0).toLocaleString()} 원
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
