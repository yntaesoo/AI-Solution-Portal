import os
import json
import uuid
import re
from datetime import datetime

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
REF_DIR = os.path.join(DATA_DIR, "reference_docs")
INDEX_FILE = os.path.join(DATA_DIR, "documents_index.json")
FOLDERS_FILE = os.path.join(DATA_DIR, "registered_folders.json")

def init_doc_manager():
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(REF_DIR, exist_ok=True)
    
    # 1. 기본 폴더 등록
    if not os.path.exists(FOLDERS_FILE):
        parent_dir = os.path.dirname(os.path.abspath(__file__))
        anchor_dir = os.path.dirname(parent_dir)
        default_folders = [
            {
                "id": "fld_current",
                "name": os.path.basename(parent_dir) or "회의록작성",
                "path": parent_dir,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
            },
            {
                "id": "fld_anchor",
                "name": os.path.basename(anchor_dir) or "앵커사업",
                "path": anchor_dir,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
            }
        ]
        with open(FOLDERS_FILE, "w", encoding="utf-8") as f:
            json.dump({"folders": default_folders}, f, ensure_ascii=False, indent=2)

    # 2. 문서 인덱스 초기화
    if not os.path.exists(INDEX_FILE):
        default_index = {"documents": []}
        parent_dir = os.path.dirname(os.path.abspath(__file__))
        anchor_dir = os.path.dirname(parent_dir)
        plan_md = os.path.join(anchor_dir, "L-Stay_Major-Up_전공학습교류프로그램_운영계획안.md")
        if os.path.exists(plan_md):
            default_index["documents"].append({
                "id": "doc_default_plan",
                "title": "L-Stay Major-Up 전공학습교류프로그램 운영계획안",
                "filename": "L-Stay_Major-Up_전공학습교류프로그램_운영계획안.md",
                "file_path": plan_md,
                "file_size": os.path.getsize(plan_md),
                "file_type": "md",
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "is_active": True
            })
        with open(INDEX_FILE, "w", encoding="utf-8") as f:
            json.dump(default_index, f, ensure_ascii=False, indent=2)

def get_registered_folders() -> list:
    """등록된 로컬 폴더 목록 조회 (Antigravity Folders 스타일)"""
    init_doc_manager()
    try:
        with open(FOLDERS_FILE, "r", encoding="utf-8") as f:
            return json.load(f).get("folders", [])
    except Exception as e:
        print("Error reading folders:", e)
        return []

def save_registered_folders(folders: list):
    init_doc_manager()
    with open(FOLDERS_FILE, "w", encoding="utf-8") as f:
        json.dump({"folders": folders}, f, ensure_ascii=False, indent=2)

def register_folder(folder_path: str) -> dict:
    """폴더를 등록하고 해당 폴더 내의 계획서/문서를 자동 색인합니다"""
    init_doc_manager()
    norm_path = os.path.abspath(folder_path.strip())
    if not os.path.exists(norm_path) or not os.path.isdir(norm_path):
        raise ValueError(f"유효한 폴더 경로가 아닙니다: {folder_path}")

    folders = get_registered_folders()
    for f in folders:
        if os.path.abspath(f.get("path", "")) == norm_path:
            # 이미 등록된 경우 해당 폴더 내 문서 재색인 후 반환
            add_local_path(norm_path)
            return f

    f_id = f"fld_{uuid.uuid4().hex[:8]}"
    name = os.path.basename(norm_path.rstrip("\\/")) or norm_path
    entry = {
        "id": f_id,
        "name": name,
        "path": norm_path,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
    }
    folders.append(entry)
    save_registered_folders(folders)

    # 폴더 내 문서 자동 색인
    add_local_path(norm_path)
    return entry

def unregister_folder(folder_id: str) -> bool:
    """등록된 폴더를 목록에서 제거 (관련 문서도 정리)"""
    folders = get_registered_folders()
    target = None
    remaining = []
    for f in folders:
        if f["id"] == folder_id:
            target = f
        else:
            remaining.append(f)

    if target:
        save_registered_folders(remaining)
        target_path = os.path.abspath(target.get("path", ""))
        # 해당 폴더 하위 문서들 인덱스에서도 제거
        docs = get_all_documents()
        kept_docs = []
        for d in docs:
            fp = os.path.abspath(d.get("file_path", ""))
            if not fp.startswith(target_path):
                kept_docs.append(d)
        save_documents(kept_docs)
        return True
    return False

def get_all_documents() -> list:
    init_doc_manager()
    try:
        with open(INDEX_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("documents", [])
    except Exception as e:
        print("Error reading document index:", e)
        return []

def save_documents(docs: list):
    init_doc_manager()
    with open(INDEX_FILE, "w", encoding="utf-8") as f:
        json.dump({"documents": docs}, f, ensure_ascii=False, indent=2)

def extract_text_from_file(file_path: str) -> str:
    """파일 경로에서 텍스트를 추출합니다 (.md, .txt, .hwp, .hwpx, .pdf 등)"""
    if not os.path.exists(file_path):
        return ""
    
    ext = os.path.splitext(file_path)[1].lower()
    
    # 1. 텍스트/마크다운 파일
    if ext in [".md", ".txt", ".json", ".csv"]:
        for enc in ["utf-8", "cp949", "euc-kr"]:
            try:
                with open(file_path, "r", encoding=enc) as f:
                    return f.read()
            except Exception:
                continue
        return ""

    # 2. 한글 파일 (.hwp, .hwpx)
    if ext in [".hwp", ".hwpx"]:
        try:
            import pyhwpx
            hwp = pyhwpx.Hwp(visible=False)
            hwp.open(os.path.abspath(file_path))
            hwp.HAction.Run("SelectAll")
            text = hwp.get_selected_text()
            hwp.quit()
            return text or ""
        except Exception as e:
            print(f"HWP text extraction error ({file_path}):", e)
            return ""

    # 3. PDF 파일 (.pdf)
    if ext == ".pdf":
        try:
            import pypdf
            reader = pypdf.PdfReader(file_path)
            pages_text = [page.extract_text() or "" for page in reader.pages]
            return "\n".join(pages_text)
        except Exception:
            pass

    return ""

def add_document_file(original_filename: str, file_bytes: bytes, title: str = None) -> dict:
    """업로드된 파일을 reference_docs에 저장하고 인덱스에 등록"""
    init_doc_manager()
    doc_id = f"doc_{uuid.uuid4().hex[:8]}"
    ext = os.path.splitext(original_filename)[1].lower()
    safe_name = f"{doc_id}_{original_filename}"
    save_path = os.path.join(REF_DIR, safe_name)

    with open(save_path, "wb") as f:
        f.write(file_bytes)

    doc_entry = {
        "id": doc_id,
        "title": title or original_filename,
        "filename": original_filename,
        "file_path": save_path,
        "file_size": len(file_bytes),
        "file_type": ext.replace(".", ""),
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "is_active": True
    }

    docs = get_all_documents()
    docs.append(doc_entry)
    save_documents(docs)
    return doc_entry

def add_local_path(target_path: str) -> list:
    """로컬 파일 또는 폴더 경로를 스캔하여 문서 등록"""
    init_doc_manager()
    if not os.path.exists(target_path):
        raise FileNotFoundError(f"경로를 찾을 수 없습니다: {target_path}")

    added = []
    docs = get_all_documents()
    existing_paths = {d.get("file_path") for d in docs}

    # 단일 파일인 경우
    if os.path.isfile(target_path):
        files_to_check = [target_path]
    else:
        # 폴더인 경우 문서 확장자 검색
        files_to_check = []
        for root, _, files in os.walk(target_path):
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in [".md", ".txt", ".hwp", ".hwpx", ".pdf", ".docx"]:
                    files_to_check.append(os.path.join(root, file))

    for fp in files_to_check:
        if fp in existing_paths:
            continue
        fname = os.path.basename(fp)
        ext = os.path.splitext(fname)[1].lower()
        doc_id = f"doc_{uuid.uuid4().hex[:8]}"
        doc_entry = {
            "id": doc_id,
            "title": os.path.splitext(fname)[0],
            "filename": fname,
            "file_path": fp,
            "file_size": os.path.getsize(fp),
            "file_type": ext.replace(".", ""),
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "is_active": True
        }
        docs.append(doc_entry)
        added.append(doc_entry)

    if added:
        save_documents(docs)
    return added

def delete_document(doc_id: str) -> bool:
    """등록된 문서 단일 삭제"""
    return delete_documents([doc_id]) > 0

def delete_documents(doc_ids: list) -> int:
    """등록된 문서 다중 / 부분 삭제"""
    if not doc_ids:
        return 0
    id_set = set(doc_ids)
    docs = get_all_documents()
    remaining = []
    deleted_count = 0

    for d in docs:
        if d["id"] in id_set:
            deleted_count += 1
            fp = d.get("file_path")
            if fp and fp.startswith(REF_DIR) and os.path.exists(fp):
                try:
                    os.remove(fp)
                except Exception as e:
                    print("Failed to remove ref file:", e)
        else:
            remaining.append(d)

    if deleted_count > 0:
        save_documents(remaining)
    return deleted_count

def delete_all_documents() -> int:
    """등록된 모든 문서 전체 일괄 삭제"""
    docs = get_all_documents()
    all_ids = [d["id"] for d in docs]
    return delete_documents(all_ids)

def get_context_text_for_ai(selected_doc_ids: list = None) -> str:
    """선택된 문서들(또는 활성화된 전체 문서)의 텍스트를 추출하여 AI 컨텍스트로 제공"""
    docs = get_all_documents()
    combined_texts = []

    for d in docs:
        if selected_doc_ids and d["id"] not in selected_doc_ids:
            continue
        if not selected_doc_ids and not d.get("is_active", True):
            continue

        fp = d.get("file_path")
        if fp and os.path.exists(fp):
            txt = extract_text_from_file(fp)
            if txt:
                combined_texts.append(f"=== [참고 문서: {d.get('title', d.get('filename'))}] ===\n{txt.strip()[:4000]}")

    return "\n\n".join(combined_texts)
