import os
import sys
import subprocess
import json
import uuid
import re
from datetime import datetime

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
REF_DIR = os.path.join(DATA_DIR, "reference_docs")
INDEX_FILE = os.path.join(DATA_DIR, "documents_index.json")
FOLDERS_FILE = os.path.join(DATA_DIR, "registered_folders.json")

def init_doc_manager():
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(REF_DIR, exist_ok=True)
    
    # 1. 기본 폴더 등록
    if not os.path.exists(FOLDERS_FILE):
        parent_dir = os.path.dirname(os.path.abspath(__file__))
        anchor_dir = os.path.dirname(parent_dir)
        default_folders = [
            {
                "id": "fld_current",
                "name": os.path.basename(parent_dir) or "회의록작성",
                "path": parent_dir,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
            },
            {
                "id": "fld_anchor",
                "name": os.path.basename(anchor_dir) or "앵커사업",
                "path": anchor_dir,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
            }
        ]
        with open(FOLDERS_FILE, "w", encoding="utf-8") as f:
            json.dump({"folders": default_folders}, f, ensure_ascii=False, indent=2)

    # 2. 문서 인덱스 초기화
    if not os.path.exists(INDEX_FILE):
        default_index = {"documents": []}
        parent_dir = os.path.dirname(os.path.abspath(__file__))
        anchor_dir = os.path.dirname(parent_dir)
        plan_md = os.path.join(anchor_dir, "L-Stay_Major-Up_전공학습교류프로그램_운영계획안.md")
        if os.path.exists(plan_md):
            default_index["documents"].append({
                "id": "doc_default_plan",
                "title": "L-Stay Major-Up 전공학습교류프로그램 운영계획안",
                "filename": "L-Stay_Major-Up_전공학습교류프로그램_운영계획안.md",
                "file_path": plan_md,
                "file_size": os.path.getsize(plan_md),
                "file_type": "md",
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "is_active": True
            })
        with open(INDEX_FILE, "w", encoding="utf-8") as f:
            json.dump(default_index, f, ensure_ascii=False, indent=2)

def get_registered_folders() -> list:
    """등록된 로컬 폴더 목록 조회 (Antigravity Folders 스타일)"""
    init_doc_manager()
    try:
        with open(FOLDERS_FILE, "r", encoding="utf-8") as f:
            return json.load(f).get("folders", [])
    except Exception as e:
        print("Error reading folders:", e)
        return []

def save_registered_folders(folders: list):
    init_doc_manager()
    with open(FOLDERS_FILE, "w", encoding="utf-8") as f:
        json.dump({"folders": folders}, f, ensure_ascii=False, indent=2)

def get_system_drives() -> list:
    """시스템에서 사용 가능한 드라이브 목록 반환 (C:\\, D:\\, H:\\ 등)"""
    drives = []
    try:
        import ctypes, string
        bitmask = ctypes.windll.kernel32.GetLogicalDrives()
        for letter in string.ascii_uppercase:
            if bitmask & 1:
                dp = f"{letter}:\\"
                if os.path.exists(dp):
                    drives.append(dp)
            bitmask >>= 1
    except Exception:
        drives = ["C:\\"]
    return drives

def get_quick_shortcuts() -> list:
    """자주 사용하는 주요 프로젝트 폴더 바로가기"""
    candidates = [
        {"name": "앵커사업 메인", "path": r"H:\Create with Anti\앵커사업"},
        {"name": "캡스톤디자인", "path": r"H:\Create with Anti\앵커사업\캡스톤디자인"},
        {"name": "정주지원캠프", "path": r"H:\Create with Anti\앵커사업\정주지원캠프"},
        {"name": "회의록작성", "path": r"H:\Create with Anti\앵커사업\회의록작성"},
    ]
    # 드라이브 추가
    for d in get_system_drives():
        candidates.append({"name": f"{d[:2]} 드라이브", "path": d})
    return [s for s in candidates if os.path.exists(s["path"])]

def list_fs_directory(target_path: str = "") -> dict:
    """웹 브라우저 파일 탐색기용 디렉토리 및 문서 목록 반환"""
    init_doc_manager()
    if not target_path or not os.path.exists(target_path):
        target_path = r"H:\Create with Anti\앵커사업"
        if not os.path.exists(target_path):
            drives = get_system_drives()
            target_path = drives[0] if drives else "C:\\"

    target_path = os.path.abspath(target_path)
    parent_path = os.path.dirname(target_path)
    if parent_path == target_path:
        parent_path = None

    folders = []
    files = []

    docs = get_all_documents()
    indexed_paths = {os.path.normpath(d.get("file_path", "")) for d in docs if d.get("file_path")}

    try:
        with os.scandir(target_path) as it:
            for entry in it:
                try:
                    if entry.is_dir(follow_symlinks=False):
                        if not entry.name.startswith("."):
                            folders.append({
                                "name": entry.name,
                                "path": os.path.normpath(entry.path)
                            })
                    elif entry.is_file(follow_symlinks=False):
                        ext = os.path.splitext(entry.name)[1].lower()
                        if ext in [".md", ".txt", ".hwp", ".hwpx", ".pdf", ".docx"]:
                            sz = entry.stat().st_size
                            sz_str = f"{sz/1024:.1f} KB" if sz < 1024*1024 else f"{sz/(1024*1024):.1f} MB"
                            mtime = datetime.fromtimestamp(entry.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
                            norm_p = os.path.normpath(entry.path)
                            files.append({
                                "name": entry.name,
                                "path": norm_p,
                                "ext": ext,
                                "size_str": sz_str,
                                "size_bytes": sz,
                                "modified_at": mtime,
                                "is_already_added": norm_p in indexed_paths
                            })
                except Exception:
                    pass
    except Exception as e:
        print(f"Error scanning directory {target_path}:", e)

    folders.sort(key=lambda x: x["name"].lower())
    files.sort(key=lambda x: x["name"].lower())

    return {
        "current_path": target_path,
        "parent_path": parent_path,
        "folders": folders,
        "files": files,
        "drives": get_system_drives(),
        "shortcuts": get_quick_shortcuts()
    }

def browse_folder_dialog(initial_dir: str = "") -> str:
    """Windows 폴더 선택 대화상자를 화면 최상단에 띄워 사용자가 선택한 폴더 경로 반환 (안전 타임아웃 적용)"""
    clean_init = initial_dir.strip().strip('"').strip("'").rstrip('\\/') if initial_dir else ""
    if not clean_init or not os.path.exists(clean_init):
        clean_init = r"H:\Create with Anti\앵커사업"
        if not os.path.exists(clean_init):
            clean_init = ""

    py_code = """
import sys, os
try:
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.overrideredirect(True)
    root.geometry('0x0+0+0')
    root.deiconify()
    root.lift()
    root.focus_force()
    root.attributes('-topmost', True)
    init_dir = sys.argv[1] if len(sys.argv) > 1 and os.path.exists(sys.argv[1]) else None
    path = filedialog.askdirectory(parent=root, initialdir=init_dir, title="추가할 로컬 폴더를 선택하세요")
    root.destroy()
    if path:
        print(os.path.normpath(path), end='')
except Exception:
    pass
"""
    try:
        res = subprocess.run(
            [sys.executable, "-c", py_code, clean_init],
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=120
        )
        out = res.stdout.strip()
        if out and os.path.exists(out) and os.path.isdir(out):
            return out
    except Exception as e:
        print("Tkinter browse failed, trying PowerShell fallback:", e)

    # PowerShell FolderBrowserDialog 폴백
    try:
        ps_cmd = (
            'Add-Type -AssemblyName System.Windows.Forms; '
            '$f = New-Object System.Windows.Forms.FolderBrowserDialog; '
            '$f.Description = "추가할 로컬 폴더를 선택하세요"; '
            '$f.ShowNewFolderButton = $true; '
            '$f.AutoUpgradeEnabled = $true; '
        )
        if clean_init and os.path.exists(clean_init):
            ps_cmd += f'$f.SelectedPath = "{clean_init}"; '
        ps_cmd += (
            '$form = New-Object System.Windows.Forms.Form; '
            '$form.TopMost = $true; '
            '$form.ShowInTaskbar = $false; '
            '$form.WindowState = [System.Windows.Forms.FormWindowState]::Minimized; '
            '$form.Show(); '
            '$form.Activate(); '
            'if ($f.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $f.SelectedPath }; '
            '$form.Dispose(); $f.Dispose()'
        )
        
        res = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps_cmd],
            capture_output=True, text=True, timeout=120, encoding="utf-8"
        )
        out = res.stdout.strip()
        if out and os.path.exists(out) and os.path.isdir(out):
            return out
    except Exception as pe:
        print("PowerShell browse failed:", pe)

    return ""

def scan_folder_candidate_docs(folder_path: str) -> list:
    """폴더 내 등록 가능한 문서 후보 목록 조회 (사용자 선택 전까지 자동 색인하지 않음)"""
    init_doc_manager()
    clean = folder_path.strip().strip('"').strip("'")
    if len(clean) > 3 and clean.endswith(('\\', '/')):
        clean = clean.rstrip('\\/')
    norm_path = os.path.abspath(clean)
    if not os.path.exists(norm_path) or not os.path.isdir(norm_path):
        raise ValueError(f"유효한 폴더가 아닙니다: {folder_path}")

    existing_docs = get_all_documents()
    existing_paths = {os.path.abspath(d.get("file_path", "")) for d in existing_docs}

    candidates = []
    for root, _, files in os.walk(norm_path):
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in [".md", ".txt", ".hwp", ".hwpx", ".pdf", ".docx"]:
                full_path = os.path.join(root, file)
                norm_fp = os.path.abspath(full_path)
                rel_path = os.path.relpath(full_path, norm_path)
                is_already_added = norm_fp in existing_paths
                
                size_bytes = os.path.getsize(full_path)
                if size_bytes < 1024:
                    size_str = f"{size_bytes} B"
                elif size_bytes < 1024 * 1024:
                    size_str = f"{size_bytes / 1024:.1f} KB"
                else:
                    size_str = f"{size_bytes / (1024 * 1024):.1f} MB"
                
                mtime = datetime.fromtimestamp(os.path.getmtime(full_path)).strftime("%Y-%m-%d %H:%M")
                
                candidates.append({
                    "filename": file,
                    "title": os.path.splitext(file)[0],
                    "file_path": full_path,
                    "path": full_path,
                    "rel_path": rel_path,
                    "file_size": size_bytes,
                    "size_str": size_str,
                    "file_type": ext.replace(".", ""),
                    "extension": ext,
                    "modified_at": mtime,
                    "is_already_added": is_already_added
                })

    candidates.sort(key=lambda x: (x["is_already_added"], x["rel_path"].lower()))
    return candidates

def register_folder(folder_path: str) -> dict:
    """폴더를 등록 목록에 추가 (하위 문서는 사용자가 선택할 수 있도록 자동 등록하지 않음)"""
    init_doc_manager()
    clean = folder_path.strip().strip('"').strip("'")
    if len(clean) > 3 and clean.endswith(('\\', '/')):
        clean = clean.rstrip('\\/')
    norm_path = os.path.abspath(clean)
    if not os.path.exists(norm_path) or not os.path.isdir(norm_path):
        raise ValueError(f"유효한 폴더 경로가 아닙니다: {folder_path}")

    folders = get_registered_folders()
    for f in folders:
        if os.path.abspath(f.get("path", "")) == norm_path:
            return f

    f_id = f"fld_{uuid.uuid4().hex[:8]}"
    name = os.path.basename(norm_path.rstrip("\\/")) or norm_path
    entry = {
        "id": f_id,
        "name": name,
        "path": norm_path,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
    }
    folders.append(entry)
    save_registered_folders(folders)
    return entry

def add_selected_documents(file_paths: list) -> list:
    """사용자가 체크 선택한 문서 파일들만 인덱스에 등록"""
    init_doc_manager()
    added = []
    docs = get_all_documents()
    existing_paths = {os.path.abspath(d.get("file_path", "")) for d in docs}

    for fp in file_paths:
        norm_fp = os.path.abspath(fp)
        if not os.path.exists(norm_fp) or norm_fp in existing_paths:
            continue
        fname = os.path.basename(norm_fp)
        ext = os.path.splitext(fname)[1].lower()
        doc_id = f"doc_{uuid.uuid4().hex[:8]}"
        doc_entry = {
            "id": doc_id,
            "title": os.path.splitext(fname)[0],
            "filename": fname,
            "file_path": norm_fp,
            "file_size": os.path.getsize(norm_fp),
            "file_type": ext.replace(".", ""),
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "is_active": True
        }
        docs.append(doc_entry)
        added.append(doc_entry)
        existing_paths.add(norm_fp)

    if added:
        save_documents(docs)
    return added

def unregister_folder(folder_id: str) -> bool:
    """등록된 폴더를 목록에서 제거 (관련 문서도 정리)"""
    folders = get_registered_folders()
    target = None
    remaining = []
    for f in folders:
        if f["id"] == folder_id:
            target = f
        else:
            remaining.append(f)

    if target:
        save_registered_folders(remaining)
        target_path = os.path.abspath(target.get("path", ""))
        # 해당 폴더 하위 문서들 인덱스에서도 제거
        docs = get_all_documents()
        kept_docs = []
        for d in docs:
            fp = os.path.abspath(d.get("file_path", ""))
            if not fp.startswith(target_path):
                kept_docs.append(d)
        save_documents(kept_docs)
        return True
    return False

def get_all_documents() -> list:
    init_doc_manager()
    try:
        with open(INDEX_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("documents", [])
    except Exception as e:
        print("Error reading document index:", e)
        return []

def save_documents(docs: list):
    init_doc_manager()
    with open(INDEX_FILE, "w", encoding="utf-8") as f:
        json.dump({"documents": docs}, f, ensure_ascii=False, indent=2)

def extract_text_from_file(file_path: str) -> str:
    """파일 경로에서 텍스트를 추출합니다 (.md, .txt, .hwp, .hwpx, .pdf 등)"""
    if not os.path.exists(file_path):
        return ""
    
    ext = os.path.splitext(file_path)[1].lower()
    
    # 1. 텍스트/마크다운 파일
    if ext in [".md", ".txt", ".json", ".csv"]:
        for enc in ["utf-8", "cp949", "euc-kr"]:
            try:
                with open(file_path, "r", encoding=enc) as f:
                    return f.read()
            except Exception:
                continue
        return ""

    # 2. 한글 파일 (.hwp, .hwpx)
    if ext in [".hwp", ".hwpx"]:
        try:
            import pyhwpx
            hwp = pyhwpx.Hwp(visible=False)
            hwp.open(os.path.abspath(file_path))
            hwp.HAction.Run("SelectAll")
            text = hwp.get_selected_text()
            hwp.quit()
            return text or ""
        except Exception as e:
            print(f"HWP text extraction error ({file_path}):", e)
            return ""

    # 3. PDF 파일 (.pdf)
    if ext == ".pdf":
        try:
            import pypdf
            reader = pypdf.PdfReader(file_path)
            pages_text = [page.extract_text() or "" for page in reader.pages]
            return "\n".join(pages_text)
        except Exception:
            pass

    return ""

def add_document_file(original_filename: str, file_bytes: bytes, title: str = None) -> dict:
    """업로드된 파일을 reference_docs에 저장하고 인덱스에 등록"""
    init_doc_manager()
    doc_id = f"doc_{uuid.uuid4().hex[:8]}"
    ext = os.path.splitext(original_filename)[1].lower()
    safe_name = f"{doc_id}_{original_filename}"
    save_path = os.path.join(REF_DIR, safe_name)

    with open(save_path, "wb") as f:
        f.write(file_bytes)

    doc_entry = {
        "id": doc_id,
        "title": title or original_filename,
        "filename": original_filename,
        "file_path": save_path,
        "file_size": len(file_bytes),
        "file_type": ext.replace(".", ""),
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "is_active": True
    }

    docs = get_all_documents()
    docs.append(doc_entry)
    save_documents(docs)
    return doc_entry

def add_local_path(target_path: str) -> list:
    """로컬 파일 또는 폴더 경로를 스캔하여 문서 등록"""
    init_doc_manager()
    if not os.path.exists(target_path):
        raise FileNotFoundError(f"경로를 찾을 수 없습니다: {target_path}")

    added = []
    docs = get_all_documents()
    existing_paths = {d.get("file_path") for d in docs}

    # 단일 파일인 경우
    if os.path.isfile(target_path):
        files_to_check = [target_path]
    else:
        # 폴더인 경우 문서 확장자 검색
        files_to_check = []
        for root, _, files in os.walk(target_path):
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in [".md", ".txt", ".hwp", ".hwpx", ".pdf", ".docx"]:
                    files_to_check.append(os.path.join(root, file))

    for fp in files_to_check:
        if fp in existing_paths:
            continue
        fname = os.path.basename(fp)
        ext = os.path.splitext(fname)[1].lower()
        doc_id = f"doc_{uuid.uuid4().hex[:8]}"
        doc_entry = {
            "id": doc_id,
            "title": os.path.splitext(fname)[0],
            "filename": fname,
            "file_path": fp,
            "file_size": os.path.getsize(fp),
            "file_type": ext.replace(".", ""),
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "is_active": True
        }
        docs.append(doc_entry)
        added.append(doc_entry)

    if added:
        save_documents(docs)
    return added

def delete_document(doc_id: str) -> bool:
    """등록된 문서 단일 삭제"""
    return delete_documents([doc_id]) > 0

def delete_documents(doc_ids: list) -> int:
    """등록된 문서 다중 / 부분 삭제"""
    if not doc_ids:
        return 0
    id_set = set(doc_ids)
    docs = get_all_documents()
    remaining = []
    deleted_count = 0

    for d in docs:
        if d["id"] in id_set:
            deleted_count += 1
            fp = d.get("file_path")
            if fp and fp.startswith(REF_DIR) and os.path.exists(fp):
                try:
                    os.remove(fp)
                except Exception as e:
                    print("Failed to remove ref file:", e)
        else:
            remaining.append(d)

    if deleted_count > 0:
        save_documents(remaining)
    return deleted_count

def delete_all_documents() -> int:
    """등록된 모든 문서 전체 일괄 삭제"""
    docs = get_all_documents()
    all_ids = [d["id"] for d in docs]
    return delete_documents(all_ids)

def get_context_text_for_ai(selected_doc_ids: list = None) -> str:
    """선택된 문서들(또는 활성화된 전체 문서)의 텍스트를 추출하여 AI 컨텍스트로 제공"""
    docs = get_all_documents()
    combined_texts = []

    for d in docs:
        if selected_doc_ids and d["id"] not in selected_doc_ids:
            continue
        if not selected_doc_ids and not d.get("is_active", True):
            continue

        fp = d.get("file_path")
        if fp and os.path.exists(fp):
            txt = extract_text_from_file(fp)
            if txt:
                combined_texts.append(f"=== [참고 문서: {d.get('title', d.get('filename'))}] ===\n{txt.strip()[:4000]}")

    return "\n\n".join(combined_texts)
