with open("portal_page.html", encoding="utf-8") as f:
    text = f.read()

import re
print("Length:", len(text))
for m in re.finditer(r'<h3[^>]*>(.*?)</h3>', text):
    print("Solution:", m.group(1))

# 아이디어 카테고리에 어떤 솔루션이 등록되어 있는지 확인
# 그리고 버튼 클릭이나 모달 구조 확인
for m in re.finditer(r'<button[^>]*>(.*?)</button>', text):
    print("Button:", m.group(1))

# '솔루션 등록' 관련 내용
idx = text.find("솔루션 등록")
if idx != -1:
    print("\n--- Context of 솔루션 등록 ---")
    print(text[max(0, idx-200):min(len(text), idx+500)])
