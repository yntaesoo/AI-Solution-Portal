import os
import re
import subprocess
import time
from datetime import datetime
from PIL import Image
import pyhwpx

TEMPLATE_FILE = "[양식] 회의비 정산서류(회의록, 참석자명부, 영수증첨부철).hwp"

def kill_stale_hwp_processes():
    """백그라운드에서 좀비 상태로 남아 COM 연결을 차단하는 Hwp 프로세스 강제 정리"""
    try:
        subprocess.run(["taskkill", "/F", "/IM", "Hwp.exe", "/T"], capture_output=True, timeout=5)
        subprocess.run(["taskkill", "/F", "/IM", "HwpApi.exe", "/T"], capture_output=True, timeout=5)
        time.sleep(0.5)
    except Exception as e:
        print("kill_stale_hwp_processes warning:", e)

def get_safe_hwp_instance(visible: bool = False, max_retries: int = 2):
    """
    HWP COM 인스턴스를 안전하게 생성하며,
    '서버 실행이 실패했습니다' (-2146959355) 등의 COM 에러 발생 시 좀비 프로세스를 정리하고 자동 재시도
    """
    last_err = None
    for attempt in range(max_retries):
        try:
            hwp = pyhwpx.Hwp(visible=visible)
            try:
                hwp.RegisterModule("FilePathCheckDLL", "FilePathCheckerModule")
            except Exception:
                pass
            return hwp
        except Exception as e:
            last_err = e
            print(f"[HWP Init Attempt {attempt+1}] 실패: {e}")
            kill_stale_hwp_processes()
            time.sleep(1.0)
            
    raise RuntimeError(f"한글(HWP) 자동화 서버 연결 실패: {last_err}")

def clean_text(s: str) -> str:
    if not s:
        return ""
    return str(s).strip()

def format_discussion_text(raw_text: str) -> str:
    """토의내용 요지: 대항목 간 빈 줄(엔터) 1칸 및 세부항목 들여쓰기(  ‣ ) 적용된 다중 문단 텍스트 생성"""
    if not raw_text:
        return ""
    clean = str(raw_text).replace("\r\n", "\n").replace("\r", "\n")
    lines = clean.split("\n")
    formatted_lines = []
    
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            if formatted_lines and formatted_lines[-1] != "":
                formatted_lines.append("")
            continue
            
        # 대항목 (○, ■, ◆, □, 1., 2., [1], [2] 등)
        is_major = bool(re.match(r'^(?:○|■|◆|□|[0-9]+[.)]|\[[0-9]+\])\s*', stripped))
        # 세부 항목 (‣, -, •, ▪, * 등)
        is_sub = bool(re.match(r'^(?:‣|•|▪|-|\*)\s*', stripped))
        
        if is_major:
            # 대항목 앞 빈 줄(엔터) 1칸 띄우기 확보
            if formatted_lines and formatted_lines[-1] != "":
                formatted_lines.append("")
            # 기호 정규화 (1., 2. 등 숫자 항목은 유지, 기타 기호는 ○로 정규화)
            if not stripped.startswith("○") and not re.match(r'^[0-9]+[.)]', stripped):
                clean_title = re.sub(r'^(?:■|◆|□)\s*', '', stripped)
                formatted_lines.append(f"○ {clean_title}")
            else:
                formatted_lines.append(stripped)
        elif is_sub:
            # 세부 항목: 공백 2칸 들여쓰기 + ‣ 기호 적용
            sub_content = re.sub(r'^(?:‣|•|▪|-|\*)\s*', '', stripped)
            formatted_lines.append(f"  ‣ {sub_content}")
        else:
            # 일반 텍스트가 대항목 아래에 올 때도 들여쓰기 유지
            formatted_lines.append(f"  {stripped}" if formatted_lines and not formatted_lines[-1].startswith("○") else stripped)
            
    return "\r\n".join(formatted_lines)

def set_discussion_shape(hwp, font_size: float = 11.0):
    """
    20261016_회의비 정산서류(외식일번가 234,000원)_윤태수.hwp 파일과 동일한
    글자 모양(휴먼명조 11pt, 장평 90%, 자간 -15%) 및 문단 모양(왼쪽 정렬, 줄간격 140%, 좌우 여백 6pt, 내어쓰기 -18.6pt) 적용
    """
    try:
        # 1. 글자 모양 설정
        c_set = hwp.HParameterSet.HCharShape
        hwp.HAction.GetDefault("CharShape", c_set.HSet)
        for lang in ["Hangul", "Latin", "Hanja", "Japanese", "Other", "Symbol", "User"]:
            setattr(c_set, f"FaceName{lang}", "휴먼명조")
            setattr(c_set, f"Ratio{lang}", 90)
            setattr(c_set, f"Spacing{lang}", -15)
        c_set.Height = int(font_size * 100)
        c_set.Bold = 0
        c_set.TextColor = 0
        hwp.HAction.Execute("CharShape", c_set.HSet)
    except Exception as e:
        print("set_discussion_charshape error:", e)

    try:
        # 2. 문단 모양 설정
        p_set = hwp.HParameterSet.HParaShape
        hwp.HAction.GetDefault("ParaShape", p_set.HSet)
        p_set.AlignType = 1          # 왼쪽 정렬 (AlignType 1)
        p_set.LineSpacingType = 0    # 퍼센트 단위 줄간격
        p_set.LineSpacing = 140      # 140%
        p_set.LeftMargin = 600       # 6.0 pt 왼쪽 여백
        p_set.RightMargin = 600      # 6.0 pt 오른쪽 여백
        p_set.Indentation = -1860    # -18.6 pt 내어쓰기 (Hanging Indent)
        p_set.PrevSpacing = 0
        p_set.NextSpacing = 0
        hwp.HAction.Execute("ParaShape", p_set.HSet)
    except Exception as e:
        print("set_discussion_parashape error:", e)

def write_discussion_text(hwp, text: str, font_size: float = None):
    """
    토의내용 요지 작성:
    20261016_회의비 정산서류(외식일번가 234,000원)_윤태수.hwp와 동일한
    포맷(대항목 ○, 세부항목 ‣), 글꼴(휴먼명조, 11pt, 장평 90%, 자간 -15%), 정렬(왼쪽정렬, 줄간격 140%, 좌우여백 6pt, 내어쓰기 -18.6pt) 적용
    """
    if not text:
        return
    formatted = format_discussion_text(text)
    
    if font_size is None:
        # 텍스트 길이에 따른 글자 크기 동적 결정 (기본 11.0pt, 본문이 길 경우 표 넘침 방지)
        clean_len = len(formatted)
        line_count = len([l for l in formatted.splitlines() if l.strip()])
        if clean_len > 700 or line_count > 16:
            font_size = 9.5
        elif clean_len > 500 or line_count > 13:
            font_size = 10.5
        else:
            font_size = 11.0  # 윤태수.hwp 표준 크기

    hwp.insert_text(formatted)
    
    # 셀 전체 선택 후 글자모양/문단모양 일괄 적용
    hwp.HAction.Run("SelectAll")
    set_discussion_shape(hwp, font_size=font_size)
    hwp.Run("Cancel")

def write_multiline_text(hwp, text: str, font_size: float = None):
    """하위 호환성 유지용 alias"""
    write_discussion_text(hwp, text, font_size)


def format_date_weekday(date_str: str) -> str:
    """date_str: YYYY-MM-DD -> YYYY.MM.DD.(요일)"""
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        weekdays = ["월", "화", "수", "목", "금", "토", "일"]
        w = weekdays[dt.weekday()]
        return f"{dt.year}.{dt.month:02d}.{dt.day:02d}.({w})"
    except Exception:
        return date_str

def set_font_size(hwp, pt_size: float):
    """현재 선택된 블록의 글자 크기 설정 (pt 단위)"""
    try:
        pset = hwp.HParameterSet.HCharShape
        hwp.HAction.GetDefault("CharShape", pset.HSet)
        pset.Height = int(pt_size * 100)
        hwp.HAction.Execute("CharShape", pset.HSet)
    except Exception as e:
        print("set_font_size error:", e)

def resize_for_hwp(img_path: str, max_w: int = 420, max_h: int = 600) -> str:
    """영수증/카드내역 이미지가 표 높이를 넘지 않도록 리사이즈"""
    if not img_path or not os.path.exists(img_path):
        return None
    try:
        img = Image.open(img_path)
        img.thumbnail((max_w, max_h), Image.Resampling.LANCZOS)
        dir_name, base_name = os.path.split(img_path)
        resized_path = os.path.join(dir_name, f"fit_{base_name}")
        img.save(resized_path, "PNG")
        return resized_path
    except Exception as e:
        print("resize error:", e)
        return img_path

def generate_meeting_minutes_hwp(
    base_dir: str,
    data: dict,
    receipt_img_path: str = None,
    card_statement_img_path: str = None,
    output_filename: str = None
) -> dict:
    """
    회의록 정산서류(회의록, 참석자명부, 영수증첨부철)를 생성합니다.
    """
    template_path = os.path.join(base_dir, TEMPLATE_FILE)
    if not os.path.exists(template_path):
        raise FileNotFoundError(f"양식 파일을 찾을 수 없습니다: {template_path}")

    # 날짜 및 파일명 결정
    meeting_date = data.get("meeting_date", "")
    meeting_name = clean_text(data.get("meeting_name", "회의록"))
    
    date_compact = meeting_date.replace("-", "") if meeting_date else datetime.now().strftime("%Y%m%d")
    
    if not output_filename:
        safe_name = re.sub(r'[\\/*?:"<>|]', "", meeting_name)[:30]
        output_filename = f"{date_compact}_회의록_{safe_name}.hwp"
        
    out_dir = os.path.join(base_dir, "output")
    os.makedirs(out_dir, exist_ok=True)
    out_hwp_path = os.path.abspath(os.path.join(out_dir, output_filename))
    out_pdf_path = os.path.abspath(os.path.splitext(out_hwp_path)[0] + ".pdf")

    # 데이터 추출
    project_name = clean_text(data.get("project_name", "앵커 사업단"))
    start_time = clean_text(data.get("start_time", "18:00"))
    end_time = clean_text(data.get("end_time", "20:00"))
    
    date_formatted = format_date_weekday(meeting_date)
    dt_str = f"{date_formatted} {start_time}~{end_time}"
    
    place_meeting = clean_text(data.get("place_meeting", "")).strip()
    place_meal = clean_text(data.get("place_meal", "")).strip()
    
    # 식사장소에 사람 이름(윤태수 등)이나 연구책임자 텍스트가 잘못 들어온 경우 필터링
    if any(k in place_meal for k in ["윤태수", "연구책임자", "책임자"]):
        place_meal = ""
        
    if not place_meeting:
        place_meeting = "동서대 NM관"
    if not place_meal:
        place_meal = "식사장소"
        
    place_str = f"{place_meeting} / {place_meal}"

    agenda = clean_text(data.get("agenda", ""))
    discussion = clean_text(data.get("discussion", ""))
    remarks = clean_text(data.get("remarks", "선회의 후 식사진행"))
    
    attendees = data.get("attendees", [])
    absentees = data.get("absentees", [])
    total_att = len(attendees)
    total_abs = len(absentees)
    total_target = total_att + total_abs
    absent_reason = clean_text(data.get("absent_reason", ""))
    
    author = data.get("author", {})
    author_dept = clean_text(author.get("dept", ""))
    author_pos = clean_text(author.get("pos", ""))
    author_name = clean_text(author.get("name", ""))
    
    total_amount = data.get("total_amount", 0)
    receipt_count = data.get("receipt_count", 1)

    # 이미지 스마트 리사이즈 (영수증 복사본 우측용)
    fit_receipt = resize_for_hwp(receipt_img_path, 400, 580) if receipt_img_path else None

    # HWP 실행 (좀비 프로세스 발생 시 자동 복구 인스턴스)
    hwp = get_safe_hwp_instance(visible=False)
    hwp.open(os.path.abspath(template_path))

    def _move_to_next_cell(h):
        cur = h.get_cell_addr()
        for _ in range(20):
            h.Run("MoveRight")
            if h.get_cell_addr() != cur:
                return True
        return False

    try:
        # 1. 2페이지 회의록 제목: [ 앵커 사업단 ] 회 의 록 (원본 서식 그대로 유지, 임의 변경 안 함)
        # 2. 3페이지 참석자명부 제목: 동서대 앵커사업단 회의 참석자명부 (원본 서식 그대로 유지, 임의 변경 안 함)

        # 3. 참석자명부 OOO 치환 (회의명 반영)
        hwp.find_replace_all("OOO", meeting_name)

        # 4. 일시 치환
        hwp.find_replace_all("2026.00.00.(월) 00:00~00:00", dt_str)

        # 5. 장소 치환 (2페이지 회의록 표 장소 및 3페이지 참석자명부 장소 일괄 반영)
        hwp.find_replace_all("회의장소 / 식사장소", place_str)

        # 3페이지 참석자명부 헤더 항목들 줄바꿈 방지 조정
        hwp.MoveDocBegin()
        if hwp.find(f"▪ 회의명 :  {meeting_name}"):
            set_font_size(hwp, 8.5)
            hwp.Run("Cancel")
        if hwp.find(f"▪ 일  시 :  {dt_str}"):
            set_font_size(hwp, 8.5)
            hwp.Run("Cancel")
        if hwp.find(f"▪ 장  소 :  {place_str}"):
            set_font_size(hwp, 8.0)
            hwp.Run("Cancel")

        # 6. 회의록 표 채우기
        hwp.MoveDocBegin()
        if hwp.find("회 의 명"):
            hwp.Run("MoveRight")
            hwp.HAction.Run("SelectAll")
            hwp.insert_text(meeting_name)
            set_font_size(hwp, 9.0)
            hwp.Run("Cancel")
            
        if hwp.find("안    건"):
            hwp.Run("MoveRight")
            hwp.HAction.Run("SelectAll")
            hwp.insert_text(agenda)
            set_font_size(hwp, 8.5)
            hwp.Run("Cancel")
            
        # 토의내용 요지: 윤태수.hwp 서식(휴먼명조 11pt, 장평 90%, 자간 -15%, 왼쪽정렬, 줄간격 140%, 좌우여백 6pt, 내어쓰기 -18.6pt) 적용
        if hwp.find("요   지") or hwp.find("토의내용"):
            _move_to_next_cell(hwp)
            hwp.HAction.Run("SelectAll")
            hwp.Run("Delete")
            write_discussion_text(hwp, discussion)
            hwp.Run("Cancel")
            
        if hwp.find("비   고"):
            hwp.Run("MoveRight")
            hwp.HAction.Run("SelectAll")
            hwp.insert_text(remarks)
            set_font_size(hwp, 8.5)
            hwp.Run("Cancel")
            
        if hwp.find("참석 대상자"):
            hwp.Run("MoveRight")
            hwp.TableCellBlock()
            hwp.Run("Erase")
            hwp.insert_text(str(total_target))
            hwp.Run("Cancel")
            
        if hwp.find("참  석  자"):
            hwp.Run("MoveRight")
            hwp.TableCellBlock()
            hwp.Run("Erase")
            hwp.insert_text(str(total_att))
            hwp.Run("Cancel")
            
        if hwp.find("불  참  자"):
            hwp.Run("MoveRight")
            hwp.TableCellBlock()
            hwp.Run("Erase")
            hwp.insert_text(str(total_abs))
            hwp.Run("Cancel")
            
        if absent_reason:
            if hwp.find("불\r\n참\r\n내\r\n용") or hwp.find("불참내용"):
                hwp.Run("MoveRight")
                hwp.TableCellBlock()
                hwp.Run("Erase")
                hwp.insert_text(absent_reason)
                hwp.Run("Cancel")

        # 작성자 정보 채우기: 라벨 셀(소속 :, 직급 :, 성명 :)은 손상 없이 보존하고, 다음 빈 셀(D11, G11, J11)로 이동하여 값 입력
        hwp.MoveDocBegin()
        if author_dept and hwp.find("소속 :"):
            if _move_to_next_cell(hwp):
                hwp.HAction.Run("SelectAll")
                hwp.Run("Delete")
                hwp.insert_text(author_dept)
                set_font_size(hwp, 8.5)
                hwp.Run("Cancel")
                
        if author_pos and hwp.find("직급 :"):
            if _move_to_next_cell(hwp):
                hwp.HAction.Run("SelectAll")
                hwp.Run("Delete")
                hwp.insert_text(author_pos)
                set_font_size(hwp, 8.5)
                hwp.Run("Cancel")
                
        if author_name and hwp.find("성명 :"):
            if _move_to_next_cell(hwp):
                hwp.HAction.Run("SelectAll")
                hwp.Run("Delete")
                hwp.insert_text(author_name)
                set_font_size(hwp, 8.5)
                hwp.Run("Cancel")

        # 7. 참석자 표 1번부터 20번까지 순차 기재
        hwp.MoveDocBegin()
        if hwp.find("참석자명부") and hwp.find("번호"):
            hwp.Run("MoveDown")  # 1번 행의 번호 셀로 이동 (예: A5)
            addr_str = hwp.get_cell_addr()
            start_row = int(addr_str[1:]) if addr_str and len(addr_str) > 1 else 5
            for i, att in enumerate(attendees):
                if i >= 20:
                    break
                r = start_row + i
                # 소속 (B)
                hwp.goto_addr(f"B{r}")
                hwp.TableCellBlock()
                hwp.Run("Erase")
                hwp.insert_text(clean_text(att.get("dept", "")))
                set_font_size(hwp, 8.5)
                hwp.Run("Cancel")
                # 직위 (D)
                hwp.goto_addr(f"D{r}")
                hwp.TableCellBlock()
                hwp.Run("Erase")
                hwp.insert_text(clean_text(att.get("pos", "")))
                set_font_size(hwp, 8.5)
                hwp.Run("Cancel")
                # 성명 (E)
                hwp.goto_addr(f"E{r}")
                hwp.TableCellBlock()
                hwp.Run("Erase")
                hwp.insert_text(clean_text(att.get("name", "")))
                set_font_size(hwp, 8.5)
                hwp.Run("Cancel")

        # 8. 영수증 첨부철
        if total_amount:
            try:
                amt_num = int(str(total_amount).replace(",", ""))
                amt_str = f"{amt_num:,}"
            except Exception:
                amt_str = str(total_amount)
                
            if hwp.find("합   계"):
                hwp.Run("MoveRight")
                hwp.TableCellBlock()
                hwp.Run("Erase")
                hwp.insert_text(amt_str)
                set_font_size(hwp, 10.5)
                hwp.Run("Cancel")
                
        if receipt_count and int(receipt_count) != 1:
            if hwp.find("영 수 증"):
                hwp.Run("MoveRight")
                hwp.TableCellBlock()
                hwp.Run("Erase")
                hwp.insert_text(str(receipt_count))
                hwp.Run("Cancel")
                
        # 영수증 첨부철: 왼쪽 '영수증 원본' 칸은 오프라인 실물 부착용이므로 절대 아무것도 넣지 않고 공란 유지!
        # 우측: '영수증 복사본' 자리에만 영수증 이미지 삽입
        hwp.MoveDocBegin()
        if hwp.find("『영수증 첨부철』"):
            # 담당자 성명 입력
            if author_name and hwp.find("담당자"):
                if _move_to_next_cell(hwp):  # L3 셀로 이동
                    hwp.TableCellBlock()
                    hwp.Run("Delete")
                    hwp.insert_text(author_name)
                    set_font_size(hwp, 9.5)
                    hwp.Run("Cancel")
                    
            if fit_receipt and os.path.exists(fit_receipt):
                if hwp.find("영수증 복사본"):
                    hwp.TableCellBlock()
                    hwp.Run("Delete")
                    hwp.insert_picture(os.path.abspath(fit_receipt), embedded=True, sizeoption=3)
                    hwp.Run("Cancel")

        # 저장
        hwp.save_as(out_hwp_path, "HWP")
        
        try:
            hwp.save_as(out_pdf_path, "PDF")
        except Exception as e:
            print("PDF save warning:", e)
            
    finally:
        try:
            hwp.Clear(1)  # 변경사항 버리고 문서 닫기 (백그라운드 저장 확인 프롬프트 방지)
        except Exception:
            pass
        try:
            hwp.quit()
        except Exception:
            pass

    if not os.path.exists(out_pdf_path):
        try:
            hwp_pdf = get_safe_hwp_instance(visible=False)
            try:
                hwp_pdf.open(out_hwp_path)
                hwp_pdf.SaveAs(out_pdf_path, "PDF")
            finally:
                try:
                    hwp_pdf.Clear(1)
                except Exception:
                    pass
                try:
                    hwp_pdf.quit()
                except Exception:
                    pass
        except Exception as pe:
            print("PDF second attempt warning:", pe)

    return {
        "hwp_path": out_hwp_path,
        "pdf_path": out_pdf_path if os.path.exists(out_pdf_path) else None,
        "filename": output_filename
    }
