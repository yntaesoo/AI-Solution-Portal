import os
import re
from datetime import datetime
from PIL import Image
import pyhwpx

TEMPLATE_FILE = "[양식] 회의비 정산서류(회의록, 참석자명부, 영수증첨부철).hwp"

def clean_text(s: str) -> str:
    if not s:
        return ""
    return str(s).strip()

def format_discussion_text(raw_text: str) -> str:
    """토의내용 요지: 대항목 간 빈 줄(엔터) 1칸 및 세부항목 들여쓰기(  ‣ ) 적용된 다중 문단 텍스트 생성"""
    if not raw_text:
        return ""
    clean = str(raw_text).replace("\r\n", "\n").replace("\r", "\n")
    lines = clean.split("\n")
    formatted_lines = []
    
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            if formatted_lines and formatted_lines[-1] != "":
                formatted_lines.append("")
            continue
            
        # 대항목 (○, ■, ◆, □, 1., 2., [1], [2] 등)
        is_major = bool(re.match(r'^(?:○|■|◆|□|[0-9]+[.)]|\[[0-9]+\])\s*', stripped))
        # 세부 항목 (‣, -, •, ▪, * 등)
        is_sub = bool(re.match(r'^(?:‣|•|▪|-|\*)\s*', stripped))
        
        if is_major:
            # 대항목 앞 빈 줄(엔터) 1칸 띄우기 확보
            if formatted_lines and formatted_lines[-1] != "":
                formatted_lines.append("")
            # 기호 정규화 (1., 2. 등 숫자 항목은 유지, 기타 기호는 ○로 정규화)
            if not stripped.startswith("○") and not re.match(r'^[0-9]+[.)]', stripped):
                clean_title = re.sub(r'^(?:■|◆|□)\s*', '', stripped)
                formatted_lines.append(f"○ {clean_title}")
            else:
                formatted_lines.append(stripped)
        elif is_sub:
            # 세부 항목: 공백 2칸 들여쓰기 + ‣ 기호 적용
            sub_content = re.sub(r'^(?:‣|•|▪|-|\*)\s*', '', stripped)
            formatted_lines.append(f"  ‣ {sub_content}")
        else:
            # 일반 텍스트가 대항목 아래에 올 때도 들여쓰기 유지
            formatted_lines.append(f"  {stripped}" if formatted_lines and not formatted_lines[-1].startswith("○") else stripped)
            
    return "\r\n".join(formatted_lines)

def write_multiline_text(hwp, text: str, font_size: float = 8.0):
    """
    한글(HWP) 표 셀 내에 대항목 간 빈 줄 1칸과 세부 항목 들여쓰기를 완벽하게 렌더링하는 다중 문단 작성기
    """
    if not text:
        return
    # 글자 크기 설정
    set_font_size(hwp, font_size)
    formatted = format_discussion_text(text)
    hwp.insert_text(formatted)


def format_date_weekday(date_str: str) -> str:
    """date_str: YYYY-MM-DD -> YYYY.MM.DD.(요일)"""
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        weekdays = ["월", "화", "수", "목", "금", "토", "일"]
        w = weekdays[dt.weekday()]
        return f"{dt.year}.{dt.month:02d}.{dt.day:02d}.({w})"
    except Exception:
        return date_str

def set_font_size(hwp, pt_size: float):
    """현재 선택된 블록의 글자 크기 설정 (pt 단위)"""
    try:
        pset = hwp.HParameterSet.HCharShape
        hwp.HAction.GetDefault("CharShape", pset.HSet)
        pset.Height = int(pt_size * 100)
        hwp.HAction.Execute("CharShape", pset.HSet)
    except Exception as e:
        print("set_font_size error:", e)

def resize_for_hwp(img_path: str, max_w: int = 420, max_h: int = 600) -> str:
    """영수증/카드내역 이미지가 표 높이를 넘지 않도록 리사이즈"""
    if not img_path or not os.path.exists(img_path):
        return None
    try:
        img = Image.open(img_path)
        img.thumbnail((max_w, max_h), Image.Resampling.LANCZOS)
        dir_name, base_name = os.path.split(img_path)
        resized_path = os.path.join(dir_name, f"fit_{base_name}")
        img.save(resized_path, "PNG")
        return resized_path
    except Exception as e:
        print("resize error:", e)
        return img_path

def generate_meeting_minutes_hwp(
    base_dir: str,
    data: dict,
    receipt_img_path: str = None,
    card_statement_img_path: str = None,
    output_filename: str = None
) -> dict:
    """
    회의록 정산서류(회의록, 참석자명부, 영수증첨부철)를 생성합니다.
    """
    template_path = os.path.join(base_dir, TEMPLATE_FILE)
    if not os.path.exists(template_path):
        raise FileNotFoundError(f"양식 파일을 찾을 수 없습니다: {template_path}")

    # 날짜 및 파일명 결정
    meeting_date = data.get("meeting_date", "")
    meeting_name = clean_text(data.get("meeting_name", "회의록"))
    
    date_compact = meeting_date.replace("-", "") if meeting_date else datetime.now().strftime("%Y%m%d")
    
    if not output_filename:
        safe_name = re.sub(r'[\\/*?:"<>|]', "", meeting_name)[:30]
        output_filename = f"{date_compact}_회의록_{safe_name}.hwp"
        
    out_dir = os.path.join(base_dir, "output")
    os.makedirs(out_dir, exist_ok=True)
    out_hwp_path = os.path.abspath(os.path.join(out_dir, output_filename))
    out_pdf_path = os.path.abspath(os.path.splitext(out_hwp_path)[0] + ".pdf")

    # 데이터 추출
    project_name = clean_text(data.get("project_name", "앵커 사업단"))
    start_time = clean_text(data.get("start_time", "18:00"))
    end_time = clean_text(data.get("end_time", "20:00"))
    
    date_formatted = format_date_weekday(meeting_date)
    dt_str = f"{date_formatted} {start_time}~{end_time}"
    
    place_meeting = clean_text(data.get("place_meeting", "")).strip()
    place_meal = clean_text(data.get("place_meal", "")).strip()
    
    # 식사장소에 사람 이름(윤태수 등)이나 연구책임자 텍스트가 잘못 들어온 경우 필터링
    if any(k in place_meal for k in ["윤태수", "연구책임자", "책임자"]):
        place_meal = ""
        
    if not place_meeting:
        place_meeting = "동서대 NM관"
    if not place_meal:
        place_meal = "식사장소"
        
    place_str = f"{place_meeting} / {place_meal}"

    agenda = clean_text(data.get("agenda", ""))
    discussion = clean_text(data.get("discussion", ""))
    remarks = clean_text(data.get("remarks", "선회의 후 식사진행"))
    
    attendees = data.get("attendees", [])
    absentees = data.get("absentees", [])
    total_att = len(attendees)
    total_abs = len(absentees)
    total_target = total_att + total_abs
    absent_reason = clean_text(data.get("absent_reason", ""))
    
    author = data.get("author", {})
    author_dept = clean_text(author.get("dept", ""))
    author_pos = clean_text(author.get("pos", ""))
    author_name = clean_text(author.get("name", ""))
    
    total_amount = data.get("total_amount", 0)
    receipt_count = data.get("receipt_count", 1)

    # 이미지 스마트 리사이즈 (영수증 복사본 우측용)
    fit_receipt = resize_for_hwp(receipt_img_path, 400, 580) if receipt_img_path else None

    # HWP 실행
    hwp = pyhwpx.Hwp(visible=False)
    hwp.open(os.path.abspath(template_path))

    def _move_to_next_cell(h):
        cur = h.get_cell_addr()
        for _ in range(10):
            h.Run("MoveRight")
            if h.get_cell_addr() != cur:
                return True
        return False

    try:
        # 1. 2페이지 회의록 제목: [ 앵커 사업단 ] 회 의 록 (원본 서식 그대로 유지, 임의 변경 안 함)
        # 2. 3페이지 참석자명부 제목: 동서대 앵커사업단 회의 참석자명부 (원본 서식 그대로 유지, 임의 변경 안 함)

        # 3. 참석자명부 OOO 치환 (회의명 반영)
        hwp.find_replace_all("OOO", meeting_name)

        # 4. 일시 치환
        hwp.find_replace_all("2026.00.00.(월) 00:00~00:00", dt_str)

        # 5. 장소 치환 (2페이지 회의록 표 장소 및 3페이지 참석자명부 장소 일괄 반영)
        hwp.find_replace_all("회의장소 / 식사장소", place_str)

        # 3페이지 참석자명부 헤더 항목들 줄바꿈 방지 조정
        hwp.MoveDocBegin()
        if hwp.find(f"▪ 회의명 :  {meeting_name}"):
            set_font_size(hwp, 8.5)
            hwp.Run("Cancel")
        if hwp.find(f"▪ 일  시 :  {dt_str}"):
            set_font_size(hwp, 8.5)
            hwp.Run("Cancel")
        if hwp.find(f"▪ 장  소 :  {place_str}"):
            set_font_size(hwp, 8.0)
            hwp.Run("Cancel")

        # 6. 회의록 표 채우기
        hwp.MoveDocBegin()
        if hwp.find("회 의 명"):
            hwp.Run("MoveRight")
            hwp.HAction.Run("SelectAll")
            hwp.insert_text(meeting_name)
            set_font_size(hwp, 9.0)
            hwp.Run("Cancel")
            
        if hwp.find("안    건"):
            hwp.Run("MoveRight")
            hwp.HAction.Run("SelectAll")
            hwp.insert_text(agenda)
            set_font_size(hwp, 8.5)
            hwp.Run("Cancel")
            
        # 토의내용 요지: write_multiline_text 적용 (대항목 간 엔터 1칸 띄어쓰기 및 세부항목 들여쓰기 렌더링)
        if hwp.find("요   지"):
            _move_to_next_cell(hwp)
            hwp.HAction.Run("SelectAll")
            hwp.Run("Delete")
            write_multiline_text(hwp, discussion, font_size=8.0)
            hwp.Run("Cancel")
            
        if hwp.find("비   고"):
            hwp.Run("MoveRight")
            hwp.HAction.Run("SelectAll")
            hwp.insert_text(remarks)
            set_font_size(hwp, 8.5)
            hwp.Run("Cancel")
            
        if hwp.find("참석 대상자"):
            hwp.Run("MoveRight")
            hwp.TableCellBlock()
            hwp.Run("Erase")
            hwp.insert_text(str(total_target))
            hwp.Run("Cancel")
            
        if hwp.find("참  석  자"):
            hwp.Run("MoveRight")
            hwp.TableCellBlock()
            hwp.Run("Erase")
            hwp.insert_text(str(total_att))
            hwp.Run("Cancel")
            
        if hwp.find("불  참  자"):
            hwp.Run("MoveRight")
            hwp.TableCellBlock()
            hwp.Run("Erase")
            hwp.insert_text(str(total_abs))
            hwp.Run("Cancel")
            
        if absent_reason:
            if hwp.find("불\r\n참\r\n내\r\n용") or hwp.find("불참내용"):
                hwp.Run("MoveRight")
                hwp.TableCellBlock()
                hwp.Run("Erase")
                hwp.insert_text(absent_reason)
                hwp.Run("Cancel")

        # 작성자 정보 채우기: 라벨 셀(소속 :, 직급 :, 성명 :)은 손상 없이 보존하고, 다음 빈 셀(D11, G11, J11)로 이동하여 값 입력
        hwp.MoveDocBegin()
        if author_dept and hwp.find("소속 :"):
            if _move_to_next_cell(hwp):
                hwp.HAction.Run("SelectAll")
                hwp.Run("Delete")
                hwp.insert_text(author_dept)
                set_font_size(hwp, 8.5)
                hwp.Run("Cancel")
                
        if author_pos and hwp.find("직급 :"):
            if _move_to_next_cell(hwp):
                hwp.HAction.Run("SelectAll")
                hwp.Run("Delete")
                hwp.insert_text(author_pos)
                set_font_size(hwp, 8.5)
                hwp.Run("Cancel")
                
        if author_name and hwp.find("성명 :"):
            if _move_to_next_cell(hwp):
                hwp.HAction.Run("SelectAll")
                hwp.Run("Delete")
                hwp.insert_text(author_name)
                set_font_size(hwp, 8.5)
                hwp.Run("Cancel")

        # 7. 참석자 표 1번부터 20번까지 순차 기재
        hwp.MoveDocBegin()
        if hwp.find("참석자명부") and hwp.find("번호"):
            hwp.Run("MoveDown")  # 1번 행의 번호 셀로 이동 (예: A5)
            addr_str = hwp.get_cell_addr()
            start_row = int(addr_str[1:]) if addr_str and len(addr_str) > 1 else 5
            for i, att in enumerate(attendees):
                if i >= 20:
                    break
                r = start_row + i
                # 소속 (B)
                hwp.goto_addr(f"B{r}")
                hwp.TableCellBlock()
                hwp.Run("Erase")
                hwp.insert_text(clean_text(att.get("dept", "")))
                set_font_size(hwp, 8.5)
                hwp.Run("Cancel")
                # 직위 (D)
                hwp.goto_addr(f"D{r}")
                hwp.TableCellBlock()
                hwp.Run("Erase")
                hwp.insert_text(clean_text(att.get("pos", "")))
                set_font_size(hwp, 8.5)
                hwp.Run("Cancel")
                # 성명 (E)
                hwp.goto_addr(f"E{r}")
                hwp.TableCellBlock()
                hwp.Run("Erase")
                hwp.insert_text(clean_text(att.get("name", "")))
                set_font_size(hwp, 8.5)
                hwp.Run("Cancel")

        # 8. 영수증 첨부철
        if total_amount:
            try:
                amt_num = int(str(total_amount).replace(",", ""))
                amt_str = f"{amt_num:,}"
            except Exception:
                amt_str = str(total_amount)
                
            if hwp.find("합   계"):
                hwp.Run("MoveRight")
                hwp.TableCellBlock()
                hwp.Run("Erase")
                hwp.insert_text(amt_str)
                set_font_size(hwp, 10.5)
                hwp.Run("Cancel")
                
        if receipt_count and int(receipt_count) != 1:
            if hwp.find("영 수 증"):
                hwp.Run("MoveRight")
                hwp.TableCellBlock()
                hwp.Run("Erase")
                hwp.insert_text(str(receipt_count))
                hwp.Run("Cancel")
                
        # 영수증 첨부철: 왼쪽 '영수증 원본' 칸은 오프라인 실물 부착용이므로 절대 아무것도 넣지 않고 공란 유지!
        # 우측: '영수증 복사본' 자리에만 영수증 이미지 삽입
        hwp.MoveDocBegin()
        if hwp.find("『영수증 첨부철』"):
            # 담당자 성명 입력
            if author_name and hwp.find("담당자"):
                if _move_to_next_cell(hwp):  # L3 셀로 이동
                    hwp.TableCellBlock()
                    hwp.Run("Delete")
                    hwp.insert_text(author_name)
                    set_font_size(hwp, 9.5)
                    hwp.Run("Cancel")
                    
            if fit_receipt and os.path.exists(fit_receipt):
                if hwp.find("영수증 복사본"):
                    hwp.TableCellBlock()
                    hwp.Run("Delete")
                    hwp.insert_picture(os.path.abspath(fit_receipt), embedded=True, sizeoption=3)
                    hwp.Run("Cancel")

        # 저장
        hwp.save_as(out_hwp_path, "HWP")
        
        try:
            hwp.save_as(out_pdf_path, "PDF")
        except Exception as e:
            print("PDF save warning:", e)
            
    finally:
        hwp.quit()

    if not os.path.exists(out_pdf_path):
        try:
            hwp_pdf = pyhwpx.Hwp(visible=False)
            hwp_pdf.open(out_hwp_path)
            hwp_pdf.SaveAs(out_pdf_path, "PDF")
            hwp_pdf.quit()
        except Exception:
            pass

    return {
        "hwp_path": out_hwp_path,
        "pdf_path": out_pdf_path if os.path.exists(out_pdf_path) else None,
        "filename": output_filename
    }
