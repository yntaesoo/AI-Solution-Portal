"""
approval_parser.py
회의비 사전품의서 (PDF / 화면 캡처 이미지) 파서
- 회의명, 일시, 장소, 안건, 참석자 추출
- 과제명/사업단명은 반영하지 않고 기존 설정값(디폴트: 앵커사업단_글로벌지원부) 유지
- 참석자는 기존 프로젝트 멤버(풀)와 대조하여 기존 정보(소속, 직급)를 유지하고 외부/신규 참석자는 소속과 이름을 반영
"""

import os
import io
import re
import json
import base64
from typing import Dict, Any, List, Optional
from PIL import Image

try:
    import pypdf
except ImportError:
    pypdf = None

try:
    import pymupdf
except ImportError:
    try:
        import fitz as pymupdf
    except ImportError:
        pymupdf = None

import ocr_parser


def load_file_bytes(file_input) -> bytes:
    """다양한 형식(경로, Base64 Data URL, 순수 Base64, 바이너리)을 bytes로 변환"""
    if isinstance(file_input, bytes):
        return file_input
    elif isinstance(file_input, bytearray):
        return bytes(file_input)
    elif isinstance(file_input, str):
        if file_input.startswith("data:"):
            header, encoded = file_input.split(",", 1)
            return base64.b64decode(encoded)
        elif len(file_input) > 200 and ("/" not in file_input[:40] and "\\" not in file_input[:40]):
            try:
                return base64.b64decode(file_input)
            except Exception:
                pass
        if os.path.exists(file_input):
            with open(file_input, "rb") as f:
                return f.read()
    return b""


def clean_raw_text(text: str) -> str:
    """PDF 또는 OCR 텍스트 내 비가시 제어문자 및 공백 정규화"""
    if not text:
        return ""
    # SOH (\x01) 등 비가시 제어문자를 공백으로 치환
    cleaned = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\ufeff]', ' ', text)
    lines = [l.strip() for l in cleaned.splitlines()]
    return "\n".join(lines)


def extract_text_from_file(file_bytes: bytes, filename: str = "") -> str:
    """PDF 또는 이미지 파일 바이너리에서 텍스트를 추출합니다."""
    if not file_bytes:
        return ""

    is_pdf = (filename.lower().endswith(".pdf") or file_bytes.startswith(b"%PDF"))

    if is_pdf:
        extracted = ""
        # 1. pypdf 텍스트 추출 시도
        if pypdf:
            try:
                reader = pypdf.PdfReader(io.BytesIO(file_bytes))
                pages_text = []
                for p in reader.pages:
                    t = p.extract_text() or ""
                    pages_text.append(t)
                extracted = "\n".join(pages_text).strip()
            except Exception as e:
                print("pypdf error:", e)

        # 2. pymupdf 텍스트 추출 시도 (pypdf 결과가 짧거나 실패 시)
        if (not extracted or len(clean_raw_text(extracted)) < 40) and pymupdf:
            try:
                doc = pymupdf.open(stream=file_bytes, filetype="pdf")
                pages_text = []
                for page in doc:
                    pages_text.append(page.get_text() or "")
                extracted = "\n".join(pages_text).strip()
            except Exception as e:
                print("pymupdf text error:", e)

        # 3. 스캔형 이미지 PDF인 경우: 첫 페이지를 이미지로 렌더링 후 winocr
        if (not extracted or len(clean_raw_text(extracted)) < 40) and pymupdf:
            try:
                doc = pymupdf.open(stream=file_bytes, filetype="pdf")
                if len(doc) > 0:
                    page = doc[0]
                    pix = page.get_pixmap(dpi=150)
                    img = Image.open(io.BytesIO(pix.tobytes("png")))
                    ocr_res = ocr_parser._safe_winocr_recognize(img.convert("RGBA"), "ko")
                    lines = [l.get("text", "") for l in ocr_res.get("lines", [])]
                    extracted = "\n".join(lines)
            except Exception as e:
                print("pymupdf ocr error:", e)

        return clean_raw_text(extracted)
    else:
        # 일반 이미지 (스크린 캡처 PNG/JPG 등)
        try:
            img = Image.open(io.BytesIO(file_bytes))
            ocr_res = ocr_parser._safe_winocr_recognize(img.convert("RGBA"), "ko")
            lines = [l.get("text", "") for l in ocr_res.get("lines", [])]
            text = "\n".join(lines)
            if not text or len(text.strip()) < 10:
                pre_img = ocr_parser.preprocess_image(img)
                ocr_res = ocr_parser._safe_winocr_recognize(pre_img, "ko")
                lines = [l.get("text", "") for l in ocr_res.get("lines", [])]
                text = "\n".join(lines)
            return clean_raw_text(text)
        except Exception as e:
            print("image ocr error:", e)
            return ""


def parse_approval_text(text: str, project_pool_attendees: List[Dict[str, str]] = None) -> Dict[str, Any]:
    """
    사전품의서 텍스트에서 회의명, 일시, 장소, 안건, 참석자를 추출합니다.
    과제명/사업단명은 추출하거나 덮어쓰지 않습니다.
    """
    text = clean_raw_text(text)
    lines = [l.strip() for l in text.splitlines() if l.strip()]

    if project_pool_attendees is None:
        project_pool_attendees = []

    pool_by_name = {m.get("name", "").strip(): m for m in project_pool_attendees if m.get("name")}

    # 1. 회의명
    meeting_name = ""
    m_name = re.search(r'회의명\s*[:：]\s*([^\r\n]+)', text)
    if not m_name:
        m_name = re.search(r'행사명\s*[:：]\s*([^\r\n]+)', text)
    if m_name:
        meeting_name = m_name.group(1).strip()
        meeting_name = re.sub(r'^\d+\s*[\.\)]\s*', '', meeting_name).strip()
    else:
        # OCR 레이블 분리 시: "회의명" 다음 행 또는 행사명 패턴 탐색
        for i, l in enumerate(lines):
            if l in ["회의명", "회의명 :", "회의 명"]:
                if i + 1 < len(lines) and not re.search(r'일\s*시|장\s*소|참석자', lines[i+1]):
                    meeting_name = lines[i+1]
                    break
            elif "업무협약식" in l or "협의회" in l or "간담회" in l:
                if not any(k in l for k in ["개요", "내용", "안건", "인쇄"]):
                    meeting_name = re.sub(r'^\d+\s*[\.\)]\s*(?:행사명|회의명)?\s*[:：]?\s*', '', l).strip()
                    break

    # 2. 일시 (날짜, 시작/종료 시간)
    meeting_date = ""
    start_time = "10:00"
    end_time = "11:30"

    date_line_idx = -1
    datetime_line = ""

    # 일시 라벨 있는 줄 우선
    m_dt = re.search(r'일\s*시\s*[:：]\s*([^\r\n]+)', text)
    if m_dt:
        datetime_line = m_dt.group(1).strip()
    else:
        # 2026-10-16 또는 2026년 ... 포맷이 있는 줄 찾기 (헤더의 인쇄일시 제외하기 위해 뒤에서부터 또는 중간부터)
        for i, l in enumerate(lines):
            # 인쇄일시나 접수일시 등 (예: "26. 11. 9. 오후 6:16", "2026년 10월 15일 연구책임자") 제외
            if re.search(r'\d{4}\s*[-/]\s*\d{1,2}\s*[-/]\s*\d{1,2}', l) and not re.search(r'인쇄|연구|동서대', l):
                datetime_line = l
                date_line_idx = i
                break

    if datetime_line:
        # 날짜 추출
        m_date = re.search(r'(\d{4})\s*[-년\./]\s*(\d{1,2})\s*[-월\./]\s*(\d{1,2})', datetime_line)
        if m_date:
            y, m, d = m_date.groups()
            meeting_date = f"{int(y):04d}-{int(m):02d}-{int(d):02d}"

        # 시간 범위 추출 (10:00 ~ 11:30 or 10시 ~ 12시)
        m_range = re.search(
            r'(\d{1,2})(?::(\d{2})|\s*시(?:\s*(\d{1,2})\s*분)?)?\s*~[\s~]*(\d{1,2})(?::(\d{2})|\s*시(?:\s*(\d{1,2})\s*분)?)?',
            datetime_line
        )
        if m_range and m_range.group(4):
            sh = int(m_range.group(1))
            sm = int(m_range.group(2) or m_range.group(3) or 0)
            eh = int(m_range.group(4))
            em = int(m_range.group(5) or m_range.group(6) or 0)
            start_time = f"{sh:02d}:{sm:02d}"
            end_time = f"{eh:02d}:{em:02d}"
        else:
            # 단일 시간 추출 (예: 10시(예정), 14:00)
            m_single = re.search(r'(\d{1,2})(?::(\d{2})|\s*시(?:\s*(\d{1,2})\s*분)?)', datetime_line)
            if m_single:
                sh = int(m_single.group(1))
                sm = int(m_single.group(2) or m_single.group(3) or 0)
                start_time = f"{sh:02d}:{sm:02d}"
                # 기본 1시간 30분 진행
                tot_m = sh * 60 + sm + 90
                end_time = f"{(tot_m // 60):02d}:{(tot_m % 60):02d}"

    # 3. 장소
    place_meeting = ""
    m_place = re.search(r'장\s*소\s*[:：]\s*([^\r\n]+)', text)
    if m_place:
        place_meeting = m_place.group(1).strip()
    elif date_line_idx >= 0 and date_line_idx + 1 < len(lines):
        # OCR에서 일시 바로 다음 행이 장소인 경우 (예: "NM 805")
        cand_place = lines[date_line_idx + 1].strip()
        if not re.search(r'참석자|외\s*\d+\s*명|행사명|개요|내용|일시', cand_place):
            place_meeting = cand_place
    if not place_meeting:
        # 패턴 매칭 (NM 805, 회의실, 세미나실, 등)
        for l in lines:
            if re.search(r'NM\s*\d+|[A-Z0-9]+관\s*\d+호|세미나실|회의실', l) and not re.search(r'연구|책임자|동서대', l):
                place_meeting = l.strip()
                break

    # 4. 회의안건 & 키워드
    m_agenda_block = re.search(r'회의안건([\s\S]*?)(?=붙임|위와 같이|연구\(사업\)책임자|$)', text)
    agenda_text_block = m_agenda_block.group(1) if m_agenda_block else text

    agenda_lines = []
    attendee_lines = []
    in_attendee = False

    for raw_l in agenda_text_block.splitlines():
        l = raw_l.strip()
        if not l:
            continue
        if re.search(r'^\d+\s*[\.\)]\s*참석자|참석자\s*\(', l):
            in_attendee = True
        if in_attendee:
            attendee_lines.append(l)
        else:
            if any(k in l for k in ["행사명", "개요", "내용", "안건"]):
                agenda_lines.append(l)

    # 안건: '내용:' 항목 우선 매칭
    extracted_agenda = ""
    for l in (agenda_lines if agenda_lines else lines):
        m_content = re.search(r'내용\s*[:：]\s*(.+)', l)
        if m_content:
            extracted_agenda = m_content.group(1).strip()
            break

    if not extracted_agenda:
        cleaned_agenda_items = [
            re.sub(r'^\d+\s*[\.\)]\s*(?:행사명|개요|안건)?\s*[:：]?\s*', '', item).strip()
            for item in agenda_lines if item
        ]
        cleaned_agenda_items = [item for item in cleaned_agenda_items if item and len(item) > 3]
        if cleaned_agenda_items:
            extracted_agenda = cleaned_agenda_items[-1]
        elif meeting_name:
            extracted_agenda = meeting_name

    # AI 토의내용 생성을 위한 추천 키워드 추출
    kw_candidates = []
    if meeting_name:
        kw_candidates.extend(re.split(r'[-–—,\s]+', meeting_name))
    if extracted_agenda:
        kw_candidates.extend(re.split(r'[-–—,\s]+', extracted_agenda))

    stop_words = {
        "동서대학교", "동서대", "위한", "및", "진행", "운영", "개최", "협의", "관련", "관한",
        "수립", "외", "등", "1부", "앵커사업단", "사전", "품의서"
    }
    extracted_keywords = []
    for kw in kw_candidates:
        kw = re.sub(r'^[^\w가-힣]+|[^\w가-힣]+$', '', kw).strip()
        if len(kw) >= 2 and kw not in stop_words and kw not in extracted_keywords:
            extracted_keywords.append(kw)
    suggested_keywords = ", ".join(extracted_keywords[:6])

    # 5. 참석자 (Attendees)
    attendee_candidates = []
    source_lines = attendee_lines if attendee_lines else lines

    # 패턴: 가. 동래구혁신어울림센터(5명): 최은지, 이가희...
    group_regex = re.compile(
        r'^\s*(?:[가나다라마바사아자차카타파하\dA-Za-z]+[\.\)\]]\s*)?([^:(\n]+?)(?:\s*\(\s*\d+\s*명\s*\))?\s*[:：]\s*([^\r\n]+)'
    )

    found_groups = False
    for line in source_lines:
        s_line = line.strip()
        if not s_line or (re.search(r'^\d+\s*[\.\)]\s*참석자', s_line) and ":" not in s_line):
            continue
        m_grp = group_regex.search(s_line)
        if m_grp:
            raw_dept = m_grp.group(1).strip()
            # 글머리 기호(가., 나., 1. 등) 제거
            dept_name = re.sub(r'^\s*[\(\[]?[가나다라마바사아자차카타파하\dA-Za-z]+[\.\)\]]\s*', '', raw_dept).strip()
            if not dept_name or "참석자" in dept_name or "안건" in dept_name:
                continue
            names_str = m_grp.group(2).strip()
            names = [n.strip() for n in re.split(r'[,/·\s\.]+', names_str) if n.strip()]
            names = [re.sub(r'^[^\w가-힣]+|[^\w가-힣]+$', '', n) for n in names if len(n) >= 2]
            if names:
                found_groups = True
                for name in names:
                    if name:
                        attendee_candidates.append({
                            "raw_group": dept_name,
                            "name": name
                        })

    # 그룹별 표기가 없는 경우: '참석자 : 윤태수, 임혜지 외 11명' 패턴 처리
    if not found_groups:
        m_single_att = re.search(r'참석자\s*[:：]\s*([^\r\n]+)', text)
        if m_single_att:
            raw_names = m_single_att.group(1).strip()
            raw_names = re.sub(r'외\s*\d+\s*명.*$', '', raw_names).strip()
            names = [n.strip() for n in re.split(r'[,/·\s\.]+', raw_names) if n.strip()]
            names = [re.sub(r'^[^\w가-힣]+|[^\w가-힣]+$', '', n) for n in names if len(n) >= 2]
            for n in names:
                if n:
                    attendee_candidates.append({
                        "raw_group": "",
                        "name": n
                    })

    # 기존 프로젝트 멤버 풀과 병합
    final_attendees = []
    seen_names = set()

    for cand in attendee_candidates:
        c_name = cand["name"].strip()
        c_group = cand["raw_group"].strip()

        matched_pool_item = pool_by_name.get(c_name)

        # 내부 그룹 소속인 경우 OCR 오타 보정 (2글자 이상 일치)
        if not matched_pool_item and len(c_name) == 3:
            for p_name, p_item in pool_by_name.items():
                if len(p_name) == 3 and sum(1 for a, b in zip(c_name, p_name) if a == b) >= 2:
                    if any(k in c_group for k in ["앵커", "글로벌", "동서"]):
                        matched_pool_item = p_item
                        c_name = p_name
                        break

        if c_name in seen_names:
            continue
        seen_names.add(c_name)

        if matched_pool_item:
            # 기존 프로젝트 멤버: 소속 및 직급 유지
            final_attendees.append({
                "dept": matched_pool_item.get("dept", ""),
                "pos": matched_pool_item.get("pos", ""),
                "name": matched_pool_item.get("name", c_name),
                "is_external": False,
                "is_existing": True
            })
        else:
            # 외부/신규 참석자: 추출된 소속 반영
            dept_to_use = c_group if c_group else "외부기관"
            final_attendees.append({
                "dept": dept_to_use,
                "pos": "",
                "name": c_name,
                "is_external": True,
                "is_existing": False
            })

    return {
        "success": True,
        "meeting_name": meeting_name,
        "meeting_date": meeting_date,
        "start_time": start_time,
        "end_time": end_time,
        "place_meeting": place_meeting,
        "agenda": extracted_agenda,
        "agenda_items": agenda_lines,
        "suggested_keywords": suggested_keywords,
        "attendees": final_attendees,
        "attendee_count": len(final_attendees),
        "external_count": sum(1 for a in final_attendees if a.get("is_external")),
        "existing_count": sum(1 for a in final_attendees if not a.get("is_external")),
        "raw_text": text
    }


def parse_approval_file(file_input, filename: str = "", project_pool_attendees: List[Dict[str, str]] = None) -> Dict[str, Any]:
    """파일(바이너리, 경로, Base64)을 받아 텍스트를 추출하고 회의 기본 정보를 파싱합니다."""
    file_bytes = load_file_bytes(file_input)
    if not file_bytes:
        return {
            "success": False,
            "message": "파일 데이터를 읽을 수 없습니다."
        }

    text = extract_text_from_file(file_bytes, filename)
    if not text or len(text.strip()) < 10:
        return {
            "success": False,
            "message": "품의서 문서에서 텍스트를 인식하지 못했습니다. 선명한 PDF 또는 캡처 이미지를 확인해주세요.",
            "raw_text": text
        }

    result = parse_approval_text(text, project_pool_attendees)
    return result
