import os
import json
import uuid

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
PROJECTS_FILE = os.path.join(DATA_DIR, "projects.json")

DEFAULT_PROJECTS = [
    {
        "id": "proj_anchor_2026",
        "name": "부산 전략산업 맞춤형 앵커인재 양성사업단",
        "default_author": {
            "dept": "앵커사업단",
            "pos": "연구원",
            "name": "김담당"
        },
        "default_place_meeting": "동서대 뉴밀레니엄관 8층 세미나실",
        "default_place_meal": "마포숯불갈비 주례본점",
        "attendees": [
            {"dept": "동서대학교", "pos": "교수", "name": "김교수"},
            {"dept": "동서대학교", "pos": "연구교수", "name": "이연구"},
            {"dept": "동서대학교", "pos": "박사과정", "name": "박학생"},
            {"dept": "㈜로지스틱스", "pos": "이사", "name": "최기업"},
            {"dept": "㈜로지스틱스", "pos": "팀장", "name": "정팀장"}
        ]
    },
    {
        "id": "proj_ris_2026",
        "name": "지자체-대학 협력기반 지역혁신사업(RIS)",
        "default_author": {
            "dept": "RIS사업단",
            "pos": "연구원",
            "name": "이담당"
        },
        "default_place_meeting": "동서대학교 산학협력관 3층 회의실",
        "default_place_meal": "",
        "attendees": [
            {"dept": "동서대학교", "pos": "사업단장", "name": "박단장"},
            {"dept": "동서대학교", "pos": "총괄교수", "name": "정교수"},
            {"dept": "부산광역시청", "pos": "주무관", "name": "최주무"},
            {"dept": "부산테크노파크", "pos": "센터장", "name": "한센터장"}
        ]
    },
    {
        "id": "proj_linc_2026",
        "name": "3단계 산학연협력 선도대학 육성사업(LINC 3.0)",
        "default_author": {
            "dept": "LINC 3.0 사업단",
            "pos": "팀장",
            "name": "박팀장"
        },
        "default_place_meeting": "동서대학교 U-IT관 세미나실",
        "default_place_meal": "",
        "attendees": [
            {"dept": "동서대학교", "pos": "부단장", "name": "강교수"},
            {"dept": "㈜테크솔루션", "pos": "대표이사", "name": "윤대표"},
            {"dept": "동서대학교", "pos": "전임연구원", "name": "조연구"}
        ]
    }
]

def init_projects():
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(PROJECTS_FILE):
        with open(PROJECTS_FILE, "w", encoding="utf-8") as f:
            json.dump({"projects": DEFAULT_PROJECTS}, f, ensure_ascii=False, indent=2)

def get_all_projects() -> list:
    init_projects()
    try:
        with open(PROJECTS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("projects", [])
    except Exception as e:
        print("Error reading projects:", e)
        return DEFAULT_PROJECTS

def get_project(project_id: str) -> dict:
    projects = get_all_projects()
    for p in projects:
        if p["id"] == project_id:
            return p
    return None

def create_project(data: dict) -> dict:
    projects = get_all_projects()
    new_id = f"proj_{uuid.uuid4().hex[:8]}"
    new_proj = {
        "id": new_id,
        "name": str(data.get("name", "신규 과제")).strip(),
        "default_author": data.get("default_author", {"dept": "", "pos": "", "name": ""}),
        "default_place_meeting": str(data.get("default_place_meeting", "")).strip(),
        "default_place_meal": str(data.get("default_place_meal", "")).strip(),
        "attendees": data.get("attendees", [])
    }
    projects.append(new_proj)
    save_projects(projects)
    return new_proj

def update_project(project_id: str, data: dict) -> dict:
    projects = get_all_projects()
    updated = None
    for p in projects:
        if p["id"] == project_id:
            if "name" in data:
                p["name"] = str(data["name"]).strip()
            if "default_author" in data:
                p["default_author"] = data["default_author"]
            if "default_place_meeting" in data:
                p["default_place_meeting"] = str(data["default_place_meeting"]).strip()
            if "default_place_meal" in data:
                p["default_place_meal"] = str(data["default_place_meal"]).strip()
            if "attendees" in data:
                p["attendees"] = data["attendees"]
            updated = p
            break
    if updated:
        save_projects(projects)
    return updated

def delete_project(project_id: str) -> bool:
    projects = get_all_projects()
    initial_len = len(projects)
    projects = [p for p in projects if p["id"] != project_id]
    if len(projects) < initial_len:
        save_projects(projects)
        return True
    return False

def save_project_attendees(project_id: str, attendees: list) -> bool:
    """특정 과제의 기본 참석자 명부를 업데이트 저장"""
    return bool(update_project(project_id, {"attendees": attendees}))

def save_projects(projects: list):
    init_projects()
    with open(PROJECTS_FILE, "w", encoding="utf-8") as f:
        json.dump({"projects": projects}, f, ensure_ascii=False, indent=2)
