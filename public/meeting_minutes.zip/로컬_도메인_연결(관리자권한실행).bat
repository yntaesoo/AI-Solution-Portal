@echo off
chcp 65001 >nul
title minutes.arfab.kr 로컬 도메인 즉각 연결
echo ========================================================
echo  minutes.arfab.kr 을 로컬 정상 작동 서버로 즉시 연결합니다
echo ========================================================
echo.

:: 관리자 권한 확인
net file >nul 2>&1
if '%errorlevel%' neq '0' (
    echo [안내] 관리자 권한이 필요합니다.
    echo 이 파일을 마우스 우클릭한 뒤 [관리자 권한으로 실행]을 선택해 주세요!
    echo.
    pause
    exit /b 1
)

findstr /i "minutes.arfab.kr" "%WINDIR%\System32\drivers\etc\hosts" >nul
if '%errorlevel%' neq '0' (
    echo. >> "%WINDIR%\System32\drivers\etc\hosts"
    echo 127.0.0.1 minutes.arfab.kr >> "%WINDIR%\System32\drivers\etc\hosts"
    echo 127.0.0.1 anchor.arfab.kr >> "%WINDIR%\System32\drivers\etc\hosts"
    ipconfig /flushdns >nul
    echo.
    echo 🎉 [성공] minutes.arfab.kr 이 현재 정상 작동 중인 로컬 서버(127.0.0.1)로 연결되었습니다!
    echo 이제 브라우저에서 http://minutes.arfab.kr 로 접속하셔도 바로 작동합니다.
) else (
    echo.
    echo 이미 hosts 파일에 minutes.arfab.kr 이 등록되어 있습니다.
    ipconfig /flushdns >nul
)

echo.
pause
