import sys
import os
import tkinter as tk
from tkinter import filedialog

def pick():
    initial_dir = sys.argv[1] if len(sys.argv) > 1 and os.path.exists(sys.argv[1]) else None
    out_file = sys.argv[2] if len(sys.argv) > 2 else None
    done_file = sys.argv[3] if len(sys.argv) > 3 else None

    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    root.lift()
    root.focus_force()

    path = filedialog.askdirectory(initialdir=initial_dir, title="추가할 로컬 폴더를 선택하세요")
    root.destroy()

    if path and out_file:
        try:
            with open(out_file, "w", encoding="utf-8") as f:
                f.write(os.path.normpath(path))
        except Exception:
            pass

    if done_file:
        try:
            with open(done_file, "w", encoding="utf-8") as f:
                f.write("done")
        except Exception:
            pass

if __name__ == "__main__":
    pick()
