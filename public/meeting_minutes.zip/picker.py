import sys
import os
import ctypes

def pick_folder():
    initial_dir = sys.argv[1] if len(sys.argv) > 1 and os.path.exists(sys.argv[1]) else None
    out_file = sys.argv[2] if len(sys.argv) > 2 else None

    import tkinter as tk
    from tkinter import filedialog

    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    root.lift()
    root.focus_force()

    try:
        root.update()
        hwnd = root.winfo_id()
        ctypes.windll.user32.SetForegroundWindow(hwnd)
    except Exception:
        pass

    path = filedialog.askdirectory(parent=root, initialdir=initial_dir, title="추가할 로컬 폴더를 선택하세요")
    root.destroy()

    if path and out_file:
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(os.path.normpath(path))
    elif path:
        print(os.path.normpath(path), end="")

if __name__ == "__main__":
    pick_folder()
