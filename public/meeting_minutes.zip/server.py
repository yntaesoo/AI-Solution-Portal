import os
import re
import json
import base64
import uuid
import subprocess
from datetime import datetime
from typing import Optional, List

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import generator
import excel_parser
import project_manager
import ocr_parser
import doc_manager
import history_manager
import discussion_generator

app = FastAPI(title="동서대 앵커사업단 회의록 자동 작성 프로그램")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
STATIC_DIR = os.path.join(BASE_DIR, "static")

os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(STATIC_DIR, exist_ok=True)

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

class Attendee(BaseModel):
    dept: str = ""
    pos: str = ""
    name: str = ""

class Author(BaseModel):
    dept: str = ""
    pos: str = ""
    name: str = ""

class ProjectCreate(BaseModel):
    name: str
    default_place_meeting: Optional[str] = ""
    default_place_meal: Optional[str] = ""
    default_author: Optional[Author] = Author()
    attendees: Optional[List[Attendee]] = []

class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    default_place_meeting: Optional[str] = None
    default_place_meal: Optional[str] = None
    default_author: Optional[Author] = None
    attendees: Optional[List[Attendee]] = None

class ProjectAttendeesSave(BaseModel):
    attendees: List[Attendee]

class OCRImageRequest(BaseModel):
    image_base64: str
    is_card: Optional[bool] = False
    target_date: Optional[str] = None
    target_amount: Optional[int] = None
    target_merchant: Optional[str] = None

class DocPathAddRequest(BaseModel):
    path: str

class DocDeleteMultipleRequest(BaseModel):
    doc_ids: List[str]

class FolderRegisterRequest(BaseModel):
    path: str

class BrowseFolderRequest(BaseModel):
    initial_dir: Optional[str] = ""

class FsListRequest(BaseModel):
    path: Optional[str] = ""

class FolderScanRequest(BaseModel):
    path: str

class AddSelectedDocsRequest(BaseModel):
    file_paths: List[str]

class GenerateDiscussionRequest(BaseModel):
    keywords: str
    agenda: Optional[str] = ""
    meeting_name: Optional[str] = ""
    selected_doc_ids: Optional[List[str]] = None

from pydantic import BaseModel, validator

class MeetingData(BaseModel):
    project_id: Optional[str] = None
    project_name: Optional[str] = "부산 전략산업 맞춤형 앵커인재 양성사업단"
    meeting_name: Optional[str] = ""
    meeting_date: Optional[str] = "" # YYYY-MM-DD
    start_time: Optional[str] = "" # HH:MM
    end_time: Optional[str] = "" # HH:MM
    place_meeting: Optional[str] = ""
    place_meal: Optional[str] = ""
    agenda: Optional[str] = ""
    discussion: Optional[str] = ""
    remarks: Optional[str] = "선회의 후 식사진행"
    attendees: Optional[List[Attendee]] = []
    absentees: Optional[List[Attendee]] = []
    absent_reason: Optional[str] = ""
    author: Optional[Author] = Author()
    total_amount: Optional[int] = 0
    receipt_count: Optional[int] = 1
    receipt_image_base64: Optional[str] = None
    receipt_image_filename: Optional[str] = None
    card_image_base64: Optional[str] = None
    card_image_filename: Optional[str] = None

    @validator('total_amount', pre=True, always=True)
    def validate_total_amount(cls, v):
        if v is None:
            return 0
        if isinstance(v, (int, float)):
            import math
            return 0 if math.isnan(v) else int(v)
        if isinstance(v, str):
            clean = re.sub(r'[^0-9]', '', v)
            return int(clean) if clean else 0
        return 0

    @validator('receipt_count', pre=True, always=True)
    def validate_receipt_count(cls, v):
        if v is None:
            return 1
        try:
            return max(1, int(v))
        except Exception:
            return 1

@app.get("/", response_class=HTMLResponse)
@app.head("/")
async def index():
    html_file = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(html_file):
        with open(html_file, "r", encoding="utf-8") as f:
            return f.read()
    return "<h1>Meeting minutes system is starting... Please wait.</h1>"

# --- 과제 관리 API ---
@app.get("/api/projects")
async def list_projects():
    """등록된 과제 목록 조회"""
    return {"success": True, "projects": project_manager.get_all_projects()}

@app.get("/api/projects/{project_id}")
async def get_project_detail(project_id: str):
    """특정 과제 상세 정보 조회"""
    p = project_manager.get_project(project_id)
    if not p:
        raise HTTPException(status_code=404, detail="과제를 찾을 수 없습니다.")
    return {"success": True, "project": p}

@app.post("/api/projects")
async def create_new_project(data: ProjectCreate):
    """신규 과제 등록"""
    new_p = project_manager.create_project(data.dict())
    return {"success": True, "project": new_p}

@app.put("/api/projects/{project_id}")
async def update_existing_project(project_id: str, data: ProjectUpdate):
    """기존 과제 수정"""
    update_data = {k: v for k, v in data.dict().items() if v is not None}
    updated = project_manager.update_project(project_id, update_data)
    if not updated:
        raise HTTPException(status_code=404, detail="과제를 찾을 수 없습니다.")
    return {"success": True, "project": updated}

@app.delete("/api/projects/{project_id}")
async def delete_existing_project(project_id: str):
    """과제 삭제"""
    ok = project_manager.delete_project(project_id)
    if not ok:
        raise HTTPException(status_code=404, detail="과제를 찾을 수 없습니다.")
    return {"success": True, "message": "과제가 삭제되었습니다."}

@app.post("/api/projects/{project_id}/attendees")
async def save_project_attendees(project_id: str, body: ProjectAttendeesSave):
    """현재 명부를 해당 과제의 기본 참석자 풀로 저장"""
    ok = project_manager.save_project_attendees(project_id, [a.dict() for a in body.attendees])
    if not ok:
        raise HTTPException(status_code=404, detail="과제 참석자 명부 저장 실패")
    return {"success": True, "message": "해당 과제의 기본 참석자 명부가 업데이트되었습니다."}

# --- 관련 문서 / 계획서 관리 API ---
@app.get("/api/docs")
async def list_documents():
    """등록된 참고 문서 / 계획서 목록 조회"""
    return {"success": True, "documents": doc_manager.get_all_documents()}

@app.post("/api/docs/upload")
async def upload_document(file: UploadFile = File(...), title: Optional[str] = Form(None)):
    """문서 파일 업로드 등록 (.md, .txt, .hwp, .hwpx, .pdf 등)"""
    try:
        content = await file.read()
        doc = doc_manager.add_document_file(file.filename, content, title=title)
        return {"success": True, "document": doc, "message": f"'{file.filename}' 문서가 성공적으로 등록되었습니다."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/docs/add-path")
async def add_document_path(req: DocPathAddRequest):
    """로컬 파일 또는 폴더 경로 등록"""
    try:
        added = doc_manager.add_local_path(req.path)
        return {
            "success": True,
            "added_count": len(added),
            "documents": added,
            "message": f"{len(added)}개의 문서가 성공적으로 추가되었습니다."
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/api/docs/{doc_id}")
async def delete_document(doc_id: str):
    """등록된 참고 문서 삭제"""
    ok = doc_manager.delete_document(doc_id)
    if not ok:
        raise HTTPException(status_code=404, detail="문서를 찾을 수 없습니다.")
    return {"success": True, "message": "문서가 삭제되었습니다."}

@app.post("/api/docs/delete-multiple")
async def delete_multiple_documents(req: DocDeleteMultipleRequest):
    """선택된 문서들 일괄/부분 삭제"""
    count = doc_manager.delete_documents(req.doc_ids)
    return {"success": True, "deleted_count": count, "message": f"{count}개의 문서가 삭제되었습니다."}

@app.post("/api/docs/delete-all")
async def delete_all_documents():
    """모든 등록 문서 전체 일괄 삭제"""
    count = doc_manager.delete_all_documents()
    return {"success": True, "deleted_count": count, "message": f"전체 {count}개의 문서가 삭제되었습니다."}

# --- Antigravity 스타일 폴더 관리 API ---
@app.get("/api/folders")
async def list_registered_folders():
    """등록된 폴더 목록 조회"""
    return {"success": True, "folders": doc_manager.get_registered_folders()}

@app.post("/api/browse-folder")
async def browse_folder(req: BrowseFolderRequest = BrowseFolderRequest()):
    """브라우저 네이티브 파일/폴더 선택 지원 안내"""
    return {"success": True, "path": "", "message": "브라우저 네이티브 대화상자 사용"}

@app.post("/api/fs/list")
async def list_fs(req: FsListRequest = FsListRequest()):
    """웹 파일/폴더 탐색기용 실시간 디렉토리 및 파일 조회"""
    try:
        data = doc_manager.list_fs_directory(req.path)
        return {"success": True, **data}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/folders/scan")
async def scan_folder_candidates(req: FolderScanRequest):
    """폴더 내 문서(.md, .txt, .hwp, .hwpx, .pdf, .docx)를 스캔하여 선택용 후보 목록 반환 (자동 등록 안 함)"""
    try:
        candidates = doc_manager.scan_folder_candidate_docs(req.path)
        return {"success": True, "folder_path": req.path, "candidates": candidates, "total": len(candidates)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/docs/add-selected")
async def add_selected_docs(req: AddSelectedDocsRequest):
    """사용자가 체크 선택한 문서들만 선별 등록"""
    try:
        added = doc_manager.add_selected_documents(req.file_paths)
        return {
            "success": True,
            "added": added,
            "count": len(added),
            "message": f"{len(added)}건의 문서가 성공적으로 등록되었습니다."
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/folders")
async def register_new_folder(req: FolderRegisterRequest):
    """폴더 추가 등록 및 후보 문서 목록 함께 반환 (사용자가 선택하여 등록 가능)"""
    try:
        f = doc_manager.register_folder(req.path)
        candidates = doc_manager.scan_folder_candidate_docs(req.path)
        return {
            "success": True,
            "folder": f,
            "candidates": candidates,
            "message": f"폴더 '{f['name']}'가 등록되었습니다."
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/api/folders/{folder_id}")
async def delete_registered_folder(folder_id: str):
    """폴더 등록 해제"""
    ok = doc_manager.unregister_folder(folder_id)
    if not ok:
        raise HTTPException(status_code=404, detail="폴더를 찾을 수 없습니다.")
    return {"success": True, "message": "폴더가 목록에서 제거되었습니다."}

# --- 키워드 & 계획서 기반 토의내용 자동 생성 API ---
@app.post("/api/generate-discussion")
async def generate_discussion(req: GenerateDiscussionRequest):
    """키워드, 회의 안건, 등록된 계획서 및 이전 회의내용을 참조하여 토의내용 자동 생성"""
    try:
        res = discussion_generator.generate_discussion_from_context(
            keywords=req.keywords,
            agenda=req.agenda,
            meeting_name=req.meeting_name,
            selected_doc_ids=req.selected_doc_ids
        )
        return res
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- 이전 회의 히스토리 조회 API ---
@app.get("/api/history")
async def list_meeting_history():
    """지금까지 작성된 회의록 기록 조회"""
    return {"success": True, "meetings": history_manager.get_all_history()}

# --- 영수증 / 카드 스마트 OCR 인식 API ---
@app.post("/api/ocr-receipt")
async def ocr_receipt(req: OCRImageRequest):
    """영수증 또는 카드 이미지에서 일시, 장소, 금액 자동 인식"""
    if not req.image_base64:
        raise HTTPException(status_code=400, detail="이미지 데이터가 없습니다.")
    res = ocr_parser.extract_receipt_info(
        req.image_base64,
        is_card=req.is_card,
        target_date=req.target_date,
        target_amount=req.target_amount,
        target_merchant=req.target_merchant
    )
    return res

@app.post("/api/upload-image")
async def upload_image(file: UploadFile = File(...)):
    """일반 이미지 파일 업로드"""
    ext = os.path.splitext(file.filename)[1] or ".png"
    filename = f"{uuid.uuid4().hex}{ext}"
    filepath = os.path.join(UPLOADS_DIR, filename)
    with open(filepath, "wb") as f:
        f.write(await file.read())
    return {"filename": filename, "filepath": filepath, "url": f"/uploads/{filename}"}

class SelectExcelRowRequest(BaseModel):
    excel_filename: str
    selected_index: int
    only_selected_row: Optional[bool] = False

@app.post("/api/upload-excel")
async def upload_excel(
    file: UploadFile = File(...),
    target_merchant: Optional[str] = Form(None),
    target_amount: Optional[str] = Form(None)
):
    """카드 지출내역서 엑셀 파일 업로드 및 분석 (가맹점명 스마트 매칭 지원)"""
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in [".xlsx", ".xls", ".csv"]:
        raise HTTPException(status_code=400, detail="엑셀 파일(.xlsx, .xls, .csv)만 지원합니다.")
        
    excel_filename = f"excel_{uuid.uuid4().hex}{ext}"
    excel_path = os.path.join(UPLOADS_DIR, excel_filename)
    with open(excel_path, "wb") as f:
        f.write(await file.read())
        
    # 가맹점명 및 금액 매칭 파싱
    clean_target_amount = None
    if target_amount:
        try:
            clean_target_amount = int(re.sub(r'[^0-9]', '', str(target_amount)))
        except Exception:
            pass

    parsed = excel_parser.parse_card_excel(excel_path, target_merchant, clean_target_amount)
    
    # 대표/선택된 가맹점 행을 하이라이트한 표 이미지 렌더링
    selected_idx = parsed.get("selected_index", 0)
    img_filename = f"table_{uuid.uuid4().hex}.png"
    img_path = os.path.join(UPLOADS_DIR, img_filename)
    excel_parser.render_excel_table_image(excel_path, img_path, selected_idx=selected_idx, only_selected_row=False)
    
    return {
        "success": True,
        "excel_filename": excel_filename,
        "parsed": parsed,
        "table_image_filename": img_filename,
        "table_image_path": img_path
    }

@app.post("/api/select-excel-row")
def select_excel_row(req: SelectExcelRowRequest):
    """지출내역서에서 특정 거래를 선택했을 때 첨부철용 표 이미지 재생성"""
    excel_path = os.path.join(UPLOADS_DIR, req.excel_filename)
    if not os.path.exists(excel_path):
        raise HTTPException(status_code=404, detail="엑셀 파일을 찾을 수 없습니다.")
        
    img_filename = f"table_{uuid.uuid4().hex}.png"
    img_path = os.path.join(UPLOADS_DIR, img_filename)
    excel_parser.render_excel_table_image(
        excel_path,
        img_path,
        selected_idx=req.selected_index,
        only_selected_row=req.only_selected_row
    )
    return {
        "success": True,
        "table_image_filename": img_filename,
        "table_image_url": f"/uploads/{img_filename}"
    }

def save_base64_image(base64_str: str, prefix: str = "img") -> str:
    """Base64 data url을 이미지 파일로 저장"""
    if not base64_str:
        return None
    # data:image/png;base64, 제거
    match = re.match(r"^data:image/(\w+);base64,(.+)$", base64_str)
    if match:
        ext = f".{match.group(1)}"
        data = base64.b64decode(match.group(2))
    else:
        ext = ".png"
        data = base64.b64decode(base64_str)
        
    filename = f"{prefix}_{uuid.uuid4().hex}{ext}"
    filepath = os.path.join(UPLOADS_DIR, filename)
    with open(filepath, "wb") as f:
        f.write(data)
    return filepath

@app.post("/api/generate")
async def generate_document(data: MeetingData):
    """회의록 HWP 및 PDF 생성"""
    try:
        # 영수증 이미지 처리
        receipt_path = None
        if data.receipt_image_base64:
            receipt_path = save_base64_image(data.receipt_image_base64, "receipt")
        elif data.receipt_image_filename:
            receipt_path = os.path.join(UPLOADS_DIR, data.receipt_image_filename)

        # 카드 지출내역서 이미지 처리
        card_path = None
        if data.card_image_base64:
            card_path = save_base64_image(data.card_image_base64, "card")
        elif data.card_image_filename:
            card_path = os.path.join(UPLOADS_DIR, data.card_image_filename)

        # HWP 생성 호출 (카드 지출내역서는 회의정보 분석/매칭 전용이며 첨부철에는 배치하지 않음)
        result = generator.generate_meeting_minutes_hwp(
            base_dir=BASE_DIR,
            data=data.dict(),
            receipt_img_path=receipt_path,
            card_statement_img_path=None
        )
        
        # 회의 히스토리에 자동 누적 저장 (추후 AI 참조용)
        try:
            history_manager.add_meeting_history(data.dict())
        except Exception as he:
            print("History save warning:", he)
        
        return {
            "success": True,
            "filename": result["filename"],
            "hwp_url": f"/api/download/{result['filename']}",
            "pdf_url": f"/api/download/{os.path.splitext(result['filename'])[0]}.pdf" if result["pdf_path"] else None,
            "hwp_path": result["hwp_path"],
            "pdf_path": result["pdf_path"]
        }
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/download/{filename}")
async def download_file(filename: str):
    """생성된 파일 다운로드"""
    filepath = os.path.join(OUTPUT_DIR, filename)
    if not os.path.exists(filepath):
        raise HTTPException(status_code=404, detail="파일을 찾을 수 없습니다.")
    return FileResponse(filepath, filename=filename)

@app.post("/api/open-hwp")
async def open_hwp_file(req: Request):
    """로컬 PC에서 한글 프로그램으로 파일 바로 열기"""
    try:
        body = await req.json()
    except Exception:
        body = {}
    filename = body.get("filename")
    filepath = None

    if filename:
        candidate = os.path.abspath(os.path.join(OUTPUT_DIR, filename))
        if os.path.exists(candidate):
            filepath = candidate
        else:
            # 확장자 없거나 다른 경우
            base_name = os.path.splitext(filename)[0]
            for f in os.listdir(OUTPUT_DIR):
                if f.startswith(base_name) and f.endswith(".hwp"):
                    filepath = os.path.abspath(os.path.join(OUTPUT_DIR, f))
                    break

    # 파일명이 없거나 못 찾은 경우: 가장 최근 생성된 .hwp 자동 선택
    if not filepath:
        hwp_files = [
            os.path.join(OUTPUT_DIR, f)
            for f in os.listdir(OUTPUT_DIR)
            if f.endswith(".hwp")
        ]
        if hwp_files:
            filepath = max(hwp_files, key=os.path.getmtime)

    if filepath and os.path.exists(filepath):
        try:
            try:
                os.startfile(filepath)
            except Exception:
                subprocess.Popen(f'start "" "{filepath}"', shell=True)
            return {"success": True, "message": f"한글 프로그램을 실행했습니다: {os.path.basename(filepath)}", "path": filepath}
        except Exception as e:
            return {"success": False, "message": f"실행 실패: {str(e)}"}
            
    return {"success": False, "message": "열 수 있는 HWP 회의록 파일이 없습니다. 먼저 회의록을 생성해주세요."}

@app.post("/api/open-folder")
async def open_output_folder():
    """저장 폴더 탐색기 열기"""
    try:
        folder_path = os.path.abspath(OUTPUT_DIR)
        os.makedirs(folder_path, exist_ok=True)
        try:
            os.startfile(folder_path)
        except Exception:
            subprocess.Popen(f'explorer "{folder_path}"')
        return {"success": True, "path": folder_path}
    except Exception as e:
        return {"success": False, "message": str(e)}

if __name__ == "__main__":
    import uvicorn
    import sys
    port = 8005
    for i, arg in enumerate(sys.argv):
        if arg in ["--port", "-p"] and i + 1 < len(sys.argv):
            try:
                port = int(sys.argv[i + 1])
            except ValueError:
                pass
    uvicorn.run("server:app", host="0.0.0.0", port=port, reload=False)
