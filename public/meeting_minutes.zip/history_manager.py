import os
import json
import uuid
from datetime import datetime

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
HISTORY_FILE = os.path.join(DATA_DIR, "meeting_history.json")

def init_history():
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(HISTORY_FILE):
        default_history = {
            "meetings": [
                {
                    "id": "hist_sample_01",
                    "meeting_name": "2026-2학기 앵커사업 L-Stay 게임개발전공 캡스톤 1차 킥오프 회의",
                    "meeting_date": "2026-09-22",
                    "project_name": "부산 전략산업 맞춤형 앵커인재 양성사업단",
                    "agenda": "참여기업 협약 체결 및 6개 졸업작품팀 2:2:2 매칭, 중간점검 일정 수립",
                    "discussion": """○ 앵커사업 L-Stay 정주 생태계 고도화 방안 논의
  ‣ 외인 유학생의 지역 정주를 위한 전공 실무 역량 강화(Major-Up) 추진
  ‣ 부산 대표 게임/콘텐츠 3개사((주)좀비메이트, 스튜디오 로, (주)유캔스타) 산학 협약 체결
○ 캡스톤디자인 1차 멘토링 매칭 및 일정 확정
  ‣ 6개 졸업작품팀과 기업 간 2:2:2 매칭 완료
  ‣ 10월 중순 프로토타입 1차 빌드 시점에 맞춘 1:1 심층 클리닉 추진 결정
○ 차후 계획 논의
  ‣ 참여기업 자문위원 위촉 및 세부 운영계획안 확정""",
                    "created_at": "2026-09-22 17:30"
                }
            ]
        }
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(default_history, f, ensure_ascii=False, indent=2)

def get_all_history() -> list:
    init_history()
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("meetings", [])
    except Exception as e:
        print("Error reading meeting history:", e)
        return []

def add_meeting_history(meeting_data: dict) -> dict:
    """회의록 생성 시 히스토리에 자동 추가"""
    init_history()
    meetings = get_all_history()
    
    # 중복 체크 (동일 날짜 및 회의명)
    m_name = meeting_data.get("meeting_name", "").strip()
    m_date = meeting_data.get("meeting_date", "").strip()
    
    entry = {
        "id": f"hist_{uuid.uuid4().hex[:8]}",
        "meeting_name": m_name,
        "meeting_date": m_date,
        "project_name": meeting_data.get("project_name", ""),
        "agenda": meeting_data.get("agenda", ""),
        "discussion": meeting_data.get("discussion", ""),
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
    }

    # 기존에 같은 회의명이 있으면 갱신, 없으면 추가
    found = False
    for i, m in enumerate(meetings):
        if m.get("meeting_name") == m_name and m.get("meeting_date") == m_date:
            meetings[i] = entry
            found = True
            break
            
    if not found:
        meetings.append(entry)

    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump({"meetings": meetings}, f, ensure_ascii=False, indent=2)
        
    return entry

def get_history_summary_for_ai() -> str:
    """AI 생성을 위해 지금까지 진행된 회의의 요약 정보 제공"""
    meetings = get_all_history()
    if not meetings:
        return "이전 회의 이력 없음."
        
    lines = []
    # 최근 회의 최대 5건 요약
    for m in meetings[-5:]:
        lines.append(f"[{m.get('meeting_date', '-')} 회의] {m.get('meeting_name', '')}")
        if m.get("agenda"):
            lines.append(f" - 안건: {m.get('agenda')}")
        if m.get("discussion"):
            disc_preview = m.get('discussion').strip()[:300].replace('\n', ' / ')
            lines.append(f" - 주요 내용: {disc_preview}...")
        lines.append("")
        
    return "\n".join(lines)
