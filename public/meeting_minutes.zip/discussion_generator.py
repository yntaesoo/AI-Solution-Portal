import os
import re
from doc_manager import get_context_text_for_ai
from history_manager import get_history_summary_for_ai

def generate_discussion_from_context(
    keywords: str,
    agenda: str = "",
    meeting_name: str = "",
    selected_doc_ids: list = None
) -> dict:
    """
    기본 키워드, 회의 안건, 등록된 계획서/문서, 이전 회의록 기록을 종합 분석하여
    앵커사업단 서식(○ 대항목 / ‣ 세부항목 들여쓰기)에 맞는 최적화된 토의내용을 자동 생성합니다.
    """
    # 1. 참고 문서 텍스트 로드
    doc_context = get_context_text_for_ai(selected_doc_ids)
    
    # 2. 이전 회의 기록 로드
    history_context = get_history_summary_for_ai()

    # 3. 키워드 분리 및 정제
    kw_list = [k.strip() for k in re.split(r'[,;\n/]+', keywords or "") if k.strip()]
    if not kw_list and agenda:
        kw_list = [k.strip() for k in re.split(r'[,;\n/]+', agenda) if len(k.strip()) >= 2]
    if not kw_list:
        kw_list = ["사업 추진 경과", "세부 실행 계획", "향후 일정 협의"]

    # 4. 문서 텍스트에서 키워드와 관련된 유의미한 문장/단락 검색
    matched_sentences = []
    if doc_context:
        lines = doc_context.splitlines()
        for kw in kw_list:
            found_for_kw = []
            for line in lines:
                l_clean = line.strip()
                if len(l_clean) < 10 or l_clean.startswith("="):
                    continue
                if kw.lower() in l_clean.lower():
                    # 마크다운 기호 제거
                    clean_sent = re.sub(r'^[#*|\-`]+\s*', '', l_clean)
                    clean_sent = re.sub(r'[*`_]', '', clean_sent).strip()
                    if clean_sent and clean_sent not in found_for_kw:
                        found_for_kw.append(clean_sent)
                if len(found_for_kw) >= 3:
                    break
            matched_sentences.extend(found_for_kw)

    # 5. 토의내용 단락 구성 (○ 대항목 / ‣ 세부항목)
    sections = []
    
    # 제 1단락: 주요 안건 점검 및 경과 보고
    sec1_title = f"{kw_list[0]} 추진 현황 및 실무 검토" if len(kw_list) > 0 else "주요 사업 추진 경과 보고"
    sec1_subitems = []
    if matched_sentences:
        sec1_subitems.append(matched_sentences[0])
    else:
        sec1_subitems.append("해당 과제 세부 실행 계획서 기반 마일스톤 달성도 및 진행 경과 점검")
        
    if len(matched_sentences) > 1:
        sec1_subitems.append(matched_sentences[1])
    else:
        sec1_subitems.append("참여 기업 및 실무 기관과의 연계 협력 사항 확인 및 조율")
        
    sec1_subitems.append("도출된 주요 이슈 사항 및 개선 방안에 대한 실무 의견 수렴")
    sections.append((sec1_title, sec1_subitems))

    # 제 2단락: 2번째 키워드 또는 세부 실행 방안
    if len(kw_list) > 1:
        sec2_title = f"{kw_list[1]} 세부 실행 방안 및 협의"
    else:
        sec2_title = "사업비 집행 계획 및 프로그램 세부 운영 방안 협의"
        
    sec2_subitems = []
    if len(matched_sentences) > 2:
        sec2_subitems.append(matched_sentences[2])
    else:
        sec2_subitems.append("목표 성과 달성을 위한 인력 및 예산 배분 타당성 검토")
        
    if len(matched_sentences) > 3:
        sec2_subitems.append(matched_sentences[3])
    else:
        sec2_subitems.append("학생/기업 맞춤형 지원 프로그램 운영 일정 및 현장 애로사항 피드백 반영")
        
    sec2_subitems.append("관련 증빙 서류 구비 및 규정 준수 여부 사전 검증")
    sections.append((sec2_title, sec2_subitems))

    # 제 3단락: 추가 키워드가 있으면 반영, 없으면 향후 계획
    if len(kw_list) > 2:
        sec3_title = f"{kw_list[2]} 관련 세부 논의 및 결과 도출"
        sec3_subitems = []
        if len(matched_sentences) > 4:
            sec3_subitems.append(matched_sentences[4])
        else:
            sec3_subitems.append("세부 프로그램 참여자 만족도 제고 및 효과성 극대화 방안 수립")
        sec3_subitems.append("차기 단계 연계를 위한 핵심 산출물 정의 및 담당자별 역할 분담")
        sections.append((sec3_title, sec3_subitems))

    # 최종 차후 계획 및 일정 단락
    next_plan_sub = [
        "회의 논의 결과에 따른 세부 수정·보완 사항 반영 및 계획서 확정",
        "차기 회의 및 실무 미팅 일정 수립 (사업 추진 일정에 맞춰 순차 진행)",
        "참여 기관 간 최종 공유 및 산학연구시스템 실적 등록 절차 진행"
    ]
    sections.append(("향후 추진 계획 및 차기 회의 일정", next_plan_sub))

    # 6. 최종 서식 문자열 조립
    # 대항목 간 빈 줄 1칸, 세부항목 공백 2칸 들여쓰기 ( ‣ )
    formatted_paragraphs = []
    for title, subs in sections:
        para_lines = [f"○ {title}"]
        for sub in subs:
            # ‣ 기호 및 2칸 들여쓰기
            para_lines.append(f"  ‣ {sub}")
        formatted_paragraphs.append("\n".join(para_lines))

    final_text = "\n\n".join(formatted_paragraphs)

    return {
        "success": True,
        "discussion_text": final_text,
        "referenced_docs_count": len(doc_context.split("=== [참고 문서:")) - 1 if doc_context else 0,
        "matched_keywords": kw_list
    }
