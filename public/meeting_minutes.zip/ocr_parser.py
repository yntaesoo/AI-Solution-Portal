import io
import os
import re
import base64
from PIL import Image, ImageEnhance
import winocr

def load_image(img_input) -> Image.Image:
    """다양한 형식(경로, Base64 Data URL, 바이너리)의 이미지를 PIL Image로 변환"""
    if isinstance(img_input, str):
        if img_input.startswith("data:image"):
            header, encoded = img_input.split(",", 1)
            data = base64.b64decode(encoded)
            return Image.open(io.BytesIO(data))
        elif len(img_input) > 300 and ("/" not in img_input[:50] and "\\" not in img_input[:50]):
            try:
                data = base64.b64decode(img_input)
                return Image.open(io.BytesIO(data))
            except Exception:
                pass
        if os.path.exists(img_input):
            return Image.open(img_input)
    elif isinstance(img_input, (bytes, bytearray)):
        return Image.open(io.BytesIO(img_input))
    elif isinstance(img_input, Image.Image):
        return img_input
    return None

def preprocess_image(pil_img: Image.Image) -> Image.Image:
    """영수증 OCR 인식률 향상을 위한 명암 대비 보정"""
    img = pil_img.convert("L")
    enhancer = ImageEnhance.Contrast(img)
    img = enhancer.enhance(1.8)
    return img.convert("RGBA")

import concurrent.futures

def _safe_winocr_recognize(img: Image.Image, lang: str = "ko") -> dict:
    """FastAPI 이벤트 루프 내 충돌 방지를 위해 별도 스레드에서 winocr 동기 실행"""
    def _run():
        return winocr.recognize_pil_sync(img, lang)
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(_run)
        return future.result()

def extract_receipt_info(img_input, is_card: bool = False, target_date: str = None, target_amount: int = None, target_merchant: str = None) -> dict:
    """
    영수증/카드 이미지에서 일시(날짜, 시간), 상호(가맹점), 결제금액을 자동 추출합니다.
    카드 이미지인 경우 표 행 군집화 및 타겟(일자, 금액, 가맹점) 스마트 매칭과 해당 행 크롭을 지원합니다.
    """
    pil_img = load_image(img_input)
    if not pil_img:
        return {
            "success": False,
            "message": "이미지를 로드할 수 없습니다.",
            "date": None,
            "time": None,
            "suggested_start_time": None,
            "merchant": None,
            "amount": None,
            "raw_text": ""
        }

    try:
        # 카드 지출내역서 표 이미지인 경우
        if is_card:
            card_res = parse_card_table_image(pil_img, target_date, target_amount, target_merchant)
            sel = card_res.get("selected_tx")
            return {
                "success": True,
                "is_card": True,
                "date": sel["date"] if sel else None,
                "time": None,
                "suggested_start_time": None,
                "merchant": sel["merchant"] if sel else None,
                "amount": sel["amount"] if sel else None,
                "amount_str": sel["amount_str"] if sel else None,
                "transactions": card_res.get("transactions", []),
                "selected_index": card_res.get("selected_index", 0),
                "cropped_image": card_res.get("cropped_b64"),
                "raw_text": sel["text"] if sel else ""
            }

        # 일반 영수증인 경우
        text = ""
        try:
            res = _safe_winocr_recognize(pil_img.convert("RGBA"), "ko")
            text = res.get("text", "")
        except Exception as e:
            print("winocr raw attempt error:", e)

        if not text or len(text.strip()) < 5:
            try:
                pre_img = preprocess_image(pil_img)
                res = _safe_winocr_recognize(pre_img, "ko")
                text = res.get("text", "")
            except Exception as e:
                print("winocr preprocessed attempt error:", e)

        parsed = parse_ocr_text(text)
        parsed["success"] = True
        parsed["is_card"] = False
        return parsed
    except Exception as e:
        print("OCR Error:", e)
        return {
            "success": False,
            "message": str(e),
            "date": None,
            "time": None,
            "suggested_start_time": None,
            "merchant": None,
            "amount": None,
            "raw_text": ""
        }

def parse_ocr_text(text: str) -> dict:
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    full_text = " ".join(lines)
    
    # 1. 날짜 추출 (YYYY-MM-DD, YYYY.MM.DD, YYYY/MM/DD, YY-MM-DD 등)
    date_val = None
    # 1순위: 거래일시, 승인일자, 판매일시, 일시 등의 키워드 직후 날짜
    kw_dt = re.search(r'(?:거래\s*일\s*시|승\s*인\s*일\s*시|판매\s*일\s*시|일\s*시|일\s*자)[\s:.]*(?:(20\d{2})|(\d{2}))[-./년\s]+(1[0-2]|0?[1-9])[-./월\s]+([12]\d|3[01]|0?[1-9])', full_text)
    if kw_dt:
        y = kw_dt.group(1) or f"20{kw_dt.group(2)}"
        m = f"{int(kw_dt.group(3)):02d}"
        d = f"{int(kw_dt.group(4)):02d}"
        date_val = f"{y}-{m}-{d}"
    else:
        # 2순위: 전화번호 지역번호 (02) 등을 제외한 4자리 연도 패턴
        gen_dt = re.search(r'(?<!\(\d{2}\))(?<!\d)(20\d{2})[-./년\s]+(1[0-2]|0?[1-9])[-./월\s]+([12]\d|3[01]|0?[1-9])', full_text)
        if gen_dt:
            y, m, d = gen_dt.groups()
            date_val = f"{y}-{int(m):02d}-{int(d):02d}"
        else:
            short_dt = re.search(r'(?<!\d)(\d{2})[-./](1[0-2]|0?[1-9])[-./]([12]\d|3[01]|0?[1-9])', full_text)
            if short_dt:
                y, m, d = short_dt.groups()
                date_val = f"20{y}-{int(m):02d}-{int(d):02d}"

    # 2. 시간 추출 (HH:MM)
    time_val = None
    # 날짜나 거래일시 직후 우선 탐색
    after_date_str = full_text
    if "거래일시" in full_text:
        after_date_str = full_text[full_text.find("거래일시"):]
    elif date_val and date_val in full_text:
        after_date_str = full_text[full_text.find(date_val):]

    tm_match = re.search(r'(?:^|[^\d])([01]?\d|2[0-3])[:;·•.]([0-5]\d)(?:[:;·•.]([0-5]\d))?', after_date_str)
    if tm_match:
        time_val = f"{int(tm_match.group(1)):02d}:{int(tm_match.group(2)):02d}"
    else:
        tm_fallback = re.search(r'(?:^|[^\d])([01]?\d|2[0-3])[:;·•.]([0-5]\d)', full_text)
        if tm_fallback:
            time_val = f"{int(tm_fallback.group(1)):02d}:{int(tm_fallback.group(2)):02d}"

    # 시작 시간 추천 (종료 시간보다 1시간 30분 ~ 2시간 전)
    suggested_start = "18:30"
    if time_val:
        try:
            h_int = int(time_val.split(":")[0])
            m_int = int(time_val.split(":")[1])
            tot = h_int * 60 + m_int - 105 # 1시간 45분 전
            if tot < 0: tot += 24 * 60
            sh = tot // 60
            sm = (tot % 60 // 10) * 10
            suggested_start = f"{sh:02d}:{sm:02d}"
        except Exception:
            pass

    # 3. 금액 추출 (총금액, 합계, '원' 단위 수치 중 최대값)
    amount_int = None
    amt_cands = []

    # '원'으로 끝나는 금액 (숫자 사이 공백 자동 제거)
    for m in re.finditer(r'([0-9\s,.]+)\s*원', full_text):
        clean = re.sub(r'[^0-9]', '', m.group(1))
        if clean:
            val = int(clean)
            if 1000 <= val <= 20000000:
                amt_cands.append(val)

    # 라벨형 금액 (총금액, 합계, 결제금액, 승인금액 등)
    for lm in re.finditer(r'(?:총[-_.\s]*[극금][-_.\s]*액|합\s*계|결\s*제\s*금\s*액|승\s*인\s*금\s*액|이\s*용\s*금\s*액)[\s:]*([0-9\s,.]+)', full_text):
        clean = re.sub(r'[^0-9]', '', lm.group(1)[:15])
        if clean:
            val = int(clean)
            if 1000 <= val <= 20000000:
                amt_cands.append(val)

    if amt_cands:
        # 영수증 최종 결제액은 공급가액, 부가세 합산된 총액(최대값)
        amount_int = max(amt_cands)

    # 4. 상호(가맹점명) 추출
    merchant_val = None
    merchant_match = re.search(r'(?:상\s*호|가\s*맹\s*점(?:명)?|매\s*장\s*명|[가卜]\s*[맹명]\s*[점뎡](?:명)?)[\s:.]*([^\n\r,\(\)\[\]]{2,25})', full_text)
    if merchant_match:
        m_cand = merchant_match.group(1).strip()
        m_cand = re.sub(r'^[뎡명:.\s]+', '', m_cand).strip()
        m_cand = re.split(r'사업|대표|전표|전화|주소|단말기|TEL|T\s*E\s*L', m_cand)[0].strip()
        if len(m_cand) >= 2:
            merchant_val = m_cand

    if not merchant_val and lines:
        exclude_words = ["영수증", "신용카드", "매출전표", "고객용", "가맹점용", "보관용", "승인", "카드사", "IC", "WIFI"]
        for line in lines[:6]:
            clean_l = re.sub(r'[\(\)\[\]0-9\-:\*]', '', line).strip()
            if len(clean_l) >= 2 and not any(ew in clean_l for ew in exclude_words):
                merchant_val = clean_l
                break

    return {
        "date": date_val,
        "time": time_val,
        "suggested_start_time": suggested_start,
        "merchant": merchant_val,
        "amount": amount_int,
        "amount_str": f"{amount_int:,}" if amount_int else None,
        "raw_text": text
    }

def parse_card_table_image(pil_img: Image.Image, target_date=None, target_amount=None, target_merchant=None) -> dict:
    """카드 지출내역서 캡처 이미지에서 표 행들을 감지하고 타겟(일자, 금액, 가맹점)과 스마트 매칭"""
    res = _safe_winocr_recognize(pil_img.convert('RGBA'), 'ko')
    
    words = []
    for line in res.get('lines', []):
        for w in line.get('words', []):
            r = w.get('bounding_rect', {})
            words.append({
                'text': w.get('text', ''),
                'x': r.get('x', 0),
                'y': r.get('y', 0),
                'h': r.get('height', 0),
                'w': r.get('width', 0)
            })

    # y좌표 기준 행 군집화
    rows = []
    for w in words:
        matched_row = None
        for r in rows:
            if abs(w['y'] - r['y']) <= 8:
                matched_row = r
                break
        if matched_row:
            matched_row['words'].append(w)
        else:
            rows.append({'y': w['y'], 'words': [w]})

    rows.sort(key=lambda r: r['y'])

    header_row = None
    for r in rows:
        t = ' '.join(w['text'] for w in r['words'])
        if any(k in t for k in ['일자', '가맹점', '카드번호', '금액', 'No']):
            header_row = r
            break

    transactions = []
    for r in rows:
        r['words'].sort(key=lambda w: w['x'])
        t = ' '.join(w['text'] for w in r['words'])
        d_m = re.search(r'(20\d{2}[-./년\s]+\d{1,2}[-./월\s]+\d{1,2})', t)
        amts = re.findall(r'(\d{1,3}(?:[.,]\d{3})+)', t)
        
        if d_m:
            clean_amt = None
            if amts:
                clean_amt = int(amts[0].replace('.', '').replace(',', ''))
            
            m_cand = target_merchant or None
            # 배제할 단어들 (인명, 책임자, 상태 등)
            exclude_names = ['연구책임자', '정상', '비고', '윤태수', '태수', '은의', '월수', '을臼', '책임자', '승인', '취소']
            if not m_cand:
                for w in r['words']:
                    wt = w['text'].strip()
                    if not re.search(r'\d{4}[-.]\d{2}[-.]\d{2}', wt) and not re.search(r'\d{4}-\d{4}', wt) and not re.search(r'^\d+[.,]?\d*$', wt):
                        if len(wt) >= 2 and not any(ex in wt for ex in exclude_names) and not wt.endswith('수'):
                            m_cand = wt
                            break  # 가맹점 컬럼은 앞쪽에 위치하므로 첫 번째 유효 단어 우선

            transactions.append({
                'y': r['y'],
                'date': d_m.group(1),
                'amount': clean_amt,
                'amount_str': f"{clean_amt:,}" if clean_amt else "",
                'merchant': target_merchant or m_cand or "",
                'text': t
            })

    # 최적 거래행 매칭
    best_idx = 0
    best_score = -1
    for idx, tx in enumerate(transactions):
        score = 0
        if target_date and tx['date'] and (target_date in tx['date'] or tx['date'] in target_date):
            score += 50
        if target_amount and tx['amount'] and tx['amount'] == target_amount:
            score += 50
        if target_merchant and tx['merchant'] and (target_merchant in tx['merchant'] or tx['merchant'] in target_merchant):
            score += 30
        if score > best_score:
            best_score = score
            best_idx = idx

    selected_tx = transactions[best_idx] if transactions else None

    # 해당 1행 분리 크롭 이미지 생성
    cropped_b64 = None
    if selected_tx and header_row:
        try:
            hy = int(header_row['y'])
            ty = int(selected_tx['y'])
            h_box = (0, max(0, hy - 8), pil_img.width, min(pil_img.height, hy + 20))
            t_box = (0, max(0, ty - 6), pil_img.width, min(pil_img.height, ty + 20))
            h_part = pil_img.crop(h_box)
            t_part = pil_img.crop(t_box)
            combined = Image.new('RGB', (pil_img.width, h_part.height + t_part.height), (255, 255, 255))
            combined.paste(h_part, (0, 0))
            combined.paste(t_part, (0, h_part.height))
            
            buf = io.BytesIO()
            combined.save(buf, format="PNG")
            cropped_b64 = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("utf-8")
        except Exception as e:
            print("Card crop error:", e)

    return {
        'transactions': transactions,
        'selected_index': best_idx,
        'selected_tx': selected_tx,
        'cropped_b64': cropped_b64
    }
