import os
import re
import pandas as pd
from PIL import Image, ImageDraw, ImageFont

def parse_card_excel(excel_path: str, target_merchant: str = None, target_amount: int = None) -> dict:
    """
    카드 지출내역서 엑셀 파일을 읽고 주요 정보를 추출합니다.
    """
    try:
        # sheet_name=None으로 모든 시트 탐색 또는 첫 시트 읽기
        df = pd.read_excel(excel_path)
    except Exception as e:
        try:
            df = pd.read_csv(excel_path, encoding='utf-8')
        except Exception:
            df = pd.read_csv(excel_path, encoding='cp949')

    # 데이터프레임의 첫 몇 행이 헤더가 아닐 수 있으므로 탐색
    # 결제일시/이용일시/승인일자, 이용금액/승인금액, 가맹점명/이용가맹점 등의 컬럼명 탐색
    columns = [str(c).strip() for c in df.columns]
    
    date_col = None
    amt_col = None
    merchant_col = None
    
    for c in df.columns:
        sc = str(c).replace(" ", "")
        if any(k in sc for k in ["일시", "일자", "승인일", "이용일", "결제일"]):
            if not date_col:
                date_col = c
        if any(k in sc for k in ["금액", "승인액", "이용금액", "청구금액", "공급가액"]):
            if not amt_col:
                amt_col = c
        if any(k in sc for k in ["가맹점", "가맹점명", "상호", "이용처", "사용처"]):
            if not merchant_col:
                merchant_col = c

    records = []
    # 데이터 행 추출
    for idx, row in df.iterrows():
        # 빈 행 무시
        if row.isna().all():
            continue
            
        r_date = str(row[date_col]).strip() if date_col and pd.notna(row[date_col]) else ""
        r_amt = str(row[amt_col]).strip() if amt_col and pd.notna(row[amt_col]) else ""
        r_merchant = str(row[merchant_col]).strip() if merchant_col and pd.notna(row[merchant_col]) else ""
        
        # 금액에서 숫자만 추출
        clean_amt = 0
        try:
            clean_amt = int(float(str(r_amt).replace(",", "").replace("원", "")))
        except Exception:
            pass
            
        # 일시에서 날짜(YYYY-MM-DD)와 시간(HH:MM) 분리
        p_date = None
        p_time = None
        s_start = None
        if r_date:
            d_match = re.search(r'(20\d{2})[-./년\s]+(0?[1-9]|1[0-2])[-./월\s]+(0?[1-9]|[12]\d|3[01])', str(r_date))
            if d_match:
                y, m, d = d_match.groups()
                p_date = f"{y}-{int(m):02d}-{int(d):02d}"
            t_match = re.search(r'([01]?\d|2[0-3])[:시\s]+([0-5]\d)', str(r_date))
            if t_match:
                h, m = t_match.groups()
                p_time = f"{int(h):02d}:{int(m):02d}"
                try:
                    h_int, m_int = int(h), int(m)
                    tot = h_int * 60 + m_int - 105
                    if tot < 0: tot += 24 * 60
                    sh, sm = tot // 60, (tot % 60 // 10) * 10
                    s_start = f"{sh:02d}:{sm:02d}"
                except Exception:
                    pass

        records.append({
            "index": idx,
            "date": r_date,
            "parsed_date": p_date,
            "parsed_time": p_time,
            "suggested_start_time": s_start,
            "amount": clean_amt,
            "amount_str": f"{clean_amt:,}" if clean_amt else r_amt,
            "merchant": r_merchant,
            "raw": {str(k): str(v) for k, v in row.items() if pd.notna(v)}
        })

    # 대표 항목 스마트 매칭 (가맹점명 또는 금액 일치도 우선 탐색)
    primary = None
    best_idx = 0
    best_score = -1

    clean_target_m = (target_merchant or "").replace(" ", "").lower()

    for idx, r in enumerate(records):
        score = 0
        r_m = (r["merchant"] or "").replace(" ", "").lower()
        
        # 가맹점명 일치 검사
        if clean_target_m and r_m:
            if clean_target_m in r_m or r_m in clean_target_m:
                score += 50
            # 단어 단위 부분 일치
            for part in clean_target_m.split():
                if len(part) >= 2 and part in r_m:
                    score += 20

        # 금액 일치 검사
        if target_amount and r["amount"] == target_amount:
            score += 40

        # 기본 금액 존재 시 소량 가점
        if r["amount"] > 0:
            score += 1

        if score > best_score:
            best_score = score
            best_idx = idx

    if records:
        primary = records[best_idx]

    return {
        "columns": [str(c) for c in df.columns],
        "records": records[:50],
        "total_count": len(records),
        "primary": primary,
        "selected_index": best_idx if records else 0
    }

def render_excel_table_image(excel_path: str, output_img_path: str, selected_idx: int = None, only_selected_row: bool = False) -> str:
    """
    엑셀 내용을 깔끔한 표 이미지(PNG)로 렌더링합니다.
    - only_selected_row=True인 경우 해당 가맹점 행만 정밀 추출하여 렌더링
    - only_selected_row=False인 경우 해당 행을 눈에 띄게 하이라이트(노란색) 처리
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    
    # 맑은 고딕 설정
    plt.rcParams['font.sans-serif'] = ['Malgun Gothic', 'NanumGothic', 'sans-serif']
    plt.rcParams['axes.unicode_minus'] = False
    
    try:
        df = pd.read_excel(excel_path)
    except Exception:
        df = pd.read_csv(excel_path, encoding='cp949', errors='ignore')

    df_clean = df.dropna(how='all')
    
    if only_selected_row and selected_idx is not None and 0 <= selected_idx < len(df_clean):
        # 해당 가맹점 거래 1건만 단독 추출하여 렌더링
        df_sub = df_clean.iloc[[selected_idx], :7].fillna("")
        title_text = "[카드 지출내역서 - 해당 거래 내역]"
    else:
        # 전체 목록(최대 12행) 렌더링
        df_sub = df_clean.iloc[:12, :7].fillna("")
        title_text = "[카드 지출내역서]"

    fig, ax = plt.subplots(figsize=(8.5, max(2.5, len(df_sub) * 0.45 + 1.2)), dpi=200)
    ax.axis('off')
    
    table_data = [list(df_sub.columns)] + df_sub.values.tolist()
    table = ax.table(
        cellText=table_data,
        loc='center',
        cellLoc='center'
    )
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(1, 1.45)
    
    # 셀 스타일링 및 선택된 행 하이라이트
    for (row, col), cell in table.get_celld().items():
        if row == 0:
            # 헤더
            cell.set_facecolor('#2D3748')
            cell.get_text().set_color('white')
            cell.get_text().set_weight('bold')
        else:
            # 데이터 행
            data_row_idx = row - 1
            is_target = False
            if only_selected_row:
                is_target = True
            elif selected_idx is not None and data_row_idx == selected_idx:
                is_target = True

            if is_target:
                # 선택된 가맹점 거래행 하이라이트 (노란색 강조)
                cell.set_facecolor('#FEF08A')
                cell.get_text().set_weight('bold')
                cell.set_edgecolor('#CA8A04')
            elif row % 2 == 1:
                cell.set_facecolor('#F8FAFC')
                cell.set_edgecolor('#CBD5E1')
            else:
                cell.set_facecolor('#FFFFFF')
                cell.set_edgecolor('#CBD5E1')

    plt.title(title_text, fontsize=12, fontweight='bold', pad=12, color='#1E293B')
    plt.tight_layout()
    plt.savefig(output_img_path, bbox_inches='tight', dpi=200)
    plt.close()
    
    return output_img_path
