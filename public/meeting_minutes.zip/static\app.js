// Global State
let projects = [];
let selectedProjectId = null;
let attendees = [];

let receiptImageBase64 = null;
let cardImageBase64 = null;
let cardImageFilename = null;
let excelParsedData = null;
let lastGeneratedFilename = null;

let receiptOcrData = null;
let cardOcrData = null;

// Initialize
document.addEventListener("DOMContentLoaded", async () => {
  // Set default date to today
  const today = new Date().toISOString().split("T")[0];
  const dateInput = document.getElementById("meetingDate");
  if (!dateInput.value) {
    dateInput.value = today;
  }

  // Setup event listeners
  setupDateTimeListeners();
  setupPasteListeners();
  setupDropzones();

  // Load Projects from server
  await loadProjects();
  loadDocumentsList();

  // Check draft or initialize first project
  const hasDraft = loadDraft();
  if (!hasDraft && projects.length > 0) {
    onProjectSelectChange(projects[0].id);
  } else {
    renderAttendees();
    updatePreview();
  }
});

// ==========================================
// 1. 과제 관리 (Projects Management)
// ==========================================
async function loadProjects() {
  try {
    const res = await fetch("/api/projects");
    const data = await res.json();
    if (data.success && data.projects) {
      projects = data.projects;
      renderProjectSelect();
    }
  } catch (err) {
    console.error("과제 목록 로드 실패:", err);
  }
}

function renderProjectSelect() {
  const select = document.getElementById("projectSelect");
  select.innerHTML = "";

  if (projects.length === 0) {
    const opt = document.createElement("option");
    opt.value = "";
    opt.textContent = "등록된 과제가 없습니다 (과제 등록 필요)";
    select.appendChild(opt);
    return;
  }

  projects.forEach((p) => {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = `📁 ${p.name}`;
    select.appendChild(opt);
  });

  if (selectedProjectId && projects.some(p => p.id === selectedProjectId)) {
    select.value = selectedProjectId;
  } else if (projects.length > 0) {
    selectedProjectId = projects[0].id;
    select.value = selectedProjectId;
  }
}

function onProjectSelectChange(forcedPid = null) {
  const select = document.getElementById("projectSelect");
  const pid = forcedPid || select.value;
  if (!pid) return;

  const proj = projects.find(p => p.id === pid);
  if (!proj) return;

  selectedProjectId = proj.id;
  select.value = proj.id;
  document.getElementById("projectName").value = proj.name;

  if (proj.default_place_meeting) {
    document.getElementById("placeMeeting").value = proj.default_place_meeting;
  }
  if (proj.default_place_meal) {
    document.getElementById("placeMeal").value = proj.default_place_meal;
  }

  if (proj.default_author) {
    document.getElementById("authorDept").value = proj.default_author.dept || "";
    document.getElementById("authorPos").value = proj.default_author.pos || "";
    document.getElementById("authorName").value = proj.default_author.name || "";
  }

  // Load project's attendees
  if (proj.attendees && Array.isArray(proj.attendees) && proj.attendees.length > 0) {
    attendees = JSON.parse(JSON.stringify(proj.attendees));
  } else {
    attendees = [];
  }

  renderAttendees();
  updatePreview();
}

function selectProjectForMeeting(pid) {
  const proj = projects.find(p => p.id === pid);
  if (!proj) return;

  onProjectSelectChange(pid);
  closeProjectModal();
  
  const count = (proj.attendees && Array.isArray(proj.attendees)) ? proj.attendees.length : 0;
  alert(`📁 [${proj.name}]\n과제와 기본 참석자 명부(${count}명)가 회의록 폼에 성공적으로 적용되었습니다!`);
}

async function saveCurrentAttendeesToProject() {
  if (!selectedProjectId) {
    alert("먼저 과제를 선택해주세요.");
    return;
  }

  const proj = projects.find(p => p.id === selectedProjectId);
  const projName = proj ? proj.name : "선택된 과제";

  if (!confirm(`현재 참석자 명부(${attendees.length}명)를\n[${projName}]의 '기본 참석자 풀'로 저장하시겠습니까?`)) {
    return;
  }

  try {
    const res = await fetch(`/api/projects/${selectedProjectId}/attendees`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ attendees: attendees })
    });
    const data = await res.json();
    if (data.success) {
      if (proj) proj.attendees = JSON.parse(JSON.stringify(attendees));
      alert("✅ 해당 과제의 기본 참석자 명부가 영구 저장되었습니다!");
    } else {
      alert("저장 실패: " + (data.detail || "오류 발생"));
    }
  } catch (err) {
    alert("서버 통신 오류: " + err.message);
  }
}

// Project Modal Logic
function openProjectModal() {
  renderProjectListInModal();
  // If current project exists, load it into the form for inspection
  const curProj = projects.find(p => p.id === selectedProjectId);
  initProjectForm(curProj || null);
  document.getElementById("projectModal").classList.remove("hidden");
}

function closeProjectModal() {
  document.getElementById("projectModal").classList.add("hidden");
}

function renderProjectListInModal() {
  const container = document.getElementById("projectListContainer");
  container.innerHTML = "";

  if (projects.length === 0) {
    container.innerHTML = `<div class="p-4 text-center text-xs text-slate-400 bg-slate-50 rounded-xl">등록된 과제가 없습니다.</div>`;
    return;
  }

  projects.forEach(p => {
    const isSelected = p.id === selectedProjectId;
    const card = document.createElement("div");
    card.className = `p-3 rounded-xl border text-xs transition cursor-pointer ${
      isSelected ? "border-indigo-500 bg-indigo-50/50 shadow-sm" : "border-slate-200 bg-white hover:border-indigo-300"
    }`;

    const attendeeCount = (p.attendees && Array.isArray(p.attendees)) ? p.attendees.length : 0;
    const authorStr = p.default_author && p.default_author.name ? `${p.default_author.name} (${p.default_author.dept || '부서미지정'})` : "-";

    card.innerHTML = `
      <div class="flex items-start justify-between gap-2 mb-1.5" onclick="editProjectInModal('${p.id}')">
        <strong class="font-bold text-slate-800 text-[13px] leading-tight break-all">${p.name}</strong>
        ${isSelected ? '<span class="px-1.5 py-0.5 bg-indigo-600 text-white text-[10px] font-bold rounded flex-shrink-0">현재선택</span>' : ''}
      </div>
      <div class="text-[11px] text-slate-500 space-y-0.5" onclick="editProjectInModal('${p.id}')">
        <div>👥 등록된 참석자: <span class="font-bold text-indigo-700">${attendeeCount}명</span></div>
        <div>✍ 기본 작성자: <span class="text-slate-700">${authorStr}</span></div>
      </div>
      <div class="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between gap-1.5">
        <button type="button" onclick="selectProjectForMeeting('${p.id}')" class="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded font-bold text-[11px] shadow-sm transition flex items-center gap-1">
          <i class="fa-solid fa-check"></i> 이 과제 선택
        </button>
        <div class="flex items-center gap-1">
          <button type="button" onclick="editProjectInModal('${p.id}')" class="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold text-[11px] transition">
            수정/보기
          </button>
          <button type="button" onclick="deleteProject('${p.id}')" class="px-2 py-1 bg-red-50 hover:bg-red-100 text-red-600 rounded font-semibold text-[11px] transition">
            삭제
          </button>
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

function initProjectForm(proj = null) {
  const formTitle = document.getElementById("projectFormTitle");
  const formMode = document.getElementById("projectFormMode");
  const btnText = document.getElementById("modalSubmitBtnText");
  const editIdInput = document.getElementById("editingProjectId");

  const nameInput = document.getElementById("modalProjectName");
  const mPlaceInput = document.getElementById("modalMeetingPlace");
  const mealPlaceInput = document.getElementById("modalMealPlace");
  const aDeptInput = document.getElementById("modalAuthorDept");
  const aPosInput = document.getElementById("modalAuthorPos");
  const aNameInput = document.getElementById("modalAuthorName");
  const tbody = document.getElementById("modalAttendeeTableBody");

  tbody.innerHTML = "";

  if (proj) {
    formTitle.innerHTML = `<i class="fa-solid fa-pen-to-square text-indigo-600"></i> 과제 정보 및 참석자 풀 수정`;
    formMode.textContent = "수정/조회 모드";
    formMode.className = "text-[10px] px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full font-bold";
    btnText.textContent = "과제 변경사항 저장";
    editIdInput.value = proj.id;

    nameInput.value = proj.name || "";
    mPlaceInput.value = proj.default_place_meeting || "";
    mealPlaceInput.value = proj.default_place_meal || "";

    const a = proj.default_author || {};
    aDeptInput.value = a.dept || "";
    aPosInput.value = a.pos || "";
    aNameInput.value = a.name || "";

    if (proj.attendees && Array.isArray(proj.attendees) && proj.attendees.length > 0) {
      proj.attendees.forEach(att => addModalAttendeeRow(att.dept, att.pos, att.name));
    }
  } else {
    formTitle.innerHTML = `<i class="fa-solid fa-plus text-indigo-600"></i> 신규 과제 등록`;
    formMode.textContent = "신규 등록";
    formMode.className = "text-[10px] px-2 py-0.5 bg-indigo-100 text-indigo-700 rounded-full font-bold";
    btnText.textContent = "과제 등록하기";
    editIdInput.value = "";

    nameInput.value = "";
    mPlaceInput.value = "동서대 NM관 세미나실";
    mealPlaceInput.value = "";
    aDeptInput.value = "사업단";
    aPosInput.value = "연구원";
    aNameInput.value = "";

    // Default template rows
    addModalAttendeeRow("동서대학교", "교수", "");
    addModalAttendeeRow("동서대학교", "연구원", "");
    addModalAttendeeRow("㈜협력기업", "이사", "");
  }

  updateModalAttendeeCount();
}

function editProjectInModal(pid) {
  const proj = projects.find(p => p.id === pid);
  if (proj) {
    initProjectForm(proj);
  }
}

function addModalAttendeeRow(dept = "", pos = "", name = "") {
  const tbody = document.getElementById("modalAttendeeTableBody");
  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td class="p-1">
      <input type="text" value="${dept || ''}" placeholder="소속" class="w-full px-1.5 py-1 text-xs border border-slate-200 rounded outline-none modal-att-dept">
    </td>
    <td class="p-1">
      <input type="text" value="${pos || ''}" placeholder="직위" class="w-full px-1.5 py-1 text-xs border border-slate-200 rounded outline-none modal-att-pos">
    </td>
    <td class="p-1">
      <input type="text" value="${name || ''}" placeholder="성명" class="w-full px-1.5 py-1 text-xs border border-slate-200 rounded outline-none font-medium modal-att-name">
    </td>
    <td class="p-1 text-center">
      <button type="button" onclick="this.closest('tr').remove(); updateModalAttendeeCount();" class="text-slate-400 hover:text-red-500 p-1">
        <i class="fa-solid fa-trash-can"></i>
      </button>
    </td>
  `;
  tbody.appendChild(tr);
  updateModalAttendeeCount();
}

function updateModalAttendeeCount() {
  const rows = document.querySelectorAll("#modalAttendeeTableBody tr");
  document.getElementById("modalAttendeeCount").textContent = rows.length;
}

function getModalAttendees() {
  const rows = document.querySelectorAll("#modalAttendeeTableBody tr");
  const list = [];
  rows.forEach(r => {
    const dept = r.querySelector(".modal-att-dept").value.trim();
    const pos = r.querySelector(".modal-att-pos").value.trim();
    const name = r.querySelector(".modal-att-name").value.trim();
    if (dept || pos || name) {
      list.push({ dept, pos, name });
    }
  });
  return list;
}

async function saveProjectFromModal() {
  const editId = document.getElementById("editingProjectId").value;
  const name = document.getElementById("modalProjectName").value.trim();

  if (!name) {
    alert("과제명을 입력해주세요.");
    document.getElementById("modalProjectName").focus();
    return;
  }

  const payload = {
    name: name,
    default_place_meeting: document.getElementById("modalMeetingPlace").value.trim(),
    default_place_meal: document.getElementById("modalMealPlace").value.trim(),
    default_author: {
      dept: document.getElementById("modalAuthorDept").value.trim(),
      pos: document.getElementById("modalAuthorPos").value.trim(),
      name: document.getElementById("modalAuthorName").value.trim()
    },
    attendees: getModalAttendees()
  };

  try {
    let url = "/api/projects";
    let method = "POST";
    if (editId) {
      url = `/api/projects/${editId}`;
      method = "PUT";
    }

    const res = await fetch(url, {
      method: method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();

    if (data.success) {
      const targetId = editId || (data.project ? data.project.id : selectedProjectId);
      alert(editId ? "과제 정보가 수정되었습니다." : "새 과제가 등록되었습니다.");
      await loadProjects();
      selectedProjectId = targetId;
      renderProjectSelect();
      renderProjectListInModal();
      onProjectSelectChange(targetId);
      closeProjectModal();
    } else {
      alert("저장 실패: " + (data.detail || "알 수 없는 오류"));
    }
  } catch (err) {
    alert("서버 통신 실패: " + err.message);
  }
}

async function deleteProject(pid) {
  const proj = projects.find(p => p.id === pid);
  const name = proj ? proj.name : "이 과제";

  if (!confirm(`정말 [${name}] 과제를 삭제하시겠습니까?`)) {
    return;
  }

  try {
    const res = await fetch(`/api/projects/${pid}`, { method: "DELETE" });
    const data = await res.json();
    if (data.success) {
      alert("과제가 삭제되었습니다.");
      if (selectedProjectId === pid) {
        selectedProjectId = null;
      }
      await loadProjects();
      renderProjectListInModal();
      initProjectForm();
      if (projects.length > 0) {
        onProjectSelectChange(projects[0].id);
      }
    } else {
      alert("삭제 실패: " + (data.detail || "오류"));
    }
  } catch (err) {
    alert("오류: " + err.message);
  }
}

// ==========================================
// 2. 일시 및 장소 실시간 미리보기
// ==========================================
function setupDateTimeListeners() {
  const dateInput = document.getElementById("meetingDate");
  const startInput = document.getElementById("startTime");
  const endInput = document.getElementById("endTime");
  const placeM = document.getElementById("placeMeeting");
  const placeE = document.getElementById("placeMeal");

  [dateInput, startInput, endInput, placeM, placeE].forEach(el => {
    el.addEventListener("input", updatePreview);
  });
}

function updatePreview() {
  const dateVal = document.getElementById("meetingDate").value;
  const startVal = document.getElementById("startTime").value;
  const endVal = document.getElementById("endTime").value;

  if (dateVal) {
    const d = new Date(dateVal);
    const weekdays = ["일", "월", "화", "수", "목", "금", "토"];
    const w = weekdays[d.getDay()];
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");

    const dtStr = `${y}.${m}.${day}.(${w}) ${startVal || "00:00"}~${endVal || "00:00"}`;
    document.getElementById("previewDateTime").textContent = dtStr;
  } else {
    document.getElementById("previewDateTime").textContent = "-";
  }

  const placeM = document.getElementById("placeMeeting").value.trim() || "회의장소";
  const placeE = document.getElementById("placeMeal").value.trim() || "식사장소";
  document.getElementById("previewPlace").textContent = `${placeM} / ${placeE}`;
}

// ==========================================
// 3. 참석자 명부 및 작성자 선택
// ==========================================
function renderAttendees() {
  const tbody = document.getElementById("attendeeTableBody");
  tbody.innerHTML = "";

  attendees.forEach((att, idx) => {
    const tr = document.createElement("tr");
    tr.className = "hover:bg-slate-50 transition";
    tr.innerHTML = `
      <td class="p-2 text-center text-slate-400 font-mono">${idx + 1}</td>
      <td class="p-2">
        <input type="text" value="${att.dept || ''}" placeholder="소속"
          onchange="updateAttendee(${idx}, 'dept', this.value)"
          class="w-full px-2 py-1 text-xs rounded border border-slate-200 focus:border-blue-500 outline-none bg-white">
      </td>
      <td class="p-2">
        <input type="text" value="${att.pos || ''}" placeholder="직위"
          onchange="updateAttendee(${idx}, 'pos', this.value)"
          class="w-full px-2 py-1 text-xs rounded border border-slate-200 focus:border-blue-500 outline-none bg-white">
      </td>
      <td class="p-2">
        <input type="text" value="${att.name || ''}" placeholder="성명"
          onchange="updateAttendee(${idx}, 'name', this.value)"
          class="w-full px-2 py-1 text-xs rounded border border-slate-200 focus:border-blue-500 outline-none bg-white font-medium">
      </td>
      <td class="p-2 text-center">
        <button type="button" onclick="removeAttendee(${idx})" class="text-slate-400 hover:text-red-500 transition p-1">
          <i class="fa-solid fa-trash-can"></i>
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  document.getElementById("attendeeCountBadge").textContent = `${attendees.length}명`;
  updateAuthorDropdown();
}

function addAttendee(dept = "", pos = "", name = "") {
  if (attendees.length >= 20) {
    alert("참석자 명부 양식은 최대 20명까지 기재 가능합니다.");
    return;
  }
  attendees.push({ dept, pos, name });
  renderAttendees();
}

function updateAttendee(idx, field, value) {
  if (attendees[idx]) {
    attendees[idx][field] = value.trim();
    updateAuthorDropdown();
  }
}

function removeAttendee(idx) {
  attendees.splice(idx, 1);
  renderAttendees();
}

function updateAuthorDropdown() {
  const select = document.getElementById("authorFromAttendeeSelect");
  if (!select) return;

  const currentVal = select.value;
  select.innerHTML = '<option value="">-- 직접 입력 --</option>';

  attendees.forEach((att, idx) => {
    if (att.name) {
      const opt = document.createElement("option");
      opt.value = String(idx);
      opt.textContent = `${att.name} (${att.dept || '소속미지정'} / ${att.pos || '직급미지정'})`;
      select.appendChild(opt);
    }
  });

  if (currentVal && select.querySelector(`option[value="${currentVal}"]`)) {
    select.value = currentVal;
  }
}

function onSelectAuthorFromAttendee(idxStr) {
  if (idxStr === "") return;
  const idx = parseInt(idxStr);
  if (attendees[idx]) {
    const a = attendees[idx];
    if (a.dept) document.getElementById("authorDept").value = a.dept;
    if (a.pos) document.getElementById("authorPos").value = a.pos;
    if (a.name) document.getElementById("authorName").value = a.name;
  }
}

// ==========================================
// 4. 영수증 & 카드 붙여넣기 및 스마트 OCR
// ==========================================
function setupPasteListeners() {
  const receiptDz = document.getElementById("receiptDropzone");
  const cardDz = document.getElementById("cardDropzone");

  receiptDz.addEventListener("paste", (e) => {
    handlePasteImage(e, (base64) => setReceiptImage(base64));
  });

  cardDz.addEventListener("paste", (e) => {
    handlePasteImage(e, (base64) => setCardImage(base64));
  });

  window.addEventListener("paste", (e) => {
    const hasImage = Array.from(e.clipboardData.items).some(x => x.type.indexOf("image") !== -1);
    if (!hasImage) return;

    if (document.activeElement === cardDz) {
      handlePasteImage(e, setCardImage);
    } else {
      handlePasteImage(e, setReceiptImage);
    }
  });
}

function handlePasteImage(e, callback) {
  const items = (e.clipboardData || e.originalEvent.clipboardData).items;
  for (let i = 0; i < items.length; i++) {
    if (items[i].type.indexOf("image") !== -1) {
      const blob = items[i].getAsFile();
      const reader = new FileReader();
      reader.onload = (event) => {
        callback(event.target.result);
      };
      reader.readAsDataURL(blob);
      e.preventDefault();
      break;
    }
  }
}

function setupDropzones() {
  const rDz = document.getElementById("receiptDropzone");
  const rInput = document.getElementById("receiptFileInput");
  rDz.addEventListener("click", (e) => {
    if (e.target.closest("button")) return;
    rInput.click();
  });
  rInput.addEventListener("change", (e) => {
    if (e.target.files && e.target.files[0]) {
      readFileAsBase64(e.target.files[0], setReceiptImage);
    }
  });

  const cDz = document.getElementById("cardDropzone");
  const cInput = document.getElementById("cardFileInput");
  cDz.addEventListener("click", (e) => {
    if (e.target.closest("button")) return;
    cInput.click();
  });
  cInput.addEventListener("change", (e) => {
    if (e.target.files && e.target.files[0]) {
      readFileAsBase64(e.target.files[0], setCardImage);
    }
  });

  const eDz = document.getElementById("excelDropzone");
  const eInput = document.getElementById("excelFileInput");
  eDz.addEventListener("click", (e) => {
    if (e.target.closest("button")) return;
    eInput.click();
  });
  eInput.addEventListener("change", (e) => {
    if (e.target.files && e.target.files[0]) {
      handleExcelUpload(e.target.files[0]);
    }
  });

  [rDz, cDz, eDz].forEach(dz => {
    dz.addEventListener("dragover", (e) => {
      e.preventDefault();
      dz.classList.add("dragover");
    });
    dz.addEventListener("dragleave", () => {
      dz.classList.remove("dragover");
    });
    dz.addEventListener("drop", (e) => {
      e.preventDefault();
      dz.classList.remove("dragover");
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        const file = e.dataTransfer.files[0];
        if (dz === rDz) {
          readFileAsBase64(file, setReceiptImage);
        } else if (dz === cDz) {
          readFileAsBase64(file, setCardImage);
        } else if (dz === eDz) {
          handleExcelUpload(file);
        }
      }
    });
  });
}

function readFileAsBase64(file, callback) {
  const reader = new FileReader();
  reader.onload = (e) => callback(e.target.result);
  reader.readAsDataURL(file);
}

function setReceiptImage(base64) {
  receiptImageBase64 = base64;
  document.getElementById("receiptPrompt").classList.add("hidden");
  document.getElementById("receiptPreviewContainer").classList.remove("hidden");
  document.getElementById("receiptPreviewImg").src = base64;

  // Run Smart OCR
  runReceiptOcr(base64);
}

function removeReceiptImage(e) {
  if (e) e.stopPropagation();
  receiptImageBase64 = null;
  receiptOcrData = null;
  document.getElementById("receiptPrompt").classList.remove("hidden");
  document.getElementById("receiptPreviewContainer").classList.add("hidden");
  document.getElementById("receiptPreviewImg").src = "";
  document.getElementById("receiptFileInput").value = "";
  document.getElementById("receiptOcrLoading").classList.add("hidden");
  document.getElementById("receiptOcrResultBox").classList.add("hidden");
}

function setCardImage(base64) {
  cardImageBase64 = base64;
  cardImageFilename = null;
  document.getElementById("cardPrompt").classList.add("hidden");
  document.getElementById("cardPreviewContainer").classList.remove("hidden");
  document.getElementById("cardPreviewImg").src = base64;

  // Run Smart OCR
  runCardOcr(base64);
}

function removeCardImage(e) {
  if (e) e.stopPropagation();
  cardImageBase64 = null;
  cardImageFilename = null;
  cardOcrData = null;
  cardTransactions = [];
  cardOriginalImageBase64 = null;
  cardCroppedImageBase64 = null;
  document.getElementById("cardPrompt").classList.remove("hidden");
  document.getElementById("cardPreviewContainer").classList.add("hidden");
  document.getElementById("cardPreviewImg").src = "";
  document.getElementById("cardFileInput").value = "";
  document.getElementById("cardOcrLoading").classList.add("hidden");
  document.getElementById("cardOcrResultBox").classList.add("hidden");
  const multiBox = document.getElementById("cardMultiRowsBox");
  if (multiBox) multiBox.classList.add("hidden");
  const croppedBox = document.getElementById("cardCroppedPreviewBox");
  if (croppedBox) croppedBox.classList.add("hidden");
}

// Smart OCR Execution
async function runReceiptOcr(base64) {
  const loading = document.getElementById("receiptOcrLoading");
  const resultBox = document.getElementById("receiptOcrResultBox");
  const summaryBox = document.getElementById("receiptOcrSummary");

  loading.classList.remove("hidden");
  resultBox.classList.add("hidden");

  try {
    const res = await fetch("/api/ocr-receipt", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image_base64: base64 })
    });
    const data = await res.json();
    loading.classList.add("hidden");

    if (data.success && (data.date || data.time || data.merchant || data.amount != null || data.amount_str)) {
      receiptOcrData = data;
      const amtStr = data.amount_str || (data.amount != null ? Number(data.amount).toLocaleString() : null);
      summaryBox.innerHTML = `
        ${data.date ? `<div>📅 일자: <strong>${data.date}</strong></div>` : ""}
        ${data.time ? `<div>🕒 승인시간: <strong>${data.time}</strong> (추천 시작: ${data.suggested_start_time || '-'})</div>` : ""}
        ${data.merchant ? `<div>🍽 식사장소(가맹점): <strong>${data.merchant}</strong></div>` : ""}
        ${amtStr ? `<div>💰 결제금액: <strong>${amtStr}원</strong></div>` : ""}
      `;
      resultBox.classList.remove("hidden");

      // 카드가 이미 업로드되어 있다면 영수증 정보 기반으로 카드 거래 자동 재매칭
      if (cardOriginalImageBase64) {
        runCardOcr(cardOriginalImageBase64);
      }
    }
  } catch (err) {
    loading.classList.add("hidden");
    console.warn("영수증 OCR 분석 실패:", err);
  }
}

function applyReceiptOcrData() {
  if (!receiptOcrData) {
    alert("인식된 영수증 데이터가 없습니다.");
    return;
  }

  let appliedMsg = [];
  if (receiptOcrData.date) {
    document.getElementById("meetingDate").value = receiptOcrData.date;
    appliedMsg.push(`회의일자: ${receiptOcrData.date}`);
  }
  if (receiptOcrData.time) {
    document.getElementById("endTime").value = receiptOcrData.time;
    appliedMsg.push(`종료시간: ${receiptOcrData.time}`);
  }
  if (receiptOcrData.suggested_start_time) {
    document.getElementById("startTime").value = receiptOcrData.suggested_start_time;
    appliedMsg.push(`시작시간: ${receiptOcrData.suggested_start_time}`);
  }
  if (receiptOcrData.merchant) {
    document.getElementById("placeMeal").value = receiptOcrData.merchant;
    appliedMsg.push(`식사장소: ${receiptOcrData.merchant}`);
  }
  
  // Safe amount handling (prevents NaN)
  const rawAmt = receiptOcrData.amount != null ? String(receiptOcrData.amount) : (receiptOcrData.amount_str || "");
  const cleanAmtStr = rawAmt.replace(/[^0-9]/g, "");
  if (cleanAmtStr) {
    const val = parseInt(cleanAmtStr, 10);
    if (!isNaN(val) && val > 0) {
      document.getElementById("totalAmount").value = val.toLocaleString();
      appliedMsg.push(`금액: ${val.toLocaleString()}원`);
    }
  }

  updatePreview();

  // 만약 카드 이미지가 이미 있는 경우 새로운 영수증 정보로 카드 재매칭
  if (cardOriginalImageBase64) {
    runCardOcr(cardOriginalImageBase64);
  }

  alert(`✨ 영수증 인식 정보가 회의록에 자동 반영되었습니다!\n\n` + appliedMsg.join("\n"));
}

let cardTransactions = [];
let selectedCardTxIndex = 0;
let cardOriginalImageBase64 = null;
let cardCroppedImageBase64 = null;

async function runCardOcr(base64) {
  cardOriginalImageBase64 = base64;
  const loading = document.getElementById("cardOcrLoading");
  const resultBox = document.getElementById("cardOcrResultBox");
  const summaryBox = document.getElementById("cardOcrSummary");
  const multiBox = document.getElementById("cardMultiRowsBox");
  const txSelect = document.getElementById("cardTxSelect");
  const croppedPreviewBox = document.getElementById("cardCroppedPreviewBox");
  const croppedImg = document.getElementById("cardCroppedImg");

  loading.classList.remove("hidden");
  resultBox.classList.add("hidden");
  if (multiBox) multiBox.classList.add("hidden");
  if (croppedPreviewBox) croppedPreviewBox.classList.add("hidden");

  // 영수증에서 인식된 일자, 금액, 식사장소를 스마트 매칭 힌트로 전달
  let tDate = (receiptOcrData && receiptOcrData.date) ? receiptOcrData.date : document.getElementById("meetingDate").value || null;
  let tAmt = (receiptOcrData && receiptOcrData.amount != null) ? receiptOcrData.amount : null;
  if (!tAmt) {
    const rawFormAmt = document.getElementById("totalAmount").value.replace(/[^0-9]/g, "");
    if (rawFormAmt) tAmt = parseInt(rawFormAmt, 10);
  }
  let tMerch = (receiptOcrData && receiptOcrData.merchant) ? receiptOcrData.merchant : (document.getElementById("placeMeal").value.trim() || null);

  try {
    const res = await fetch("/api/ocr-receipt", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        image_base64: base64,
        is_card: true,
        target_date: tDate,
        target_amount: tAmt,
        target_merchant: tMerch
      })
    });
    const data = await res.json();
    loading.classList.add("hidden");

    if (data.success) {
      cardOcrData = data;
      cardTransactions = data.transactions || [];
      selectedCardTxIndex = data.selected_index || 0;

      // 크롭된 표 이미지가 있으면 우선 서식 첨부용으로 적용
      if (data.cropped_image) {
        cardCroppedImageBase64 = data.cropped_image;
        cardImageBase64 = data.cropped_image;
        if (croppedImg && croppedPreviewBox) {
          croppedImg.src = data.cropped_image;
          croppedPreviewBox.classList.remove("hidden");
        }
      } else {
        cardImageBase64 = base64;
      }

      const amtStr = data.amount_str || (data.amount != null ? Number(data.amount).toLocaleString() : null);
      summaryBox.innerHTML = `
        ${data.date ? `<div>📅 일자: <strong>${data.date}</strong></div>` : ""}
        ${data.merchant ? `<div>🍽 식사장소(가맹점): <strong>${data.merchant}</strong></div>` : ""}
        ${amtStr ? `<div>💰 결제금액: <strong>${amtStr}원</strong></div>` : ""}
      `;

      // 여러 건의 거래가 감지된 경우 드롭다운 렌더링
      if (cardTransactions.length > 0 && multiBox && txSelect) {
        document.getElementById("cardTxCount").textContent = cardTransactions.length;
        txSelect.innerHTML = "";
        cardTransactions.forEach((tx, idx) => {
          const opt = document.createElement("option");
          opt.value = idx;
          const matchTag = (idx === selectedCardTxIndex) ? " [★영수증 일치]" : "";
          opt.textContent = `${tx.date} | ${tx.merchant || '가맹점'} | ${tx.amount_str || (tx.amount ? tx.amount.toLocaleString() : '0')}원${matchTag}`;
          if (idx === selectedCardTxIndex) opt.selected = true;
          txSelect.appendChild(opt);
        });
        multiBox.classList.remove("hidden");
      }

      resultBox.classList.remove("hidden");
    }
  } catch (err) {
    loading.classList.add("hidden");
    console.warn("카드 OCR 분석 실패:", err);
  }
}

function onSelectCardTx(idxStr) {
  const idx = parseInt(idxStr, 10);
  if (isNaN(idx) || !cardTransactions[idx]) return;

  selectedCardTxIndex = idx;
  const tx = cardTransactions[idx];
  if (!cardOcrData) cardOcrData = {};
  cardOcrData.date = tx.date;
  cardOcrData.merchant = tx.merchant;
  cardOcrData.amount = tx.amount;
  cardOcrData.amount_str = tx.amount_str;

  const summaryBox = document.getElementById("cardOcrSummary");
  summaryBox.innerHTML = `
    ${tx.date ? `<div>📅 일자: <strong>${tx.date}</strong></div>` : ""}
    ${tx.merchant ? `<div>🍽 식사장소(가맹점): <strong>${tx.merchant}</strong></div>` : ""}
    ${tx.amount_str ? `<div>💰 결제금액: <strong>${tx.amount_str}원</strong></div>` : ""}
  `;
}

function applyCardOcrData() {
  if (!cardOcrData) {
    alert("인식된 카드 데이터가 없습니다.");
    return;
  }

  let appliedMsg = [];
  if (cardOcrData.date) {
    document.getElementById("meetingDate").value = cardOcrData.date;
    appliedMsg.push(`회의일자: ${cardOcrData.date}`);
  }
  if (cardOcrData.time) {
    document.getElementById("endTime").value = cardOcrData.time;
    appliedMsg.push(`종료시간: ${cardOcrData.time}`);
  }
  if (cardOcrData.suggested_start_time) {
    document.getElementById("startTime").value = cardOcrData.suggested_start_time;
    appliedMsg.push(`시작시간: ${cardOcrData.suggested_start_time}`);
  }
  if (cardOcrData.merchant) {
    const isPersonName = ["윤태수", "연구책임자", "책임자", "은의", "월수"].some(k => cardOcrData.merchant.includes(k)) || cardOcrData.merchant.endsWith("수");
    const currentMeal = document.getElementById("placeMeal").value.trim();
    if (!isPersonName && (!currentMeal || currentMeal === "회의장소 / 식사장소")) {
      document.getElementById("placeMeal").value = cardOcrData.merchant;
      appliedMsg.push(`식사장소: ${cardOcrData.merchant}`);
    }
  }

  const rawAmt = cardOcrData.amount != null ? String(cardOcrData.amount) : (cardOcrData.amount_str || "");
  const cleanAmtStr = rawAmt.replace(/[^0-9]/g, "");
  if (cleanAmtStr) {
    const val = parseInt(cleanAmtStr, 10);
    if (!isNaN(val) && val > 0) {
      document.getElementById("totalAmount").value = val.toLocaleString();
      appliedMsg.push(`금액: ${val.toLocaleString()}원`);
    }
  }

  updatePreview();
  alert(`✨ 카드 지출내역 정보가 회의록에 자동 반영되었습니다!\n\n` + appliedMsg.join("\n"));
}

// Tab Switching
function switchCardTab(tab) {
  const imgBtn = document.getElementById("tabCardImgBtn");
  const excelBtn = document.getElementById("tabCardExcelBtn");
  const imgContent = document.getElementById("cardImgTabContent");
  const excelContent = document.getElementById("cardExcelTabContent");

  if (tab === "img") {
    imgBtn.className = "py-2 px-3 border-b-2 border-cyan-600 text-cyan-700 flex items-center gap-1.5";
    excelBtn.className = "py-2 px-3 text-slate-500 hover:text-slate-700 flex items-center gap-1.5";
    imgContent.classList.remove("hidden");
    excelContent.classList.add("hidden");
  } else {
    excelBtn.className = "py-2 px-3 border-b-2 border-emerald-600 text-emerald-700 flex items-center gap-1.5";
    imgBtn.className = "py-2 px-3 text-slate-500 hover:text-slate-700 flex items-center gap-1.5";
    excelContent.classList.remove("hidden");
    imgContent.classList.add("hidden");
  }
}

// ==========================================
// 5. 엑셀 업로드 및 다건 거래 매칭/선택
// ==========================================
async function handleExcelUpload(file) {
  const formData = new FormData();
  formData.append("file", file);

  // 현재 입력된 식사장소나 영수증 가맹점, 금액을 스마트 매칭 인자로 전송
  const targetMeal = document.getElementById("placeMeal").value.trim() || (receiptOcrData ? receiptOcrData.merchant : "");
  const targetAmt = document.getElementById("totalAmount").value.replace(/[^0-9]/g, "");
  if (targetMeal) formData.append("target_merchant", targetMeal);
  if (targetAmt) formData.append("target_amount", targetAmt);

  try {
    document.getElementById("excelPrompt").innerHTML = `
      <div class="py-4 text-center">
        <div class="inline-block w-8 h-8 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
        <p class="text-xs text-emerald-700 mt-2">엑셀 지출내역 분석 및 가맹점 매칭 중...</p>
      </div>
    `;

    const res = await fetch("/api/upload-excel", {
      method: "POST",
      body: formData
    });
    const data = await res.json();

    if (!data.success) {
      alert("엑셀 분석 오류: " + (data.detail || "알 수 없는 오류"));
      return;
    }

    excelParsedData = data;
    cardImageFilename = data.table_image_filename;

    document.getElementById("excelPrompt").classList.add("hidden");
    document.getElementById("excelResultBox").classList.remove("hidden");

    // 다건 거래 목록 구성
    const records = (data.parsed && data.parsed.records) ? data.parsed.records : [];
    const multiBox = document.getElementById("excelMultiRowsBox");
    const txSelect = document.getElementById("excelTxSelect");
    txSelect.innerHTML = "";

    if (records.length > 1) {
      multiBox.classList.remove("hidden");
      document.getElementById("excelTxCount").textContent = records.length;

      records.forEach((r, idx) => {
        const opt = document.createElement("option");
        opt.value = String(r.index !== undefined ? r.index : idx);
        const dt = r.parsed_date || r.date || "일시미상";
        const m = r.merchant || "가맹점미상";
        const amt = r.amount_str || `${r.amount}원`;
        const isMatch = (data.parsed.selected_index === (r.index !== undefined ? r.index : idx));
        opt.textContent = `[${idx + 1}] ${dt} | ${m} | ${amt} ${isMatch ? '⭐ (일치 추천)' : ''}`;
        if (isMatch) opt.selected = true;
        txSelect.appendChild(opt);
      });
    } else {
      multiBox.classList.add("hidden");
    }

    renderExcelSummary();
    document.getElementById("excelTableImg").src = `/uploads/${data.table_image_filename}?t=${Date.now()}`;

  } catch (err) {
    alert("엑셀 업로드 실패: " + err.message);
  }
}

function renderExcelSummary() {
  if (!excelParsedData || !excelParsedData.parsed) return;
  const primary = excelParsedData.parsed.primary;
  let summaryHtml = "";
  if (primary) {
    summaryHtml = `
      <div>📌 <strong>선택된 거래처</strong>: ${primary.merchant || "가맹점명 없음"}</div>
      <div>💰 <strong>금액</strong>: ${primary.amount_str || primary.amount}원</div>
      <div>🕒 <strong>일시</strong>: ${primary.parsed_date || primary.date || "일시 없음"} ${primary.parsed_time || ""}</div>
    `;
  } else {
    summaryHtml = `총 ${excelParsedData.parsed.total_count}건의 내역이 감지되었습니다.`;
  }
  document.getElementById("excelSummaryText").innerHTML = summaryHtml;
}

async function onSelectExcelTx(idxStr) {
  if (!excelParsedData || !excelParsedData.parsed || !excelParsedData.excel_filename) return;
  const idx = parseInt(idxStr, 10);
  const records = excelParsedData.parsed.records || [];
  const selectedRecord = records.find(r => (r.index !== undefined ? r.index : records.indexOf(r)) === idx) || records[idx];

  if (!selectedRecord) return;
  excelParsedData.parsed.primary = selectedRecord;
  excelParsedData.parsed.selected_index = idx;
  renderExcelSummary();

  const isOnlyRow = document.getElementById("excelOnlySelectedCheck").checked;

  // Call API to re-render table image for the selected row
  try {
    const res = await fetch("/api/select-excel-row", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        excel_filename: excelParsedData.excel_filename,
        selected_index: idx,
        only_selected_row: isOnlyRow
      })
    });
    const data = await res.json();
    if (data.success) {
      cardImageFilename = data.table_image_filename;
      document.getElementById("excelTableImg").src = `${data.table_image_url}?t=${Date.now()}`;
    }
  } catch (e) {
    console.warn("표 이미지 재생성 실패:", e);
  }
}

function toggleExcelOnlyRow(checked) {
  const txSelect = document.getElementById("excelTxSelect");
  if (txSelect && txSelect.value !== undefined) {
    onSelectExcelTx(txSelect.value);
  }
}

function applyExcelDataToForm() {
  if (!excelParsedData || !excelParsedData.parsed || !excelParsedData.parsed.primary) {
    alert("적용할 엑셀 데이터가 없습니다.");
    return;
  }
  const p = excelParsedData.parsed.primary;
  let appliedMsg = [];

  const rawAmt = p.amount != null ? String(p.amount) : (p.amount_str || "");
  const cleanAmtStr = rawAmt.replace(/[^0-9]/g, "");
  if (cleanAmtStr) {
    const val = parseInt(cleanAmtStr, 10);
    if (!isNaN(val) && val > 0) {
      document.getElementById("totalAmount").value = val.toLocaleString();
      appliedMsg.push(`금액: ${val.toLocaleString()}원`);
    }
  }

  if (p.merchant) {
    document.getElementById("placeMeal").value = p.merchant;
    appliedMsg.push(`식사장소: ${p.merchant}`);
  }
  if (p.parsed_date) {
    document.getElementById("meetingDate").value = p.parsed_date;
    appliedMsg.push(`회의일자: ${p.parsed_date}`);
  }
  if (p.parsed_time) {
    document.getElementById("endTime").value = p.parsed_time;
    appliedMsg.push(`종료시간: ${p.parsed_time}`);
  }
  if (p.suggested_start_time) {
    document.getElementById("startTime").value = p.suggested_start_time;
    appliedMsg.push(`시작시간: ${p.suggested_start_time}`);
  }

  updatePreview();
  alert("✨ 엑셀 데이터가 회의록 폼에 자동 반영되었습니다!\n\n" + appliedMsg.join("\n"));
}

// Currency formatter
function formatCurrency(input) {
  let val = input.value.replace(/[^0-9]/g, "");
  if (!val) {
    input.value = "0";
    return;
  }
  input.value = Number(val).toLocaleString();
}

// Discussion Templates
function insertDiscussionTemplate(type) {
  const textarea = document.getElementById("discussion");
  if (type === "industry") {
    textarea.value = `○ 산학 연계 실무 프로젝트 추진 경과 검토
  ‣ 참여기업 멘토링 매칭 현황 점검 및 중간 피드백 검토
  ‣ 학생 프로젝트팀 과제 수행 일정 및 필요 기자재 지원 방안 협의
  ‣ 산학 장학금 및 활동비 지급 기준 확정

○ 4분기 기업 현장 워크숍 및 멘토링 일정 조율
  ‣ 현장실습 및 기업체 방문 일정 확정 (11월 중순 개시)
  ‣ 멘토링 보고서 양식 간소화 합의

○ 향후 추진 계획
  ‣ 성과발표회 일정 수립 및 외부 전문가 심사위원 위촉 논의
  ‣ 차기 회의 일정 협의`;
  } else if (type === "project") {
    textarea.value = `○ 2026년도 사업계획서 세부 실행 방안 논의
  ‣ 핵심 성과지표(KPI) 달성을 위한 분기별 마일스톤 점검
  ‣ 예산 집행 세부 계획 및 비목별 잔여 예산 효율적 재배분 방안 검토
  ‣ 협력기관 및 참여기업 연계 프로그램 활성화 논의

○ 증빙 서류 및 성과 관리 체계 점검
  ‣ 사업단 정산 지침 준수 여부 및 회의비 집행 기준 확인
  ‣ 학생 연구원 인건비 및 장학금 정산 일정 안내

○ 차후 계획
  ‣ 중간 성과보고서 제출 일정 조율
  ‣ 차기 운영위원회 일정 확정`;
  }
}

// ==========================================
// 6. 회의록 문서 생성 (HWP + PDF)
// ==========================================
async function submitForm() {
  const projectName = document.getElementById("projectName").value.trim();
  const meetingName = document.getElementById("meetingName").value.trim();
  const meetingDate = document.getElementById("meetingDate").value;
  const discussion = document.getElementById("discussion").value.trim();

  if (!projectName) {
    alert("과제명을 입력해주세요.");
    document.getElementById("projectName").focus();
    return;
  }
  if (!meetingName) {
    alert("회의명을 입력해주세요.");
    document.getElementById("meetingName").focus();
    return;
  }
  if (!meetingDate) {
    alert("회의 일자를 선택해주세요.");
    document.getElementById("meetingDate").focus();
    return;
  }
  if (!discussion) {
    alert("토의내용 요약본을 입력해주세요.");
    document.getElementById("discussion").focus();
    return;
  }

  // Safe integer parsing (prevents NaN/null 422 error)
  const rawAmtStr = document.getElementById("totalAmount").value.replace(/[^0-9]/g, "");
  const totalAmt = parseInt(rawAmtStr, 10) || 0;
  const receiptCount = parseInt(document.getElementById("receiptCount").value, 10) || 1;

  // Check receipt image
  if (!receiptImageBase64) {
    if (!confirm("영수증 이미지가 첨부되지 않았습니다. 영수증 없이 문서를 생성하시겠습니까?")) {
      return;
    }
  }

  const payload = {
    project_id: selectedProjectId,
    project_name: projectName,
    meeting_name: meetingName,
    meeting_date: meetingDate,
    start_time: document.getElementById("startTime").value,
    end_time: document.getElementById("endTime").value,
    place_meeting: document.getElementById("placeMeeting").value.trim(),
    place_meal: document.getElementById("placeMeal").value.trim(),
    agenda: document.getElementById("agenda").value.trim(),
    discussion: discussion,
    remarks: document.getElementById("remarks").value.trim(),
    attendees: attendees,
    absentees: [],
    absent_reason: "",
    author: {
      dept: document.getElementById("authorDept").value.trim(),
      pos: document.getElementById("authorPos").value.trim(),
      name: document.getElementById("authorName").value.trim()
    },
    total_amount: totalAmt,
    receipt_count: receiptCount,
    receipt_image_base64: receiptImageBase64,
    card_image_base64: cardImageBase64,
    card_image_filename: cardImageFilename
  };

  document.getElementById("loadingOverlay").classList.remove("hidden");

  try {
    const res = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    document.getElementById("loadingOverlay").classList.add("hidden");

    if (!res.ok || !data.success) {
      let errMsg = data.detail || "알 수 없는 오류";
      if (Array.isArray(data.detail)) {
        errMsg = data.detail.map(e => `${e.loc ? e.loc.join('.') : ''}: ${e.msg}`).join('\n');
      }
      alert("회의록 문서 생성 실패:\n" + errMsg);
      return;
    }

    lastGeneratedFilename = data.filename;
    document.getElementById("resultFileName").textContent = data.filename;
    document.getElementById("downloadHwpLink").href = data.hwp_url;
    if (data.pdf_url) {
      document.getElementById("downloadPdfLink").href = data.pdf_url;
      document.getElementById("downloadPdfLink").classList.remove("hidden");
    } else {
      document.getElementById("downloadPdfLink").classList.add("hidden");
    }

    document.getElementById("resultModal").classList.remove("hidden");
    saveDraft();

  } catch (err) {
    document.getElementById("loadingOverlay").classList.add("hidden");
    alert("서버 통신 실패: " + err.message);
  }
}

// Open HWP direct
async function openHwpDirect() {
  try {
    const res = await fetch("/api/open-hwp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename: lastGeneratedFilename || null })
    });
    const data = await res.json();
    if (data.success) {
      alert("✅ " + data.message);
    } else {
      alert("⚠️ 한글 실행 알림:\n" + data.message);
    }
  } catch (err) {
    alert("오류: " + err.message);
  }
}

async function openOutputFolder() {
  try {
    const res = await fetch("/api/open-folder", { method: "POST" });
    const data = await res.json();
    if (data.success) {
      // 윈도우 탐색기가 열림
    } else {
      alert("저장 폴더 열기 실패:\n" + (data.message || "오류"));
    }
  } catch (e) {
    alert("오류: " + e.message);
  }
}

function closeModal() {
  document.getElementById("resultModal").classList.add("hidden");
}

// LocalStorage Draft
function saveDraft() {
  const draft = {
    selectedProjectId: selectedProjectId,
    projectName: document.getElementById("projectName").value,
    meetingName: document.getElementById("meetingName").value,
    meetingDate: document.getElementById("meetingDate").value,
    startTime: document.getElementById("startTime").value,
    endTime: document.getElementById("endTime").value,
    placeMeeting: document.getElementById("placeMeeting").value,
    placeMeal: document.getElementById("placeMeal").value,
    agenda: document.getElementById("agenda").value,
    discussion: document.getElementById("discussion").value,
    remarks: document.getElementById("remarks").value,
    authorDept: document.getElementById("authorDept").value,
    authorPos: document.getElementById("authorPos").value,
    authorName: document.getElementById("authorName").value,
    totalAmount: document.getElementById("totalAmount").value,
    receiptCount: document.getElementById("receiptCount").value,
    attendees: attendees
  };
  localStorage.setItem("meeting_draft", JSON.stringify(draft));
}

function loadDraft() {
  try {
    const raw = localStorage.getItem("meeting_draft");
    if (!raw) return false;
    const d = JSON.parse(raw);
    if (d.selectedProjectId && projects.some(p => p.id === d.selectedProjectId)) {
      selectedProjectId = d.selectedProjectId;
      document.getElementById("projectSelect").value = selectedProjectId;
    }
    if (d.projectName) document.getElementById("projectName").value = d.projectName;
    if (d.meetingName) document.getElementById("meetingName").value = d.meetingName;
    if (d.meetingDate) document.getElementById("meetingDate").value = d.meetingDate;
    if (d.startTime) document.getElementById("startTime").value = d.startTime;
    if (d.endTime) document.getElementById("endTime").value = d.endTime;
    if (d.placeMeeting) document.getElementById("placeMeeting").value = d.placeMeeting;
    if (d.placeMeal) document.getElementById("placeMeal").value = d.placeMeal;
    if (d.agenda) document.getElementById("agenda").value = d.agenda;
    if (d.discussion) document.getElementById("discussion").value = d.discussion;
    if (d.remarks) document.getElementById("remarks").value = d.remarks;
    if (d.authorDept) document.getElementById("authorDept").value = d.authorDept;
    if (d.authorPos) document.getElementById("authorPos").value = d.authorPos;
    if (d.authorName) document.getElementById("authorName").value = d.authorName;
    if (d.totalAmount) document.getElementById("totalAmount").value = d.totalAmount;
    if (d.receiptCount) document.getElementById("receiptCount").value = d.receiptCount;
    if (d.attendees && Array.isArray(d.attendees) && d.attendees.length > 0) {
      attendees = d.attendees;
      renderAttendees();
    }
    updatePreview();
    return true;
  } catch (e) {
    console.error("Draft load failed", e);
    return false;
  }
}

function resetForm() {
  if (!confirm("모든 입력 내용을 초기화하시겠습니까?")) return;
  localStorage.removeItem("meeting_draft");
  location.reload();
}

function loadSamplePreset() {
  if (projects.length > 0) {
    onProjectSelectChange(projects[0].id);
  }
  document.getElementById("meetingName").value = "2026 앵커사업 L-Stay Major-Up 전공학습 교류회 1차 회의";
  document.getElementById("meetingDate").value = "2026-10-15";
  document.getElementById("startTime").value = "13:30";
  document.getElementById("endTime").value = "17:30";
  document.getElementById("placeMeeting").value = "동서대학교 산학협력관 1층 세미나홀";
  document.getElementById("placeMeal").value = "스콜";
  document.getElementById("agenda").value = "캡스톤 참여기업 연계 Major-Up 전공학습 교류회 운영 및 중간평가";
  insertDiscussionTemplate("industry");
  document.getElementById("remarks").value = "선회의 후 식사진행";
  document.getElementById("totalAmount").value = "185,000";
  document.getElementById("receiptCount").value = "1";
  updatePreview();
  alert("💡 앵커사업단 회의록 표준 예시 데이터가 입력되었습니다!");
}

// ==========================================
// 8. 토의내용 작성 모드 & AI 스마트 자동 생성 (중단 지원)
// ==========================================
let currentDiscussionMode = "manual";
let aiAbortController = null;

function switchDiscussionMode(mode) {
  currentDiscussionMode = mode;
  const tabManual = document.getElementById("tabModeManual");
  const tabAi = document.getElementById("tabModeAi");
  const aiBox = document.getElementById("aiGeneratorBox");

  if (mode === "ai") {
    tabAi.className = "px-3.5 py-1.5 rounded-lg bg-white text-indigo-700 shadow-sm transition flex items-center gap-1.5 font-bold";
    tabManual.className = "px-3.5 py-1.5 rounded-lg text-slate-600 hover:text-slate-900 transition flex items-center gap-1.5 font-bold";
    aiBox.classList.remove("hidden");
    loadDocumentsList();
  } else {
    tabManual.className = "px-3.5 py-1.5 rounded-lg bg-white text-blue-700 shadow-sm transition flex items-center gap-1.5 font-bold";
    tabAi.className = "px-3.5 py-1.5 rounded-lg text-slate-600 hover:text-slate-900 transition flex items-center gap-1.5 font-bold";
    aiBox.classList.add("hidden");
  }
}

async function generateDiscussionFromAI() {
  const keywordsInput = document.getElementById("aiKeywords");
  const keywords = keywordsInput.value.trim();
  const agenda = document.getElementById("agenda").value.trim();
  const meetingName = document.getElementById("meetingName").value.trim();
  const btnRun = document.getElementById("btnRunAiGenerate");
  const btnAbort = document.getElementById("btnAbortAiGenerate");

  if (!keywords && !agenda) {
    alert("키워드 또는 회의 안건을 입력해주세요.");
    keywordsInput.focus();
    return;
  }

  aiAbortController = new AbortController();
  const originalBtnHtml = btnRun.innerHTML;
  btnRun.disabled = true;
  btnRun.innerHTML = `<i class="fa-solid fa-spinner animate-spin"></i> <span>계획서 분석 및 생성 중...</span>`;
  if (btnAbort) btnAbort.classList.remove("hidden");

  try {
    const res = await fetch("/api/generate-discussion", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: aiAbortController.signal,
      body: JSON.stringify({
        keywords: keywords,
        agenda: agenda,
        meeting_name: meetingName
      })
    });
    const data = await res.json();
    btnRun.disabled = false;
    btnRun.innerHTML = originalBtnHtml;
    if (btnAbort) btnAbort.classList.add("hidden");

    if (data.success && data.discussion_text) {
      document.getElementById("discussion").value = data.discussion_text;
      saveDraft();
      alert(`✨ [AI 스마트 토의내용 생성 완료]\n\n등록된 계획서(${data.referenced_docs_count || 0}건) 및 이전 회의 기록을 참조하여 앵커사업단 서식(○ 대항목 / ‣ 세부항목 들여쓰기)으로 자동 완성되었습니다!`);
    } else {
      alert("생성 실패: " + (data.detail || "오류가 발생했습니다."));
    }
  } catch (err) {
    btnRun.disabled = false;
    btnRun.innerHTML = originalBtnHtml;
    if (btnAbort) btnAbort.classList.add("hidden");

    if (err.name === "AbortError") {
      alert("⏹ AI 토의내용 자동 생성이 사용자에 의해 중단되었습니다.");
    } else {
      alert("서버 통신 오류: " + err.message);
    }
  } finally {
    aiAbortController = null;
  }
}

function abortAiGeneration() {
  if (aiAbortController) {
    aiAbortController.abort();
  }
}

// ==========================================
// 9. 과제 기본 참석자 명부 불러오기
// ==========================================
function reloadProjectDefaultAttendees() {
  if (!selectedProjectId) {
    alert("선택된 과제가 없습니다.");
    return;
  }
  const proj = projects.find(p => p.id === selectedProjectId);
  if (!proj) return;

  if (confirm(`[${proj.name}]의 기본 참석자 풀을 다시 불러오시겠습니까?\n(현재 수정 중인 참석자 목록이 덮어씌워집니다)`)) {
    if (proj.attendees && Array.isArray(proj.attendees)) {
      attendees = JSON.parse(JSON.stringify(proj.attendees));
    } else {
      attendees = [];
    }
    renderAttendees();
    alert(`✅ 기본 참석자 명부(${attendees.length}명)를 다시 불러왔습니다.`);
  }
}

// ==========================================
// 10. 관련 문서 및 Folders 관리 모달 (Antigravity Style)
// ==========================================
let referenceDocs = [];
let registeredFolders = [];
let selectedDocIds = new Set();

function openDocModal() {
  loadFoldersList();
  loadDocumentsList();
  document.getElementById("docModal").classList.remove("hidden");
}

function closeDocModal() {
  document.getElementById("docModal").classList.add("hidden");
}

// --- Antigravity 스타일 Folders 관리 ---
async function loadFoldersList() {
  try {
    const res = await fetch("/api/folders");
    const data = await res.json();
    if (data.success) {
      registeredFolders = data.folders || [];
      renderFoldersList();
    }
  } catch (err) {
    console.warn("폴더 목록 로드 실패:", err);
  }
}

function renderFoldersList() {
  const container = document.getElementById("folderListContainer");
  if (!container) return;
  container.innerHTML = "";

  if (registeredFolders.length === 0) {
    container.innerHTML = `<div class="p-4 text-center text-xs text-slate-400 bg-slate-50">등록된 폴더가 없습니다. 아래 버튼으로 폴더를 추가하세요.</div>`;
    return;
  }

  registeredFolders.forEach((f) => {
    const row = document.createElement("div");
    row.className = "px-4 py-3 flex items-center justify-between text-xs font-bold text-slate-800 hover:bg-slate-50 transition group";
    row.innerHTML = `
      <div class="flex items-center gap-2.5 min-w-0 pr-2">
        <i class="fa-regular fa-folder text-slate-400 text-sm flex-shrink-0"></i>
        <span class="font-mono text-slate-800 truncate" title="${f.path}">${f.name}/</span>
      </div>
      <button type="button" onclick="deleteFolderItem('${f.id}')"
        class="text-slate-400 hover:text-rose-600 p-1 transition flex-shrink-0 cursor-pointer" title="폴더 등록 해제">
        <i class="fa-solid fa-xmark text-sm"></i>
      </button>
    `;
    container.appendChild(row);
  });
}

function toggleInlineFolderAdd() {
  const box = document.getElementById("inlineFolderAddBox");
  if (!box) return;
  box.classList.toggle("hidden");
  if (!box.classList.contains("hidden")) {
    document.getElementById("newFolderPathInput").focus();
  }
}

async function submitNewFolderRegister() {
  const input = document.getElementById("newFolderPathInput");
  const p = input ? input.value.trim() : "";
  if (!p) {
    alert("추가할 폴더 경로를 입력해주세요.");
    return;
  }

  try {
    const res = await fetch("/api/folders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path: p })
    });
    const data = await res.json();
    if (data.success) {
      toggleInlineFolderAdd();
      loadFoldersList();
      loadDocumentsList();
      alert(`✅ 폴더가 성공적으로 등록되고 관련 문서가 색인되었습니다!`);
    } else {
      alert("폴더 등록 실패: " + (data.detail || "오류"));
    }
  } catch (err) {
    alert("통신 오류: " + err.message);
  }
}

async function deleteFolderItem(folderId) {
  if (!confirm("이 폴더의 등록을 해제하시겠습니까?\n(해당 폴더에서 색인된 문서 목록도 함께 정리됩니다)")) return;
  try {
    const res = await fetch(`/api/folders/${folderId}`, { method: "DELETE" });
    const data = await res.json();
    if (data.success) {
      loadFoldersList();
      loadDocumentsList();
    } else {
      alert("해제 실패: " + (data.detail || "오류"));
    }
  } catch (err) {
    alert("통신 오류: " + err.message);
  }
}

// --- 문서 목록 관리 & 일괄/부분 삭제 ---
async function loadDocumentsList() {
  try {
    const res = await fetch("/api/docs");
    const data = await res.json();
    if (data.success) {
      referenceDocs = data.documents || [];
      selectedDocIds.clear();
      renderDocList();
      const badge = document.getElementById("refDocCountBadge");
      if (badge) badge.textContent = referenceDocs.length;
      const hBadge = document.getElementById("headerDocBadge");
      if (hBadge) hBadge.textContent = referenceDocs.length;
      const countBadge = document.getElementById("docCountBadge");
      if (countBadge) countBadge.textContent = `${referenceDocs.length}건`;
    }
  } catch (err) {
    console.warn("참조 문서 목록 로드 실패:", err);
  }
}

function renderDocList() {
  const container = document.getElementById("docListContainer");
  if (!container) return;
  container.innerHTML = "";

  const selectAll = document.getElementById("selectAllDocsCheckbox");
  if (selectAll) selectAll.checked = false;
  updateSelectedDocsUI();

  if (referenceDocs.length === 0) {
    container.innerHTML = `<div class="p-6 text-center text-xs text-slate-400 bg-slate-50 rounded-2xl border border-dashed border-slate-200">색인된 문서가 없습니다. 왼쪽에서 폴더를 추가하거나 파일을 업로드하세요.</div>`;
    return;
  }

  referenceDocs.forEach((doc) => {
    const isChecked = selectedDocIds.has(doc.id);
    const card = document.createElement("div");
    card.className = `p-3 rounded-xl border text-xs transition flex items-start justify-between gap-3 ${
      isChecked ? "border-emerald-500 bg-emerald-50/40 shadow-xs" : "border-slate-200 bg-white hover:border-slate-300"
    }`;

    const sizeKb = doc.file_size ? (doc.file_size / 1024).toFixed(1) + " KB" : "-";
    const typeUpper = (doc.file_type || "doc").toUpperCase();

    card.innerHTML = `
      <div class="flex items-start gap-2.5 min-w-0 flex-1">
        <input type="checkbox" ${isChecked ? "checked" : ""}
          onchange="toggleDocCheck('${doc.id}', this.checked)"
          class="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer mt-0.5 flex-shrink-0">
        <div class="space-y-0.5 min-w-0 flex-1">
          <div class="flex items-center gap-1.5 flex-wrap">
            <span class="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded flex-shrink-0">${typeUpper}</span>
            <strong class="font-bold text-slate-800 break-all leading-tight text-xs">${doc.title || doc.filename}</strong>
          </div>
          <p class="text-[11px] text-slate-400 font-mono truncate" title="${doc.file_path || doc.filename}">${doc.file_path || doc.filename}</p>
          <div class="text-[10px] text-slate-400 flex items-center gap-3 pt-0.5">
            <span>크기: ${sizeKb}</span>
            <span>등록: ${doc.created_at || '-'}</span>
          </div>
        </div>
      </div>
      <button type="button" onclick="deleteDocItem('${doc.id}')"
        class="text-slate-400 hover:text-rose-600 p-1 transition flex-shrink-0 cursor-pointer" title="개별 삭제">
        <i class="fa-solid fa-xmark text-sm"></i>
      </button>
    `;
    container.appendChild(card);
  });
}

function toggleDocCheck(docId, isChecked) {
  if (isChecked) {
    selectedDocIds.add(docId);
  } else {
    selectedDocIds.delete(docId);
  }
  updateSelectedDocsUI();
  // 카드 스타일 갱신
  renderDocList();
}

function toggleSelectAllDocs(isAllChecked) {
  if (isAllChecked) {
    referenceDocs.forEach(d => selectedDocIds.add(d.id));
  } else {
    selectedDocIds.clear();
  }
  updateSelectedDocsUI();
  renderDocList();
}

function updateSelectedDocsUI() {
  const btn = document.getElementById("btnDeleteSelectedDocs");
  const countText = document.getElementById("selectedDocCountText");
  const selectAll = document.getElementById("selectAllDocsCheckbox");

  const count = selectedDocIds.size;
  if (countText) countText.textContent = count;
  if (btn) btn.disabled = count === 0;

  if (selectAll && referenceDocs.length > 0) {
    selectAll.checked = count === referenceDocs.length;
  }
}

async function deleteSelectedDocuments() {
  const count = selectedDocIds.size;
  if (count === 0) return;
  if (!confirm(`선택한 ${count}개의 문서를 삭제하시겠습니까?`)) return;

  try {
    const res = await fetch("/api/docs/delete-multiple", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ doc_ids: Array.from(selectedDocIds) })
    });
    const data = await res.json();
    if (data.success) {
      selectedDocIds.clear();
      loadDocumentsList();
    } else {
      alert("삭제 실패: " + (data.detail || "오류"));
    }
  } catch (err) {
    alert("통신 오류: " + err.message);
  }
}

async function deleteAllDocuments() {
  if (referenceDocs.length === 0) {
    alert("삭제할 문서가 없습니다.");
    return;
  }
  if (!confirm(`정말로 등록된 전체 문서(${referenceDocs.length}건)를 모두 삭제하시겠습니까?`)) return;

  try {
    const res = await fetch("/api/docs/delete-all", { method: "POST" });
    const data = await res.json();
    if (data.success) {
      selectedDocIds.clear();
      loadDocumentsList();
    } else {
      alert("삭제 실패: " + (data.detail || "오류"));
    }
  } catch (err) {
    alert("통신 오류: " + err.message);
  }
}

async function deleteDocItem(docId) {
  if (!confirm("이 문서를 목록에서 삭제하시겠습니까?")) return;
  try {
    const res = await fetch(`/api/docs/${docId}`, { method: "DELETE" });
    const data = await res.json();
    if (data.success) {
      selectedDocIds.delete(docId);
      loadDocumentsList();
    } else {
      alert("삭제 실패: " + (data.detail || "오류"));
    }
  } catch (err) {
    alert("통신 오류: " + err.message);
  }
}

async function handleDocFileUpload(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append("file", file);

  try {
    const res = await fetch("/api/docs/upload", {
      method: "POST",
      body: formData
    });
    const data = await res.json();
    if (data.success) {
      document.getElementById("docFileInput").value = "";
      alert(`✅ [${file.name}] 문서가 성공적으로 등록되었습니다!`);
      loadDocumentsList();
    } else {
      alert("업로드 실패: " + (data.detail || "오류"));
    }
  } catch (err) {
    alert("통신 오류: " + err.message);
  }
}

