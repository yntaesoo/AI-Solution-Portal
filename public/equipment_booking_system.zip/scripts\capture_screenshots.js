const puppeteer = require('puppeteer-core');
const fs = require('fs');
const path = require('path');

const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const OUTPUT_DIR = path.join(__dirname, '..', 'manual_screenshots');

if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

async function run() {
  console.log('Launching Chrome from:', CHROME_PATH);
  const browser = await puppeteer.launch({
    executablePath: CHROME_PATH,
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--window-size=1280,920']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 920, deviceScaleFactor: 2 });

  // Helper function to login
  const loginAs = async (id, pw) => {
    await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle0' });
    await page.evaluate(() => {
      document.cookie.split(";").forEach(c => {
        document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
      });
      localStorage.clear();
    });
    await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle0' });
    await page.waitForSelector('input[type="text"]');
    await page.type('input[type="text"]', id);
    await page.type('input[type="password"]', pw);
    await page.click('button[type="submit"]');
    await page.waitForNavigation({ waitUntil: 'networkidle0' });
  };

  // 1. Login Screen
  console.log('1. Capturing Login Screen...');
  await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle0' });
  await page.screenshot({ path: path.join(OUTPUT_DIR, '01_login_screen.png') });

  // 2. Register Screen
  console.log('2. Capturing Register Screen...');
  await page.goto('http://localhost:3000/register', { waitUntil: 'networkidle0' });
  await page.screenshot({ path: path.join(OUTPUT_DIR, '02_student_register.png') });

  // 3. Equipment Catalog
  console.log('3. Capturing Equipment Catalog...');
  await page.goto('http://localhost:3000/catalog', { waitUntil: 'networkidle0' });
  await page.screenshot({ path: path.join(OUTPUT_DIR, '03_equipment_catalog.png') });

  // 4 & 5 & 6. Student Booking Flow
  console.log('4. Logging in as Student and checking Booking page...');
  await loginAs('20240001', 'student1234');

  // Go to booking with terms unagreed to trigger First-time modal
  await page.goto('http://localhost:3000/booking', { waitUntil: 'networkidle0' });
  await new Promise(r => setTimeout(r, 600));
  await page.screenshot({ path: path.join(OUTPUT_DIR, '04_first_time_pledge_modal.png') });

  // Accept terms
  await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    const confirmBtn = btns.find(b => b.textContent.includes('동의') || b.textContent.includes('Agree') || b.textContent.includes('확인'));
    if (confirmBtn) confirmBtn.click();
  });
  await new Promise(r => setTimeout(r, 600));

  // Add 1 equipment item to cart
  await page.evaluate(() => {
    const addBtns = Array.from(document.querySelectorAll('button'));
    const addBtn = addBtns.find(b => b.textContent.trim().startsWith('Add') || b.textContent.includes('담기'));
    if (addBtn) addBtn.click();
  });
  await new Promise(r => setTimeout(r, 600));

  // Fill in Project Title and ensure instructor selected
  await page.evaluate(() => {
    const select = document.querySelector('select');
    if (select && select.options.length > 1) {
      select.selectedIndex = 1;
      select.dispatchEvent(new Event('change', { bubbles: true }));
    }
    const inputs = Array.from(document.querySelectorAll('input'));
    const titleInput = inputs.find(i => i.placeholder && (i.placeholder.includes('Project') || i.placeholder.includes('제목')));
    if (titleInput) {
      titleInput.value = '2026 IC Capstone Project - Short Film Production';
      titleInput.dispatchEvent(new Event('input', { bubbles: true }));
    }
  });
  await new Promise(r => setTimeout(r, 600));

  // Screenshot Booking Form & Cart
  await page.screenshot({ path: path.join(OUTPUT_DIR, '05_booking_form_and_cart.png') });

  // Click final Reserve button to show Confirmation Modal
  await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    const submitBtn = btns.find(b => b.textContent.includes('예약 신청하기') || b.textContent.includes('Submit Booking') || b.textContent.includes('신청하기'));
    if (submitBtn) submitBtn.click();
  });
  await new Promise(r => setTimeout(r, 800));
  await page.screenshot({ path: path.join(OUTPUT_DIR, '06_final_confirm_modal.png') });

  // Dismiss modal
  await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    const cancelBtn = btns.find(b => b.textContent.includes('취소') || b.textContent.includes('Cancel') || b.textContent.includes('돌아가기'));
    if (cancelBtn) cancelBtn.click();
  });
  await new Promise(r => setTimeout(r, 500));

  // 7. Student My Bookings
  console.log('7. Capturing Student My Bookings...');
  await page.goto('http://localhost:3000/my-bookings', { waitUntil: 'networkidle0' });
  await page.screenshot({ path: path.join(OUTPUT_DIR, '07_student_my_bookings.png') });

  // 8. Faculty Portal
  console.log('8. Logging in as Faculty and capturing Approval Portal...');
  await loginAs('PROF_YOON', 'prof1234');
  await page.goto('http://localhost:3000/faculty', { waitUntil: 'networkidle0' });
  await page.screenshot({ path: path.join(OUTPUT_DIR, '08_faculty_approval_portal.png') });

  // 9, 10, 11. Admin Pages (Tab navigation)
  console.log('9. Logging in as Admin and capturing Dashboard Tabs...');
  await loginAs('ADMIN001', 'admin1234');
  await page.goto('http://localhost:3000/admin', { waitUntil: 'networkidle0' });
  await new Promise(r => setTimeout(r, 600));

  // Admin Tab 1: Equipment & Bulk Excel
  await page.evaluate(() => {
    const tabs = Array.from(document.querySelectorAll('button'));
    const eqTab = tabs.find(b => b.textContent.includes('장비 관리') || b.textContent.includes('Equipment'));
    if (eqTab) eqTab.click();
  });
  await new Promise(r => setTimeout(r, 600));
  await page.screenshot({ path: path.join(OUTPUT_DIR, '09_admin_equipment_bulk.png') });

  // Admin Tab 2: Operations Desk (Check-out / Check-in)
  await page.evaluate(() => {
    const tabs = Array.from(document.querySelectorAll('button'));
    const opTab = tabs.find(b => b.textContent.includes('현장 출납') || b.textContent.includes('Operations'));
    if (opTab) opTab.click();
  });
  await new Promise(r => setTimeout(r, 600));
  await page.screenshot({ path: path.join(OUTPUT_DIR, '10_admin_operations_desk.png') });

  // Admin Tab 3: Settings & Custom Fields
  await page.evaluate(() => {
    const tabs = Array.from(document.querySelectorAll('button'));
    const setTab = tabs.find(b => b.textContent.includes('시스템 설정') || b.textContent.includes('Settings'));
    if (setTab) setTab.click();
  });
  await new Promise(r => setTimeout(r, 600));
  await page.screenshot({ path: path.join(OUTPUT_DIR, '11_admin_custom_fields.png') });

  // 12. Mobile Responsive View
  console.log('12. Capturing Mobile View...');
  await page.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
  await page.goto('http://localhost:3000/booking', { waitUntil: 'networkidle0' });
  await new Promise(r => setTimeout(r, 800));
  await page.screenshot({ path: path.join(OUTPUT_DIR, '12_mobile_responsive_view.png') });

  await browser.close();
  console.log('All 12 screenshots refreshed and captured successfully!');
}

run().catch(err => {
  console.error('Screenshot capture failed:', err);
  process.exit(1);
});
