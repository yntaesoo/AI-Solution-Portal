const puppeteer = require('puppeteer-core');

(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
    args: ['--no-sandbox', '--window-size=1280,900']
  });
  const page = await browser.newPage();
  await page.goto('http://localhost:3000/catalog', { waitUntil: 'networkidle0' });
  const input = await page.$('input[placeholder*="Search"]');

  // Search 'Canon'
  await input.click();
  await page.keyboard.type('Canon');
  await new Promise(r => setTimeout(r, 200));
  const canonCount = await page.evaluate(() => document.querySelectorAll('.grid > div').length);
  console.log('Cards matching Canon:', canonCount);

  // Click clear button
  await page.click('button[title="Clear search"]');
  await new Promise(r => setTimeout(r, 200));
  const clearedCount = await page.evaluate(() => document.querySelectorAll('.grid > div').length);
  console.log('Cards after clear:', clearedCount);

  // Search 'Wireless'
  await input.click();
  await page.keyboard.type('Wireless');
  await new Promise(r => setTimeout(r, 200));
  const wirelessCount = await page.evaluate(() => document.querySelectorAll('.grid > div').length);
  console.log('Cards matching Wireless:', wirelessCount);

  await browser.close();
  console.log('Catalog Search test PASSED perfectly!');
})().catch(err => {
  console.error(err);
  process.exit(1);
});
