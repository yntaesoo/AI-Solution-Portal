import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { hashPassword } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Admin only." }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const roleFilter = searchParams.get("role"); // ALL, STUDENT_UNDERGRAD, STUDENT_GRAD
    const search = searchParams.get("search");

    const where: any = {};
    if (roleFilter && roleFilter !== "ALL") {
      where.role = roleFilter;
    }
    if (search) {
      where.OR = [
        { studentId: { contains: search } },
        { fullName: { contains: search } },
        { email: { contains: search } },
        { phone: { contains: search } },
      ];
    }

    const students = await prisma.user.findMany({
      where,
      include: {
        customValues: { include: { field: true } },
        penalties: { where: { isActive: true } },
        reservations: {
          select: { id: true, status: true, reservationNo: true },
        },
      },
      orderBy: { studentId: "asc" },
    });

    return NextResponse.json({ students });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// Admin manual student add (Specification 5-(3))
export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Admin only." }, { status: 403 });
    }

    const body = await req.json();
    const { studentId, fullName, email, phone, role, isCertified, password } = body;

    if (!studentId || !fullName) {
      return NextResponse.json({ error: "Student ID and Full Name are required." }, { status: 400 });
    }

    const existing = await prisma.user.findUnique({
      where: { studentId: studentId.trim() },
    });
    if (existing) {
      return NextResponse.json({ error: "Student ID already exists." }, { status: 409 });
    }

    const passwordHash = await hashPassword(password || "12345678");

    const created = await prisma.user.create({
      data: {
        studentId: studentId.trim(),
        fullName: fullName.trim(),
        email: email ? email.trim() : `${studentId.trim()}@dongseo.ac.kr`,
        phone: phone ? phone.trim() : "010-0000-0000",
        passwordHash,
        role: role || "STUDENT_UNDERGRAD",
        isCertified: !!isCertified,
        status: "ACTIVE",
      },
    });

    return NextResponse.json({ success: true, student: created });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// Update student certification or status
export async function PATCH(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Admin only." }, { status: 403 });
    }

    const body = await req.json();
    const { id, isCertified, status, role } = body;

    if (!id) {
      return NextResponse.json({ error: "Student ID (UUID) is required." }, { status: 400 });
    }

    const updated = await prisma.user.update({
      where: { id },
      data: {
        isCertified: typeof isCertified === "boolean" ? isCertified : undefined,
        status: status || undefined,
        role: role || undefined,
      },
    });

    return NextResponse.json({ success: true, student: updated });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
