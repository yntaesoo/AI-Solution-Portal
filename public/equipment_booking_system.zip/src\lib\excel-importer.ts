import * as XLSX from "xlsx";
import { prisma } from "./prisma";

export interface ParsedEquipmentRow {
  category: string;
  subcategory: string;
  brand: string;
  modelName: string;
  quantity: number;
  remarks: string | null;
  targetAudience: "ALL" | "UNDERGRAD" | "GRAD" | "CERTIFIED";
}

export function parseEquipmentExcel(buffer: Buffer): ParsedEquipmentRow[] {
  const workbook = XLSX.read(buffer, { type: "buffer" });
  const sheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[sheetName];

  // Convert to array of arrays to handle custom header rows
  const rawData: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

  // Locate the header row: Look for row containing "Categorization" or "Category"
  let headerRowIndex = -1;
  for (let i = 0; i < Math.min(10, rawData.length); i++) {
    const row = rawData[i];
    if (
      row &&
      row.some(
        (cell) =>
          typeof cell === "string" &&
          (cell.toLowerCase().includes("categor") || cell.toLowerCase().includes("model"))
      )
    ) {
      headerRowIndex = i;
      break;
    }
  }

  if (headerRowIndex === -1) {
    headerRowIndex = 2; // Default to row 3 (0-indexed 2) based on inspection
  }

  const results: ParsedEquipmentRow[] = [];
  let currentCategory = "General";
  let currentSubcategory = "General";

  for (let i = headerRowIndex + 1; i < rawData.length; i++) {
    const row = rawData[i];
    if (!row || row.length === 0) continue;

    // Check if entire row is empty or not an equipment row
    const rawCat = row[0] ? String(row[0]).trim().replace(/\r?\n/g, " ") : null;
    const rawSubcat = row[1] ? String(row[1]).trim().replace(/\r?\n/g, " ") : null;
    const rawBrand = row[2] ? String(row[2]).trim() : "";
    const rawModel = row[3] ? String(row[3]).trim() : "";
    const rawQty = row[4];
    const rawRemarks = row[5] ? String(row[5]).trim() : null;

    // If both model and brand are empty, skip row
    if (!rawModel && !rawBrand) continue;

    // Forward fill category & subcategory if empty
    if (rawCat) currentCategory = rawCat;
    if (rawSubcat) currentSubcategory = rawSubcat;

    const quantity = typeof rawQty === "number" ? rawQty : parseInt(String(rawQty || "1"), 10) || 1;

    // Smart detect target audience from remarks
    let targetAudience: "ALL" | "UNDERGRAD" | "GRAD" | "CERTIFIED" = "ALL";
    if (rawRemarks) {
      const lowerRemarks = rawRemarks.toLowerCase();
      if (lowerRemarks.includes("trained") || lowerRemarks.includes("special training") || lowerRemarks.includes("prof. yoon")) {
        targetAudience = "CERTIFIED";
      } else if (lowerRemarks.includes("grad") || lowerRemarks.includes("graduate only")) {
        targetAudience = "GRAD";
      } else if (lowerRemarks.includes("undergrad only")) {
        targetAudience = "UNDERGRAD";
      }
    }

    results.push({
      category: currentCategory,
      subcategory: currentSubcategory,
      brand: rawBrand || "Generic",
      modelName: rawModel || "Unnamed Model",
      quantity,
      remarks: rawRemarks,
      targetAudience,
    });
  }

  return results;
}

export async function importEquipmentData(rows: ParsedEquipmentRow[]) {
  let createdModels = 0;
  let createdItems = 0;
  let categoryOrder = 1;
  let subcategoryOrder = 1;

  for (const row of rows) {
    // 1. Find or create Category
    let category = await prisma.category.findUnique({
      where: { nameEn: row.category },
    });
    if (!category) {
      category = await prisma.category.create({
        data: {
          nameEn: row.category,
          displayOrder: categoryOrder++,
        },
      });
    }

    // 2. Find or create Subcategory
    let subcategory = await prisma.subcategory.findFirst({
      where: {
        categoryId: category.id,
        nameEn: row.subcategory,
      },
    });
    if (!subcategory) {
      subcategory = await prisma.subcategory.create({
        data: {
          categoryId: category.id,
          nameEn: row.subcategory,
          displayOrder: subcategoryOrder++,
        },
      });
    }

    // 3. Find or create EquipmentModel
    let model = await prisma.equipmentModel.findFirst({
      where: {
        subcategoryId: subcategory.id,
        modelName: row.modelName,
        brand: row.brand,
      },
    });

    if (!model) {
      model = await prisma.equipmentModel.create({
        data: {
          subcategoryId: subcategory.id,
          brand: row.brand,
          modelName: row.modelName,
          totalQuantity: row.quantity,
          remarks: row.remarks,
          targetAudience: row.targetAudience,
          isAvailable: true,
        },
      });
      createdModels++;
    } else {
      // Update quantity and remarks
      model = await prisma.equipmentModel.update({
        where: { id: model.id },
        data: {
          totalQuantity: row.quantity,
          remarks: row.remarks,
          targetAudience: row.targetAudience,
        },
      });
    }

    // 4. Ensure individual EquipmentItem units exist up to totalQuantity
    const existingItemsCount = await prisma.equipmentItem.count({
      where: { modelId: model.id },
    });

    const neededItems = row.quantity - existingItemsCount;
    if (neededItems > 0) {
      // Short prefix e.g. CAM-01, SOU-01
      const catCode = row.category.replace(/[^a-zA-Z]/g, "").slice(0, 3).toUpperCase() || "EQP";
      const modelCode = row.modelName.replace(/[^a-zA-Z0-9]/g, "").slice(0, 4).toUpperCase();

      for (let k = 1; k <= neededItems; k++) {
        const itemNumber = existingItemsCount + k;
        const barcodeId = `DSU-${catCode}-${modelCode}-${String(itemNumber).padStart(2, "0")}`;

        // Check if barcode already taken
        const exists = await prisma.equipmentItem.findUnique({
          where: { barcodeId },
        });

        const finalBarcode = exists ? `${barcodeId}-${Date.now().toString().slice(-4)}` : barcodeId;

        await prisma.equipmentItem.create({
          data: {
            modelId: model.id,
            barcodeId: finalBarcode,
            serialNumber: `SN-${finalBarcode}`,
            status: "AVAILABLE",
          },
        });
        createdItems++;
      }
    }
  }

  return { createdModels, createdItems, totalRowsParsed: rows.length };
}
