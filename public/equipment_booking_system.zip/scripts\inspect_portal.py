import re
from bs4 import BeautifulSoup

with open('portal_page.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Let's inspect the cards
# Find all text and links
cards = re.split(r'class=["\'][^"\']*card[^"\']*["\']', html)
print(f"Total card sections: {len(cards)-1}")

for i, c in enumerate(cards[1:], 1):
    # strip tags
    clean = re.sub(r'<[^>]+>', '\n', c[:1000])
    lines = [l.strip() for l in clean.split('\n') if l.strip() and len(l.strip()) > 1]
    link_match = re.search(r'href=["\']([^"\']+)["\']', c)
    link = link_match.group(1) if link_match else "No link"
    print(f"\n--- Card {i} [Link: {link}] ---")
    for l in lines[:5]:
        print("  ", l)
