"use client";

import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
import {
  Package,
  Calendar,
  CheckSquare,
  Users,
  Settings,
  Upload,
  Download,
  Plus,
  Trash2,
  Edit,
  Search,
  CheckCircle2,
  AlertTriangle,
  QrCode,
  Camera,
  Layers,
  ShieldAlert,
  ArrowRight,
  Printer,
  FileSpreadsheet,
} from "lucide-react";

export default function AdminPage() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<"equipment" | "reservations" | "operations" | "students" | "settings">("equipment");
  const [loading, setLoading] = useState(true);

  // Tab 1: Equipment States
  const [models, setModels] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("ALL");
  const [equipmentSearch, setEquipmentSearch] = useState("");
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isAddEquipmentModalOpen, setIsAddEquipmentModalOpen] = useState(false);
  const [selectedBarcodeItem, setSelectedBarcodeItem] = useState<any | null>(null);

  // Form states for new equipment
  const [newSubcatId, setNewSubcatId] = useState("");
  const [newBrand, setNewBrand] = useState("");
  const [newModelName, setNewModelName] = useState("");
  const [newQuantity, setNewQuantity] = useState("1");
  const [newRemarks, setNewRemarks] = useState("");
  const [newAudience, setNewAudience] = useState("ALL");

  // Tab 2: Reservation States
  const [reservations, setReservations] = useState<any[]>([]);
  const [resStatusFilter, setResStatusFilter] = useState("ALL");

  // Tab 3: Field Operations (Check-out & Check-in)
  const [activeResForDesk, setActiveResForDesk] = useState<any | null>(null);
  const [deskAction, setDeskAction] = useState<"CHECKOUT" | "CHECKIN">("CHECKOUT");
  const [barcodeInput, setBarcodeInput] = useState("");
  const [onSiteBarcode, setOnSiteBarcode] = useState("");
  const [deskNotes, setDeskNotes] = useState("");
  const [isDamaged, setIsDamaged] = useState(false);
  const [damageNotes, setDamageNotes] = useState("");
  const [damagePhoto, setDamagePhoto] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  // Tab 4: Students & Dynamic Custom Fields
  const [students, setStudents] = useState<any[]>([]);
  const [customFields, setCustomFields] = useState<any[]>([]);
  const [isAddStudentModalOpen, setIsAddStudentModalOpen] = useState(false);
  const [isAddFieldModalOpen, setIsAddFieldModalOpen] = useState(false);

  // New Custom Field Form
  const [newFieldName, setNewFieldName] = useState("");
  const [newFieldLabelEn, setNewFieldLabelEn] = useState("");
  const [newFieldLabelKo, setNewFieldLabelKo] = useState("");
  const [newFieldType, setNewFieldType] = useState("TEXT");
  const [newFieldOptions, setNewFieldOptions] = useState("");
  const [newFieldRequired, setNewFieldRequired] = useState(false);

  // Tab 5: Settings States
  const [settings, setSettings] = useState<any>({});
  const [autoApproval, setAutoApproval] = useState("AUTO");
  const [bannerTitleEn, setBannerTitleEn] = useState("");
  const [bannerDescEn, setBannerDescEn] = useState("");
  const [popupActive, setPopupActive] = useState(true);
  const [popupTitleEn, setPopupTitleEn] = useState("");
  const [popupContentEn, setPopupContentEn] = useState("");

  useEffect(() => {
    fetch("/api/auth/me")
      .then((res) => res.json())
      .then((data) => {
        if (!data.user || (data.user.role !== "SUPER_ADMIN" && data.user.role !== "LAB_ASSISTANT")) {
          router.push("/login");
          return;
        }
        setCurrentUser(data.user);
        loadAllData();
      });
  }, []);

  const loadAllData = () => {
    setLoading(true);
    Promise.all([
      fetch("/api/equipment").then((r) => r.json()),
      fetch("/api/equipment/categories").then((r) => r.json()),
      fetch("/api/reservations?all=true").then((r) => r.json()),
      fetch("/api/students").then((r) => r.json()),
      fetch("/api/custom-fields").then((r) => r.json()),
      fetch("/api/settings").then((r) => r.json()),
    ])
      .then(([eq, cat, res, stu, cf, set]) => {
        if (eq.models) setModels(eq.models);
        if (cat.categories) setCategories(cat.categories);
        if (res.reservations) setReservations(res.reservations);
        if (stu.students) setStudents(stu.students);
        if (cf.fields) setCustomFields(cf.fields);
        if (set.settings) {
          setSettings(set.settings);
          setAutoApproval(set.settings.approval_mode || "AUTO");
          setBannerTitleEn(set.settings.notice_banner?.title_en || "");
          setBannerDescEn(set.settings.notice_banner?.desc_en || "");
          setPopupActive(set.settings.popup_notice?.active ?? true);
          setPopupTitleEn(set.settings.popup_notice?.title_en || "");
          setPopupContentEn(set.settings.popup_notice?.content_en || "");
        }
      })
      .finally(() => setLoading(false));
  };

  // 1. Bulk Excel Upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/equipment/bulk-upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Upload failed");

      alert(`✅ ${data.message}`);
      setIsUploadModalOpen(false);
      loadAllData();
    } catch (err: any) {
      alert("❌ Upload Error: " + err.message);
    }
  };

  // 2. Add Single Equipment Model
  const handleAddEquipment = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/equipment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subcategoryId: newSubcatId,
          brand: newBrand,
          modelName: newModelName,
          totalQuantity: newQuantity,
          remarks: newRemarks,
          targetAudience: newAudience,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to add");

      alert("Equipment added successfully!");
      setIsAddEquipmentModalOpen(false);
      loadAllData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  // 3. Delete Equipment Model
  const handleDeleteEquipment = async (id: string) => {
    if (!confirm("Are you sure you want to delete this equipment model?")) return;
    try {
      const res = await fetch(`/api/equipment?id=${id}`, { method: "DELETE" });
      if (res.ok) {
        alert("Equipment deleted.");
        loadAllData();
      }
    } catch (e: any) {
      alert(e.message);
    }
  };

  // 4. Reservation Status Action
  const handleReservationAction = async (id: string, action: string, extra: any = {}) => {
    try {
      const res = await fetch("/api/reservations", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, action, ...extra }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Action failed");

      alert(`Reservation updated: ${action}`);
      loadAllData();
    } catch (e: any) {
      alert(e.message);
    }
  };

  // 5. Digital Signature Canvas Helpers
  const startDrawing = (e: any) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches?.[0]?.clientX) - rect.left;
    const y = (e.clientY || e.touches?.[0]?.clientY) - rect.top;
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e: any) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches?.[0]?.clientX) - rect.left;
    const y = (e.clientY || e.touches?.[0]?.clientY) - rect.top;
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  // 6. Complete Check-out Desk Operation
  const handleCompleteCheckout = async () => {
    if (!canvasRef.current) return;
    const signatureDataUrl = canvasRef.current.toDataURL("image/png");

    try {
      const res = await fetch("/api/operations/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reservationId: activeResForDesk.id,
          checkoutNotes: deskNotes,
          signatureDataUrl,
          signerName: activeResForDesk.user.fullName,
          additionalBarcodeIds: onSiteBarcode ? [onSiteBarcode] : [],
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Checkout failed");

      alert("✅ Check-out and signature recorded successfully!");
      setActiveResForDesk(null);
      loadAllData();
    } catch (e: any) {
      alert(e.message);
    }
  };

  // 7. Complete Check-in Desk Operation (Late check & damage)
  const handleCompleteCheckin = async () => {
    if (!canvasRef.current) return;
    const signatureDataUrl = canvasRef.current.toDataURL("image/png");

    try {
      const res = await fetch("/api/operations/checkin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reservationId: activeResForDesk.id,
          checkinNotes: deskNotes,
          signatureDataUrl,
          signerName: activeResForDesk.user.fullName,
          damageReport: {
            isDamaged,
            notes: damageNotes,
            photoUrl: damagePhoto,
          },
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Checkin failed");

      alert(`✅ ${data.message}`);
      setActiveResForDesk(null);
      loadAllData();
    } catch (e: any) {
      alert(e.message);
    }
  };

  // 8. Add Dynamic Custom Field
  const handleAddCustomField = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const optionsArray = newFieldOptions
        ? newFieldOptions.split(",").map((s) => s.trim())
        : undefined;

      const res = await fetch("/api/custom-fields", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fieldName: newFieldName,
          labelEn: newFieldLabelEn,
          labelKo: newFieldLabelKo,
          fieldType: newFieldType,
          options: optionsArray,
          isRequired: newFieldRequired,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to create field");

      alert("Dynamic custom field created!");
      setIsAddFieldModalOpen(false);
      setNewFieldName("");
      setNewFieldLabelEn("");
      loadAllData();
    } catch (e: any) {
      alert(e.message);
    }
  };

  // 9. Save System Settings
  const handleSaveSettings = async () => {
    try {
      await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: "approval_mode", value: autoApproval }),
      });

      await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          key: "notice_banner",
          value: { title_en: bannerTitleEn, desc_en: bannerDescEn },
        }),
      });

      await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          key: "popup_notice",
          value: { active: popupActive, title_en: popupTitleEn, content_en: popupContentEn },
        }),
      });

      alert("Settings saved successfully!");
      loadAllData();
    } catch (e: any) {
      alert(e.message);
    }
  };

  if (loading || !currentUser) {
    return <div className="text-center py-20 text-slate-400">Loading Admin Dashboard...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold mb-2">
            CAS 5106 Lab Administration
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">Admin Operations Console</h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-1">
            Manage 135+ Film & VFX assets, digital sign-offs, dynamic student schema, and override policies
          </p>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="/api/equipment/export"
            className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <Download className="w-4 h-4" />
            <span>Export Equipment Excel</span>
          </a>
          <a
            href="/api/students/export"
            className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export Students Excel</span>
          </a>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab("equipment")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === "equipment" ? "bg-blue-600 text-white shadow-sm" : "bg-white text-slate-600 hover:bg-slate-100"
          }`}
        >
          <Package className="w-4 h-4" />
          <span>1. Equipment & Bulk Import ({models.length})</span>
        </button>

        <button
          onClick={() => setActiveTab("reservations")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === "reservations" ? "bg-blue-600 text-white shadow-sm" : "bg-white text-slate-600 hover:bg-slate-100"
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>2. Reservations & Approval ({reservations.length})</span>
        </button>

        <button
          onClick={() => setActiveTab("operations")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === "operations" ? "bg-blue-600 text-white shadow-sm" : "bg-white text-slate-600 hover:bg-slate-100"
          }`}
        >
          <CheckSquare className="w-4 h-4" />
          <span>3. Field Check-out / In Desk</span>
        </button>

        <button
          onClick={() => setActiveTab("students")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === "students" ? "bg-blue-600 text-white shadow-sm" : "bg-white text-slate-600 hover:bg-slate-100"
          }`}
        >
          <Users className="w-4 h-4" />
          <span>4. Students & Dynamic Fields</span>
        </button>

        <button
          onClick={() => setActiveTab("settings")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === "settings" ? "bg-blue-600 text-white shadow-sm" : "bg-white text-slate-600 hover:bg-slate-100"
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>5. System Settings</span>
        </button>
      </div>

      {/* ============================================================== */}
      {/* TAB 1: EQUIPMENT INVENTORY & BULK IMPORT */}
      {/* ============================================================== */}
      {activeTab === "equipment" && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200">
            <div className="flex items-center gap-2 flex-1">
              <Search className="w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search equipment by model, brand, or remarks..."
                value={equipmentSearch}
                onChange={(e) => setEquipmentSearch(e.target.value)}
                className="w-full text-xs outline-none bg-transparent"
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsUploadModalOpen(true)}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-sm"
              >
                <Upload className="w-4 h-4" />
                <span>Bulk Import Excel</span>
              </button>
              <button
                onClick={() => setIsAddEquipmentModalOpen(true)}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>Add Equipment</span>
              </button>
            </div>
          </div>

          {/* Equipment Table */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold">
                  <tr>
                    <th className="py-3 px-4">Category & Subcategory</th>
                    <th className="py-3 px-4">Brand</th>
                    <th className="py-3 px-4">Model Name</th>
                    <th className="py-3 px-4">Total / Avail</th>
                    <th className="py-3 px-4">Audience</th>
                    <th className="py-3 px-4">Remarks & Accessories</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {models
                    .filter((m) =>
                      equipmentSearch
                        ? m.modelName.toLowerCase().includes(equipmentSearch.toLowerCase()) ||
                          m.brand.toLowerCase().includes(equipmentSearch.toLowerCase())
                        : true
                    )
                    .map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50/80 transition">
                        <td className="py-3 px-4">
                          <span className="font-semibold text-slate-800">
                            {item.subcategory?.category?.nameEn}
                          </span>
                          <span className="text-slate-400 block text-[10px]">
                            {item.subcategory?.nameEn}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-medium text-slate-600">{item.brand}</td>
                        <td className="py-3 px-4 font-bold text-slate-900">{item.modelName}</td>
                        <td className="py-3 px-4">
                          <span className="font-bold text-emerald-600">{item.availableQuantity}</span> /{" "}
                          <span className="text-slate-500">{item.totalQuantity}</span>
                        </td>
                        <td className="py-3 px-4">
                          {item.targetAudience === "CERTIFIED" ? (
                            <span className="px-2 py-0.5 rounded bg-amber-50 text-amber-800 font-semibold text-[10px] border border-amber-200">
                              Certified Only
                            </span>
                          ) : (
                            <span className="text-slate-500 text-[10px]">All Students</span>
                          )}
                        </td>
                        <td className="py-3 px-4 max-w-xs truncate text-slate-500 text-[11px]" title={item.remarks}>
                          {item.remarks || "-"}
                        </td>
                        <td className="py-3 px-4 text-right space-x-2">
                          <button
                            onClick={() => setSelectedBarcodeItem(item)}
                            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg"
                            title="Generate QR / Barcodes"
                          >
                            <QrCode className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteEquipment(item.id)}
                            className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 2: RESERVATIONS & APPROVAL */}
      {/* ============================================================== */}
      {activeTab === "reservations" && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {["ALL", "SUBMITTED", "PROF_APPROVED", "CONFIRMED", "CHECKED_OUT", "RETURNED", "CANCELLED"].map((st) => (
              <button
                key={st}
                onClick={() => setResStatusFilter(st)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                  resStatusFilter === st ? "bg-blue-600 text-white" : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-50"
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {reservations
              .filter((r) => (resStatusFilter === "ALL" ? true : r.status === resStatusFilter))
              .map((res) => (
                <div key={res.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b pb-3 text-xs">
                    <div>
                      <span className="font-bold text-blue-700">{res.reservationNo}</span> •{" "}
                      <span className="font-semibold text-slate-900">{res.projectTitle}</span> (
                      {res.user?.fullName} - {res.user?.studentId})
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-full font-bold bg-slate-100 text-slate-700">
                        {res.status}
                      </span>
                    </div>
                  </div>

                  <div className="text-xs text-slate-600 flex flex-wrap gap-4">
                    <div>
                      Pickup: <strong>{new Date(res.rentalStartTime).toLocaleDateString()} {new Date(res.rentalStartTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</strong>
                    </div>
                    <div>
                      Return Due: <strong>{new Date(res.returnDueTime).toLocaleDateString()}</strong>
                    </div>
                    <div>
                      Items: <strong>{res.items?.map((it: any) => `${it.model?.modelName} (x${it.quantity})`).join(", ")}</strong>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t text-xs">
                    {res.status === "SUBMITTED" && (
                      <button
                        onClick={() => handleReservationAction(res.id, "PROF_APPROVE")}
                        className="px-3 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-lg font-semibold"
                      >
                        Prof. Approve
                      </button>
                    )}

                    {(res.status === "SUBMITTED" || res.status === "PROF_APPROVED") && (
                      <button
                        onClick={() => handleReservationAction(res.id, "ADMIN_CONFIRM")}
                        className="px-3 py-1.5 bg-emerald-600 text-white hover:bg-emerald-700 rounded-lg font-semibold"
                      >
                        Admin Final Confirm
                      </button>
                    )}

                    {res.status === "CONFIRMED" && (
                      <button
                        onClick={() => {
                          setActiveResForDesk(res);
                          setDeskAction("CHECKOUT");
                          setActiveTab("operations");
                        }}
                        className="px-3 py-1.5 bg-indigo-600 text-white hover:bg-indigo-700 rounded-lg font-semibold"
                      >
                        Open Check-out Desk
                      </button>
                    )}

                    {res.status === "CHECKED_OUT" && (
                      <button
                        onClick={() => {
                          setActiveResForDesk(res);
                          setDeskAction("CHECKIN");
                          setActiveTab("operations");
                        }}
                        className="px-3 py-1.5 bg-amber-600 text-white hover:bg-amber-700 rounded-lg font-semibold"
                      >
                        Open Check-in Return Desk
                      </button>
                    )}

                    <button
                      onClick={() => handleReservationAction(res.id, "REJECT")}
                      className="px-3 py-1.5 bg-red-50 text-red-700 hover:bg-red-100 rounded-lg font-semibold"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 3: FIELD OPERATIONS (DESK TABLET CANVAS & BARCODE) */}
      {/* ============================================================== */}
      {activeTab === "operations" && (
        <div className="space-y-6">
          {!activeResForDesk ? (
            <div className="bg-white p-12 text-center rounded-3xl border border-slate-200 text-slate-500 text-xs">
              <p className="text-sm font-semibold text-slate-700 mb-2">No active reservation selected for Field Desk.</p>
              <p>Go to Tab 2 (Reservations) and click "Open Check-out Desk" or "Open Check-in Desk".</p>
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
              <div className="flex items-center justify-between border-b pb-4">
                <div>
                  <span className="text-xs font-bold text-blue-600 uppercase">
                    Field Desk • {deskAction === "CHECKOUT" ? "Check-out (대여 반출)" : "Check-in (반납 검수)"}
                  </span>
                  <h2 className="text-xl font-bold text-slate-900">
                    {activeResForDesk.reservationNo} - {activeResForDesk.user?.fullName} ({activeResForDesk.user?.studentId})
                  </h2>
                </div>
                <button
                  onClick={() => setActiveResForDesk(null)}
                  className="px-3 py-1.5 bg-slate-100 rounded-lg text-xs font-semibold"
                >
                  Exit Desk
                </button>
              </div>

              {/* Items to verify */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Equipment List to Verify:
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {activeResForDesk.items?.map((it: any) => (
                    <div key={it.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
                      <div className="font-bold text-slate-900">{it.model?.modelName}</div>
                      <div className="text-slate-500">
                        {it.model?.brand} • Quantity: {it.quantity}
                      </div>
                      {it.equipmentItem && (
                        <div className="text-[11px] font-mono text-blue-700 bg-blue-50 px-2 py-0.5 rounded inline-block">
                          Assigned Barcode: {it.equipmentItem.barcodeId}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Check-in Damage and Late Checking */}
              {deskAction === "CHECKIN" && (
                <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 space-y-3 text-xs">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="damageToggle"
                      checked={isDamaged}
                      onChange={(e) => setIsDamaged(e.target.checked)}
                      className="rounded text-amber-600"
                    />
                    <label htmlFor="damageToggle" className="font-bold text-amber-900">
                      Report Damage / Needs Repair (파손 또는 수리 필요 여부)
                    </label>
                  </div>

                  {isDamaged && (
                    <div className="space-y-2 pt-2 border-t border-amber-200">
                      <textarea
                        placeholder="Describe damage details..."
                        value={damageNotes}
                        onChange={(e) => setDamageNotes(e.target.value)}
                        className="w-full p-2 border border-amber-300 rounded-xl bg-white"
                        rows={2}
                      />
                      <p className="text-[11px] text-amber-700">
                        * Damaged item will be switched to UNDER_REPAIR in real-time, and subsequent booked students will receive notice.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Notes */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Manager Inspection Notes (관리자 상태 점검 코멘트)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Checked all cables, battery 100%, clean sensor"
                  value={deskNotes}
                  onChange={(e) => setDeskNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              {/* Digital Signature Pad (Specification 4-(6)) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-900">
                    Student Digital Signature (서약서 전자 서명 패드) *
                  </label>
                  <button
                    type="button"
                    onClick={clearCanvas}
                    className="text-xs text-blue-600 hover:underline font-semibold"
                  >
                    Clear Signature
                  </button>
                </div>
                <div className="border-2 border-dashed border-slate-300 rounded-2xl bg-white overflow-hidden touch-none">
                  <canvas
                    ref={canvasRef}
                    width={600}
                    height={180}
                    className="w-full h-44 cursor-crosshair"
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onTouchStart={startDrawing}
                    onTouchMove={draw}
                    onTouchEnd={stopDrawing}
                  />
                </div>
                <p className="text-[11px] text-slate-400">
                  Touch pen or finger on iPad/Tablet to sign official equipment custody agreement.
                </p>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                {deskAction === "CHECKOUT" ? (
                  <button
                    onClick={handleCompleteCheckout}
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20"
                  >
                    Complete Check-out & Save PDF Agreement
                  </button>
                ) : (
                  <button
                    onClick={handleCompleteCheckin}
                    className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-500/20"
                  >
                    Complete Check-in Inspection & Archive Document
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 4: STUDENTS & DYNAMIC CUSTOM FIELDS (KEY REQUIREMENT 3) */}
      {/* ============================================================== */}
      {activeTab === "students" && (
        <div className="space-y-6">
          {/* Dynamic Custom Fields Section */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-3">
              <div>
                <h3 className="font-bold text-base text-slate-900">
                  Dynamic Registration & Profile Fields (동적 커스텀 필드 엔진)
                </h3>
                <p className="text-xs text-slate-500">
                  Requirement 3: Backend admin can add, remove, and manage custom registration fields (e.g. Major, WeChat ID, Kakao ID)
                </p>
              </div>
              <button
                onClick={() => setIsAddFieldModalOpen(true)}
                className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 self-start sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Add Custom Field</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
              {customFields.map((f) => (
                <div key={f.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">{f.labelEn}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 font-mono">
                      {f.fieldType}
                    </span>
                  </div>
                  <div className="text-slate-500 text-[11px]">
                    Identifier: <code className="text-slate-700">{f.fieldName}</code>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Required: {f.isRequired ? "Yes" : "No"} • Show in Sign-up: {f.isVisibleOnRegister ? "Yes" : "No"}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Student Directory Table */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h3 className="font-bold text-base text-slate-900">Enrolled Students & Whitelist ({students.length})</h3>
                <p className="text-xs text-slate-500">IC class enrolled students, graduate permissions, and certified badges</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <tr>
                    <th className="py-2.5 px-3">Student ID</th>
                    <th className="py-2.5 px-3">Full Name</th>
                    <th className="py-2.5 px-3">Email & Phone</th>
                    <th className="py-2.5 px-3">Role</th>
                    <th className="py-2.5 px-3">Certified</th>
                    <th className="py-2.5 px-3">Penalties</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {students.map((stu) => (
                    <tr key={stu.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-800">{stu.studentId}</td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900">{stu.fullName}</td>
                      <td className="py-2.5 px-3 text-slate-500">
                        {stu.email} • {stu.phone}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-semibold">
                          {stu.role === "STUDENT_GRAD" ? "Graduate" : "Undergrad"}
                        </span>
                      </td>
                      <td className="py-2.5 px-3">
                        {stu.isCertified ? (
                          <span className="text-emerald-700 font-bold text-[10px]">Trained (Prof. Yoon)</span>
                        ) : (
                          <span className="text-slate-400 text-[10px]">Standard</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3">
                        {stu.penalties?.length > 0 ? (
                          <span className="text-red-600 font-bold text-[10px]">Suspended</span>
                        ) : (
                          <span className="text-emerald-600 text-[10px]">Clear</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 5: SYSTEM SETTINGS */}
      {/* ============================================================== */}
      {activeTab === "settings" && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6 max-w-3xl">
          <div className="border-b pb-4">
            <h2 className="text-lg font-bold text-slate-900">System Operations & Notice Policies</h2>
            <p className="text-xs text-slate-500">Manage approval automation and portal announcements</p>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Faculty Approval Workflow (교수 승인 모드)
              </label>
              <select
                value={autoApproval}
                onChange={(e) => setAutoApproval(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white"
              >
                <option value="AUTO">AUTO: Automatically verify during semester (학기 중 자동 승인)</option>
                <option value="MANUAL">MANUAL: Require manual faculty sign-off in vacation (방학 중 수동 승인)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">Portal Hero Banner Title (English)</label>
              <input
                type="text"
                value={bannerTitleEn}
                onChange={(e) => setBannerTitleEn(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">Portal Hero Banner Description</label>
              <textarea
                value={bannerDescEn}
                onChange={(e) => setBannerDescEn(e.target.value)}
                rows={2}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl"
              />
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800">Operational Holiday Popup Alert</span>
                <input
                  type="checkbox"
                  checked={popupActive}
                  onChange={(e) => setPopupActive(e.target.checked)}
                  className="rounded text-blue-600"
                />
              </div>
              <input
                type="text"
                placeholder="Popup Title"
                value={popupTitleEn}
                onChange={(e) => setPopupTitleEn(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white"
              />
              <textarea
                placeholder="Popup Content (English / Chinese)..."
                value={popupContentEn}
                onChange={(e) => setPopupContentEn(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white"
              />
            </div>

            <button
              onClick={handleSaveSettings}
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-md shadow-blue-500/20"
            >
              Save Settings
            </button>
          </div>
        </div>
      )}

      {/* Modal: Bulk Excel Upload */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="font-bold text-base text-slate-900">Bulk Import Equipment Excel</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Upload existing equipment spreadsheets (like <code>Dept. of Film and VFX Equipment.xlsx</code>). Merged category cells are automatically resolved.
            </p>
            <input
              type="file"
              accept=".xlsx, .xls"
              onChange={handleFileUpload}
              className="w-full text-xs file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
            />
            <div className="flex justify-end">
              <button
                onClick={() => setIsUploadModalOpen(false)}
                className="px-4 py-2 bg-slate-100 rounded-xl text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add Custom Field */}
      {isAddFieldModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <form onSubmit={handleAddCustomField} className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl text-xs">
            <h3 className="font-bold text-base text-slate-900">Add New Dynamic Custom Field</h3>
            <div>
              <label className="block font-semibold mb-1">Field Identifier (Code Name) *</label>
              <input
                type="text"
                required
                placeholder="e.g. visa_type, advisor_name, dorm_room"
                value={newFieldName}
                onChange={(e) => setNewFieldName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">English Label *</label>
              <input
                type="text"
                required
                placeholder="e.g. Visa Status / Major"
                value={newFieldLabelEn}
                onChange={(e) => setNewFieldLabelEn(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">Korean Label</label>
              <input
                type="text"
                placeholder="e.g. 비자 상태 / 소속 학과"
                value={newFieldLabelKo}
                onChange={(e) => setNewFieldLabelKo(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">Field Type</label>
              <select
                value={newFieldType}
                onChange={(e) => setNewFieldType(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white"
              >
                <option value="TEXT">Text Input</option>
                <option value="SELECT">Select Dropdown</option>
                <option value="NUMBER">Number</option>
                <option value="WEBCAM_IMAGE">Webcam / Photo</option>
              </select>
            </div>
            {newFieldType === "SELECT" && (
              <div>
                <label className="block font-semibold mb-1">Options (comma separated)</label>
                <input
                  type="text"
                  placeholder="Option 1, Option 2, Option 3"
                  value={newFieldOptions}
                  onChange={(e) => setNewFieldOptions(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
            )}
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="reqCheck"
                checked={newFieldRequired}
                onChange={(e) => setNewFieldRequired(e.target.checked)}
              />
              <label htmlFor="reqCheck">Mandatory Field (필수 입력 항목)</label>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddFieldModalOpen(false)}
                className="px-4 py-2 bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold"
              >
                Create Field
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: Add Single Equipment */}
      {isAddEquipmentModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <form onSubmit={handleAddEquipment} className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl text-xs">
            <h3 className="font-bold text-base text-slate-900">Add Equipment Model</h3>
            <div>
              <label className="block font-semibold mb-1">Category & Subcategory *</label>
              <select
                required
                value={newSubcatId}
                onChange={(e) => setNewSubcatId(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white"
              >
                <option value="">-- Select Subcategory --</option>
                {categories.map((c) =>
                  c.subcategories?.map((s: any) => (
                    <option key={s.id} value={s.id}>
                      {c.nameEn} › {s.nameEn}
                    </option>
                  ))
                )}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold mb-1">Brand *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Sony, Canon, TILTA"
                  value={newBrand}
                  onChange={(e) => setNewBrand(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Model Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. FX3, MB-T12"
                  value={newModelName}
                  onChange={(e) => setNewModelName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold mb-1">Quantity (보유 수량) *</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={newQuantity}
                  onChange={(e) => setNewQuantity(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Target Audience</label>
                <select
                  value={newAudience}
                  onChange={(e) => setNewAudience(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white"
                >
                  <option value="ALL">All Students (Standard)</option>
                  <option value="CERTIFIED">Certified Only (Prof. Yoon Training)</option>
                  <option value="GRAD">Graduate Students Only</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block font-semibold mb-1">Remarks & Package Components</label>
              <textarea
                placeholder="Batteries, charger, memory cards, case, cables..."
                value={newRemarks}
                onChange={(e) => setNewRemarks(e.target.value)}
                rows={2}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddEquipmentModalOpen(false)}
                className="px-4 py-2 bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold"
              >
                Save Equipment
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: Barcode QR Viewer / Print */}
      {selectedBarcodeItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <span className="text-xs text-blue-600 font-semibold uppercase">{selectedBarcodeItem.brand}</span>
                <h3 className="text-base font-bold text-slate-900">{selectedBarcodeItem.modelName}</h3>
              </div>
              <button onClick={() => setSelectedBarcodeItem(null)} className="p-1 rounded-lg text-slate-400">
                ✕
              </button>
            </div>

            <div className="space-y-3 max-h-72 overflow-y-auto">
              <p className="text-xs text-slate-500">Asset Units ({selectedBarcodeItem.items?.length || 0}):</p>
              <div className="grid grid-cols-2 gap-2">
                {selectedBarcodeItem.items?.map((it: any) => (
                  <div key={it.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50 text-xs space-y-1">
                    <span className="font-mono font-bold text-blue-700 block">{it.barcodeId}</span>
                    <span className="text-[10px] text-slate-500">Status: {it.status}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-between items-center pt-3 border-t">
              <span className="text-xs text-slate-400">Specification 2-(5): QR & Barcode generation</span>
              <button
                onClick={() => window.print()}
                className="px-4 py-2 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Print Labels</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
