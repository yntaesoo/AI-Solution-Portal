const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");
const XLSX = require("xlsx");

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Starting Database Seed for DSU IC Equipment Booking System...");

  // 1. Create Default Super Admin & Lab Staff
  const adminPassword = await bcrypt.hash("admin1234", 10);
  const admin = await prisma.user.upsert({
    where: { studentId: "ADMIN001" },
    update: {},
    create: {
      studentId: "ADMIN001",
      fullName: "Lab Manager (IC Lab)",
      email: "ic.lab@dongseo.ac.kr",
      phone: "051-320-2000",
      passwordHash: adminPassword,
      role: "SUPER_ADMIN",
      status: "ACTIVE",
    },
  });
  console.log("✅ Super Admin created:", admin.studentId);

  // 2. Create Faculty User (Prof. Yoon - CAS 5106 Film & VFX)
  const profPassword = await bcrypt.hash("prof1234", 10);
  const faculty = await prisma.user.upsert({
    where: { studentId: "PROF_YOON" },
    update: {},
    create: {
      studentId: "PROF_YOON",
      fullName: "Prof. Yoon (Film & VFX)",
      email: "prof.yoon@dongseo.ac.kr",
      phone: "051-320-2114",
      passwordHash: profPassword,
      role: "FACULTY",
      status: "ACTIVE",
    },
  });
  console.log("✅ Faculty created:", faculty.studentId);

  // 3. Create Sample Students (Undergrad, Grad English Track, Certified)
  const studentPassword = await bcrypt.hash("student1234", 10);
  const student1 = await prisma.user.upsert({
    where: { studentId: "20240001" },
    update: {},
    create: {
      studentId: "20240001",
      fullName: "Alex Johnson (International Student)",
      email: "alex@dsu.kr",
      phone: "010-1234-5678",
      passwordHash: studentPassword,
      role: "STUDENT_UNDERGRAD",
      status: "ACTIVE",
      isCertified: true, // Trained by Prof. Yoon
    },
  });

  const student2 = await prisma.user.upsert({
    where: { studentId: "20240002" },
    update: {},
    create: {
      studentId: "20240002",
      fullName: "Zhang Wei (Grad Visual Contents)",
      email: "zhangwei@dsu.kr",
      phone: "010-9876-5432",
      passwordHash: studentPassword,
      role: "STUDENT_GRAD",
      status: "ACTIVE",
      isCertified: false,
    },
  });
  console.log("✅ Sample Students created:", student1.studentId, student2.studentId);

  // 4. Create Dynamic Custom Field Definitions (Admin can add/remove these anytime!)
  const customFields = [
    {
      fieldName: "major",
      labelEn: "Department / Major",
      labelKo: "소속 학과",
      labelZh: "所属院系",
      fieldType: "SELECT",
      optionsJson: JSON.stringify([
        "Dept. of Film and VFX (영화영상학과)",
        "Dept. of Digital Design (디지털디자인학부)",
        "Dept. of Computer Engineering (컴퓨터공학과)",
        "Dept. of Visual Contents (비주얼콘텐츠학과)",
        "Other IC Departments (기타 학과)",
      ]),
      isRequired: true,
      isVisibleOnRegister: true,
      isEditableByUser: true,
      displayOrder: 1,
    },
    {
      fieldName: "wechat_id",
      labelEn: "WeChat ID (微信)",
      labelKo: "위챗 아이디",
      labelZh: "微信号",
      fieldType: "TEXT",
      optionsJson: null,
      isRequired: false,
      isVisibleOnRegister: true,
      isEditableByUser: true,
      displayOrder: 2,
    },
    {
      fieldName: "kakao_id",
      labelEn: "KakaoTalk ID",
      labelKo: "카카오톡 아이디",
      labelZh: "KakaoTalk 账号",
      fieldType: "TEXT",
      optionsJson: null,
      isRequired: false,
      isVisibleOnRegister: true,
      isEditableByUser: true,
      displayOrder: 3,
    },
    {
      fieldName: "nationality",
      labelEn: "Nationality",
      labelKo: "국적",
      labelZh: "国籍",
      fieldType: "TEXT",
      optionsJson: null,
      isRequired: false,
      isVisibleOnRegister: true,
      isEditableByUser: true,
      displayOrder: 4,
    },
    {
      fieldName: "profile_photo",
      labelEn: "Profile Photo (Webcam / Upload)",
      labelKo: "프로필 사진 (웹캠 촬영/업로드)",
      labelZh: "个人照片（摄像头拍摄/上传）",
      fieldType: "WEBCAM_IMAGE",
      optionsJson: null,
      isRequired: false,
      isVisibleOnRegister: true,
      isEditableByUser: true,
      displayOrder: 5,
    },
  ];

  for (const field of customFields) {
    const createdField = await prisma.customFieldDefinition.upsert({
      where: { fieldName: field.fieldName },
      update: field,
      create: field,
    });

    // Populate student1 custom values
    if (field.fieldName === "major") {
      await prisma.userCustomValue.upsert({
        where: {
          userId_fieldId: {
            userId: student1.id,
            fieldId: createdField.id,
          },
        },
        update: { value: "Dept. of Film and VFX (영화영상학과)" },
        create: {
          userId: student1.id,
          fieldId: createdField.id,
          value: "Dept. of Film and VFX (영화영상학과)",
        },
      });
    }
  }
  console.log("✅ Dynamic Custom Fields seeded.");

  // 5. System Settings (Regulations, Notices, Banners)
  const systemSettings = [
    {
      key: "terms_of_service",
      value: JSON.stringify({
        en: `1. All equipment must be handled with extreme care and used strictly for academic purposes.
2. The standard rental period is 3 days. Late returns will incur penalties:
   - 1st Late Return: 1 Month Rental Suspension
   - 2nd Late Return: 1 Semester (6 Months) Rental Suspension
3. Users are personally responsible for any damage or loss during the rental period.
4. Any cancellation must be made at least 1 day before the reservation date. Changes cannot be made after confirmation.`,
        zh: `1. 所有器材必须轻拿轻放，且仅用于教学与学术创作目的。
2. 标准借用期限为 3 天。逾期归还将被处以限制借用处罚：
   - 第一次逾期：暂停借用权限 1 个月
   - 第二次逾期：暂停借用权限 1 学期（6 个月）
3. 借用人对借用期间器材的损坏或遗失承担全责。
4. 如需取消预约，必须在借用日前至少 1 天申请。管理员审核确认后不可更改。`,
      }),
    },
    {
      key: "notice_banner",
      value: JSON.stringify({
        title_en: "DSU International College Equipment Lab (CAS 5106)",
        title_zh: "东西大学 国际学院 器材室（CAS 5106）",
        desc_en: "Operating Hours: Mon - Fri 09:30 - 17:00 (Break: 12:00 - 13:00). Pickups every 30 mins.",
        desc_zh: "开放时间：周一至周五 09:30 - 17:00（午休 12:00 - 13:00）。提货时间以30分钟为单位。",
      }),
    },
    {
      key: "popup_notice",
      value: JSON.stringify({
        active: true,
        title_en: "Holiday & Semester Notice",
        title_zh: "节假日与学期运营通知",
        content_en: "The equipment lab will be closed on official public holidays. Please plan your returns in advance.",
        content_zh: "器材室在法定节假日期间休息。请提前规划您的归还时间。",
      }),
    },
    {
      key: "approval_mode",
      value: "AUTO", // AUTO in semester, MANUAL in vacation
    },
  ];

  for (const s of systemSettings) {
    await prisma.systemSetting.upsert({
      where: { key: s.key },
      update: { value: s.value },
      create: { key: s.key, value: s.value },
    });
  }
  console.log("✅ System Settings initialized.");

  // 6. Automatically Import Initial Equipment from Excel if file exists
  const excelPath = path.join(process.cwd(), "DSUEquipmentList", "Dept. of Film and VFX Equipment.xlsx");
  if (fs.existsSync(excelPath)) {
    console.log("📂 Found initial equipment excel file at:", excelPath);
    const buffer = fs.readFileSync(excelPath);
    const workbook = XLSX.read(buffer, { type: "buffer" });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rawData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

    let currentCategory = "Camera";
    let currentSubcategory = "General";
    let count = 0;

    for (let i = 3; i < rawData.length; i++) {
      const row = rawData[i];
      if (!row || row.length === 0) continue;

      const rawCat = row[0] ? String(row[0]).trim().replace(/\r?\n/g, " ") : null;
      const rawSubcat = row[1] ? String(row[1]).trim().replace(/\r?\n/g, " ") : null;
      const rawBrand = row[2] ? String(row[2]).trim() : "";
      const rawModel = row[3] ? String(row[3]).trim() : "";
      const rawQty = row[4];
      const rawRemarks = row[5] ? String(row[5]).trim() : null;

      if (!rawModel && !rawBrand) continue;

      if (rawCat) currentCategory = rawCat;
      if (rawSubcat) currentSubcategory = rawSubcat;

      const quantity = typeof rawQty === "number" ? rawQty : parseInt(String(rawQty || "1"), 10) || 1;

      let targetAudience = "ALL";
      if (rawRemarks) {
        const lowerRemarks = rawRemarks.toLowerCase();
        if (lowerRemarks.includes("trained") || lowerRemarks.includes("special training") || lowerRemarks.includes("prof. yoon")) {
          targetAudience = "CERTIFIED";
        } else if (lowerRemarks.includes("grad")) {
          targetAudience = "GRAD";
        }
      }

      // Upsert Category
      const cat = await prisma.category.upsert({
        where: { nameEn: currentCategory },
        update: {},
        create: { nameEn: currentCategory, displayOrder: count },
      });

      // Upsert Subcategory
      const subcat = await prisma.subcategory.upsert({
        where: {
          categoryId_nameEn: {
            categoryId: cat.id,
            nameEn: currentSubcategory,
          },
        },
        update: {},
        create: { categoryId: cat.id, nameEn: currentSubcategory, displayOrder: count },
      });

      // Create Model
      const model = await prisma.equipmentModel.create({
        data: {
          subcategoryId: subcat.id,
          brand: rawBrand || "Standard",
          modelName: rawModel || "Item",
          totalQuantity: quantity,
          remarks: rawRemarks,
          targetAudience,
          isAvailable: true,
        },
      });

      // Create individual items
      const catCode = currentCategory.replace(/[^a-zA-Z]/g, "").slice(0, 3).toUpperCase() || "EQP";
      const modelCode = (rawModel || "ITEM").replace(/[^a-zA-Z0-9]/g, "").slice(0, 4).toUpperCase();

      for (let k = 1; k <= quantity; k++) {
        const barcodeId = `DSU-${catCode}-${modelCode}-${String(k).padStart(2, "0")}`;
        await prisma.equipmentItem.upsert({
          where: { barcodeId },
          update: {},
          create: {
            modelId: model.id,
            barcodeId,
            serialNumber: `SN-${barcodeId}`,
            status: "AVAILABLE",
          },
        });
      }
      count++;
    }
    console.log(`✅ Successfully imported ${count} equipment models from Excel!`);
  }

  console.log("🎉 Database Seed Completed Successfully!");
}

main()
  .catch((e) => {
    console.error("❌ Seed Error:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
