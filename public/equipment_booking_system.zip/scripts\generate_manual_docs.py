import os
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml, OxmlElement
from docx.oxml.ns import nsdecls, qn

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    HRFlowable,
    KeepTogether,
)
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# -------------------------------------------------------------
# 1. GENERATE DOCX (Word Document)
# -------------------------------------------------------------
def generate_docx(md_path, docx_path):
    print("Generating DOCX:", docx_path)
    doc = Document()

    # Page Margins
    for section in doc.sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)

    # Base Colors
    BLUE = RGBColor(0, 64, 152)      # DSU Blue #004098
    DARK = RGBColor(30, 41, 59)      # Slate 800
    GRAY = RGBColor(100, 116, 139)   # Slate 500

    # Read Markdown
    with open(md_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # Document Header Title
    title_p = doc.add_paragraph()
    title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_title = title_p.add_run("동서대학교 International College (IC)\n스마트 기자재 예약 관리시스템 사용자 매뉴얼")
    run_title.font.name = "맑은 고딕"
    run_title.font.size = Pt(20)
    run_title.font.bold = True
    run_title.font.color.rgb = BLUE

    sub_p = doc.add_paragraph()
    sub_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_sub = sub_p.add_run("Dongseo University IC Equipment Booking System User Manual (v1.0)")
    run_sub.font.name = "맑은 고딕"
    run_sub.font.size = Pt(11)
    run_sub.font.color.rgb = GRAY

    # Add quick info box
    table = doc.add_table(rows=2, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    
    cell_00 = table.cell(0, 0)
    cell_00.text = "장비실 위치"
    cell_01 = table.cell(0, 1)
    cell_01.text = "동서대학교 CAS관 5106호 (CAS 5106)"
    
    cell_10 = table.cell(1, 0)
    cell_10.text = "외부 접속 URL (Cloudflare Tunnel)"
    cell_11 = table.cell(1, 1)
    cell_11.text = "https://endless-expertise-geographic-flyer.trycloudflare.com"

    for row in table.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                for r in p.runs:
                    r.font.name = "맑은 고딕"
                    r.font.size = Pt(9.5)

    doc.add_paragraph() # Spacer

    in_faq = False
    for line in lines:
        raw = line.strip()
        if not raw:
            continue

        # Skip main markdown title as we already made it
        if raw.startswith("# ") and "사용자 매뉴얼" in raw:
            continue
        if raw.startswith("### (Dongseo University"):
            continue
        if raw.startswith("> **장비실 위치:") or raw.startswith("> **운영 시간:") or raw.startswith("> **시스템 접속"):
            continue

        # Heading 1 (## 2. 학생용 매뉴얼)
        if raw.startswith("## "):
            h = doc.add_heading(level=1)
            h.paragraph_format.space_before = Pt(18)
            h.paragraph_format.space_after = Pt(8)
            run = h.add_run(raw.replace("## ", "").replace("👨‍🎓 ", "").replace("👩‍🏫 ", "").replace("🛠️ ", "").replace("❓ ", "").replace("📌 ", ""))
            run.font.name = "맑은 고딕"
            run.font.size = Pt(14)
            run.font.bold = True
            run.font.color.rgb = BLUE
            continue

        # Heading 2 (### STEP 1...)
        if raw.startswith("### "):
            h = doc.add_heading(level=2)
            h.paragraph_format.space_before = Pt(12)
            h.paragraph_format.space_after = Pt(4)
            run = h.add_run(raw.replace("### ", ""))
            run.font.name = "맑은 고딕"
            run.font.size = Pt(12)
            run.font.bold = True
            run.font.color.rgb = DARK
            continue

        # Heading 3 (#### 탭 1...)
        if raw.startswith("#### "):
            h = doc.add_heading(level=3)
            h.paragraph_format.space_before = Pt(8)
            h.paragraph_format.space_after = Pt(2)
            run = h.add_run(raw.replace("#### ", ""))
            run.font.name = "맑은 고딕"
            run.font.size = Pt(11)
            run.font.bold = True
            run.font.color.rgb = RGBColor(79, 70, 229) # Indigo
            continue

        # Bullet list items
        if raw.startswith("- ") or raw.startswith("* "):
            p = doc.add_paragraph(style='List Bullet')
            p.paragraph_format.space_after = Pt(3)
            clean_text = raw[2:]
            # parse bold text
            parts = re.split(r'(\*\*.*?\*\*)', clean_text)
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    r = p.add_run(part[2:-2])
                    r.font.bold = True
                else:
                    r = p.add_run(part)
                r.font.name = "맑은 고딕"
                r.font.size = Pt(10)
            continue

        # Numbered list items
        if re.match(r'^\d+\.\s', raw):
            p = doc.add_paragraph(style='List Number')
            p.paragraph_format.space_after = Pt(3)
            clean_text = re.sub(r'^\d+\.\s', '', raw)
            parts = re.split(r'(\*\*.*?\*\*)', clean_text)
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    r = p.add_run(part[2:-2])
                    r.font.bold = True
                else:
                    r = p.add_run(part)
                r.font.name = "맑은 고딕"
                r.font.size = Pt(10)
            continue

        # Quotes or Note boxes
        if raw.startswith("> "):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.4)
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(4)
            clean_text = raw[2:].replace("**💡 약관 동의 안내:**", "[💡 약관 동의 안내]").replace("**⚠️ 주의:**", "[⚠️ 주의]")
            r = p.add_run(clean_text)
            r.font.name = "맑은 고딕"
            r.font.size = Pt(9.5)
            r.font.italic = True
            r.font.color.rgb = RGBColor(71, 85, 105)
            continue

        # Regular Paragraph
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(4)
        parts = re.split(r'(\*\*.*?\*\*)', raw)
        for part in parts:
            if part.startswith('**') and part.endswith('**'):
                r = p.add_run(part[2:-2])
                r.font.bold = True
            else:
                r = p.add_run(part)
            r.font.name = "맑은 고딕"
            r.font.size = Pt(10)

    doc.save(docx_path)
    print("DOCX generated successfully:", docx_path)


# -------------------------------------------------------------
# 2. GENERATE PDF (ReportLab with Korean TTF)
# -------------------------------------------------------------
class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_decorations(num_pages)
            super().showPage()
        super().save()

    def draw_page_decorations(self, total_pages):
        self.saveState()
        self.setFont("Malgun", 8)
        self.setFillColor(colors.HexColor("#64748b"))

        # Header (pages > 1)
        if self._pageNumber > 1:
            self.drawString(54, 842 - 36, "동서대학교 International College (IC) 스마트 기자재 예약시스템 사용자 매뉴얼")
            self.setStrokeColor(colors.HexColor("#e2e8f0"))
            self.setLineWidth(0.5)
            self.line(54, 842 - 42, 595 - 54, 842 - 42)

        # Footer
        footer_text = f"Page {self._pageNumber} of {total_pages}"
        self.drawRightString(595 - 54, 36, footer_text)
        self.drawString(54, 36, "CAS Building Room 5106 | ic.lab@dongseo.ac.kr")
        self.setStrokeColor(colors.HexColor("#e2e8f0"))
        self.setLineWidth(0.5)
        self.line(54, 46, 595 - 54, 46)

        self.restoreState()


def generate_pdf(md_path, pdf_path):
    print("Generating PDF:", pdf_path)

    # Register Korean Font
    pdfmetrics.registerFont(TTFont("Malgun", "C:/Windows/Fonts/malgun.ttf"))
    pdfmetrics.registerFont(TTFont("MalgunBold", "C:/Windows/Fonts/malgunbd.ttf"))

    doc = SimpleDocTemplate(
        pdf_path,
        pagesize=A4,
        leftMargin=54,
        rightMargin=54,
        topMargin=54,
        bottomMargin=54,
    )

    styles = getSampleStyleSheet()

    # Custom Korean Typography Styles
    title_style = ParagraphStyle(
        "CoverTitle",
        parent=styles["Normal"],
        fontName="MalgunBold",
        fontSize=18,
        leading=24,
        textColor=colors.HexColor("#004098"),
        alignment=1, # Center
        spaceAfter=6,
    )

    subtitle_style = ParagraphStyle(
        "CoverSubtitle",
        parent=styles["Normal"],
        fontName="Malgun",
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#475569"),
        alignment=1,
        spaceAfter=14,
    )

    h1_style = ParagraphStyle(
        "Header1",
        parent=styles["Normal"],
        fontName="MalgunBold",
        fontSize=13,
        leading=18,
        textColor=colors.HexColor("#004098"),
        spaceBefore=14,
        spaceAfter=6,
        keepWithNext=True,
    )

    h2_style = ParagraphStyle(
        "Header2",
        parent=styles["Normal"],
        fontName="MalgunBold",
        fontSize=11,
        leading=16,
        textColor=colors.HexColor("#1e293b"),
        spaceBefore=10,
        spaceAfter=4,
        keepWithNext=True,
    )

    h3_style = ParagraphStyle(
        "Header3",
        parent=styles["Normal"],
        fontName="MalgunBold",
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#4338ca"),
        spaceBefore=6,
        spaceAfter=2,
        keepWithNext=True,
    )

    body_style = ParagraphStyle(
        "Body",
        parent=styles["Normal"],
        fontName="Malgun",
        fontSize=9,
        leading=14,
        textColor=colors.HexColor("#1e293b"),
        spaceAfter=4,
    )

    bullet_style = ParagraphStyle(
        "Bullet",
        parent=body_style,
        leftIndent=14,
        firstLineIndent=-10,
        spaceAfter=3,
    )

    quote_style = ParagraphStyle(
        "Quote",
        parent=body_style,
        fontName="Malgun",
        fontSize=8.5,
        leading=13,
        textColor=colors.HexColor("#475569"),
        leftIndent=18,
        rightIndent=18,
        spaceBefore=4,
        spaceAfter=6,
    )

    story = []

    # Title Banner
    story.append(Paragraph("동서대학교 International College (IC)<br/>스마트 기자재 예약 관리시스템 사용자 매뉴얼", title_style))
    story.append(Paragraph("Dongseo University IC Equipment Booking System User Manual (v1.0)", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#004098"), spaceBefore=2, spaceAfter=10))

    # Info summary table
    summary_data = [
        [
            Paragraph("<b>장비실 위치</b>", body_style),
            Paragraph("동서대학교 CAS관 5106호 (CAS 5106호 실습실)", body_style),
        ],
        [
            Paragraph("<b>운영 시간</b>", body_style),
            Paragraph("월 ~ 금 09:30 ~ 17:00 (점심시간 12:00 ~ 13:00)", body_style),
        ],
        [
            Paragraph("<b>외부 접속 URL (Cloudflare)</b>", body_style),
            Paragraph("<font color='#004098'><u>https://endless-expertise-geographic-flyer.trycloudflare.com</u></font>", body_style),
        ],
    ]
    t = Table(summary_data, colWidths=[130, 350])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#f8fafc")),
        ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor("#cbd5e1")),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor("#e2e8f0")),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(t)
    story.append(Spacer(1, 10))

    # Read markdown and build flowables
    with open(md_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    for line in lines:
        raw = line.strip()
        if not raw:
            continue

        # Skip headers already added
        if raw.startswith("# ") and "사용자 매뉴얼" in raw:
            continue
        if raw.startswith("### (Dongseo University"):
            continue
        if raw.startswith("> **장비실 위치:") or raw.startswith("> **운영 시간:") or raw.startswith("> **시스템 접속"):
            continue

        # Clean bold tags for ReportLab XML: **text** -> <b>text</b>
        fmt = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', raw)

        # H1
        if raw.startswith("## "):
            clean = fmt.replace("## ", "").replace("👨‍🎓 ", "").replace("👩‍🏫 ", "").replace("🛠️ ", "").replace("❓ ", "").replace("📌 ", "")
            story.append(Paragraph(clean, h1_style))
            continue

        # H2
        if raw.startswith("### "):
            clean = fmt.replace("### ", "")
            story.append(Paragraph(clean, h2_style))
            continue

        # H3
        if raw.startswith("#### "):
            clean = fmt.replace("#### ", "")
            story.append(Paragraph(clean, h3_style))
            continue

        # Bullets
        if raw.startswith("- ") or raw.startswith("* "):
            clean = fmt[2:]
            story.append(Paragraph(f"• {clean}", bullet_style))
            continue

        # Numbered
        if re.match(r'^\d+\.\s', raw):
            story.append(Paragraph(fmt, bullet_style))
            continue

        # Quotes
        if raw.startswith("> "):
            clean = fmt[2:]
            story.append(Paragraph(clean, quote_style))
            continue

        # Regular
        story.append(Paragraph(fmt, body_style))

    doc.build(story, canvasmaker=NumberedCanvas)
    print("PDF generated successfully:", pdf_path)


if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    md_file = os.path.join(base_dir, "USER_MANUAL.md")
    docx_file = os.path.join(base_dir, "USER_MANUAL.docx")
    pdf_file = os.path.join(base_dir, "USER_MANUAL.pdf")

    generate_docx(md_file, docx_file)
    generate_pdf(md_file, pdf_file)
    print("All conversions complete!")
