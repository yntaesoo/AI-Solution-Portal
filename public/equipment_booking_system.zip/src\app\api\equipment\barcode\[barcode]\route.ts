import { NextRequest, NextResponse } from "next/server";
import QRCode from "qrcode";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest, { params }: { params: { barcode: string } }) {
  try {
    const barcode = decodeURIComponent(params.barcode);

    // Look up item in database
    const item = await prisma.equipmentItem.findUnique({
      where: { barcodeId: barcode },
      include: {
        model: {
          include: {
            subcategory: {
              include: { category: true },
            },
          },
        },
      },
    });

    const qrDataUrl = await QRCode.toDataURL(barcode, {
      width: 256,
      margin: 2,
      color: { dark: "#000000", light: "#ffffff" },
    });

    return NextResponse.json({
      barcode,
      qrDataUrl,
      item,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
