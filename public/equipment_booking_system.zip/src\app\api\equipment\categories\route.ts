import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  try {
    const categories = await prisma.category.findMany({
      include: {
        subcategories: {
          include: {
            _count: { select: { models: true } },
          },
          orderBy: { displayOrder: "asc" },
        },
      },
      orderBy: { displayOrder: "asc" },
    });

    return NextResponse.json({ categories });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Admin only." }, { status: 403 });
    }

    const { type, nameEn, nameKo, categoryId } = await req.json();

    if (type === "CATEGORY") {
      const created = await prisma.category.create({
        data: { nameEn: nameEn.trim(), nameKo: nameKo?.trim() },
      });
      return NextResponse.json({ success: true, category: created });
    } else if (type === "SUBCATEGORY") {
      if (!categoryId) {
        return NextResponse.json({ error: "Category ID is required for Subcategory." }, { status: 400 });
      }
      const created = await prisma.subcategory.create({
        data: { categoryId, nameEn: nameEn.trim(), nameKo: nameKo?.trim() },
      });
      return NextResponse.json({ success: true, subcategory: created });
    }

    return NextResponse.json({ error: "Invalid type" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// Migrate equipment and delete category/subcategory (Specification 2-(3))
export async function DELETE(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Admin only." }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const type = searchParams.get("type"); // CATEGORY or SUBCATEGORY
    const id = searchParams.get("id");
    const targetSubcategoryId = searchParams.get("targetSubcategoryId"); // If migrating models

    if (!id || !type) {
      return NextResponse.json({ error: "ID and type are required." }, { status: 400 });
    }

    if (type === "SUBCATEGORY") {
      // If models exist, check if targetSubcategoryId provided
      const modelsCount = await prisma.equipmentModel.count({ where: { subcategoryId: id } });
      if (modelsCount > 0) {
        if (!targetSubcategoryId) {
          return NextResponse.json(
            { error: `This subcategory contains ${modelsCount} equipment items. Please select a target subcategory to migrate them before deletion.` },
            { status: 400 }
          );
        }
        // Migrate models
        await prisma.equipmentModel.updateMany({
          where: { subcategoryId: id },
          data: { subcategoryId: targetSubcategoryId },
        });
      }

      await prisma.subcategory.delete({ where: { id } });
      return NextResponse.json({ success: true, message: "Subcategory deleted and items migrated." });
    } else if (type === "CATEGORY") {
      await prisma.category.delete({ where: { id } });
      return NextResponse.json({ success: true, message: "Category deleted." });
    }

    return NextResponse.json({ error: "Invalid type." }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
