import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { comparePassword, createToken, TOKEN_NAME } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const { studentId, password } = await req.json();

    if (!studentId || !password) {
      return NextResponse.json({ error: "Student ID and password are required." }, { status: 400 });
    }

    const cleanId = String(studentId).trim();

    // Case-insensitive lookup (e.g. admin001 vs ADMIN001 vs Admin001)
    const user = await prisma.user.findFirst({
      where: {
        OR: [
          { studentId: cleanId },
          { studentId: cleanId.toUpperCase() },
          { studentId: cleanId.toLowerCase() },
        ],
      },
      include: {
        penalties: { where: { isActive: true } },
      },
    });

    if (!user) {
      return NextResponse.json({ error: "Invalid Student ID or password." }, { status: 401 });
    }

    const isMatch = await comparePassword(String(password).trim(), user.passwordHash);
    if (!isMatch) {
      return NextResponse.json({ error: "Invalid Student ID or password." }, { status: 401 });
    }

    if (user.status === "BLOCKED") {
      return NextResponse.json({ error: "Your account is disabled. Please contact the lab manager." }, { status: 403 });
    }

    const token = createToken({
      id: user.id,
      studentId: user.studentId,
      fullName: user.fullName,
      email: user.email,
      role: user.role,
      isCertified: user.isCertified,
    });

    const response = NextResponse.json({
      success: true,
      user: {
        id: user.id,
        studentId: user.studentId,
        fullName: user.fullName,
        email: user.email,
        role: user.role,
        isCertified: user.isCertified,
        penalties: user.penalties,
      },
    });

    // IMPORTANT FOR MOBILE BROWSERS:
    // If accessing via HTTP (e.g. http://192.168.0.101:3000), 'secure: true' causes mobile browsers
    // (iOS Safari, Chrome, Samsung) to immediately reject/drop the cookie!
    // Only enable secure if protocol is actually HTTPS.
    const isHttps = req.nextUrl.protocol === "https:";

    response.cookies.set(TOKEN_NAME, token, {
      httpOnly: true,
      secure: isHttps,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    });

    return response;
  } catch (error: any) {
    console.error("Login API error:", error);
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 });
  }
}
