import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const session = await getCurrentUser();
    if (!session) {
      return NextResponse.json({ user: null });
    }

    const user = await prisma.user.findUnique({
      where: { id: session.id },
      include: {
        penalties: {
          where: { isActive: true },
        },
        customValues: {
          include: { field: true },
        },
      },
    });

    if (!user) {
      return NextResponse.json({ user: null });
    }

    return NextResponse.json({
      user: {
        id: user.id,
        studentId: user.studentId,
        fullName: user.fullName,
        email: user.email,
        phone: user.phone,
        role: user.role,
        status: user.status,
        isCertified: user.isCertified,
        profilePhotoUrl: user.profilePhotoUrl,
        penalties: user.penalties,
        customValues: user.customValues,
      },
    });
  } catch (error) {
    return NextResponse.json({ user: null });
  }
}
