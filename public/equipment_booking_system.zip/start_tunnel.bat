@echo off
chcp 65001 > nul
echo ========================================================
echo  Cloudflare Tunnel 외부 모바일 접속 시작
echo  로컬 포트 3000 -> 전 세계 모바일 HTTPS 터널링
echo ========================================================
cloudflared tunnel --url http://localhost:3000
pause
