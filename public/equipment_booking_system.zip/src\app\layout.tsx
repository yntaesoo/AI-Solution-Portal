import type { Metadata, Viewport } from "next";
import "./globals.css";
import Navbar from "@/components/Navbar";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export const metadata: Metadata = {
  title: "DSU IC Equipment Booking System | 동서대 IC 기자재 예약",
  description: "Equipment booking and asset management system for Dongseo University International College",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 flex flex-col font-sans antialiased text-slate-900">
        <Navbar />
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {children}
        </main>
        <footer className="border-t border-slate-200 bg-white py-6 mt-12 text-center text-xs text-slate-500">
          <p>© 2026 Dongseo University International College Equipment Lab (CAS 5106). All rights reserved.</p>
          <p className="mt-1">For urgent inquiries: ic.lab@dongseo.ac.kr | Office: CAS 5106</p>
        </footer>
      </body>
    </html>
  );
}
