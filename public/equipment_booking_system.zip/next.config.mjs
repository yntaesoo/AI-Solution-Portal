/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: false, // For easier canvas & webcam mounting
};

export default nextConfig;
