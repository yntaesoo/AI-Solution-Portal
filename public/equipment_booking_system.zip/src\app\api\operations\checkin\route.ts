import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { applyLatePenalty } from "@/lib/penalty-engine";

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Lab Admin only." }, { status: 403 });
    }

    const body = await req.json();
    const {
      reservationId,
      checkinNotes,
      signatureDataUrl,
      signerName,
      damageReport, // { isDamaged: boolean, notes: string, photoUrl: string, brokenItemIds: string[] }
    } = body;

    if (!reservationId || !signatureDataUrl) {
      return NextResponse.json({ error: "Reservation ID and Digital Signature are required." }, { status: 400 });
    }

    const reservation = await prisma.reservation.findUnique({
      where: { id: reservationId },
      include: {
        items: { include: { equipmentItem: true, model: true } },
        user: true,
      },
    });

    if (!reservation) {
      return NextResponse.json({ error: "Reservation not found." }, { status: 404 });
    }

    const now = new Date();
    // 1. Check if Late (Specification 5-(4))
    const isLate = now > new Date(reservation.returnDueTime);
    let penaltyResult = null;

    if (isLate) {
      penaltyResult = await applyLatePenalty(
        reservation.userId,
        `Late return for reservation ${reservation.reservationNo}. Due: ${new Date(reservation.returnDueTime).toLocaleDateString()}, Returned: ${now.toLocaleDateString()}`
      );
    }

    // 2. Return items to AVAILABLE or mark as UNDER_REPAIR if damaged
    const brokenIds = (damageReport?.brokenItemIds || []) as string[];
    for (const item of reservation.items) {
      if (item.equipmentItemId) {
        const isThisDamaged = brokenIds.includes(item.equipmentItemId) || damageReport?.isDamaged;

        if (isThisDamaged) {
          await prisma.equipmentItem.update({
            where: { id: item.equipmentItemId },
            data: {
              status: "UNDER_REPAIR",
              conditionNotes: damageReport?.notes || "Damaged during return inspection",
              brokenPhotoUrl: damageReport?.photoUrl || null,
            },
          });

          // Log damage incident
          await prisma.auditLog.create({
            data: {
              userId: reservation.userId,
              action: "EQUIPMENT_DAMAGED",
              details: `Equipment ${item.model.modelName} (Barcode: ${item.equipmentItem?.barcodeId}) damaged during return.`,
            },
          });
        } else {
          await prisma.equipmentItem.update({
            where: { id: item.equipmentItemId },
            data: {
              status: "AVAILABLE",
            },
          });
        }
      }
    }

    // 3. Save Return Digital Signature
    await prisma.signatureLog.create({
      data: {
        reservationId: reservation.id,
        signatureType: "CHECKIN",
        signatureDataUrl,
        signerName: signerName || reservation.user.fullName,
      },
    });

    // 4. Update reservation status to RETURNED
    const updated = await prisma.reservation.update({
      where: { id: reservation.id },
      data: {
        status: "RETURNED",
        actualReturnTime: now,
        isLate,
        checkinNotes: checkinNotes || (damageReport?.isDamaged ? "Returned with damage report." : "Returned safely in good condition."),
      },
      include: {
        signatureLogs: true,
      },
    });

    return NextResponse.json({
      success: true,
      message: isLate
        ? `Return completed. Warning: Marked as LATE! Penalty applied (${penaltyResult?.reason}).`
        : "Return inspection and signature completed successfully!",
      reservation: updated,
      isLate,
      penalty: penaltyResult,
    });
  } catch (error: any) {
    console.error("Checkin error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
