const http = require('http');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

function request(options, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : '';
    const req = http.request({
      hostname: 'localhost',
      port: 3000,
      headers: {
        'Content-Type': 'application/json',
        ...(data ? { 'Content-Length': Buffer.byteLength(data) } : {}),
        ...options.headers
      },
      ...options
    }, res => {
      let resBody = '';
      res.on('data', chunk => resBody += chunk);
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: JSON.parse(resBody || '{}') }));
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

async function verify() {
  // Clean test bookings
  await prisma.reservation.deleteMany({ where: { projectTitle: { contains: 'Verification' } } });

  // 1. Student Login
  const stuLogin = await request({ path: '/api/auth/login', method: 'POST' }, { studentId: '20240001', password: 'student1234' });
  const stuCookie = stuLogin.headers['set-cookie'][0].split(';')[0];
  console.log('1. Student Logged in:', stuLogin.body.user.fullName);

  // 2. Fetch Models and Faculty
  const eqRes = await request({ path: '/api/equipment', method: 'GET' });
  const model = eqRes.body.models[0];

  const facRes = await request({ path: '/api/faculty', method: 'GET' });
  const prof = facRes.body.faculty.find(f => f.studentId === 'PROF_YOON');
  console.log('2. Target Model:', model.modelName, '| Target Faculty:', prof.fullName);

  // 3. Student Creates New Booking
  const bookingPayload = {
    facultyId: prof.id,
    projectType: 'INDIVIDUAL',
    projectTitle: 'Verification Film Shoot Scene',
    rentalStartTime: '2026-10-18T10:00:00',
    items: [{ modelId: model.id, quantity: 1 }]
  };
  const bookRes = await request({
    path: '/api/reservations',
    method: 'POST',
    headers: { 'Cookie': stuCookie }
  }, bookingPayload);

  console.log('3. Student Created Reservation:', bookRes.body.reservation.reservationNo, 'Status:', bookRes.body.reservation.status);

  // 4. Prof. Yoon Logs in
  const profLogin = await request({ path: '/api/auth/login', method: 'POST' }, { studentId: 'PROF_YOON', password: 'prof1234' });
  const profCookie = profLogin.headers['set-cookie'][0].split(';')[0];
  console.log('4. Prof. Yoon Logged in:', profLogin.body.user.fullName);

  // 5. Prof. Yoon views pending reservations list
  const listRes = await request({
    path: '/api/reservations?all=true',
    method: 'GET',
    headers: { 'Cookie': profCookie }
  });
  const pendingRequests = listRes.body.reservations.filter(r => r.status === 'SUBMITTED');
  console.log('5. Prof. Yoon sees pending requests count:', pendingRequests.length);
  const found = pendingRequests.find(r => r.id === bookRes.body.reservation.id);
  if (found) {
    console.log('✅ SUCCESS: Student request appears on Faculty approval list! Reservation:', found.reservationNo);
  } else {
    console.error('❌ Request not found in list!');
  }
}

verify()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
