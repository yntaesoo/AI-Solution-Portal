import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { parseEquipmentExcel, importEquipmentData } from "@/lib/excel-importer";

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Admin only." }, { status: 403 });
    }

    const formData = await req.formData();
    const file = formData.get("file") as File;

    if (!file) {
      return NextResponse.json({ error: "No Excel file provided." }, { status: 400 });
    }

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Parse with smart merged cell forward-filling
    const rows = parseEquipmentExcel(buffer);
    if (rows.length === 0) {
      return NextResponse.json({ error: "No equipment data found in the uploaded file." }, { status: 400 });
    }

    // Save into Database
    const result = await importEquipmentData(rows);

    return NextResponse.json({
      success: true,
      message: `Successfully imported ${result.createdModels} new models and verified ${result.createdItems} asset barcodes.`,
      result,
    });
  } catch (error: any) {
    console.error("Bulk upload error:", error);
    return NextResponse.json({ error: error.message || "Failed to parse and import Excel file." }, { status: 500 });
  }
}
