import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { hashPassword, createToken, TOKEN_NAME } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { studentId, fullName, email, phone, password, role, customFields } = body;

    // Validate Core Fields
    if (!studentId || !fullName || !email || !phone || !password) {
      return NextResponse.json(
        { error: "Student ID, Full Name, Email, Phone, and Password are all required." },
        { status: 400 }
      );
    }

    // Check duplicate studentId or email
    const existing = await prisma.user.findFirst({
      where: {
        OR: [{ studentId: studentId.trim() }, { email: email.trim().toLowerCase() }],
      },
    });

    if (existing) {
      if (existing.studentId === studentId.trim()) {
        return NextResponse.json({ error: "Student ID already registered." }, { status: 409 });
      }
      return NextResponse.json({ error: "Email address already registered." }, { status: 409 });
    }

    // Verify required dynamic custom fields
    const requiredDefs = await prisma.customFieldDefinition.findMany({
      where: { isActive: true, isRequired: true, isVisibleOnRegister: true },
    });

    for (const def of requiredDefs) {
      const val = customFields ? customFields[def.id] : undefined;
      if (!val || String(val).trim() === "") {
        return NextResponse.json(
          { error: `The custom field '${def.labelEn}' is required.` },
          { status: 400 }
        );
      }
    }

    const passwordHash = await hashPassword(password);
    const assignedRole = role === "STUDENT_GRAD" ? "STUDENT_GRAD" : "STUDENT_UNDERGRAD";

    // Create User
    const user = await prisma.user.create({
      data: {
        studentId: studentId.trim(),
        fullName: fullName.trim(),
        email: email.trim().toLowerCase(),
        phone: phone.trim(),
        passwordHash,
        role: assignedRole,
        status: "ACTIVE",
        profilePhotoUrl: customFields && customFields["profile_photo"] ? customFields["profile_photo"] : null,
      },
    });

    // Save Dynamic Custom Values
    if (customFields && typeof customFields === "object") {
      for (const [fieldId, val] of Object.entries(customFields)) {
        if (!val) continue;

        // Find field definition by id or fieldName
        const fieldDef = await prisma.customFieldDefinition.findFirst({
          where: {
            OR: [{ id: fieldId }, { fieldName: fieldId }],
          },
        });

        if (fieldDef) {
          await prisma.userCustomValue.create({
            data: {
              userId: user.id,
              fieldId: fieldDef.id,
              value: String(val),
            },
          });
        }
      }
    }

    // Auto login: issue token
    const token = createToken({
      id: user.id,
      studentId: user.studentId,
      fullName: user.fullName,
      email: user.email,
      role: user.role,
      isCertified: user.isCertified,
    });

    const response = NextResponse.json({
      success: true,
      message: "Registration successful!",
      user: {
        id: user.id,
        studentId: user.studentId,
        fullName: user.fullName,
        role: user.role,
      },
    });

    const isHttps = req.nextUrl.protocol === "https:";

    response.cookies.set(TOKEN_NAME, token, {
      httpOnly: true,
      secure: isHttps,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    });

    return response;
  } catch (error: any) {
    console.error("Register API error:", error);
    return NextResponse.json({ error: error.message || "Failed to register" }, { status: 500 });
  }
}
