import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { validateUserBookingEligibility } from "@/lib/penalty-engine";

export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");
    const all = searchParams.get("all") === "true";

    const where: any = {};

    const facultyIdParam = searchParams.get("facultyId");

    // Students only see their own reservations; faculty and admin can review student requests
    if (user.role === "STUDENT_UNDERGRAD" || user.role === "STUDENT_GRAD") {
      where.userId = user.id;
    } else if (user.role === "FACULTY") {
      if (facultyIdParam) {
        where.facultyId = facultyIdParam;
      }
      // If no specific facultyIdParam, faculty sees all reservations so nothing is hidden
    }

    if (status && status !== "ALL") {
      where.status = status;
    }

    const reservations = await prisma.reservation.findMany({
      where,
      include: {
        user: { select: { id: true, studentId: true, fullName: true, email: true, phone: true } },
        faculty: { select: { id: true, fullName: true } },
        items: {
          include: {
            model: {
              include: {
                subcategory: { include: { category: true } },
              },
            },
            equipmentItem: true,
          },
        },
        teamMembers: true,
        signatureLogs: true,
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ reservations });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Please log in to make a booking." }, { status: 401 });
    }

    const body = await req.json();
    const {
      facultyId,
      projectType,
      projectTitle,
      projectDescription,
      rentalStartTime,
      items, // array of { modelId, quantity }
      teamMembers, // array of { studentId, studentName }
    } = body;

    if (!projectTitle || !rentalStartTime || !items || items.length === 0) {
      return NextResponse.json({ error: "Project Title, Rental Date/Time, and Items are required." }, { status: 400 });
    }

    const startDate = new Date(rentalStartTime);
    // Standard rental period is 3 days (Specification 4-(13))
    const returnDueDate = new Date(startDate);
    returnDueDate.setDate(returnDueDate.getDate() + 3);
    returnDueDate.setHours(17, 0, 0, 0); // 17:00 standard return time

    // Validate student eligibility and limits
    const validation = await validateUserBookingEligibility(user.id, startDate, returnDueDate);
    if (!validation.allowed) {
      return NextResponse.json({ error: validation.reason }, { status: 400 });
    }

    // Check special training requirement for items
    for (const item of items) {
      const model = await prisma.equipmentModel.findUnique({
        where: { id: item.modelId },
      });
      if (model?.targetAudience === "CERTIFIED" && !user.isCertified) {
        return NextResponse.json(
          { error: `The equipment '${model.modelName}' is restricted to users who have completed the certified training.` },
          { status: 403 }
        );
      }
    }

    // Check team members conflict (Specification 4-(3))
    if (projectType === "TEAM" && Array.isArray(teamMembers) && teamMembers.length > 0) {
      for (const tm of teamMembers) {
        const conflict = await prisma.teamMember.findFirst({
          where: {
            studentId: tm.studentId.trim(),
            reservation: {
              status: { in: ["SUBMITTED", "PROF_APPROVED", "CONFIRMED", "CHECKED_OUT"] },
              rentalStartTime: { lte: returnDueDate },
              returnDueTime: { gte: startDate },
            },
          },
        });
        if (conflict) {
          return NextResponse.json(
            { error: `Team member ${tm.studentName} (${tm.studentId}) already has an active booking during this period.` },
            { status: 400 }
          );
        }
      }
    }

    // Initial status is always SUBMITTED so that faculty approval is explicitly required
    const initialStatus = "SUBMITTED";

    // Generate unique reservation number: RES-YYYYMMDD-XXXX
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, "");
    const countToday = await prisma.reservation.count();
    const reservationNo = `RES-${dateStr}-${String(countToday + 1).padStart(3, "0")}`;

    const reservation = await prisma.reservation.create({
      data: {
        reservationNo,
        userId: user.id,
        facultyId: facultyId || null,
        projectType: projectType || "INDIVIDUAL",
        projectTitle: projectTitle.trim(),
        projectDescription,
        rentalStartTime: startDate,
        returnDueTime: returnDueDate,
        status: initialStatus,
        items: {
          create: items.map((it: any) => ({
            modelId: it.modelId,
            quantity: it.quantity || 1,
          })),
        },
        teamMembers: {
          create: Array.isArray(teamMembers)
            ? teamMembers.map((tm: any) => ({
                studentId: tm.studentId.trim(),
                studentName: tm.studentName.trim(),
              }))
            : [],
        },
      },
      include: {
        items: { include: { model: true } },
        teamMembers: true,
      },
    });

    return NextResponse.json({
      success: true,
      message: "Reservation submitted! Your request is now pending faculty approval.",
      reservation,
    });
  } catch (error: any) {
    console.error("Create reservation error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// Update Reservation (Approval, Rejection, Cancellation, Override)
export async function PATCH(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { id, action, rejectionReason, extendedDueDate, isClassUse } = body;

    if (!id || !action) {
      return NextResponse.json({ error: "Reservation ID and Action are required." }, { status: 400 });
    }

    const reservation = await prisma.reservation.findUnique({
      where: { id },
      include: { items: true },
    });

    if (!reservation) {
      return NextResponse.json({ error: "Reservation not found." }, { status: 404 });
    }

    const isAdmin = user.role === "SUPER_ADMIN" || user.role === "LAB_ASSISTANT";
    const isOwner = reservation.userId === user.id;

    let newStatus = reservation.status;
    let updateData: any = {};

    switch (action) {
      case "PROF_APPROVE":
        if (user.role !== "FACULTY" && !isAdmin) {
          return NextResponse.json({ error: "Faculty or Admin only." }, { status: 403 });
        }
        newStatus = "PROF_APPROVED";
        break;

      case "ADMIN_CONFIRM":
        if (!isAdmin) {
          return NextResponse.json({ error: "Admin only." }, { status: 403 });
        }
        newStatus = "CONFIRMED";
        break;

      case "REJECT":
        if (!isAdmin && user.role !== "FACULTY") {
          return NextResponse.json({ error: "Unauthorized." }, { status: 403 });
        }
        newStatus = "REJECTED";
        updateData.rejectionReason = rejectionReason || "Rejected by administrator.";
        break;

      case "CANCEL":
        // Student can cancel up to 1 day before rentalStartTime (Specification 4-(10))
        if (!isAdmin && !isOwner) {
          return NextResponse.json({ error: "Unauthorized." }, { status: 403 });
        }
        if (isOwner && !isAdmin) {
          const hoursUntilStart =
            (new Date(reservation.rentalStartTime).getTime() - Date.now()) / (1000 * 60 * 60);
          if (hoursUntilStart < 24) {
            return NextResponse.json(
              { error: "Cancellations must be made at least 24 hours before the rental start time." },
              { status: 400 }
            );
          }
        }
        newStatus = "CANCELLED";
        break;

      case "EXTEND_DUE_DATE":
        // Vacation extension up to 7 days (Admin Override Specification 4-(13))
        if (!isAdmin) {
          return NextResponse.json({ error: "Admin only." }, { status: 403 });
        }
        if (extendedDueDate) {
          updateData.returnDueTime = new Date(extendedDueDate);
        }
        break;

      case "OVERRIDE_CLASS_USE":
        // Admin override to designate as class use
        if (!isAdmin) {
          return NextResponse.json({ error: "Admin only." }, { status: 403 });
        }
        updateData.projectType = "CLASS_USE";
        newStatus = "CONFIRMED";
        break;

      default:
        return NextResponse.json({ error: "Invalid action." }, { status: 400 });
    }

    updateData.status = newStatus;

    const updated = await prisma.reservation.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json({ success: true, reservation: updated });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
