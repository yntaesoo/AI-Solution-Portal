"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Hash, Lock, AlertCircle, ArrowRight, ShieldCheck, UserCheck, GraduationCap, CheckCircle2, Loader2 } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [studentId, setStudentId] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const performLogin = async (idToUse: string, pwToUse: string) => {
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      const cleanId = idToUse.trim();
      const cleanPw = pwToUse.trim();

      if (!cleanId || !cleanPw) {
        throw new Error("Please enter both Student/Staff ID and Password.");
      }

      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId: cleanId, password: cleanPw }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Login failed. Please check your credentials.");
      }

      setSuccessMsg(`Welcome, ${data.user?.fullName}! Redirecting...`);

      // Determine redirect URL
      let targetUrl = "/booking";
      if (data.user?.role === "SUPER_ADMIN" || data.user?.role === "LAB_ASSISTANT") {
        targetUrl = "/admin";
      } else if (data.user?.role === "FACULTY") {
        targetUrl = "/faculty";
      }

      // Use window.location.href to guarantee cookie recognition on mobile browsers (Safari/Chrome)
      setTimeout(() => {
        window.location.href = targetUrl;
      }, 300);
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await performLogin(studentId, password);
  };

  // One-click quick login for testing
  const handleQuickLoginAndSubmit = async (id: string, pw: string) => {
    setStudentId(id);
    setPassword(pw);
    await performLogin(id, pw);
  };

  return (
    <div className="max-w-lg mx-auto py-6 sm:py-12 px-4">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-700 to-indigo-800 p-8 text-white text-center">
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">IC Equipment Portal</h1>
          <p className="text-blue-100 text-sm mt-1">Dongseo University International College (CAS 5106)</p>
          <div className="mt-3 inline-block px-3.5 py-1 bg-white/10 rounded-full text-xs font-semibold text-blue-100">
            e-class SSO Integrated Account (PC / Mobile)
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
          {error && (
            <div className="p-4 rounded-2xl bg-red-50 border border-red-200 text-red-800 text-sm flex items-center gap-3">
              <AlertCircle className="w-5 h-5 flex-shrink-0 text-red-600" />
              <span className="font-semibold">{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 flex-shrink-0 text-emerald-600" />
              <span className="font-semibold">{successMsg}</span>
            </div>
          )}

          <div>
            <label className="block text-sm font-bold text-slate-800 mb-1.5">
              Student ID / Staff ID (학번 또는 교번) *
            </label>
            <div className="relative">
              <Hash className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                required
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                inputMode="text"
                placeholder="e.g. 20240001, PROF_YOON, ADMIN001"
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                className="w-full pl-11 pr-4 py-3 text-base border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white text-slate-900"
              />
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Case-insensitive (대소문자 구분 없이 입력 가능)
            </p>
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-800 mb-1.5">
              Password (비밀번호) *
            </label>
            <div className="relative">
              <Lock className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="password"
                required
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-11 pr-4 py-3 text-base border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white text-slate-900"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-extrabold rounded-2xl shadow-lg shadow-blue-500/25 transition disabled:opacity-50 text-base flex items-center justify-center gap-2 active:scale-98"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Signing in...</span>
              </>
            ) : (
              <>
                <span>Sign In to Portal</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-sm">
            <Link href="/register" className="text-blue-600 hover:underline font-bold">
              New Student? Create Account (회원가입)
            </Link>
            <span className="text-slate-400 text-xs font-medium">CAS 5106 Lab</span>
          </div>

          {/* Quick One-Click Demo Logins for Fast Mobile & Desktop Testing */}
          <div className="mt-6 pt-5 border-t border-dashed border-slate-200">
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2.5 text-center">
              ⚡ One-Click Instant Login (원클릭 즉시 로그인)
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
              <button
                type="button"
                disabled={loading}
                onClick={() => handleQuickLoginAndSubmit("20240001", "student1234")}
                className="p-3.5 rounded-2xl bg-emerald-50 hover:bg-emerald-100 active:bg-emerald-200 border border-emerald-200 text-emerald-950 font-bold text-center transition flex flex-col items-center gap-1 shadow-2xs"
              >
                <UserCheck className="w-5 h-5 text-emerald-600" />
                <span className="text-sm">Student (학생)</span>
                <span className="text-[11px] text-emerald-700 font-normal">20240001</span>
              </button>

              <button
                type="button"
                disabled={loading}
                onClick={() => handleQuickLoginAndSubmit("PROF_YOON", "prof1234")}
                className="p-3.5 rounded-2xl bg-amber-50 hover:bg-amber-100 active:bg-amber-200 border border-amber-200 text-amber-950 font-bold text-center transition flex flex-col items-center gap-1 shadow-2xs"
              >
                <GraduationCap className="w-5 h-5 text-amber-600" />
                <span className="text-sm">Prof. Yoon (교수)</span>
                <span className="text-[11px] text-amber-700 font-normal">PROF_YOON</span>
              </button>

              <button
                type="button"
                disabled={loading}
                onClick={() => handleQuickLoginAndSubmit("ADMIN001", "admin1234")}
                className="p-3.5 rounded-2xl bg-blue-50 hover:bg-blue-100 active:bg-blue-200 border border-blue-200 text-blue-950 font-bold text-center transition flex flex-col items-center gap-1 shadow-2xs"
              >
                <ShieldCheck className="w-5 h-5 text-blue-600" />
                <span className="text-sm">Admin (관리자)</span>
                <span className="text-[11px] text-blue-700 font-normal">ADMIN001</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
