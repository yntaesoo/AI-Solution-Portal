"use client";

import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Camera, Check, User, Mail, Phone, Lock, Hash, AlertCircle, RefreshCw, X } from "lucide-react";

interface CustomField {
  id: string;
  fieldName: string;
  labelEn: string;
  labelKo: string;
  labelZh?: string;
  fieldType: string; // TEXT, SELECT, NUMBER, WEBCAM_IMAGE, CHECKBOX
  optionsJson?: string;
  isRequired: boolean;
  isVisibleOnRegister: boolean;
}

export default function RegisterPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Core 5 required fields
  const [studentId, setStudentId] = useState("");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("STUDENT_UNDERGRAD");

  // Dynamic Custom Fields fetched from backend
  const [customFields, setCustomFields] = useState<CustomField[]>([]);
  const [customValues, setCustomValues] = useState<Record<string, any>>({});

  // Webcam Capture state
  const [isWebcamOpen, setIsWebcamOpen] = useState(false);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    // Fetch dynamic registration fields defined in Admin
    fetch("/api/custom-fields?register=true")
      .then((res) => res.json())
      .then((data) => {
        if (data.fields) {
          setCustomFields(data.fields);
        }
      })
      .catch((err) => console.error("Error loading custom fields:", err));
  }, []);

  const handleCustomChange = (fieldId: string, val: any) => {
    setCustomValues((prev) => ({ ...prev, [fieldId]: val }));
  };

  // Start Webcam
  const startWebcam = async () => {
    try {
      setIsWebcamOpen(true);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 320, height: 320 } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (e: any) {
      alert("Unable to access webcam: " + e.message);
      setIsWebcamOpen(false);
    }
  };

  // Capture Photo
  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement("canvas");
      canvas.width = 300;
      canvas.height = 300;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, 300, 300);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.85);
        setCapturedPhoto(dataUrl);
        handleCustomChange("profile_photo", dataUrl);
      }
    }
    stopWebcam();
  };

  const stopWebcam = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsWebcamOpen(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const payload = {
        studentId,
        fullName,
        email,
        phone,
        password,
        role,
        customFields: {
          ...customValues,
          profile_photo: capturedPhoto || customValues["profile_photo"] || null,
        },
      };

      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Registration failed");
      }

      // Successful registration & auto-login
      router.push("/booking");
      router.refresh();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-8">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-700 to-indigo-700 px-8 py-8 text-white">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Student Registration</h1>
          <p className="text-blue-100 text-sm mt-1">
            Dongseo University International College 기자재 예약 시스템 회원가입
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {error && (
            <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm flex items-center gap-3">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Section 1: Core 5 Required Fields */}
          <div className="space-y-4">
            <h2 className="text-sm font-semibold text-slate-900 uppercase tracking-wider text-blue-700 flex items-center gap-1.5 border-b pb-2">
              <span>1. Basic Information (기본 계정 정보)</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Student ID (학번) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Hash className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. 20261234"
                    value={studentId}
                    onChange={(e) => setStudentId(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Full Name (영문/한글 이름) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Alex Johnson"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Email Address (이메일) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    placeholder="student@dongseo.ac.kr"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Phone Number (핸드폰번호) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="tel"
                    required
                    placeholder="010-1234-5678"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Password (비밀번호) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    placeholder="At least 6 characters"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Academic Program (과정 구분)
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                >
                  <option value="STUDENT_UNDERGRAD">Undergraduate (학부생 - 1 Month Advance Booking)</option>
                  <option value="STUDENT_GRAD">Graduate (대학원생 - 2 Months Advance Booking)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 2: Dynamic Custom Fields (Configured in Backend) */}
          {customFields.length > 0 && (
            <div className="space-y-4 pt-4">
              <h2 className="text-sm font-semibold text-slate-900 uppercase tracking-wider text-indigo-700 flex items-center justify-between border-b pb-2">
                <span>2. Additional Profile Information (추가 정보)</span>
                <span className="text-[10px] text-slate-400 font-normal lowercase tracking-normal">
                  (Managed dynamically by Lab Admin)
                </span>
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {customFields.map((field) => {
                  let options: string[] = [];
                  if (field.fieldType === "SELECT" && field.optionsJson) {
                    try {
                      options = JSON.parse(field.optionsJson);
                    } catch {}
                  }

                  if (field.fieldType === "WEBCAM_IMAGE") {
                    return (
                      <div key={field.id} className="sm:col-span-2 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                        <label className="block text-xs font-semibold text-slate-700 mb-2">
                          {field.labelEn} ({field.labelKo}) {field.isRequired && <span className="text-red-500">*</span>}
                        </label>

                        <div className="flex items-center gap-4">
                          {capturedPhoto ? (
                            <div className="relative w-20 h-20 rounded-2xl overflow-hidden border-2 border-blue-500 shadow-sm">
                              <img src={capturedPhoto} alt="Profile" className="w-full h-full object-cover" />
                              <button
                                type="button"
                                onClick={() => setCapturedPhoto(null)}
                                className="absolute top-1 right-1 p-0.5 bg-black/60 text-white rounded-full hover:bg-red-600"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ) : (
                            <div className="w-20 h-20 rounded-2xl bg-slate-200 flex items-center justify-center text-slate-400">
                              <User className="w-8 h-8" />
                            </div>
                          )}

                          <div className="space-y-2">
                            <button
                              type="button"
                              onClick={startWebcam}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-100 hover:bg-blue-200 rounded-xl transition"
                            >
                              <Camera className="w-4 h-4" />
                              <span>Take Photo with Webcam (웹캠 촬영)</span>
                            </button>
                            <p className="text-[11px] text-slate-500">
                              Specification 3-(7): Take webcam photo or upload file for equipment verification.
                            </p>
                          </div>
                        </div>

                        {/* Webcam Capture Modal */}
                        {isWebcamOpen && (
                          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
                            <div className="bg-white rounded-2xl p-5 max-w-sm w-full space-y-4 shadow-2xl">
                              <h3 className="font-bold text-sm text-slate-900">Webcam Profile Capture</h3>
                              <div className="w-full aspect-square bg-black rounded-xl overflow-hidden relative">
                                <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline />
                              </div>
                              <div className="flex gap-2">
                                <button
                                  type="button"
                                  onClick={capturePhoto}
                                  className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-xs"
                                >
                                  Capture Photo
                                </button>
                                <button
                                  type="button"
                                  onClick={stopWebcam}
                                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
                                >
                                  Cancel
                                </button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  }

                  if (field.fieldType === "SELECT") {
                    return (
                      <div key={field.id} className="sm:col-span-2">
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          {field.labelEn} ({field.labelKo}) {field.isRequired && <span className="text-red-500">*</span>}
                        </label>
                        <select
                          required={field.isRequired}
                          value={customValues[field.id] || ""}
                          onChange={(e) => handleCustomChange(field.id, e.target.value)}
                          className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                        >
                          <option value="">-- Select {field.labelEn} --</option>
                          {options.map((opt, i) => (
                            <option key={i} value={opt}>
                              {opt}
                            </option>
                          ))}
                        </select>
                      </div>
                    );
                  }

                  return (
                    <div key={field.id}>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        {field.labelEn} ({field.labelKo}) {field.isRequired && <span className="text-red-500">*</span>}
                      </label>
                      <input
                        type={field.fieldType === "NUMBER" ? "number" : "text"}
                        required={field.isRequired}
                        placeholder={`Enter ${field.labelEn}`}
                        value={customValues[field.id] || ""}
                        onChange={(e) => handleCustomChange(field.id, e.target.value)}
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <Link href="/login" className="text-xs text-blue-600 hover:underline">
              Already have an account? Sign In here
            </Link>

            <button
              type="submit"
              disabled={loading}
              className="w-full sm:w-auto px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-lg shadow-blue-500/25 transition disabled:opacity-50"
            >
              {loading ? "Creating Account..." : "Complete Registration"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
