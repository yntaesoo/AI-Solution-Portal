import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const forRegister = searchParams.get("register") === "true";

    const where: any = { isActive: true };
    if (forRegister) {
      where.isVisibleOnRegister = true;
    }

    const fields = await prisma.customFieldDefinition.findMany({
      where,
      orderBy: { displayOrder: "asc" },
    });

    return NextResponse.json({ fields });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Admin only." }, { status: 403 });
    }

    const body = await req.json();
    const {
      fieldName,
      labelEn,
      labelKo,
      labelZh,
      fieldType,
      options,
      isRequired,
      isVisibleOnRegister,
      displayOrder,
    } = body;

    if (!fieldName || !labelEn) {
      return NextResponse.json({ error: "Field Name and English Label are required." }, { status: 400 });
    }

    // Clean fieldName: lowercase letters, digits, underscores
    const cleanName = fieldName.trim().toLowerCase().replace(/[^a-z0-9_]/g, "_");

    const existing = await prisma.customFieldDefinition.findUnique({
      where: { fieldName: cleanName },
    });
    if (existing) {
      return NextResponse.json({ error: `Field '${cleanName}' already exists.` }, { status: 409 });
    }

    const created = await prisma.customFieldDefinition.create({
      data: {
        fieldName: cleanName,
        labelEn: labelEn.trim(),
        labelKo: labelKo ? labelKo.trim() : labelEn.trim(),
        labelZh: labelZh ? labelZh.trim() : null,
        fieldType: fieldType || "TEXT",
        optionsJson: Array.isArray(options) ? JSON.stringify(options) : null,
        isRequired: !!isRequired,
        isVisibleOnRegister: isVisibleOnRegister !== false,
        displayOrder: displayOrder || 0,
      },
    });

    return NextResponse.json({ success: true, field: created });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Admin only." }, { status: 403 });
    }

    const body = await req.json();
    const { id, labelEn, labelKo, labelZh, isRequired, isVisibleOnRegister, displayOrder, isActive, options } = body;

    if (!id) {
      return NextResponse.json({ error: "Field ID is required." }, { status: 400 });
    }

    const updated = await prisma.customFieldDefinition.update({
      where: { id },
      data: {
        labelEn,
        labelKo,
        labelZh,
        isRequired,
        isVisibleOnRegister,
        displayOrder,
        isActive,
        optionsJson: options ? JSON.stringify(options) : undefined,
      },
    });

    return NextResponse.json({ success: true, field: updated });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Unauthorized. Super Admin only." }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Field ID is required." }, { status: 400 });
    }

    await prisma.customFieldDefinition.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: "Field deleted." });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
