"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Camera, Search, Filter, ShieldCheck, CheckCircle2, AlertTriangle, ArrowRight, Info, Layers } from "lucide-react";

export default function CatalogPage() {
  const [models, setModels] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("ALL");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [activeModalItem, setActiveModalItem] = useState<any | null>(null);

  useEffect(() => {
    fetch("/api/equipment/categories")
      .then((res) => res.json())
      .then((data) => {
        if (data.categories) setCategories(data.categories);
      });

    loadEquipment();
  }, [selectedCategory]);

  const loadEquipment = () => {
    setLoading(true);
    let url = "/api/equipment";
    if (selectedCategory !== "ALL") {
      url += `?categoryId=${selectedCategory}`;
    }

    fetch(url)
      .then((res) => res.json())
      .then((data) => {
        if (data.models) setModels(data.models);
      })
      .finally(() => setLoading(false));
  };

  const filtered = models.filter((m) => {
    if (!search || !search.trim()) return true;
    const q = search.toLowerCase().trim();
    return (
      (m.modelName && m.modelName.toLowerCase().includes(q)) ||
      (m.brand && m.brand.toLowerCase().includes(q)) ||
      (m.remarks && m.remarks.toLowerCase().includes(q)) ||
      (m.subcategory?.nameEn && m.subcategory.nameEn.toLowerCase().includes(q)) ||
      (m.subcategory?.category?.nameEn && m.subcategory.category.nameEn.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Equipment Inventory Catalog
          </h1>
          <p className="text-sm text-slate-500 mt-1 font-medium">
            Dongseo University Film & VFX Production Resources ({models.length} Models registered in database)
          </p>
        </div>

        <Link
          href="/booking"
          className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl text-base font-bold shadow-md shadow-blue-500/20 transition self-start md:self-auto"
        >
          <span>Go to Booking Cart</span>
          <ArrowRight className="w-5 h-5" />
        </Link>
      </div>

      {/* Filter and Search Bar Section */}
      <div className="space-y-3">
        {/* Dedicated Full-Width Search Input */}
        <div className="relative w-full">
          <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Search by model name, brand (e.g. Sony, Canon, Blackmagic), or remarks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-12 pr-12 py-3.5 bg-white border border-slate-300 rounded-2xl text-base text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs transition"
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch("")}
              className="absolute right-4 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition text-sm font-bold"
              title="Clear search"
            >
              ✕
            </button>
          )}
        </div>

        {/* Category Pills (Dedicated scrollable row) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5">
          <button
            onClick={() => setSelectedCategory("ALL")}
            className={`px-4 py-2.5 rounded-xl text-sm font-bold whitespace-nowrap transition flex-shrink-0 ${
              selectedCategory === "ALL" ? "bg-slate-900 text-white shadow-sm" : "bg-white text-slate-700 border border-slate-200 hover:bg-slate-100"
            }`}
          >
            All Categories
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-4 py-2.5 rounded-xl text-sm font-bold whitespace-nowrap transition flex-shrink-0 ${
                selectedCategory === c.id ? "bg-blue-600 text-white shadow-md shadow-blue-500/20" : "bg-white text-slate-700 border border-slate-200 hover:bg-slate-100"
              }`}
            >
              {c.nameEn}
            </button>
          ))}
        </div>

        {/* Search Results Summary */}
        {search.trim() && (
          <div className="flex items-center justify-between text-sm bg-blue-50 border border-blue-200 px-4 py-2.5 rounded-xl text-blue-900">
            <span>
              Search results for &ldquo;<strong>{search}</strong>&rdquo;: {filtered.length} equipment item(s) found
            </span>
            <button
              onClick={() => setSearch("")}
              className="text-xs text-blue-700 hover:text-blue-900 font-bold underline ml-2"
            >
              Clear Search
            </button>
          </div>
        )}
      </div>

      {/* Grid */}
      {loading ? (
        <div className="text-center py-24 text-slate-500 text-base font-semibold">Loading equipment inventory...</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-3xl border border-slate-200 text-slate-600 text-base font-medium">
          No equipment found matching your criteria.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((item) => {
            const isSpecial = item.targetAudience === "CERTIFIED";
            const isAvailable = item.availableQuantity > 0;

            return (
              <div
                key={item.id}
                className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Category and Badges */}
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-100">
                      {item.subcategory?.category?.nameEn} › {item.subcategory?.nameEn}
                    </span>
                    {isSpecial ? (
                      <span className="flex items-center gap-1 font-bold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                        <ShieldCheck className="w-4 h-4" />
                        <span>Certified</span>
                      </span>
                    ) : (
                      <span className="text-slate-400 font-semibold">Standard</span>
                    )}
                  </div>

                  {/* Brand & Model */}
                  <div>
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{item.brand}</span>
                    <h3 className="font-extrabold text-lg sm:text-xl text-slate-900 leading-snug">{item.modelName}</h3>
                  </div>

                  {/* Remarks / Package Details */}
                  {item.remarks && (
                    <p className="text-sm text-slate-600 line-clamp-3 bg-slate-50 p-3 rounded-2xl border border-slate-100 leading-relaxed">
                      {item.remarks}
                    </p>
                  )}
                </div>

                <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div className="text-sm">
                    <span className="text-slate-500 font-medium">Available: </span>
                    <span className={`font-extrabold text-base ${isAvailable ? "text-emerald-600" : "text-red-500"}`}>
                      {item.availableQuantity}
                    </span>
                    <span className="text-slate-400 font-medium"> / {item.totalQuantity}</span>
                  </div>

                  <button
                    onClick={() => setActiveModalItem(item)}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-sm font-bold text-slate-800 transition"
                  >
                    View Details
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Item Detail Modal */}
      {activeModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-100 space-y-5 animate-scaleUp">
            <div className="flex items-center justify-between border-b pb-4">
              <div>
                <span className="text-xs text-blue-600 font-bold uppercase tracking-wider">{activeModalItem.brand}</span>
                <h3 className="text-2xl font-black text-slate-900">{activeModalItem.modelName}</h3>
              </div>
              <button
                onClick={() => setActiveModalItem(null)}
                className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-sm text-slate-700">
              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-4 rounded-2xl">
                <div>
                  <span className="text-slate-400 block text-xs font-semibold">Category:</span>
                  <span className="font-bold text-slate-900 text-sm">
                    {activeModalItem.subcategory?.category?.nameEn} › {activeModalItem.subcategory?.nameEn}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-xs font-semibold">Total Quantity:</span>
                  <span className="font-bold text-slate-900 text-sm">{activeModalItem.totalQuantity} Units</span>
                </div>
              </div>

              <div>
                <span className="font-bold text-slate-800 block mb-1 text-sm">Package & Accessories:</span>
                <p className="p-4 bg-slate-50 rounded-2xl leading-relaxed whitespace-pre-line text-slate-700 text-sm border border-slate-100">
                  {activeModalItem.remarks || "Standard manufacturer case and cables included."}
                </p>
              </div>

              {activeModalItem.targetAudience === "CERTIFIED" && (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs sm:text-sm font-semibold">
                  ⚠️ Special Qualification: Restricted to students who have finished specialized certified training by Prof. Yoon.
                </div>
              )}
            </div>

            <div className="pt-2 flex justify-end gap-3">
              <Link
                href="/booking"
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold shadow-md shadow-blue-500/20"
              >
                Go to Reservation
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
