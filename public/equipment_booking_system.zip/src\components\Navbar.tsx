"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import {
  Camera,
  Calendar,
  User,
  LogOut,
  ShieldAlert,
  Settings,
  Package,
  FileCheck,
  Menu,
  X,
  Smartphone,
} from "lucide-react";

export default function Navbar() {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    fetch("/api/auth/me")
      .then((res) => res.json())
      .then((data) => {
        if (data.user) setCurrentUser(data.user);
      })
      .catch(() => {});
  }, [pathname]);

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setCurrentUser(null);
    setMobileMenuOpen(false);
    router.push("/login");
    router.refresh();
  };

  const isAdmin = currentUser?.role === "SUPER_ADMIN" || currentUser?.role === "LAB_ASSISTANT";
  const isFaculty = currentUser?.role === "FACULTY" || isAdmin;
  const hasPenalty = currentUser?.penalties && currentUser.penalties.length > 0;

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo & System Title */}
          <Link href="/" className="flex items-center space-x-3 group">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/25 group-hover:scale-105 transition">
              <Camera className="w-7 h-7" />
            </div>
            <div>
              <div className="font-extrabold text-xl leading-tight text-slate-900 tracking-tight flex items-center gap-2">
                <span>DSU IC Equipment</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold border border-blue-200">
                  CAS 5106
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 font-medium">International College 기자재 예약 시스템</p>
            </div>
          </Link>

          {/* Desktop Navigation Links (Increased Font Size text-base) */}
          <nav className="hidden lg:flex items-center space-x-2">
            <Link
              href="/"
              className={`px-3.5 py-2.5 rounded-xl text-base font-semibold transition ${
                pathname === "/" ? "bg-slate-100 text-blue-700" : "text-slate-700 hover:text-slate-900 hover:bg-slate-50"
              }`}
            >
              Notice / 首页
            </Link>

            <Link
              href="/catalog"
              className={`px-3.5 py-2.5 rounded-xl text-base font-semibold transition ${
                pathname.startsWith("/catalog") ? "bg-slate-100 text-blue-700" : "text-slate-700 hover:text-slate-900 hover:bg-slate-50"
              }`}
            >
              Catalog
            </Link>

            <Link
              href="/booking"
              className={`px-3.5 py-2.5 rounded-xl text-base font-semibold transition ${
                pathname.startsWith("/booking") ? "bg-blue-50 text-blue-700" : "text-slate-700 hover:text-slate-900 hover:bg-slate-50"
              }`}
            >
              Reserve
            </Link>

            {currentUser && (
              <Link
                href="/my-bookings"
                className={`px-3.5 py-2.5 rounded-xl text-base font-semibold transition ${
                  pathname.startsWith("/my-bookings") ? "bg-slate-100 text-blue-700" : "text-slate-700 hover:text-slate-900 hover:bg-slate-50"
                }`}
              >
                My Bookings
              </Link>
            )}

            {isFaculty && (
              <Link
                href="/faculty"
                className={`px-3.5 py-2.5 rounded-xl text-base font-semibold transition flex items-center gap-1.5 ${
                  pathname.startsWith("/faculty")
                    ? "bg-amber-500 text-white shadow-md shadow-amber-500/20"
                    : "text-amber-700 bg-amber-50 hover:bg-amber-100"
                }`}
              >
                <FileCheck className="w-5 h-5" />
                <span>Faculty Approval (교수 승인)</span>
              </Link>
            )}

            {isAdmin && (
              <Link
                href="/admin"
                className={`px-3.5 py-2.5 rounded-xl text-base font-semibold transition flex items-center gap-1.5 ${
                  pathname.startsWith("/admin")
                    ? "bg-blue-600 text-white shadow-md shadow-blue-500/20"
                    : "text-blue-700 bg-blue-50 hover:bg-blue-100"
                }`}
              >
                <Settings className="w-5 h-5" />
                <span>Admin Console</span>
              </Link>
            )}
          </nav>

          {/* User Section & Mobile Toggle */}
          <div className="flex items-center space-x-3">
            {hasPenalty && (
              <div className="hidden sm:flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full bg-red-100 text-red-800 border border-red-300 font-bold animate-pulse">
                <ShieldAlert className="w-4 h-4" />
                <span>Penalty Active</span>
              </div>
            )}

            {currentUser ? (
              <div className="hidden sm:flex items-center space-x-3">
                <div className="text-right">
                  <div className="text-base font-bold text-slate-800 leading-tight">
                    {currentUser.fullName}
                  </div>
                  <div className="text-xs text-slate-500 font-medium">
                    {currentUser.studentId} • {currentUser.role === "SUPER_ADMIN" ? "Admin" : currentUser.role === "FACULTY" ? "Faculty" : "Student"}
                  </div>
                </div>
                <button
                  onClick={handleLogout}
                  title="Logout"
                  className="p-2.5 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-xl transition"
                >
                  <LogOut className="w-6 h-6" />
                </button>
              </div>
            ) : (
              <div className="hidden sm:flex items-center space-x-2">
                <Link
                  href="/login"
                  className="px-4 py-2 text-sm font-bold text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition"
                >
                  Login
                </Link>
                <Link
                  href="/register"
                  className="px-5 py-2.5 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md shadow-blue-500/25 transition"
                >
                  Sign Up
                </Link>
              </div>
            )}

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2.5 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 transition"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation (Phone friendly touch menu) */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-3 shadow-xl animate-fadeIn">
          {currentUser && (
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between mb-2">
              <div>
                <div className="text-base font-bold text-slate-900">{currentUser.fullName}</div>
                <div className="text-xs text-slate-500">
                  {currentUser.studentId} ({currentUser.role})
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="px-3 py-1.5 text-xs font-bold text-red-600 bg-red-50 rounded-xl"
              >
                Logout
              </button>
            </div>
          )}

          <div className="flex flex-col space-y-1">
            <Link
              href="/"
              onClick={() => setMobileMenuOpen(false)}
              className={`p-3 rounded-xl text-base font-bold ${
                pathname === "/" ? "bg-blue-50 text-blue-700" : "text-slate-700 hover:bg-slate-100"
              }`}
            >
              Notice / 首页 (Lab Announcements)
            </Link>

            <Link
              href="/catalog"
              onClick={() => setMobileMenuOpen(false)}
              className={`p-3 rounded-xl text-base font-bold ${
                pathname.startsWith("/catalog") ? "bg-blue-50 text-blue-700" : "text-slate-700 hover:bg-slate-100"
              }`}
            >
              Equipment Catalog (135+ Items)
            </Link>

            <Link
              href="/booking"
              onClick={() => setMobileMenuOpen(false)}
              className={`p-3 rounded-xl text-base font-bold ${
                pathname.startsWith("/booking") ? "bg-blue-50 text-blue-700" : "text-slate-700 hover:bg-slate-100"
              }`}
            >
              Reserve Equipment (예약 신청)
            </Link>

            {currentUser && (
              <Link
                href="/my-bookings"
                onClick={() => setMobileMenuOpen(false)}
                className={`p-3 rounded-xl text-base font-bold ${
                  pathname.startsWith("/my-bookings") ? "bg-blue-50 text-blue-700" : "text-slate-700 hover:bg-slate-100"
                }`}
              >
                My Bookings & Agreements
              </Link>
            )}

            {isFaculty && (
              <Link
                href="/faculty"
                onClick={() => setMobileMenuOpen(false)}
                className={`p-3 rounded-xl text-base font-bold flex items-center gap-2 ${
                  pathname.startsWith("/faculty")
                    ? "bg-amber-500 text-white"
                    : "text-amber-800 bg-amber-50 hover:bg-amber-100"
                }`}
              >
                <FileCheck className="w-5 h-5" />
                <span>Faculty Approval (교수 승인)</span>
              </Link>
            )}

            {isAdmin && (
              <Link
                href="/admin"
                onClick={() => setMobileMenuOpen(false)}
                className={`p-3 rounded-xl text-base font-bold flex items-center gap-2 ${
                  pathname.startsWith("/admin")
                    ? "bg-blue-600 text-white"
                    : "text-blue-700 bg-blue-50 hover:bg-blue-100"
                }`}
              >
                <Settings className="w-5 h-5" />
                <span>Admin Operations Console</span>
              </Link>
            )}
          </div>

          {!currentUser && (
            <div className="pt-2 grid grid-cols-2 gap-2">
              <Link
                href="/login"
                onClick={() => setMobileMenuOpen(false)}
                className="py-3 text-center text-sm font-bold text-slate-700 bg-slate-100 rounded-xl"
              >
                Login
              </Link>
              <Link
                href="/register"
                onClick={() => setMobileMenuOpen(false)}
                className="py-3 text-center text-sm font-bold text-white bg-blue-600 rounded-xl shadow-md"
              >
                Sign Up
              </Link>
            </div>
          )}
        </div>
      )}
    </header>
  );
}
