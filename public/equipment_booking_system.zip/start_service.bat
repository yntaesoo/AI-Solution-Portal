@echo off
chcp 65001 >nul
title DSU Equipment Booking System (Port 8000)
cd /d "%~dp0"
echo ========================================================
echo  동서대 영화·영상·VFX 실습 장비예약 시스템 (Next.js)
echo  포트: 8000
echo  로컬 주소: http://localhost:8000
echo  포털 주소: http://equipment.arfab.kr
echo ========================================================
echo.
call "C:\Program Files\nodejs\npm.cmd" run start
pause
