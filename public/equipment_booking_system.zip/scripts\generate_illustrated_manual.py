import os
import sys
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, KeepTogether, PageBreak, HRFlowable
)
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCREENSHOTS_DIR = os.path.join(BASE_DIR, "manual_screenshots")

DOCX_NAME = "동서대_IC_장비예약시스템_사용자매뉴얼(그림포함).docx"
PDF_NAME = "동서대_IC_장비예약시스템_사용자매뉴얼(그림포함).pdf"
DOCX_OUT = os.path.join(BASE_DIR, DOCX_NAME)
PDF_OUT = os.path.join(BASE_DIR, PDF_NAME)

FONT_PATH = "C:/Windows/Fonts/malgun.ttf"
FONT_BOLD_PATH = "C:/Windows/Fonts/malgunbd.ttf"
if os.path.exists(FONT_BOLD_PATH):
    pdfmetrics.registerFont(TTFont("MalgunBold", FONT_BOLD_PATH))
    pdfmetrics.registerFont(TTFont("Malgun", FONT_PATH))
else:
    pdfmetrics.registerFont(TTFont("Malgun", FONT_PATH))
    pdfmetrics.registerFont(TTFont("MalgunBold", FONT_PATH))

# Manual Content Definition
SECTIONS = [
    {
        "id": "1",
        "title": "제1부: 시스템 접속 및 로그인 (PC & Mobile)",
        "intro": "동서대학교 International College(IC) 유학생 및 재학생을 위한 장비예약 관리시스템은 PC 웹 브라우저뿐만 아니라 스마트폰 모바일 환경에서도 최적화되어 동작합니다. 본 장에서는 시스템 접속, 로그인, 회원가입 절차를 안내합니다.",
        "steps": [
            {
                "subtitle": "1.1 모바일 반응형 접속 및 외부망 지원",
                "desc": "교내 Wi-Fi뿐만 아니라 외부 이동통신망(LTE/5G)에서도 접속 가능하도록 모바일 반응형 터치 UI와 하단 탭 내비게이션 바가 기본 탑재되어 있습니다. 스마트폰으로 접속 시 한 손 조작이 용이한 레이아웃으로 자동 전환됩니다.",
                "image": "12_mobile_responsive_view.png",
                "caption": "[그림 1-1] 스마트폰 모바일 화면 예시 (하단 고정 내비게이션 탭 및 터치 최적화 UI)",
                "tips": [
                    "스마트폰 접속 시 화면 하단의 '신청서 작성', '장비 선택', '장바구니' 단계를 통해 직관적으로 예약할 수 있습니다.",
                    "Cloudflare 보안 터널을 통해 학교 밖 외부망이나 가정에서도 별도 VPN 없이 안전하게 접속됩니다."
                ]
            },
            {
                "subtitle": "1.2 로그인 및 원클릭 테스트 계정 지원",
                "desc": "발급받은 학번(Student ID) 또는 교번(Staff ID)과 비밀번호를 입력하여 로그인합니다. 대소문자를 구분하지 않으며, 실습 및 시연을 위해 학생/교수자/관리자 '원클릭 즉시 로그인' 버튼도 함께 제공됩니다.",
                "image": "01_login_screen.png",
                "caption": "[그림 1-2] 통합 로그인 화면 (학번/교번 입력 및 원클릭 빠른 로그인 버튼)",
                "tips": [
                    "학생 계정: 학번 20240001 (비밀번호: student1234)",
                    "교수자 계정: 교번 PROF_YOON (비밀번호: prof1234)",
                    "관리자 계정: 관리자 ID ADMIN001 (비밀번호: admin1234)"
                ]
            },
            {
                "subtitle": "1.3 신규 학생 회원가입 및 학과/국적 추가 정보",
                "desc": "계정이 없는 학생은 로그인 하단의 'New Student? Create Account (회원가입)'을 눌러 가입합니다. 기본 5대 정보(학번, 이름, 이메일, 전화번호, 비밀번호) 외에도 관리자가 설정한 동적 커스텀 필드(학과, SNS ID, 국적 등)를 입력할 수 있습니다.",
                "image": "02_student_register.png",
                "caption": "[그림 1-3] 학생 회원가입 화면 (기본 정보 및 관리자 지정 커스텀 추가 필드 입력란)",
                "tips": [
                    "다국적 유학생을 위해 영어와 한국어가 병기 표기되어 있습니다.",
                    "학과(Department) 및 SNS 메신저(카카오톡/위챗)를 정확히 입력하면 대여 승인 및 반납 안내 연락을 신속히 받을 수 있습니다."
                ]
            }
        ]
    },
    {
        "id": "2",
        "title": "제2부: 학생(Student) 장비 예약 및 마이페이지",
        "intro": "학생은 최신 방송/영상/VFX 장비 목록을 조회하고, 수업 과제 및 졸업작품 제작을 위해 장비를 장바구니에 담아 담당 교수자에게 예약을 신청할 수 있습니다.",
        "steps": [
            {
                "subtitle": "2.1 장비 카탈로그 탐색 및 실시간 수량 확인",
                "desc": "보유 중인 135종의 학과 전문 장비(Camera, Lens, Audio, Lighting, Rig 등)를 카테고리별로 실시간 조회할 수 있습니다. 장비별 총 수량과 현재 대여 가능한 잔여 수량이 실시간으로 표시됩니다.",
                "image": "03_equipment_catalog.png",
                "caption": "[그림 2-1] 장비 카탈로그 화면 (대분류/소분류별 실시간 보유 및 잔여 수량 표시)",
                "tips": [
                    "상단 검색창에 'Sony', 'Canon', 'Wireless' 등 모델명을 입력하여 빠르게 검색할 수 있습니다.",
                    "'Prof. Yoon Certified' 배지가 붙은 특수 고가 장비는 인증 교육을 이수한 학생만 대여 가능합니다."
                ]
            },
            {
                "subtitle": "2.2 최초 1회 준수 서약서 팝업 확인",
                "desc": "학생이 최초로 장비 예약(Reserve) 메뉴에 진입할 때, 분실/파손 방지 및 대여 규정을 숙지하도록 돕는 준수 서약서 팝업이 노출됩니다. 이 팝업은 최초 1회만 표시되며, 동의 후 정상 예약이 가능합니다.",
                "image": "04_first_time_pledge_modal.png",
                "caption": "[그림 2-2] 최초 예약 시 준수 서약서 확인 모달 (장비 관리 및 반납 규정 안내)",
                "tips": [
                    "대여 기간(기본 3일) 준수 및 지연 반납 시 페널티 정책(지연일수의 2배 대여 정지)이 안내됩니다.",
                    "'동의하고 예약 계속하기' 버튼을 누르면 다음 접속부터는 팝업 없이 바로 예약서 작성이 가능합니다."
                ]
            },
            {
                "subtitle": "2.3 예약 신청서 작성 및 3단 장바구니 담기",
                "desc": "예약 화면은 3단 레이아웃(대분류 → 품목 목록 → 선택된 장바구니)으로 구성되어 있습니다. 담당 교수자, 프로젝트명, 반출 희망일시를 입력한 뒤 원하는 장비의 '+ Add' 버튼을 눌러 장바구니에 담습니다.",
                "image": "05_booking_form_and_cart.png",
                "caption": "[그림 2-3] 예약 신청서 및 3단 장바구니 (교수자 지정, 프로젝트 정보, 담은 장비 목록)",
                "tips": [
                    "팀 과제인 경우 'Team'을 선택하고 팀원의 학번을 등록하면 동일 기간 내 중복 대여를 사전에 방지합니다.",
                    "반출일시를 선택하면 3일 대여 규칙에 따라 반납 마감 일시(오후 17:00)가 자동 계산됩니다."
                ]
            },
            {
                "subtitle": "2.4 예약 신청 전 최종 확인 팝업",
                "desc": "예약 신청 버튼을 클릭하면, 신청서 제출 전 최종 확인 팝업이 나타납니다. 교수자 승인 이후에는 학생이 임의로 장비를 변경하거나 취소할 수 없음을 명시하여 신중한 신청을 유도합니다.",
                "image": "06_final_confirm_modal.png",
                "caption": "[그림 2-4] 최종 예약 확인 팝업 (승인 후 수정 불가 정책 재확인)",
                "tips": [
                    "품목과 일정이 정확한지 팝업에서 마지막으로 검토한 후 '최종 예약 신청(Submit)'을 누릅니다.",
                    "신청 즉시 상태는 'SUBMITTED(승인 대기)'로 전환되어 교수자 포털 대기함으로 즉시 전송됩니다."
                ]
            },
            {
                "subtitle": "2.5 학생 마이페이지 (My Bookings) 현황 조회",
                "desc": "신청한 예약 내역과 승인 진행 상황을 실시간으로 확인할 수 있습니다. 상태는 'SUBMITTED(교수자 승인 대기)' → 'PROF_APPROVED(승인 완료/출납 대기)' → 'CHECKED_OUT(대여 중)' → 'RETURNED(반납 완료)' 순으로 자동 갱신됩니다.",
                "image": "07_student_my_bookings.png",
                "caption": "[그림 2-5] 학생 마이페이지 화면 (신청 상태, 반납 마감일, 대여 장비 내역 실시간 추적)",
                "tips": [
                    "승인이 완료되면 초록색 'Professor Approved' 배지가 표시되며, 지정된 반출 시간에 실습실(CAS 5106)을 방문하여 장비를 수령하면 됩니다.",
                    "반려된 경우 담당 교수자가 작성한 반려 사유를 확인할 수 있습니다."
                ]
            }
        ]
    },
    {
        "id": "3",
        "title": "제3부: 교수자(Faculty) 승인 포털",
        "intro": "교수자는 본인에게 배정된 학생들의 장비 대여 신청 건을 검토하고, 프로젝트 타당성과 안전성을 확인한 후 온라인에서 즉시 승인하거나 사유를 적어 반려할 수 있습니다.",
        "steps": [
            {
                "subtitle": "3.1 승인 대기 목록 검토 및 세부 내역",
                "desc": "교수자 계정으로 로그인하면 상단 메뉴에 'Faculty Approval' 전용 탭이 열립니다. 대기 중인 학생들의 학번, 성명, 프로젝트명, 대여 희망 일정 및 신청 장비 품목과 수량이 일목요연하게 표시됩니다.",
                "image": "08_faculty_approval_portal.png",
                "caption": "[그림 3-1] 교수자 승인 포털 (대기 신청 목록, 학생 상세 정보, 단건/일괄 승인 버튼)",
                "tips": [
                    "학생이 신청한 프로젝트 설명과 장비 구성을 검토하여 교육 목적에 부합하는지 확인합니다.",
                    "우측 상단의 'Approve All' 버튼을 사용하면 여러 건의 대기 신청을 한 번에 신속 승인할 수 있습니다.",
                    "부적절한 신청인 경우 'Reject' 버튼을 눌러 피드백 사유를 작성하면 학생 마이페이지에 전달됩니다."
                ]
            }
        ]
    },
    {
        "id": "4",
        "title": "제4부: 관리자(Admin) 통합 운영 및 환경 설정",
        "intro": "관리자(랩 매니저/조교)는 135개 장비의 일괄 엑셀 등록/다운로드, 학생 회원가입 동적 커스텀 필드 관리, 현장 출납/반납 데스크 운영 및 페널티 부여 기능을 수행합니다.",
        "steps": [
            {
                "subtitle": "4.1 장비 관리 및 엑셀 대량 일괄 등록 / 다운로드",
                "desc": "장비 목록 탭에서는 135개 전체 장비의 시리얼, 재고, 보관함을 관리합니다. 학과에서 관리 중인 엑셀 파일(.xlsx)을 드래그 앤 드롭하여 단번에 시스템에 일괄 반영하거나, 현재 시스템 데이터를 최신 엑셀 파일로 내려받을 수 있습니다.",
                "image": "09_admin_equipment_bulk.png",
                "caption": "[그림 4-1] 관리자 장비 관리 (엑셀 일괄 임포트, 엑셀 다운로드, 신규 장비 추가)",
                "tips": [
                    "병합 셀(Merged Cells)과 카테고리 계층 구조를 스마트 파서가 자동 해석하여 오류 없이 등록합니다.",
                    "장비별 개별 수정, 삭제, 고장 상태 변경(Under Maintenance)도 원클릭으로 가능합니다."
                ]
            },
            {
                "subtitle": "4.2 현장 출납 / 반납 데스크 (Operations Desk)",
                "desc": "학생이 실습실(CAS 5106)에 방문했을 때 현장 출납(Check-out) 및 반납(Check-in) 처리를 수행하는 데스크 화면입니다. 장비 시리얼 번호와 구성품(배터리, 충전기 등)의 누락 여부를 체크리스트로 확인합니다.",
                "image": "10_admin_operations_desk.png",
                "caption": "[그림 4-2] 현장 출납/반납 데스크 (체크리스트 확인, 구성품 점검, 반납 완료 처리)",
                "tips": [
                    "반납 시 파손이나 부품 분실이 발생한 경우 체크하면 시스템 기록 및 학생 계정에 알림이 연동됩니다.",
                    "지연 반납 학생의 경우 시스템이 초과 일수를 계산하여 자동 페널티 기간을 설정합니다."
                ]
            },
            {
                "subtitle": "4.3 학생 관리 및 회원가입 동적 커스텀 필드 빌더",
                "desc": "학생 관리 탭에서는 가입된 학생들의 상세 정보 및 페널티 현황을 조회할 수 있으며, 'Custom Field Builder'를 통해 코딩 없이 새로운 회원가입 입력 항목(예: 학과, 여권번호, 메신저 ID 등)을 즉시 생성/수정/삭제할 수 있습니다.",
                "image": "11_admin_custom_fields.png",
                "caption": "[그림 4-3] 관리자 학생 관리 및 동적 커스텀 필드 설정 (필드 타입, 필수 여부, 라벨 제어)",
                "tips": [
                    "텍스트(Text), 선택형(Select 드롭다운), 파일 첨부 등 다양한 필드 유형을 지원합니다.",
                    "여기서 추가된 필드는 학생 회원가입 페이지에 즉각 반영되어 데이터가 수집됩니다."
                ]
            }
        ]
    }
]

def build_docx():
    print(f"Generating Illustrated DOCX: {DOCX_OUT}")
    doc = Document()

    # Page Margins: 0.8 inch
    sections = doc.sections
    for s in sections:
        s.top_margin = Inches(0.8)
        s.bottom_margin = Inches(0.8)
        s.left_margin = Inches(0.8)
        s.right_margin = Inches(0.8)

    # Document Title
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_title = p_title.add_run("동서대학교 International College\n장비예약 관리시스템 사용자 매뉴얼")
    r_title.bold = True
    r_title.font.size = Pt(22)
    r_title.font.name = "Malgun Gothic"
    r_title.font.color.rgb = RGBColor(30, 64, 175) # Blue 800

    # Subtitle
    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_sub = p_sub.add_run("실제 예시 화면과 함께하는 학생 · 교수자 · 관리자 통합 가이드 (PC & Mobile)\n")
    r_sub.font.size = Pt(12)
    r_sub.font.name = "Malgun Gothic"
    r_sub.font.color.rgb = RGBColor(100, 116, 139)

    # Meta Table
    tbl = doc.add_table(rows=2, cols=2)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.autofit = False
    
    meta_info = [
        ("시스템 명칭", "동서대학교 IC 장비예약 관리시스템 (CAS 5106)"),
        ("외부 접속 URL", "https://endless-expertise-geographic-flyer.trycloudflare.com (Cloudflare Secure Tunnel)"),
        ("문서 버전", "v1.0 (그림 및 예시화면 포함 정식판)"),
        ("발행 및 관리", "동서대학교 영상애니메이션학부 / International College")
    ]
    r_idx = 0
    c_idx = 0
    for k, v in meta_info:
        cell = tbl.cell(r_idx, c_idx)
        p = cell.paragraphs[0]
        r1 = p.add_run(f"• {k}: ")
        r1.bold = True
        r1.font.size = Pt(9.5)
        r1.font.name = "Malgun Gothic"
        r2 = p.add_run(v)
        r2.font.size = Pt(9.5)
        r2.font.name = "Malgun Gothic"
        c_idx += 1
        if c_idx > 1:
            c_idx = 0
            r_idx += 1

    doc.add_paragraph() # spacing

    # Loop Sections
    for sec in SECTIONS:
        # Section Heading
        h1 = doc.add_paragraph()
        r_h1 = h1.add_run(sec["title"])
        r_h1.bold = True
        r_h1.font.size = Pt(16)
        r_h1.font.name = "Malgun Gothic"
        r_h1.font.color.rgb = RGBColor(30, 58, 138)

        # Intro
        p_intro = doc.add_paragraph()
        r_intro = p_intro.add_run(sec["intro"])
        r_intro.font.size = Pt(10.5)
        r_intro.font.name = "Malgun Gothic"
        r_intro.font.color.rgb = RGBColor(51, 65, 85)

        # Steps
        for step in sec["steps"]:
            # Subtitle
            h2 = doc.add_paragraph()
            r_h2 = h2.add_run(step["subtitle"])
            r_h2.bold = True
            r_h2.font.size = Pt(13)
            r_h2.font.name = "Malgun Gothic"
            r_h2.font.color.rgb = RGBColor(15, 23, 42)

            # Desc
            p_desc = doc.add_paragraph()
            r_desc = p_desc.add_run(step["desc"])
            r_desc.font.size = Pt(10)
            r_desc.font.name = "Malgun Gothic"
            r_desc.font.color.rgb = RGBColor(71, 85, 105)

            # Image
            img_path = os.path.join(SCREENSHOTS_DIR, step["image"])
            if os.path.exists(img_path):
                p_img = doc.add_paragraph()
                p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
                # If mobile image, use narrower width
                img_width = Inches(3.2) if "mobile" in step["image"] else Inches(5.8)
                p_img.add_run().add_picture(img_path, width=img_width)

                # Caption
                p_cap = doc.add_paragraph()
                p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
                r_cap = p_cap.add_run(step["caption"])
                r_cap.font.size = Pt(9)
                r_cap.font.name = "Malgun Gothic"
                r_cap.italic = True
                r_cap.font.color.rgb = RGBColor(100, 116, 139)

            # Tips / Action Points
            if "tips" in step and step["tips"]:
                tip_box = doc.add_table(rows=1, cols=1)
                tip_box.alignment = WD_TABLE_ALIGNMENT.CENTER
                cell = tip_box.cell(0, 0)
                # Light blue shading
                shading = parse_xml(r'<w:shd {} w:fill="F0F9FF"/>'.format(nsdecls('w')))
                cell._tc.get_or_add_tcPr().append(shading)
                p_tip = cell.paragraphs[0]
                r_tip_title = p_tip.add_run("💡 주요 핵심 안내 및 조작 팁\n")
                r_tip_title.bold = True
                r_tip_title.font.size = Pt(9.5)
                r_tip_title.font.name = "Malgun Gothic"
                r_tip_title.font.color.rgb = RGBColor(3, 105, 161)
                for t in step["tips"]:
                    r_t = p_tip.add_run(f"• {t}\n")
                    r_t.font.size = Pt(9)
                    r_t.font.name = "Malgun Gothic"
                    r_t.font.color.rgb = RGBColor(12, 74, 110)

            doc.add_paragraph() # Spacing between steps

    doc.save(DOCX_OUT)
    print(f"DOCX Generated successfully: {DOCX_OUT}")

class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_header_footer(num_pages)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def draw_header_footer(self, page_count):
        self.saveState()
        self.setFont("Malgun", 8)
        self.setFillColor(colors.HexColor("#64748B"))
        # Header (pages > 1)
        if self._pageNumber > 1:
            self.drawString(54, 800, "동서대학교 International College 장비예약 관리시스템 사용자 매뉴얼")
            self.setStrokeColor(colors.HexColor("#E2E8F0"))
            self.setLineWidth(0.5)
            self.line(54, 792, 541, 792)
        # Footer
        self.drawRightString(541, 36, f"페이지 {self._pageNumber} / {page_count}")
        self.drawString(54, 36, "동서대 IC 장비예약시스템 | Dongseo University CAS 5106 Lab")
        self.setStrokeColor(colors.HexColor("#E2E8F0"))
        self.setLineWidth(0.5)
        self.line(54, 48, 541, 48)
        self.restoreState()

def build_pdf():
    print(f"Generating Illustrated PDF: {PDF_OUT}")
    doc = SimpleDocTemplate(
        PDF_OUT,
        pagesize=A4,
        leftMargin=45,
        rightMargin=45,
        topMargin=54,
        bottomMargin=54
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "DocTitle",
        parent=styles["Normal"],
        fontName="MalgunBold",
        fontSize=20,
        leading=26,
        textColor=colors.HexColor("#1E3A8A"),
        alignment=1,
        spaceAfter=6
    )
    sub_style = ParagraphStyle(
        "DocSub",
        parent=styles["Normal"],
        fontName="Malgun",
        fontSize=11,
        leading=16,
        textColor=colors.HexColor("#64748B"),
        alignment=1,
        spaceAfter=15
    )
    sec_style = ParagraphStyle(
        "SecTitle",
        parent=styles["Normal"],
        fontName="MalgunBold",
        fontSize=15,
        leading=20,
        textColor=colors.HexColor("#1E40AF"),
        spaceBefore=14,
        spaceAfter=8,
        keepWithNext=True
    )
    step_style = ParagraphStyle(
        "StepTitle",
        parent=styles["Normal"],
        fontName="MalgunBold",
        fontSize=12,
        leading=16,
        textColor=colors.HexColor("#0F172A"),
        spaceBefore=10,
        spaceAfter=6,
        keepWithNext=True
    )
    body_style = ParagraphStyle(
        "Body",
        parent=styles["Normal"],
        fontName="Malgun",
        fontSize=9.5,
        leading=14,
        textColor=colors.HexColor("#334155"),
        spaceAfter=6
    )
    cap_style = ParagraphStyle(
        "Caption",
        parent=styles["Normal"],
        fontName="Malgun",
        fontSize=8.5,
        leading=12,
        textColor=colors.HexColor("#64748B"),
        alignment=1,
        spaceBefore=4,
        spaceAfter=8
    )
    tip_style = ParagraphStyle(
        "TipText",
        parent=styles["Normal"],
        fontName="Malgun",
        fontSize=8.5,
        leading=13,
        textColor=colors.HexColor("#0369A1")
    )

    story = []

    # Title & Subtitle
    story.append(Paragraph("동서대학교 International College<br/>장비예약 관리시스템 사용자 매뉴얼", title_style))
    story.append(Paragraph("실제 예시 화면과 함께하는 학생 · 교수자 · 관리자 통합 가이드 (PC & Mobile)", sub_style))

    # Meta Table Box
    meta_data = [
        [
            Paragraph("<b>• 시스템 명칭:</b> 동서대 IC 장비예약 관리시스템 (CAS 5106)", body_style),
            Paragraph("<b>• 버전:</b> v1.0 (예시화면 수록 정식판)", body_style)
        ],
        [
            Paragraph("<b>• 외부 접속:</b> trycloudflare.com (보안 터널)", body_style),
            Paragraph("<b>• 주관:</b> 영상애니메이션학부 / International College", body_style)
        ]
    ]
    meta_table = Table(meta_data, colWidths=[270, 235])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#F8FAFC")),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor("#E2E8F0")),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor("#E2E8F0")),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 12))

    for sec in SECTIONS:
        story.append(Paragraph(sec["title"], sec_style))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#DBEAFE"), spaceAfter=8))
        story.append(Paragraph(sec["intro"], body_style))
        story.append(Spacer(1, 4))

        for step in sec["steps"]:
            story.append(Paragraph(step["subtitle"], step_style))
            story.append(Paragraph(step["desc"], body_style))

            img_path = os.path.join(SCREENSHOTS_DIR, step["image"])
            if os.path.exists(img_path):
                # Scale appropriately for PDF
                if "mobile" in step["image"]:
                    img_w = 200
                    img_h = 432
                else:
                    img_w = 460
                    img_h = 240
                
                img_flowable = RLImage(img_path, width=img_w, height=img_h)
                story.append(KeepTogether([
                    img_flowable,
                    Paragraph(step["caption"], cap_style)
                ]))

            if "tips" in step and step["tips"]:
                tip_paras = [Paragraph("<b>💡 주요 핵심 안내 및 조작 팁</b>", tip_style)]
                for t in step["tips"]:
                    tip_paras.append(Paragraph(f"• {t}", tip_style))
                
                tip_table = Table([[tip_paras]], colWidths=[505])
                tip_table.setStyle(TableStyle([
                    ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#F0F9FF")),
                    ('BOX', (0,0), (-1,-1), 1, colors.HexColor("#BAE6FD")),
                    ('TOPPADDING', (0,0), (-1,-1), 6),
                    ('BOTTOMPADDING', (0,0), (-1,-1), 6),
                    ('LEFTPADDING', (0,0), (-1,-1), 10),
                    ('RIGHTPADDING', (0,0), (-1,-1), 10),
                ]))
                story.append(KeepTogether([tip_table]))

            story.append(Spacer(1, 10))

    doc.build(story, canvasmaker=NumberedCanvas)
    print(f"PDF Generated successfully: {PDF_OUT}")

if __name__ == "__main__":
    build_docx()
    build_pdf()
    print("All illustrated documents created successfully!")
