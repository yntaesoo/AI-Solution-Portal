import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const facultyList = await prisma.user.findMany({
      where: {
        role: "FACULTY",
        status: "ACTIVE",
      },
      select: {
        id: true,
        studentId: true,
        fullName: true,
        email: true,
      },
      orderBy: { fullName: "asc" },
    });

    return NextResponse.json({ faculty: facultyList });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
