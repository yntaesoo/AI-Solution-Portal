"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Calendar,
  Clock,
  MapPin,
  AlertTriangle,
  Info,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  BookOpen,
  Camera,
  X,
  Smartphone,
  GraduationCap,
} from "lucide-react";

export default function HomePage() {
  const [settings, setSettings] = useState<any>(null);
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    fetch("/api/settings")
      .then((res) => res.json())
      .then((data) => {
        if (data.settings) {
          setSettings(data.settings);
          if (data.settings.popup_notice?.active) {
            setShowPopup(true);
          }
        }
      })
      .catch(() => {});
  }, []);

  const banner = settings?.notice_banner || {
    title_en: "DSU International College Equipment Lab (CAS 5106)",
    title_zh: "东西大学 国际学院 器材室（CAS 5106）",
    desc_en: "Operating Hours: Mon - Fri 09:30 - 17:00 (Break: 12:00 - 13:00). Pickups every 30 mins.",
    desc_zh: "开放时间：周一至周五 09:30 - 17:00（午休 12:00 - 13:00）。提货时间以30分钟为单位。",
  };

  const popup = settings?.popup_notice;

  return (
    <div className="space-y-8 animate-fadeIn max-w-7xl mx-auto pb-10">
      {/* Holiday / Operational Announcement Modal Popup */}
      {showPopup && popup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-100 relative animate-scaleUp">
            <button
              onClick={() => setShowPopup(false)}
              className="absolute top-5 right-5 text-slate-400 hover:text-slate-600 p-1.5 rounded-xl hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-3 text-amber-600 mb-3">
              <div className="p-3 rounded-2xl bg-amber-50">
                <AlertTriangle className="w-7 h-7" />
              </div>
              <div>
                <h3 className="font-extrabold text-xl text-slate-900">{popup.title_en}</h3>
                <p className="text-xs sm:text-sm text-amber-700 font-bold">{popup.title_zh}</p>
              </div>
            </div>
            <div className="space-y-3 text-sm sm:text-base text-slate-700 py-4 border-y border-slate-100">
              <p className="leading-relaxed whitespace-pre-line font-medium">{popup.content_en}</p>
              <p className="leading-relaxed whitespace-pre-line text-slate-500 text-sm mt-2">{popup.content_zh}</p>
            </div>
            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setShowPopup(false)}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold transition shadow-md"
              >
                I Understand / 知道了
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Smartphone Wi-Fi Access Banner */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-4 text-white shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-white/20 rounded-xl">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-bold text-sm sm:text-base">Mobile Ready System (스마트폰 접속 지원)</h4>
            <p className="text-xs sm:text-sm text-emerald-100">
              Open mobile browser on campus Wi-Fi at: <code className="bg-black/20 px-2 py-0.5 rounded font-mono font-bold">http://192.168.0.101:3000</code>
            </p>
          </div>
        </div>
        <span className="self-end sm:self-auto text-xs px-3 py-1 bg-white/20 rounded-full font-bold">
          Touch Friendly
        </span>
      </div>

      {/* Hero Notice Banner */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-900 via-indigo-950 to-slate-900 text-white p-8 sm:p-14 shadow-2xl">
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/20 text-blue-200 border border-blue-400/30 text-xs sm:text-sm font-bold">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            Semester Equipment Rental Active (학기 중 정상 운영)
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight">
            {banner.title_en}
          </h1>
          <h2 className="text-lg sm:text-2xl text-blue-200 font-semibold">{banner.title_zh}</h2>
          <div className="text-slate-200 text-sm sm:text-base leading-relaxed pt-2 space-y-1">
            <p className="font-medium">{banner.desc_en}</p>
            <p className="text-slate-400 text-xs sm:text-sm">{banner.desc_zh}</p>
          </div>

          <div className="pt-5 flex flex-wrap gap-4">
            <Link
              href="/booking"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-2xl bg-blue-500 hover:bg-blue-600 font-bold text-white text-base shadow-xl shadow-blue-500/30 transition transform hover:-translate-y-0.5"
            >
              <span>Reserve Equipment Now</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              href="/catalog"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-2xl bg-white/10 hover:bg-white/20 backdrop-blur font-bold text-white text-base border border-white/20 transition"
            >
              <Camera className="w-5 h-5" />
              <span>Browse Catalog (135+ Models)</span>
            </Link>
          </div>
        </div>

        {/* Decorative Element */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
      </section>

      {/* Quick Info Grid with Bigger Fonts */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
            <Clock className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-900 text-lg">Pickup & Return Times</h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5 mb-3 font-medium">대여 및 반출 시간 안내</p>
          <ul className="text-sm text-slate-700 space-y-2 leading-relaxed">
            <li>• Pickups every <strong>30 minutes</strong> during lab hours</li>
            <li>• Standard Rental Duration: <strong>3 Days</strong></li>
            <li>• Book at least 1 day in advance</li>
            <li>• Returns due strictly by <strong>17:00</strong> on the 3rd day</li>
          </ul>
        </div>

        <div className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-4">
            <MapPin className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-900 text-lg">Lab Location & Contact</h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5 mb-3 font-medium">장비실 위치 및 연락처</p>
          <ul className="text-sm text-slate-700 space-y-2 leading-relaxed">
            <li>• <strong>Location:</strong> CAS Building Room 5106 (CAS 5106호)</li>
            <li>• <strong>Email:</strong> ic.lab@dongseo.ac.kr</li>
            <li>• <strong>Management:</strong> Film & VFX Equipment Office</li>
            <li>• Virtual Production & In-Camera VFX storage</li>
          </ul>
        </div>

        <div className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-900 text-lg">Strict Penalty Rules</h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5 mb-3 font-medium">반납 지각 및 패널티 규정 (지각 체크)</p>
          <ul className="text-sm text-slate-700 space-y-2 leading-relaxed">
            <li>• <strong>1st Late Return:</strong> 1 Month Booking Suspension</li>
            <li>• <strong>2nd Late Return:</strong> 1 Semester (6 Months) Suspension</li>
            <li>• Consecutive back-to-back rentals strictly blocked</li>
            <li>• Max <strong>2 active bookings</strong> allowed per student</li>
          </ul>
        </div>
      </section>

      {/* Guidelines & Terms Preview */}
      <section className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 rounded-2xl bg-blue-50 text-blue-700">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">Equipment Rental Regulations / 器材借用规程</h2>
            <p className="text-xs sm:text-sm text-slate-500">Dongseo University International College Academic Equipment Policy</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-sm sm:text-base text-slate-700">
          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 space-y-3">
            <h4 className="font-bold text-slate-900 flex items-center gap-2 text-base">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
              English Regulations
            </h4>
            <div className="text-sm leading-relaxed text-slate-700 space-y-2.5">
              <p>1. Equipment is available to enrolled IC students and non-IC students taking IC courses.</p>
              <p>2. Graduate students may reserve up to 2 months in advance; undergraduate students up to 1 month.</p>
              <p>3. Advanced cameras (e.g., Blackmagic PYXIS 12K) require prior completion of certified training by Prof. Yoon.</p>
              <p>4. Digital signature is mandatory upon checkout and return using the laboratory tablet.</p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 space-y-3">
            <h4 className="font-bold text-slate-900 flex items-center gap-2 text-base">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-600"></span>
              中文借用规程
            </h4>
            <div className="text-sm leading-relaxed text-slate-700 space-y-2.5">
              <p>1. 本系统面向修读国际学院（IC）课程的所有在校学生开放。</p>
              <p>2. 研究生可提前2个月预约器材；本科生可提前1个月预约（先到先得）。</p>
              <p>3. 部分高精器材（如Blackmagic PYXIS 12K）仅限参加过尹教授培训的学员借用。</p>
              <p>4. 提货和归还时必须在器材室平板电脑上完成电子签名以建立责任凭证。</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
