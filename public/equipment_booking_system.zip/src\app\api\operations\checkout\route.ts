import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Lab Admin only." }, { status: 403 });
    }

    const body = await req.json();
    const {
      reservationId,
      checkoutNotes,
      signatureDataUrl,
      signerName,
      mappedItems, // array of { reservationItemId, barcodeId }
      additionalBarcodeIds, // array of barcodeId added on site
    } = body;

    if (!reservationId || !signatureDataUrl) {
      return NextResponse.json({ error: "Reservation ID and Digital Signature are required." }, { status: 400 });
    }

    const reservation = await prisma.reservation.findUnique({
      where: { id: reservationId },
      include: { items: true, user: true },
    });

    if (!reservation) {
      return NextResponse.json({ error: "Reservation not found." }, { status: 404 });
    }

    // 1. Map Barcodes to reserved items and mark EquipmentItem as RENTED
    if (Array.isArray(mappedItems)) {
      for (const map of mappedItems) {
        if (!map.barcodeId) continue;
        const item = await prisma.equipmentItem.findUnique({
          where: { barcodeId: map.barcodeId.trim() },
        });

        if (item) {
          await prisma.reservationItem.update({
            where: { id: map.reservationItemId },
            data: { equipmentItemId: item.id },
          });

          await prisma.equipmentItem.update({
            where: { id: item.id },
            data: { status: "RENTED" },
          });
        }
      }
    }

    // 2. Add extra on-site items if requested (Specification 4-(16))
    if (Array.isArray(additionalBarcodeIds)) {
      for (const barcode of additionalBarcodeIds) {
        if (!barcode) continue;
        const item = await prisma.equipmentItem.findUnique({
          where: { barcodeId: barcode.trim() },
          include: { model: true },
        });

        if (item && item.status === "AVAILABLE") {
          await prisma.reservationItem.create({
            data: {
              reservationId: reservation.id,
              modelId: item.modelId,
              equipmentItemId: item.id,
              quantity: 1,
            },
          });

          await prisma.equipmentItem.update({
            where: { id: item.id },
            data: { status: "RENTED" },
          });
        }
      }
    }

    // 3. Save digital signature
    await prisma.signatureLog.create({
      data: {
        reservationId: reservation.id,
        signatureType: "CHECKOUT",
        signatureDataUrl,
        signerName: signerName || reservation.user.fullName,
      },
    });

    // 4. Update reservation status to CHECKED_OUT
    const updated = await prisma.reservation.update({
      where: { id: reservation.id },
      data: {
        status: "CHECKED_OUT",
        checkoutNotes: checkoutNotes || "Equipment handed over in good condition.",
      },
      include: {
        items: { include: { model: true, equipmentItem: true } },
        signatureLogs: true,
      },
    });

    return NextResponse.json({
      success: true,
      message: "Check-out completed and digital signature recorded!",
      reservation: updated,
    });
  } catch (error: any) {
    console.error("Checkout error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
