# [MASTER SPECIFICATION & PROMPT] 동서대학교 International College (IC) 유학생 장비예약 관리시스템 개발 사양서

> **문서 버전:** v1.0.0 (Master Release)  
> **기준 일자:** 2026-10-13  
> **참조 문서:** 
> - `장비 예약 시스템 구축시 검토 사항 정리_26-04-20.pdf`
> - `장비예약시스템_요구사항_정리_및_검토_26-10-11.pdf`
> - `Dept. of Film and VFX Equipment.xlsx` (장비 보유 인벤토리)
> **대상 사용자:** 동서대 International College(IC) 소속/수강 외국인 유학생, 교수자, 장비실 관리자/조교

---

## 1. 프로젝트 개요 및 핵심 목표 (Project Overview)

### 1.1 배경 및 목적
동서대학교 International College(IC)의 Film & VFX 등 실습 중심 학과 및 IC 개설 교과목을 수강하는 다국적 유학생을 위해, 직관적이고 표준화된 **웹 기반 스마트 기자재 예약 및 반출/반납 자산 관리 시스템**을 구축한다. 기존 수기/오프라인 대여의 분실·파손 위험을 최소화하고, 다국어 환경 지원 및 전자서명 기반의 책임 대여 체계를 확립한다.

### 1.2 핵심 3대 중점 요구사항 (User Key Directives)
1. **규정 및 검토의견의 완벽한 시스템화**:
   - 2026.04.20 원안 및 2026.10.11 검토 의견(규정 상충, 상태 전이, 승인 체계, 패널티, 전자서명)을 일관된 논리 모델로 표준화.
2. **장비 리스트 일괄등록 및 동적 자산 관리**:
   - `Dept. of Film and VFX Equipment.xlsx` 인벤토리 엑셀 서식(대분류, 소분류, 브랜드, 모델명, 수량, 비고 등)을 관리자 화면에서 일괄 업로드(Bulk Import) 및 다운로드(Export) 지원.
   - 개별 시리얼/바코드(QR) 매핑, 추가/수정/삭제(CRUD), 대분류/소분류 이동 및 구조 관리.
3. **학생 회원가입 및 백엔드 동적 커스텀 필드(Dynamic Custom Schema)**:
   - 기본 필수 필드: 학번(Student ID), 이름(Full Name), 이메일(Email), 연락처(Phone Number), 비밀번호(Password).
   - 관리자(Backend) 설정에 따라 가입 및 프로필에 추가 필드(예: 소속학과, 국적/비자, 위챗 ID, 카카오톡 ID, 웹캠 촬영 프로필 사진 등)를 자유롭게 추가/수정/비활성화할 수 있는 동적 폼 엔진(EAV 또는 JSON Schema Form) 탑재.

---

## 2. 시스템 아키텍처 및 기술 스택 권장안 (System Architecture)

### 2.1 권장 기술 스택 (Modern Full-Stack)
- **Frontend**: Next.js 14+ (App Router) 또는 React + Vite, TypeScript, Tailwind CSS, shadcn/ui (반응형: Desktop, Tablet iPad 전자서명, Mobile).
- **Backend / API**: Node.js (NestJS / Next.js API Routes) 또는 Python (FastAPI) - RESTful / Type-safe API.
- **Database**: PostgreSQL (Prisma ORM 또는 Drizzle ORM) + JSONB 지원 (동적 회원 필드 및 장비 옵션 관리에 최적).
- **인증/보안**: JWT 기반 세션/쿠키, Role-Based Access Control (RBAC), bcrypt 비밀번호 암호화.
- **문서/파일/바코드 처리**:
  - 서명: `react-signature-canvas` (태블릿 터치 서명 지원)
  - 바코드/QR: `qrcode`, `html5-qrcode` (카메라 기반 웹 스캔 및 출력 생성)
  - 엑셀/PDF: `xlsx` / `exceljs`, `jspdf` / `pdfmake` (대여증 자동 생성 및 보관)
  - 웹캠 촬영: `react-webcam` (프로필 사진 및 파손 장비 실시간 캡처)

### 2.2 반응형 디바이스 및 다국어 지원 (i18n)
- **지원 디바이스**: PC 웹 브라우저, 관리실 태블릿(iPad/Android Tablet - 서약서 서명 및 현장 바코드 스캔), 모바일 웹.
- **다국어 체계**:
  - UI 레이블 & 기본 인터페이스: **영어(English)** 기본.
  - 규정(Regulations), 공지사항(Notices), 팝업/배너 안내: **영어 + 중국어(간체) 병기** 필수.
  - 관리자 콘솔: 관리자 편의를 위해 **한국어/영어** 토글 지원.

---

## 3. 사용자 역할 및 권한 관리 (Role & Permission)

### 3.1 사용자 역할 (RBAC)
1. **슈퍼 관리자 (Super Admin)**:
   - 시스템 전체 설정, 관리자 계정 생성, 동적 가입 필드 설정, 데이터베이스 백업 및 감사 로그(Audit Logs) 열람.
2. **장비실 관리자/조교 (Equipment Manager / Lab Assistant)**:
   - 장비 일괄 업로드 및 CRUD, 바코드/QR 출력, 대여 승인/반려, 현장 반출(서명 수합), 반납 점검(파손/지각 체크), 관리자 직권(Override) 제어.
3. **교수자 (Faculty / Instructor)**:
   - 본인 수업 과제용 장비 예약 신청 건 검토 및 승인/반려, 수업용 대여 신청 내역 조회.
4. **학생 (Student - Undergrad / Grad / Certified)**:
   - 장비 검색 및 예약, 약관 동의, 전자서약서 서명, 본인 대여 이력 및 패널티 조회.

### 3.2 수강생 자동 필터링 및 권한 라이프사이클
- **IC 수강생 자동 매핑**: 매 학기 IC 개설 수업 수강신청 명단(Excel/CSV 업로드)과 대조하여 자동 권한 부여. 타 단과대 학생이라도 IC 교과목 수강 시 예약 권한 부여. 비수강자는 예약 불가(사유 안내).
- **대학원생 권한**: 대학원 비주얼콘텐츠학과 영어트랙 학생에 한해 2개월 전 우선 예약 권한 부여 (수강생 명단 플래그 또는 관리자 지정).
- **특별교육 이수자 (Certified Users)**: 고가/고급 장비(예: Blackmagic PYXIS 12K 등 윤 교수 사전 교육 이수 필수 장비)는 관리자가 학생 계정에 "특수 교육 수료 태그(Certification Tag)"를 부여한 경우에만 예약 슬롯 활성화.
- **관리자 수동 지정(Whitelist)**: 교환학생, 특별연구생 등 학적 사각지대 학생을 위해 관리자가 학번을 입력하여 수동 권한 부여/회수 가능.

---

## 4. 회원 관리 및 동적 커스텀 필드 설계 (User & Dynamic Fields)

### 4.1 회원가입 및 프로필 기본 필드 (Core Fields)
- `student_id` (학번, Unique, 로그인 ID)
- `full_name` (영문/한글 이름)
- `email` (학교/개인 이메일, 알림 수신용)
- `phone` (연락처, 필수)
- `password_hash` (암호화된 비밀번호)
- `status` (ACTIVE, BLOCKED, PENALTY, PENDING_APPROVAL)
- `role` (UNDERGRAD, GRADUATE, FACULTY, STAFF, ADMIN)

### 4.2 백엔드 주도 동적 커스텀 필드 시스템 (Dynamic Custom Field Engine)
관리자가 Admin UI에서 코딩 없이 학생 가입/프로필 필드를 추가/제어:
- **필드 메타데이터 테이블 (`custom_field_definitions`)**:
  - `field_name` (식별자, 예: `major`, `wechat_id`, `kakao_id`, `nationality`, `profile_photo`)
  - `label_en`, `label_ko`, `label_zh` (다국어 라벨)
  - `field_type` (`TEXT`, `NUMBER`, `SELECT`, `RADIO`, `CHECKBOX`, `IMAGE_WEBCAM`, `DATE`)
  - `options` (드롭다운 옵션 목록 - JSON Array)
  - `is_required` (필수 여부 - true/false)
  - `is_visible_on_register` (가입 화면 표시 여부)
  - `is_editable_by_user` (사용자 수정 가능 여부)
  - `display_order` (정렬 순서)
- **학생별 값 저장 (`user_custom_values`)**:
  - `user_id` + `custom_field_id` + `field_value` (또는 `users` 테이블 내 `jsonb` 프로필 필드로 저장)
- **웹캠 프로필 사진 등록 지원**:
  - 회원가입 또는 프로필 설정 시 PC/노트북 웹캠으로 즉석 얼굴 사진 캡처 또는 파일 업로드 지원.

---

## 5. 장비 자산 관리 및 엑셀 일괄 등록 (Equipment Inventory & Bulk Import)

### 5.1 인벤토리 데이터 구조 (2-Tier Hierarchy)
현장 보유 목록(`Dept. of Film and VFX Equipment.xlsx`)의 구조를 수용하여 모델(Item Type)과 개별 실물(Asset Unit)을 분리 관리:
1. **장비 모델/품목 (Equipment Model)**:
   - `category_id` (대분류: Camera, Camera Accessory, Lighting, Sound, Grip, Production Support 등)
   - `subcategory_id` (소분류: DSLR Camera, Cinema Modular Camera, Lens, Tripod 등)
   - `brand` (제조사: Canon, Blackmagic, Sony, TILTA 등)
   - `model_name` (모델명: EOS 700D Set, PYXIS 6K 등)
   - `total_quantity` (총 보유 수량)
   - `remarks` (기본 구성품: 배터리, 충전기, 케이스, 케이블 등 / 대여 제한 메모)
   - `target_audience` (대여 가능 대상: ALL, UNDERGRAD_ONLY, GRAD_ONLY, CERTIFIED_ONLY, CUSTOM_GROUP)
   - `description_materials` (장비 설명 텍스트, 사용자 매뉴얼 PDF, 패킹 가이드 사진, 외부 참고 링크)
2. **개별 실물 장비 (Equipment Item / Asset Serial)**:
   - `asset_tag` / `barcode_id` (고유 자산번호 및 바코드/QR 번호)
   - `serial_number` (제조사 시리얼 번호)
   - `status` (AVAILABLE, RESERVED, RENTED, UNDER_REPAIR, BROKEN, LOST, CLASS_USE)
   - `current_condition_notes` (상태 점검 메모 및 웹캠 파손 사진 URL)

### 5.2 엑셀 일괄 등록 (Bulk Upload / Import) 및 관리 기능
- **스마트 엑셀 파서 (Merged Cell Support)**:
  - 제공된 엑셀(`Dept. of Film and VFX Equipment.xlsx`)처럼 대분류(Categorization)와 소분류(Sort)가 병합되어 빈 칸으로 나타나는 행을 자동으로 직전 상위 카테고리로 채움(Forward Fill) 처리하여 데이터 손실 없이 완벽 Import.
  - 필수 컬럼 자동 검증: Category, Subcategory, Brand, Model, Quantity, Remarks.
  - 업로드 전 프리뷰 화면 제공 (정상 건수, 오류 건수, 신규 생성 카테고리 알림).
- **엑셀 출력 (Bulk Export)**:
  - 대분류/소분류별 장비명, 수량, 가용 상태, 비고가 포함된 정규 보고서 엑셀 다운로드 (규정 1-(1)).
- **동적 카테고리 관리**:
  - 관리자가 대분류/소분류를 추가/수정/삭제 가능.
  - 특정 카테고리 삭제 시, 해당 카테고리에 속한 장비들을 다른 카테고리로 안전하게 일괄 이전(Migrate)하는 모달 지원 (규정 2-(3)).
- **바코드 & QR 코드 생성 및 라벨 출력**:
  - 장비 신규 등록 또는 일괄 등록 시 품목별/시리얼별 고유 QR 코드 및 바코드 자동 생성.
  - 라벨 프린터 규격(A4 스티커 또는 전용 라벨지)에 맞춘 다건 출력 인쇄 기능 (규정 2-(5)).

---

## 6. 예약 및 대여 워크플로우 (Reservation Lifecycle & Rules)

### 6.1 규정 상충 해결 및 상태 머신 (Reservation State Machine)
검토 의견(A-1, A-2)의 상충을 해결하기 위해 예약 상태 및 권한을 다음과 같이 명확히 정의함:

| 상태 (Status) | 설명 | 학생 권한 | 관리자 권한 | 장비 재고 상태 |
| :--- | :--- | :--- | :--- | :--- |
| **DRAFT** | 장바구니 담기 및 작성 중 | 추가 / 삭제 / 변경 자유 | - | 미점유 |
| **SUBMITTED** | 약관 동의 및 신청서 제출 | **취소 가능, 품목 수정 가능** | 접수 확인, 반려, 직권 취소 | 가점유 (Hold) |
| **PROF_APPROVED** | 교수자 승인 완료 (학기 중 자동) | 취소 가능 (품목 수정 불가) | 최종 승인 또는 반려 | 가점유 유지 |
| **CONFIRMED** | 관리자 최종 승인 완료 | **취소만 가능 (사용 1일 전까지)** | **직권 추가/변경/취소 가능** | 예약 확정 (Reserved) |
| **CHECKED_OUT** | 현장 서명 후 장비 반출(대여 중) | 반납 준비 | 현장 품목 추가, 상태 기록 | 대여 중 (Rented) |
| **RETURNED** | 반납 검수 및 최종 서명 완료 | 내역 및 서약서 조회 | 파손/지각 체크, 패널티 부과 | 사용 가능 복귀 (Available) |
| **CANCELLED / REJECTED** | 취소 또는 반려 | 재신청 | 반려 사유 입력 | 즉시 재고 환원 |

### 6.2 예약 프로세스 상세 단계 (Step-by-Step)
1. **로그인 & 패널티 팝업**:
   - 학생 로그인 시 현재 누적 패널티 내역 및 이용 제한 여부 표시 (정지 상태일 시 예약 신청 차단).
2. **약관 동의 (Terms of Service)**:
   - 예약 시작 시 기자재 이용 서약서 팝업 (관리자가 언제든 수정 가능). "동의(Agree)" 필수.
3. **과제 및 프로젝트 정보 입력**:
   - 담당 교수자 선택 (수강 과목 연동)
   - 과제 유형: 개인 과제 (Individual) / 팀 과제 (Team) / 졸업 작품 (Graduation Project)
   - 프로젝트 제목 및 간략한 개요(Description) 필수 입력.
4. **팀 과제 그룹핑 및 중복 방지 (Team Conflict Prevention)**:
   - 팀 과제 선택 시 팀원 학번 입력 -> 시스템이 자동 그룹핑.
   - 동일 수업의 동일 기간 내에 등록된 팀원은 중복으로 장비를 신청할 수 없도록 자동 차단.
5. **대여 일정 및 시간 선택**:
   - 기본 대여 기간: **3일 (3 Days)**. (주말/공휴일 포함 여부는 관리자 설정 캘린더 연동).
   - 반출 시간: **30분 단위**로 지정 (예: 10:00, 10:30, 11:00 ...).
   - 반납 예정 시각: 반출일로부터 3일째 되는 날의 지정 업무 마감 시각(예: 17:00) 자동 세팅.
6. **장비 선택 3단 레이아웃 (Cart UI & Availability Calendar)**:
   - 좌측: 대분류 (Category List)
   - 중앙: 소분류 및 가용 장비 리스트 (Subcategory & Items with stock status)
   - 우측: 장바구니 (Selected Items Basket)
   - 보조 뷰: 장비별 월간/주간 대여 가용 달력 (Calendar View).
7. **최종 확인 팝업**:
   - *"최종 승인 후에는 장비 변경이 불가하며, 취소는 1일 전까지만 가능합니다. 계속 진행하시겠습니까?"* 다국어 안내 팝업 확인 후 최종 제출.

### 6.3 대여 규칙 및 제한 (Rules & Quotas)
- **예약 오픈 시점**:
  - 대학원생: 사용 희망일 기준 **2개월 전**부터 예약 가능.
  - 학부생: 사용 희망일 기준 **1개월 전**부터 예약 가능.
  - 신청 마감: 최소 사용일 **1일 전**까지. (선착순 원칙).
- **보유 건수 및 연속 대여 제한**:
  - 1인당 동시 유효 예약/대여는 **최대 2건**으로 제한.
  - 동일 장비의 연속 대여는 원칙적 불가 (최소 1일의 반납 간격/쿨다운 필요).
- **방학 중 대여 및 연장 (Vacation Policy)**:
  - 방학 중 잔여 재고가 있고 후속 예약이 없을 경우 관리자 직권으로 **최대 7일까지 연장** 가능.
  - 승인 방식: 학기 중에는 교수자 "자동 승인(Auto-Approval)", 방학 중에는 지도교수 또는 학과 지정 교수 "수동 승인(Manual-Approval)" 모드로 관리자가 손쉽게 전환.
- **수업용 장비 지정 및 관리자 직권(Override)**:
  - 관리자는 시스템 규칙에 구애받지 않고 언제든 특정 장비를 수업용(Class Use)으로 지정하거나 직권 대여/취소 가능.
  - 기존 예약이 있는 장비를 직권 취소할 경우 해당 학생에게 대체 장비 안내 및 취소 이메일 자동 발송.

---

## 7. 현장 반출(대여) 및 반납 검수 처리 (Field Operations)

### 7.1 대여 반출 처리 (Check-out)
1. **신청 내역 호출**: 학생 학번 조회 또는 예약증 바코드/QR 스캔.
2. **실물 장비 바코드 스캔 매핑**:
   - 출고할 실물 장비의 바코드/QR을 스캔하여 해당 예약 건에 시리얼 단위로 실시간 매핑.
3. **현장 즉석 품목 추가**:
   - 현장에서 학생 요청 및 관리자 판단에 따라 추가 소모품/부속 장비를 바코드 스캔으로 즉시 추가.
4. **외관 점검 및 관리자 코멘트**:
   - 출고 전 장비 작동 상태 및 외관 점검 메모 기록.
5. **전자 서명 (Digital Signature Pad)**:
   - 태블릿 화면에서 대여 약관 서약서에 학생이 직접 터치펜/손가락으로 전자 서명.
   - 서명 완료 즉시 공식 전자 대여 확인증(PDF)이 생성되어 보관되며, 필요 시 즉시 출력.

### 7.2 반납 검수 및 파손/지각 처리 (Check-in)
1. **장비 회수 스캔**: 반납 장비 바코드 스캔으로 반납 건 자동 매칭.
2. **지각(연체) 자동 판정**:
   - 규정된 반납 마감 시각 초과 시 시스템이 "지각(Late)" 플래그 자동 체크.
3. **상태 검수 및 파손 보고**:
   - 정상 반납 / 수리 필요 / 파손 / 분실 중 관리자 선택.
   - 파손/이상 발생 시 태블릿/PC 웹캠으로 즉석 실물 사진 촬영 또는 이미지 업로드 첨부.
   - 파손 처리 시 시스템 인벤토리에 실시간 '대여 불가(UNDER_REPAIR)' 반영.
   - **자동 안내 메일**: 해당 파손 장비를 향후 예약해 둔 후속 학생들에게 *"장비 파손으로 인한 대여 불가 및 대체 안내"* 이메일 자동 발송.
4. **반납 전자 서명**:
   - 점검 내용 확인 후 최종 반납 서명 진행 -> 완료 서류로 자동 아카이빙.

### 7.3 패널티 규정 및 자동 해제 (Penalty System)
- **지각 1회**: **1개월 대여 금지**.
- **지각 2회**: **1학기(6개월) 대여 금지**.
- **파손/분실**: 관리자 수동 평가 및 배상 절차 등록 시까지 임시 대여 제한.
- **자동 해제**: 패널티 기간이 경과하면 시스템 스케줄러가 매일 자정에 이용 권한 자동 복구.
- **가변성**: 관리자 콘솔에서 학생별 패널티 사유 수정, 기간 단축, 직권 사면(Pardon) 가능.

---

## 8. 홈페이지 운영, 알림 및 출력 보고서 (Portal & Reporting)

### 8.1 포털 첫 화면 및 공지 시스템
- **상단 긴급 팝업 (Modal Popup)**:
  - 장비실 휴무일, 근무 시간 단축, 방학 중 운영 안내 등 텍스트 중심 공지 (관리자가 즉시 수정).
- **메인 안내 배너 (Hero/Banner)**:
  - 장비실 위치(CAS 5106 등), 일일 대여/반납 시간, 유의사항 영문/중문 병기 배너.
- **이메일 자동 알림 서비스 (SMTP Engine)**:
  - 예약 신청 접수 / 교수 승인 / 관리자 최종 확정 안내.
  - 반납 예정일 D-1 사전 리마인드 알림.
  - 파손/직권 취소로 인한 긴급 통보 알림.

### 8.2 출력 및 엑셀 리포트 기능
1. **장비 보유 현황 엑셀 다운로드**: 대분류별 세부 항목, 장비명, 수량, 가용 상태, 비고 (규정 1-(1)).
2. **학생 전체 명단 및 대여 현황 엑셀**: 학부/대학원, 수강 과목별 필터링 및 대여 이력 출력 (규정 1-(2)).
3. **파손/분실/수리 중 장비 리포트**: 손상 장비 목록 및 직전 대여자 추적 보고서 (규정 1-(3)).
4. **수업용 대여 이력 리포트**: 교수자별, 과목별 수업 대여 품목 및 기간 리스트 (규정 2-(4)).
5. **전자 대여/반납 계약서 PDF**: 학생 서명, 바코드, 품목 리스트가 각인된 공식 증빙 문서.

---

## 9. 데이터베이스 스키마 설계안 (ERD Draft)

```mermaid
erDiagram
    USERS ||--o{ USER_CUSTOM_VALUES : has
    CUSTOM_FIELD_DEFINITIONS ||--o{ USER_CUSTOM_VALUES : defines
    USERS ||--o{ RESERVATIONS : places
    USERS ||--o{ PENALTIES : receives
    CATEGORIES ||--o{ SUBCATEGORIES : contains
    SUBCATEGORIES ||--o{ EQUIPMENT_MODELS : categorizes
    EQUIPMENT_MODELS ||--o{ EQUIPMENT_ITEMS : instantiates
    RESERVATIONS ||--o{ RESERVATION_ITEMS : includes
    EQUIPMENT_ITEMS ||--o{ RESERVATION_ITEMS : assigned_to
    RESERVATIONS ||--o{ TEAM_MEMBERS : groups
    RESERVATIONS ||--o{ SIGNATURE_LOGS : signs

    USERS {
        uuid id PK
        string student_id UK "학번"
        string full_name
        string email UK
        string phone
        string password_hash
        string role "UNDERGRAD, GRADUATE, FACULTY, STAFF, ADMIN"
        string status "ACTIVE, BLOCKED, PENALTY"
        string profile_image_url
        boolean is_certified "특수장비 교육이수 여부"
    }

    CUSTOM_FIELD_DEFINITIONS {
        uuid id PK
        string field_name UK
        string label_en
        string label_ko
        string label_zh
        string field_type "TEXT, SELECT, WEBCAM, etc."
        jsonb options
        boolean is_required
        boolean is_visible_on_register
        int display_order
    }

    USER_CUSTOM_VALUES {
        uuid id PK
        uuid user_id FK
        uuid field_id FK
        text field_value
    }

    CATEGORIES {
        uuid id PK
        string name_en
        string name_ko
    }

    SUBCATEGORIES {
        uuid id PK
        uuid category_id FK
        string name_en
        string name_ko
    }

    EQUIPMENT_MODELS {
        uuid id PK
        uuid subcategory_id FK
        string brand
        string model_name
        int total_quantity
        text remarks "구성품 및 패키지 메모"
        text target_audience "ALL, GRAD_ONLY, CERTIFIED_ONLY 등"
        text manual_url
        text packing_guide_image
        text external_link
    }

    EQUIPMENT_ITEMS {
        uuid id PK
        uuid model_id FK
        string barcode_id UK "바코드/QR 코드"
        string serial_number
        string status "AVAILABLE, RESERVED, RENTED, UNDER_REPAIR, BROKEN, LOST, CLASS_USE"
        text condition_notes
        string broken_photo_url
    }

    RESERVATIONS {
        uuid id PK
        uuid user_id FK
        uuid faculty_id FK
        string project_type "INDIVIDUAL, TEAM, GRADUATION"
        string project_title
        text project_description
        datetime rental_start_time "30분 단위"
        datetime return_due_time
        datetime actual_return_time
        string status "DRAFT, SUBMITTED, PROF_APPROVED, CONFIRMED, CHECKED_OUT, RETURNED, CANCELLED"
        text checkout_notes
        text checkin_notes
        boolean is_late
    }

    RESERVATION_ITEMS {
        uuid id PK
        uuid reservation_id FK
        uuid model_id FK
        uuid equipment_item_id FK "현장 바코드 매핑"
        int quantity
    }

    TEAM_MEMBERS {
        uuid id PK
        uuid reservation_id FK
        string student_id
        string student_name
    }

    PENALTIES {
        uuid id PK
        uuid user_id FK
        string reason "LATE_RETURN, DAMAGE, LOSS"
        datetime start_date
        datetime end_date
        boolean is_active
        text notes
    }

    SIGNATURE_LOGS {
        uuid id PK
        uuid reservation_id FK
        string signature_type "CHECKOUT, CHECKIN"
        text signature_data_url "Base64 or S3 URL"
        datetime signed_at
        string ip_address
    }
```

---

## 10. AI 코딩/개발 실행용 마스터 프롬프트 (Prompt for Implementation)

이 사양서를 기반으로 실제 애플리케이션 코드를 구축할 때 아래 프롬프트를 AI 에이전트에 입력하여 모듈별로 개발을 단계적으로 착수할 수 있습니다.

```markdown
### [AI System Builder Prompt]
당신은 풀스택 엔터프라이즈 시스템 전문 수석 개발자입니다.
위 "동서대학교 International College (IC) 유학생 장비예약 관리시스템 개발 사양서 (v1.0.0)"의 모든 명세를 100% 준수하여 프로덕션 레벨의 웹 애플리케이션을 단계별로 구축하십시오.

[필수 구현 지침]
1. 프레임워크: Next.js (App Router) + TypeScript + Tailwind CSS + Prisma + SQLite/PostgreSQL
2. 국제화: 영어(English) 기본 인터페이스 + 안내/규정은 영어/중국어 병기 지원
3. 백엔드 동적 회원 필드 엔진:
   - 학번, 이름, 이메일, 전화번호, 비밀번호 기본 필드
   - 관리자가 DB 및 Admin 설정에서 소속학과(Major), 위챗/카톡 ID, 웹캠 사진 등 필드를 동적으로 추가/제어할 수 있는 구조
4. 장비 대량 엑셀 등록:
   - `Dept. of Film and VFX Equipment.xlsx` 구조(대분류, 소분류, 브랜드, 모델명, 수량, 비고)의 병합 셀을 완벽 파싱하는 일괄 업로드 및 엑셀 다운로드 API/UI 구현
5. 바코드 및 QR 코드:
   - 신규 장비 라벨 출력용 QR/바코드 렌더링 및 웹 카메라 기반 현장 바코드 스캐너
6. 대여/반납 전자서명:
   - HTML5 Canvas 기반 터치/마우스 전자서약서 서명 및 PDF 대여증 자동 생성
7. 엄격한 규칙 및 패널티 엔진:
   - 3일 대여, 2건 제한, 연속대여 차단, 지각 1회(1개월)/2회(1학기) 자동 패널티 산출
   - 관리자 직권(Override) 승인 및 수업용 장비 지정 기능

우선 1단계로 [데이터베이스 스키마 (Prisma Schema), 엑셀 파서 유틸리티, 동적 커스텀 필드 구조]부터 코드를 작성해 주십시오.
```

---

## 11. 승인 및 향후 개발 로드맵 (Next Steps)
- [ ] **사용자 검토 및 확정**: 본 개발 사양서의 정책, 워크플로우, 동적 필드 및 엑셀 일괄 등록 구조 확인
- [ ] **Phase 1**: 데이터베이스 모델링 & 인증/동적 회원가입/관리자 회원 관리 모듈 구현
- [ ] **Phase 2**: 장비 엑셀 대량 업로드(Dept. of Film and VFX Equipment.xlsx 연동), CRUD, 바코드/QR 라벨 출력 모듈 구현
- [ ] **Phase 3**: 학생 예약 3단 UI(장바구니형), 캘린더, 약관 동의, 팀 과제 중복 방지 로직 구현
- [ ] **Phase 4**: 관리실 태블릿용 현장 반출/반납 검수, 바코드 스캔, 터치 전자 서명, 대여증 PDF 생성 모듈 구현
- [ ] **Phase 5**: 패널티 자동화 스케줄러, 이메일 알림 연동, 엑셀 현황 보고서 출력 및 최종 배포
