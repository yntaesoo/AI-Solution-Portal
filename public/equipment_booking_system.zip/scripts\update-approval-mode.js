const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcryptjs");

const prisma = new PrismaClient();

async function updateFacultyAndApproval() {
  // 1. Update approval_mode to MANUAL so that student submissions explicitly require faculty approval
  await prisma.systemSetting.upsert({
    where: { key: "approval_mode" },
    update: { value: "MANUAL" },
    create: { key: "approval_mode", value: "MANUAL" },
  });
  console.log("✅ Approval mode set to MANUAL (Faculty approval required).");

  // 2. Add Prof. Kim
  const profPassword = await bcrypt.hash("prof1234", 10);
  await prisma.user.upsert({
    where: { studentId: "PROF_KIM" },
    update: {},
    create: {
      studentId: "PROF_KIM",
      fullName: "Prof. David Kim (Digital Design & VFX)",
      email: "prof.kim@dongseo.ac.kr",
      phone: "051-320-2222",
      passwordHash: profPassword,
      role: "FACULTY",
      status: "ACTIVE",
    },
  });

  const facultyList = await prisma.user.findMany({
    where: { role: "FACULTY" },
    select: { studentId: true, fullName: true, id: true },
  });
  console.log("Faculty Members:", facultyList);
}

updateFacultyAndApproval()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
