"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  Calendar,
  Clock,
  User,
  Users,
  AlertTriangle,
  CheckCircle2,
  Trash2,
  Plus,
  ShieldAlert,
  ArrowRight,
  Info,
  Check,
  ShoppingBag,
  GraduationCap,
  Sparkles,
  Search,
} from "lucide-react";

export default function BookingPage() {
  const router = useRouter();

  // User & System States
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [settings, setSettings] = useState<any>(null);
  const [facultyList, setFacultyList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Booking Form States
  const [facultyId, setFacultyId] = useState("");
  const [projectType, setProjectType] = useState("INDIVIDUAL"); // INDIVIDUAL, TEAM, GRADUATION
  const [projectTitle, setProjectTitle] = useState("");
  const [projectDescription, setProjectDescription] = useState("");
  const [rentalDate, setRentalDate] = useState("");
  const [pickupTime, setPickupTime] = useState("10:00");

  // Mobile View Step Toggle ("form" | "catalog" | "cart")
  const [mobileStep, setMobileStep] = useState<"form" | "catalog" | "cart">("form");

  // Team Members
  const [teamMembers, setTeamMembers] = useState<{ studentId: string; studentName: string }[]>([]);
  const [newTeamId, setNewTeamId] = useState("");
  const [newTeamName, setNewTeamName] = useState("");

  // Cart
  const [cart, setCart] = useState<any[]>([]);

  // Equipment Data
  const [categories, setCategories] = useState<any[]>([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>("");
  const [selectedSubcategoryId, setSelectedSubcategoryId] = useState<string>("");
  const [equipmentList, setEquipmentList] = useState<any[]>([]);
  const [itemSearch, setItemSearch] = useState<string>("");

  // Popups & Agreements
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [agreedTerms, setAgreedTerms] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    // 1. Fetch current user
    fetch("/api/auth/me")
      .then((res) => res.json())
      .then((data) => {
        if (!data.user) {
          router.push("/login");
          return;
        }
        setCurrentUser(data.user);
        if (typeof window !== "undefined") {
          const hasAgreed = localStorage.getItem("dsu_terms_agreed_once") === "true";
          if (!hasAgreed) {
            setShowTermsModal(true);
          } else {
            setAgreedTerms(true);
          }
        }
      });

    // 2. Fetch categories
    fetch("/api/equipment/categories")
      .then((res) => res.json())
      .then((data) => {
        if (data.categories && data.categories.length > 0) {
          setCategories(data.categories);
          setSelectedCategoryId(data.categories[0].id);
          if (data.categories[0].subcategories?.length > 0) {
            setSelectedSubcategoryId(data.categories[0].subcategories[0].id);
          }
        }
      });

    // 3. Fetch faculty list for assignment
    fetch("/api/faculty")
      .then((res) => res.json())
      .then((data) => {
        if (data.faculty && data.faculty.length > 0) {
          setFacultyList(data.faculty);
          setFacultyId(data.faculty[0].id); // default to first faculty e.g. Prof. Yoon
        }
      });

    // 4. Fetch system settings
    fetch("/api/settings")
      .then((res) => res.json())
      .then((data) => {
        if (data.settings) setSettings(data.settings);
      });

    // Default rental date to tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    setRentalDate(tomorrow.toISOString().split("T")[0]);

    setLoading(false);
  }, []);

  // Fetch equipment when category changes
  useEffect(() => {
    if (!selectedCategoryId) return;
    let url = `/api/equipment?categoryId=${selectedCategoryId}`;
    if (selectedSubcategoryId) url += `&subcategoryId=${selectedSubcategoryId}`;

    fetch(url)
      .then((res) => res.json())
      .then((data) => {
        if (data.models) setEquipmentList(data.models);
      });
  }, [selectedCategoryId, selectedSubcategoryId]);

  const activeCategory = categories.find((c) => c.id === selectedCategoryId);

  // Cart actions
  const addToCart = (model: any) => {
    if (model.targetAudience === "CERTIFIED" && !currentUser?.isCertified) {
      alert("⚠️ Special Training Required: This equipment requires certified training by Prof. Yoon.");
      return;
    }

    setCart((prev) => {
      const exists = prev.find((item) => item.modelId === model.id);
      if (exists) {
        if (exists.quantity >= model.availableQuantity) {
          alert("Cannot exceed currently available inventory quantity.");
          return prev;
        }
        return prev.map((item) =>
          item.modelId === model.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [
        ...prev,
        {
          modelId: model.id,
          modelName: model.modelName,
          brand: model.brand,
          quantity: 1,
          availableQuantity: model.availableQuantity,
          targetAudience: model.targetAudience,
        },
      ];
    });
  };

  const removeFromCart = (modelId: string) => {
    setCart((prev) => prev.filter((item) => item.modelId !== modelId));
  };

  // Add team member
  const handleAddTeamMember = () => {
    if (!newTeamId || !newTeamName) return;
    if (newTeamId.trim() === currentUser?.studentId) {
      alert("You are already the booking leader.");
      return;
    }
    if (teamMembers.some((t) => t.studentId === newTeamId.trim())) {
      alert("Team member already added.");
      return;
    }

    setTeamMembers([...teamMembers, { studentId: newTeamId.trim(), studentName: newTeamName.trim() }]);
    setNewTeamId("");
    setNewTeamName("");
  };

  const handleRemoveTeamMember = (id: string) => {
    setTeamMembers(teamMembers.filter((t) => t.studentId !== id));
  };

  // Submit Reservation
  const handleFinalSubmit = async () => {
    setSubmitting(true);
    setErrorMessage(null);

    try {
      const rentalStartTime = `${rentalDate}T${pickupTime}:00`;

      const payload = {
        facultyId: facultyId || null,
        projectType,
        projectTitle,
        projectDescription,
        rentalStartTime,
        items: cart.map((c) => ({ modelId: c.modelId, quantity: c.quantity })),
        teamMembers,
      };

      const res = await fetch("/api/reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Reservation failed");
      }

      alert("🎉 " + data.message);
      setShowConfirmModal(false);
      router.push("/my-bookings");
    } catch (err: any) {
      setErrorMessage(err.message);
      setShowConfirmModal(false);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading || !currentUser) {
    return <div className="text-center py-24 text-slate-500 text-base font-semibold">Loading booking portal...</div>;
  }

  const hasPenalty = currentUser.penalties && currentUser.penalties.length > 0;
  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Penalty Alert if Active */}
      {hasPenalty && (
        <div className="p-5 rounded-2xl bg-red-50 border border-red-200 text-red-900 flex items-center gap-3">
          <ShieldAlert className="w-8 h-8 flex-shrink-0 text-red-600" />
          <div className="text-sm">
            <h4 className="font-bold text-base">Booking Restriction in Effect (대여 정지 중)</h4>
            <p className="mt-0.5">
              Your account has an active penalty until{" "}
              <strong>{new Date(currentUser.penalties[0].endDate).toLocaleDateString()}</strong>. Equipment booking is temporarily suspended.
            </p>
          </div>
        </div>
      )}

      {/* Terms of Service Modal */}
      {showTermsModal && !agreedTerms && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center gap-3 border-b pb-3 text-blue-700">
              <ShoppingBag className="w-7 h-7" />
              <div>
                <h3 className="font-extrabold text-xl text-slate-900">Equipment Rental Agreement</h3>
                <p className="text-sm text-slate-500 font-medium">기자재 대여 이용 약관 및 서약서 (동의 필수)</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 max-h-72 overflow-y-auto text-sm space-y-3 text-slate-700 leading-relaxed">
              <div className="font-bold text-slate-900 text-base">English Regulations:</div>
              <p className="whitespace-pre-line text-sm">
                {settings?.terms_of_service?.en ||
                  `1. Standard rental duration is 3 days. Return strictly by 17:00 on due date.
2. 1st Late return: 1 month rental suspension. 2nd Late return: 1 semester suspension.
3. Cancellations must be made at least 24h prior. Equipment cannot be altered after confirmation.`}
              </p>
              <div className="font-bold text-slate-900 text-base pt-3 border-t">中文条款:</div>
              <p className="whitespace-pre-line text-sm text-slate-600">
                {settings?.terms_of_service?.zh ||
                  `1. 标准借用期为3天。归还截止时间为当天17:00。
2. 第一次逾期：暂停借用1个月；第二次逾期：暂停借用1学期。
3. 审核确认后不可更改器材，取消须至少提前24小时。`}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3">
              <span className="text-xs text-slate-500">Agreement mandatory to continue</span>
              <button
                onClick={() => {
                  if (typeof window !== "undefined") {
                    localStorage.setItem("dsu_terms_agreed_once", "true");
                  }
                  setAgreedTerms(true);
                  setShowTermsModal(false);
                }}
                className="w-full sm:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold shadow-md shadow-blue-500/25 transition flex items-center justify-center gap-2"
              >
                <Check className="w-5 h-5" />
                <span>Agree & Continue / 同意并继续</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-7 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center gap-3 text-amber-600">
              <div className="p-2.5 bg-amber-50 rounded-2xl">
                <AlertTriangle className="w-7 h-7" />
              </div>
              <div>
                <h3 className="font-extrabold text-lg text-slate-900">Final Confirmation / 最终确认</h3>
                <p className="text-xs font-semibold text-amber-700">Non-modifiability notice after approval</p>
              </div>
            </div>

            <div className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
              <p className="font-semibold text-slate-900">
                "Once approved by the professor and administrator, equipment items cannot be altered. Cancellations are only permitted up to 1 day prior."
              </p>
              <p className="text-slate-500 text-xs">
                교수 및 관리자 승인 후에는 장비 변경이 불가하며, 취소는 사용 1일 전까지만 가능합니다. 계속 신청하시겠습니까?
              </p>
            </div>

            <div className="flex gap-2 justify-end pt-2">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-sm font-semibold"
              >
                Back to Edit
              </button>
              <button
                disabled={submitting}
                onClick={handleFinalSubmit}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold shadow-md shadow-blue-500/20"
              >
                {submitting ? "Submitting..." : "Yes, Submit for Faculty Approval"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Step Navigator (Visible only on small screens) */}
      <div className="lg:hidden flex rounded-2xl bg-white p-1 border border-slate-200 shadow-sm">
        <button
          onClick={() => setMobileStep("form")}
          className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition ${
            mobileStep === "form" ? "bg-blue-600 text-white" : "text-slate-600"
          }`}
        >
          1. Schedule & Prof
        </button>
        <button
          onClick={() => setMobileStep("catalog")}
          className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition ${
            mobileStep === "catalog" ? "bg-blue-600 text-white" : "text-slate-600"
          }`}
        >
          2. Choose Items
        </button>
        <button
          onClick={() => setMobileStep("cart")}
          className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition relative ${
            mobileStep === "cart" ? "bg-blue-600 text-white" : "text-slate-600"
          }`}
        >
          3. Cart ({totalCartCount})
        </button>
      </div>

      {/* Section 1: Project, Schedule, and Faculty Selection */}
      <div className={`bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-5 ${mobileStep !== "form" ? "hidden lg:block" : ""}`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
            <Calendar className="w-6 h-6 text-blue-600" />
            <span>1. Schedule & Course Faculty (과제 및 지도교수 설정)</span>
          </h2>
          <span className="text-xs text-blue-600 font-bold bg-blue-50 px-3 py-1 rounded-full border border-blue-100">
            Faculty Sign-off Required
          </span>
        </div>

        {errorMessage && (
          <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 flex-shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 text-sm">
          {/* Faculty Selector (Crucial Requirement!) */}
          <div className="lg:col-span-2">
            <label className="block font-bold text-slate-800 mb-1.5 flex items-center gap-1.5">
              <GraduationCap className="w-4 h-4 text-blue-600" />
              <span>Course Instructor / Faculty (담당 교수자 선택) *</span>
            </label>
            <select
              value={facultyId}
              onChange={(e) => setFacultyId(e.target.value)}
              className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 bg-white text-slate-900 font-semibold text-sm"
            >
              {facultyList.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.fullName} ({f.studentId}) - CAS 5106
                </option>
              ))}
            </select>
            <p className="text-xs text-slate-500 mt-1">
              * This professor will review and approve your reservation before lab manager sign-off.
            </p>
          </div>

          <div>
            <label className="block font-bold text-slate-800 mb-1.5">Project Type (과제 구분) *</label>
            <select
              value={projectType}
              onChange={(e) => setProjectType(e.target.value)}
              className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 bg-white text-slate-900 font-semibold text-sm"
            >
              <option value="INDIVIDUAL">Individual Project (개인 과제)</option>
              <option value="TEAM">Team Project (팀 과제)</option>
              <option value="GRADUATION">Graduation Project (졸업 작품)</option>
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-800 mb-1.5">Project Title (과제 제목) *</label>
            <input
              type="text"
              required
              placeholder="e.g. VFX Short Film Scene 1"
              value={projectTitle}
              onChange={(e) => setProjectTitle(e.target.value)}
              className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 text-sm"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-800 mb-1.5">Pickup Date (반출 희망일) *</label>
            <input
              type="date"
              required
              value={rentalDate}
              onChange={(e) => setRentalDate(e.target.value)}
              className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 text-sm"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-800 mb-1.5">Pickup Time (30분 단위) *</label>
            <select
              value={pickupTime}
              onChange={(e) => setPickupTime(e.target.value)}
              className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 bg-white text-slate-900 font-semibold text-sm"
            >
              <option value="09:30">09:30 AM</option>
              <option value="10:00">10:00 AM</option>
              <option value="10:30">10:30 AM</option>
              <option value="11:00">11:00 AM</option>
              <option value="11:30">11:30 AM</option>
              <option value="13:30">01:30 PM</option>
              <option value="14:00">02:00 PM</option>
              <option value="14:30">02:30 PM</option>
              <option value="15:00">03:00 PM</option>
              <option value="15:30">03:30 PM</option>
              <option value="16:00">04:00 PM</option>
              <option value="16:30">04:30 PM</option>
            </select>
          </div>
        </div>

        {/* Team Members Input if TEAM */}
        {projectType === "TEAM" && (
          <div className="p-4 bg-indigo-50/70 rounded-2xl border border-indigo-100 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
              <span className="text-sm font-bold text-indigo-900 flex items-center gap-1.5">
                <Users className="w-4 h-4" />
                <span>Team Members Grouping (중복 신청 방지)</span>
              </span>
              <span className="text-xs text-indigo-600 font-medium">
                * Enrolled team members cannot duplicate requests during the same rental period.
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <input
                type="text"
                placeholder="Student ID (학번)"
                value={newTeamId}
                onChange={(e) => setNewTeamId(e.target.value)}
                className="px-4 py-2 text-sm bg-white border border-indigo-200 rounded-xl focus:outline-none"
              />
              <input
                type="text"
                placeholder="Student Name (이름)"
                value={newTeamName}
                onChange={(e) => setNewTeamName(e.target.value)}
                className="px-4 py-2 text-sm bg-white border border-indigo-200 rounded-xl focus:outline-none"
              />
              <button
                type="button"
                onClick={handleAddTeamMember}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-bold shadow-sm"
              >
                Add Member
              </button>
            </div>

            {teamMembers.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-1">
                {teamMembers.map((tm) => (
                  <span
                    key={tm.studentId}
                    className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white text-indigo-900 border border-indigo-200 text-xs font-semibold shadow-sm"
                  >
                    <span>{tm.studentName} ({tm.studentId})</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveTeamMember(tm.studentId)}
                      className="text-slate-400 hover:text-red-600 text-sm font-bold"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Mobile Next button to Step 2 */}
        <div className="lg:hidden pt-2 flex justify-end">
          <button
            type="button"
            onClick={() => setMobileStep("catalog")}
            className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2 shadow-md"
          >
            <span>Next: Select Equipment Items</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 3-Pane Cart Layout (Specification 4-(5)) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Pane 1: Main Categories */}
        <div className={`lg:col-span-3 bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-2 ${mobileStep !== "catalog" ? "hidden lg:block" : ""}`}>
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider px-2 mb-2">
            1. Main Categories (대분류)
          </h3>
          <div className="space-y-1.5">
            {categories.map((cat) => {
              const isSelected = selectedCategoryId === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategoryId(cat.id);
                    if (cat.subcategories?.length > 0) {
                      setSelectedSubcategoryId(cat.subcategories[0].id);
                    } else {
                      setSelectedSubcategoryId("");
                    }
                  }}
                  className={`w-full text-left px-4 py-3 rounded-2xl text-sm font-bold transition flex items-center justify-between ${
                    isSelected ? "bg-blue-600 text-white shadow-md shadow-blue-500/20" : "text-slate-700 hover:bg-slate-100"
                  }`}
                >
                  <span>{cat.nameEn}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${isSelected ? "bg-blue-700 text-white" : "bg-slate-100 text-slate-600"}`}>
                    {cat.subcategories?.length || 0}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Pane 2: Subcategories and Available Items */}
        <div className={`lg:col-span-5 bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4 ${mobileStep !== "catalog" ? "hidden lg:block" : ""}`}>
          <div className="flex items-center justify-between border-b pb-3">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              2. Available Items (소분류 및 품목)
            </h3>
            <span className="text-xs text-blue-700 font-bold bg-blue-50 px-2.5 py-1 rounded-full">
              {equipmentList.length} Items
            </span>
          </div>

          {/* Subcategory pills */}
          {activeCategory?.subcategories && activeCategory.subcategories.length > 0 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {activeCategory.subcategories.map((sub: any) => {
                const isSelected = selectedSubcategoryId === sub.id;
                return (
                  <button
                    key={sub.id}
                    onClick={() => setSelectedSubcategoryId(sub.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs whitespace-nowrap transition font-bold ${
                      isSelected ? "bg-slate-900 text-white shadow-sm" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    {sub.nameEn}
                  </button>
                );
              })}
            </div>
          )}

          {/* Quick Search inside Pane 2 */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search items in this category..."
              value={itemSearch}
              onChange={(e) => setItemSearch(e.target.value)}
              className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {itemSearch && (
              <button
                type="button"
                onClick={() => setItemSearch("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>

          {/* Item List with Bigger Font */}
          <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1">
            {equipmentList.filter((item) => {
              if (!itemSearch.trim()) return true;
              const q = itemSearch.toLowerCase().trim();
              return (
                (item.modelName && item.modelName.toLowerCase().includes(q)) ||
                (item.brand && item.brand.toLowerCase().includes(q)) ||
                (item.remarks && item.remarks.toLowerCase().includes(q))
              );
            }).length === 0 ? (
              <div className="text-center py-16 text-slate-400 text-sm">No equipment found matching criteria.</div>
            ) : (
              equipmentList
                .filter((item) => {
                  if (!itemSearch.trim()) return true;
                  const q = itemSearch.toLowerCase().trim();
                  return (
                    (item.modelName && item.modelName.toLowerCase().includes(q)) ||
                    (item.brand && item.brand.toLowerCase().includes(q)) ||
                    (item.remarks && item.remarks.toLowerCase().includes(q))
                  );
                })
                .map((item) => {
                  const isAvailable = item.availableQuantity > 0;
                  const inCart = cart.find((c) => c.modelId === item.id);

                return (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl border border-slate-200 hover:border-blue-400 transition flex items-center justify-between gap-3 bg-slate-50/60"
                  >
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{item.brand}</span>
                        {item.targetAudience === "CERTIFIED" && (
                          <span className="text-xs px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-bold">
                            Prof. Yoon Certified
                          </span>
                        )}
                      </div>
                      <div className="text-base font-bold text-slate-900 leading-snug">{item.modelName}</div>
                      <div className="text-xs text-slate-600">
                        Available: <strong className={isAvailable ? "text-emerald-700 font-bold" : "text-red-500"}>{item.availableQuantity}</strong> / {item.totalQuantity} Units
                      </div>
                    </div>

                    <button
                      onClick={() => addToCart(item)}
                      disabled={!isAvailable}
                      className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white rounded-xl text-sm font-bold transition flex items-center gap-1.5 flex-shrink-0 shadow-sm"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{inCart ? `Add (${inCart.quantity})` : "Add"}</span>
                    </button>
                  </div>
                );
              })
            )}
          </div>

          {/* Mobile Next button to Step 3 */}
          <div className="lg:hidden pt-2">
            <button
              type="button"
              onClick={() => setMobileStep("cart")}
              className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2 shadow-md"
            >
              <span>View Cart ({totalCartCount} items)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Pane 3: Selected Basket (Right) */}
        <div className={`lg:col-span-4 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4 ${mobileStep !== "cart" ? "hidden lg:block" : ""}`}>
          <div className="flex items-center justify-between border-b pb-3">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-blue-600" />
              <span>3. Selected Cart (장바구니)</span>
            </h3>
            <span className="text-sm font-bold px-3 py-1 rounded-full bg-blue-50 text-blue-700">
              {totalCartCount} Items
            </span>
          </div>

          {cart.length === 0 ? (
            <div className="text-center py-16 text-slate-400 text-sm">
              Your cart is empty. Please add equipment items to proceed.
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2.5 max-h-[360px] overflow-y-auto pr-1">
                {cart.map((item) => (
                  <div
                    key={item.modelId}
                    className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-sm"
                  >
                    <div>
                      <div className="font-bold text-slate-900 text-base">{item.modelName}</div>
                      <div className="text-xs text-slate-500 font-medium">
                        {item.brand} • Quantity: <span className="font-bold text-blue-700">{item.quantity}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => removeFromCart(item.modelId)}
                      className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition"
                      title="Remove"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Standard 3 Days Period Notice */}
              <div className="p-4 rounded-2xl bg-blue-50 border border-blue-100 text-xs text-blue-900 space-y-1">
                <div className="font-bold text-sm">Standard Rental Period: 3 Days</div>
                <div>
                  Return Due: <strong>{new Date(new Date(rentalDate).setDate(new Date(rentalDate).getDate() + 3)).toLocaleDateString()} 17:00</strong>
                </div>
              </div>

              <button
                disabled={cart.length === 0 || hasPenalty || !projectTitle}
                onClick={() => setShowConfirmModal(true)}
                className="w-full py-4 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-2xl text-base font-extrabold shadow-lg shadow-blue-500/25 transition flex items-center justify-center gap-2"
              >
                <span>Submit Reservation for Review</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
