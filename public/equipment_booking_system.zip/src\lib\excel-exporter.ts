import * as XLSX from "xlsx";
import { prisma } from "./prisma";

export async function exportEquipmentToExcel(): Promise<Buffer> {
  const models = await prisma.equipmentModel.findMany({
    include: {
      subcategory: {
        include: {
          category: true,
        },
      },
      items: true,
    },
    orderBy: [
      { subcategory: { category: { displayOrder: "asc" } } },
      { subcategory: { displayOrder: "asc" } },
      { modelName: "asc" },
    ],
  });

  const exportRows = models.map((m) => {
    const availableCount = m.items.filter((i) => i.status === "AVAILABLE").length;
    const underRepairCount = m.items.filter((i) => i.status === "UNDER_REPAIR" || i.status === "BROKEN").length;
    const rentedCount = m.items.filter((i) => i.status === "RENTED").length;

    return {
      "Category": m.subcategory.category.nameEn,
      "Subcategory": m.subcategory.nameEn,
      "Brand": m.brand,
      "Model Name": m.modelName,
      "Total Quantity": m.totalQuantity,
      "Available Quantity": availableCount,
      "Rented Quantity": rentedCount,
      "Under Repair / Damaged": underRepairCount,
      "Target Audience": m.targetAudience,
      "Remarks & Components": m.remarks || "",
    };
  });

  const worksheet = XLSX.utils.json_to_sheet(exportRows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Inventory Report");

  return XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
}

export async function exportStudentsToExcel(): Promise<Buffer> {
  const students = await prisma.user.findMany({
    where: {
      role: { in: ["STUDENT_UNDERGRAD", "STUDENT_GRAD"] },
    },
    include: {
      customValues: {
        include: { field: true },
      },
      penalties: {
        where: { isActive: true },
      },
      reservations: {
        where: {
          status: { in: ["CONFIRMED", "CHECKED_OUT"] },
        },
      },
    },
    orderBy: { studentId: "asc" },
  });

  const exportRows = students.map((s) => {
    const customData: Record<string, string> = {};
    s.customValues.forEach((cv) => {
      customData[cv.field.labelEn || cv.field.fieldName] = cv.value;
    });

    return {
      "Student ID": s.studentId,
      "Full Name": s.fullName,
      "Email": s.email,
      "Phone": s.phone,
      "Role": s.role === "STUDENT_GRAD" ? "Graduate" : "Undergraduate",
      "Account Status": s.status,
      "Active Penalties": s.penalties.length,
      "Active Bookings": s.reservations.length,
      "Special Equipment Certified": s.isCertified ? "Yes" : "No",
      ...customData,
    };
  });

  const worksheet = XLSX.utils.json_to_sheet(exportRows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Student Directory");

  return XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
}
