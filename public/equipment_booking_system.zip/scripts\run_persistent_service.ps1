# ========================================================
# DSU IC Equipment Booking System - Persistent Watchdog Service
# Automatically starts & monitors Next.js (port 3000) & Cloudflare Tunnel
# ========================================================

$projectDir = "H:\Create with Anti\EquipmentBookingSystem"
$logDir = "$projectDir\logs"
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }

$serverLog = "$logDir\next_server.log"
$tunnelLog = "$logDir\cloudflare_tunnel.log"
$urlFile = "$projectDir\LIVE_MOBILE_URL.txt"
$desktopHtml = "C:\Users\yntae\OneDrive\바탕 화면\동서대_IC_장비예약_바로가기.html"

function Update-DesktopHtml($newUrl) {
    if (-not $newUrl) { return }
    $encodedUrl = [System.Uri]::EscapeDataString($newUrl)
    $htmlContent = @"
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>동서대 IC 장비예약 관리시스템 바로가기</title>
  <style>
    * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Malgun Gothic", "Segoe UI", sans-serif; }
    body { background: #0f172a; color: #f8fafc; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 20px; }
    .card { background: #1e293b; border: 1px solid #334155; border-radius: 28px; padding: 36px; max-width: 480px; width: 100%; text-align: center; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5); }
    .badge { display: inline-block; padding: 6px 14px; background: #0284c7; color: #fff; font-size: 12px; font-weight: 800; border-radius: 9999px; margin-bottom: 16px; letter-spacing: 0.05em; }
    h1 { font-size: 22px; font-weight: 800; margin: 0 0 8px 0; color: #f1f5f9; }
    p.desc { font-size: 13px; color: #94a3b8; margin: 0 0 24px 0; line-height: 1.5; }
    .qr-box { background: #ffffff; padding: 16px; border-radius: 20px; display: inline-block; margin-bottom: 24px; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.3); }
    .qr-box img { display: block; width: 200px; height: 200px; }
    .qr-desc { font-size: 12px; color: #64748b; margin-top: 8px; font-weight: 600; }
    .btn-main { display: block; width: 100%; padding: 16px; background: #2563eb; color: #ffffff; text-decoration: none; font-size: 16px; font-weight: 800; border-radius: 18px; margin-bottom: 12px; transition: all 0.2s; box-shadow: 0 10px 20px -5px rgba(37,99,235,0.4); }
    .btn-main:hover { background: #1d4ed8; transform: translateY(-2px); }
    .btn-sub { display: block; width: 100%; padding: 12px; background: #334155; color: #cbd5e1; text-decoration: none; font-size: 13px; font-weight: 700; border-radius: 14px; transition: all 0.2s; }
    .btn-sub:hover { background: #475569; color: #fff; }
    .info-box { margin-top: 20px; padding: 14px; background: #0f172a; border-radius: 14px; border: 1px solid #1e293b; text-align: left; font-size: 12px; color: #94a3b8; line-height: 1.6; }
    .info-box strong { color: #38bdf8; }
  </style>
</head>
<body>
  <div class="card">
    <div class="badge">동서대학교 INTERNATIONAL COLLEGE</div>
    <h1>장비예약 관리시스템</h1>
    <p class="desc">스마트폰 카메라로 아래 QR 코드를 스캔하거나<br>버튼을 클릭하여 포털로 접속하세요.</p>

    <!-- QR Code -->
    <div class="qr-box">
      <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=$encodedUrl" alt="접속 QR코드" />
      <div class="qr-desc">스마트폰 카메라로 스캔 시 즉시 이동</div>
    </div>

    <!-- Main Mobile URL Button -->
    <a href="$newUrl" target="_blank" class="btn-main">
      🌐 모바일 / 외부망 실시간 접속하기
    </a>

    <!-- Local Wi-Fi Button -->
    <a href="http://192.168.0.101:3000" target="_blank" class="btn-sub">
      📶 교내 Wi-Fi 직접 접속 (192.168.0.101:3000)
    </a>

    <div class="info-box">
      <div>• <strong>현재 실시간 주소:</strong> $newUrl</div>
      <div>• <strong>테스트 계정:</strong> 학생(20240001) / 교수(PROF_YOON) / 관리자(ADMIN001)</div>
      <div>• <strong>비밀번호:</strong> student1234 / prof1234 / admin1234</div>
    </div>
  </div>
</body>
</html>
"@
    Set-Content -Path $desktopHtml -Value $htmlContent -Encoding UTF8
    Set-Content -Path $urlFile -Value $newUrl -Encoding UTF8
}

# Main Monitoring Loop
while ($true) {
    # 1. Check Next.js Server (Port 3000)
    $conn = Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue
    if (-not $conn) {
        Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Next.js server not running on 3000. Launching..."
        Start-Process -FilePath "node.exe" -ArgumentList "`"$projectDir\node_modules\next\dist\bin\next`" start -H 0.0.0.0 -p 3000" -WorkingDirectory $projectDir -WindowStyle Hidden
        Start-Sleep -Seconds 5
    }

    # 2. Check cloudflared process
    $cfProc = Get-Process -Name "cloudflared" -ErrorAction SilentlyContinue
    if (-not $cfProc) {
        Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] cloudflared not running. Launching..."
        Start-Process -FilePath "cmd.exe" -ArgumentList "/c cloudflared tunnel --url http://localhost:3000 > `"$tunnelLog`" 2>&1" -WorkingDirectory $projectDir -WindowStyle Hidden
        Start-Sleep -Seconds 6
    }

    # 3. Extract and update tunnel URL if available
    if (Test-Path $tunnelLog) {
        $content = Get-Content $tunnelLog -Raw -ErrorAction SilentlyContinue
        if ($content -match "https://([a-zA-Z0-9\-]+)\.trycloudflare\.com") {
            $extractedUrl = $matches[0]
            $prevUrl = if (Test-Path $urlFile) { (Get-Content $urlFile -Raw).Trim() } else { "" }
            if ($extractedUrl -ne $prevUrl) {
                Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] New Tunnel URL detected: $extractedUrl"
                Update-DesktopHtml $extractedUrl
            }
        }
    }

    Start-Sleep -Seconds 20
}
