import { prisma } from "./prisma";

export interface BookingValidationResult {
  allowed: boolean;
  reason?: string;
  activePenalties?: any[];
}

export async function validateUserBookingEligibility(
  userId: string,
  targetStartDate: Date,
  targetEndDate: Date
): Promise<BookingValidationResult> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      penalties: {
        where: { isActive: true },
      },
      reservations: {
        where: {
          status: { in: ["SUBMITTED", "PROF_APPROVED", "CONFIRMED", "CHECKED_OUT"] },
        },
      },
    },
  });

  if (!user) {
    return { allowed: false, reason: "User not found." };
  }

  // 1. Check account status
  if (user.status === "BLOCKED") {
    return { allowed: false, reason: "Your account is currently blocked by administration." };
  }

  // 2. Check active penalties and expire past ones
  const now = new Date();
  const validPenalties = [];
  for (const penalty of user.penalties) {
    if (new Date(penalty.endDate) <= now) {
      await prisma.penalty.update({
        where: { id: penalty.id },
        data: { isActive: false },
      });
    } else {
      validPenalties.push(penalty);
    }
  }

  if (validPenalties.length > 0) {
    const latestEndDate = validPenalties.reduce(
      (max, p) => (new Date(p.endDate) > max ? new Date(p.endDate) : max),
      new Date(0)
    );
    return {
      allowed: false,
      reason: `You have an active penalty restriction until ${latestEndDate.toLocaleDateString()}. Equipment booking is suspended.`,
      activePenalties: validPenalties,
    };
  }

  // 3. Check 2-active-bookings quota (Specification 5-2)
  if (user.reservations.length >= 2) {
    return {
      allowed: false,
      reason: "Maximum 2 active bookings allowed per student. Please return or complete existing reservations first.",
    };
  }

  // 4. Check advance booking window (Specification 5-1)
  // Grad: 60 days in advance, Undergrad: 30 days in advance, Min 1 day before
  const diffDays = Math.ceil((targetStartDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  const isGrad = user.role === "STUDENT_GRAD";
  const maxAdvanceDays = isGrad ? 60 : 30;

  if (diffDays < 1) {
    return {
      allowed: false,
      reason: "Bookings must be requested at least 1 day in advance.",
    };
  }

  if (diffDays > maxAdvanceDays) {
    return {
      allowed: false,
      reason: `${isGrad ? "Graduate" : "Undergraduate"} students can book up to ${maxAdvanceDays} days in advance.`,
    };
  }

  // 5. Check consecutive booking restriction (Consecutive back-to-back rentals prohibited)
  for (const existing of user.reservations) {
    const existingEnd = new Date(existing.returnDueTime);
    const existingStart = new Date(existing.rentalStartTime);

    // If new booking starts right when old ends or overlap
    const gapMs = Math.abs(targetStartDate.getTime() - existingEnd.getTime());
    const gapDays = gapMs / (1000 * 60 * 60 * 24);

    if (gapDays < 1 && (targetStartDate >= existingStart && targetStartDate <= existingEnd)) {
      return {
        allowed: false,
        reason: "Consecutive back-to-back rentals are prohibited. A minimum 1-day interval is required between bookings.",
      };
    }
  }

  return { allowed: true };
}

export async function applyLatePenalty(userId: string, notes?: string) {
  // Check prior late penalties
  const priorLateCount = await prisma.penalty.count({
    where: {
      userId,
      reason: { startsWith: "LATE_RETURN" },
    },
  });

  const now = new Date();
  let endDate = new Date(now);
  let reason = "LATE_RETURN_1";
  let description = "1st Late Return: 1 Month Equipment Booking Restriction";

  if (priorLateCount >= 1) {
    reason = "LATE_RETURN_2";
    // 1 semester (approx 6 months)
    endDate.setMonth(endDate.getMonth() + 6);
    description = "2nd+ Late Return: 1 Semester (6 Months) Equipment Booking Restriction";
  } else {
    // 1 month
    endDate.setMonth(endDate.getMonth() + 1);
  }

  const penalty = await prisma.penalty.create({
    data: {
      userId,
      reason,
      startDate: now,
      endDate,
      isActive: true,
      notes: notes ? `${description} (${notes})` : description,
    },
  });

  // Update user status
  await prisma.user.update({
    where: { id: userId },
    data: { status: "PENALTY" },
  });

  return penalty;
}
