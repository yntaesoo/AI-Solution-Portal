const puppeteer = require('puppeteer-core');
const path = require('path');

(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
    args: ['--no-sandbox', '--window-size=1280,950']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 950, deviceScaleFactor: 2 });
  
  // Login as Admin
  await page.goto('http://localhost:3000/login');
  await page.waitForSelector('input[type="text"]');
  await page.type('input[type="text"]', 'ADMIN001');
  await page.type('input[type="password"]', 'admin1234');
  await page.click('button[type="submit"]');
  await page.waitForNavigation({ waitUntil: 'networkidle0' });
  await page.goto('http://localhost:3000/admin', { waitUntil: 'networkidle0' });

  const clickTab = async (label) => {
    await page.evaluate((l) => {
      const btns = Array.from(document.querySelectorAll('button'));
      const b = btns.find(x => x.textContent.includes(l));
      if (b) b.click();
    }, label);
    await new Promise(r => setTimeout(r, 800));
  };

  console.log('Capturing Equipment tab...');
  await clickTab('1. Equipment');
  await page.screenshot({ path: path.join(__dirname, '..', 'manual_screenshots', '09_admin_equipment_bulk.png') });

  console.log('Capturing Operations Desk tab...');
  await clickTab('3. Field Check-out');
  await page.screenshot({ path: path.join(__dirname, '..', 'manual_screenshots', '10_admin_operations_desk.png') });

  console.log('Capturing Students & Custom Fields tab...');
  await clickTab('4. Students');
  await page.screenshot({ path: path.join(__dirname, '..', 'manual_screenshots', '11_admin_custom_fields.png') });

  await browser.close();
  console.log('Admin tabs captured successfully!');
})().catch(err => {
  console.error(err);
  process.exit(1);
});
