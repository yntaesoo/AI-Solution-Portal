import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        dsu: {
          blue: "#004098",
          dark: "#002b66",
          light: "#e6f0fa",
          accent: "#ff6b00",
        },
      },
    },
  },
  plugins: [],
};
export default config;
