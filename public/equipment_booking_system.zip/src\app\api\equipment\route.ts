import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const categoryId = searchParams.get("categoryId");
    const subcategoryId = searchParams.get("subcategoryId");
    const search = searchParams.get("search");
    const audience = searchParams.get("audience"); // ALL, UNDERGRAD, GRAD, CERTIFIED

    const where: any = { isAvailable: true };

    if (categoryId) {
      where.subcategory = { categoryId };
    }
    if (subcategoryId) {
      where.subcategoryId = subcategoryId;
    }
    if (audience && audience !== "ALL") {
      where.OR = [{ targetAudience: "ALL" }, { targetAudience: audience }];
    }
    if (search) {
      where.OR = [
        { modelName: { contains: search } },
        { brand: { contains: search } },
        { remarks: { contains: search } },
      ];
    }

    const models = await prisma.equipmentModel.findMany({
      where,
      include: {
        subcategory: {
          include: { category: true },
        },
        items: true,
      },
      orderBy: [
        { subcategory: { category: { displayOrder: "asc" } } },
        { subcategory: { displayOrder: "asc" } },
        { modelName: "asc" },
      ],
    });

    // Calculate real-time availability
    const enriched = models.map((m) => {
      const availableItems = m.items.filter((i) => i.status === "AVAILABLE");
      const rentedItems = m.items.filter((i) => i.status === "RENTED");
      const damagedItems = m.items.filter((i) => i.status === "UNDER_REPAIR" || i.status === "BROKEN");

      return {
        ...m,
        availableQuantity: availableItems.length,
        rentedQuantity: rentedItems.length,
        damagedQuantity: damagedItems.length,
      };
    });

    return NextResponse.json({ models: enriched });
  } catch (error: any) {
    console.error("Equipment GET error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Admin only." }, { status: 403 });
    }

    const body = await req.json();
    const { subcategoryId, brand, modelName, totalQuantity, remarks, targetAudience, manualUrl, packingGuideImg } = body;

    if (!subcategoryId || !modelName || !totalQuantity) {
      return NextResponse.json({ error: "Subcategory, Model Name, and Quantity are required." }, { status: 400 });
    }

    const model = await prisma.equipmentModel.create({
      data: {
        subcategoryId,
        brand: brand || "Generic",
        modelName: modelName.trim(),
        totalQuantity: parseInt(totalQuantity, 10),
        remarks,
        targetAudience: targetAudience || "ALL",
        manualUrl,
        packingGuideImg,
        isAvailable: true,
      },
    });

    // Auto-create item barcodes
    const catCode = "EQP";
    const modelCode = modelName.replace(/[^a-zA-Z0-9]/g, "").slice(0, 4).toUpperCase();
    for (let i = 1; i <= parseInt(totalQuantity, 10); i++) {
      const barcodeId = `DSU-${catCode}-${modelCode}-${String(i).padStart(2, "0")}-${Date.now().toString().slice(-4)}`;
      await prisma.equipmentItem.create({
        data: {
          modelId: model.id,
          barcodeId,
          serialNumber: `SN-${barcodeId}`,
          status: "AVAILABLE",
        },
      });
    }

    return NextResponse.json({ success: true, model });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Admin only." }, { status: 403 });
    }

    const body = await req.json();
    const { id, brand, modelName, totalQuantity, remarks, targetAudience, manualUrl, packingGuideImg, isAvailable } = body;

    if (!id) {
      return NextResponse.json({ error: "Model ID is required." }, { status: 400 });
    }

    const updated = await prisma.equipmentModel.update({
      where: { id },
      data: {
        brand,
        modelName,
        totalQuantity: totalQuantity ? parseInt(totalQuantity, 10) : undefined,
        remarks,
        targetAudience,
        manualUrl,
        packingGuideImg,
        isAvailable,
      },
    });

    return NextResponse.json({ success: true, model: updated });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "SUPER_ADMIN" && user.role !== "LAB_ASSISTANT")) {
      return NextResponse.json({ error: "Unauthorized. Admin only." }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Model ID is required." }, { status: 400 });
    }

    await prisma.equipmentModel.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: "Equipment model deleted." });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
