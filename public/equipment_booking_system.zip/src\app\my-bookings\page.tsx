"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  XCircle,
  ShieldAlert,
  ArrowRight,
  Info,
  Check,
} from "lucide-react";

export default function MyBookingsPage() {
  const router = useRouter();
  const [reservations, setReservations] = useState<any[]>([]);
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((res) => res.json())
      .then((data) => {
        if (!data.user) {
          router.push("/login");
          return;
        }
        setUser(data.user);
      });

    loadReservations();
  }, []);

  const loadReservations = () => {
    setLoading(true);
    fetch("/api/reservations")
      .then((res) => res.json())
      .then((data) => {
        if (data.reservations) setReservations(data.reservations);
      })
      .finally(() => setLoading(false));
  };

  const handleCancelBooking = async (id: string) => {
    if (!confirm("Are you sure you want to cancel this reservation? (예약을 취소하시겠습니까?)")) return;

    try {
      const res = await fetch("/api/reservations", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, action: "CANCEL" }),
      });

      const data = await res.json();
      if (!res.ok) {
        alert(data.error || "Failed to cancel");
        return;
      }

      alert("Reservation cancelled successfully.");
      loadReservations();
    } catch (e: any) {
      alert(e.message);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "SUBMITTED":
        return <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">Awaiting Faculty Approval</span>;
      case "PROF_APPROVED":
        return <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-800 border border-blue-200">Faculty Approved (Pending Admin)</span>;
      case "CONFIRMED":
        return <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">Confirmed (Ready for Pickup)</span>;
      case "CHECKED_OUT":
        return <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-800 border border-indigo-200">Checked Out (In Use)</span>;
      case "RETURNED":
        return <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700">Returned</span>;
      case "CANCELLED":
        return <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-500">Cancelled</span>;
      default:
        return <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700">{status}</span>;
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Header */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            My Equipment Bookings
          </h1>
          <p className="text-sm text-slate-500 mt-1 font-medium">
            Tracking your reservations, faculty approvals, and digital check-in/out agreements
          </p>
        </div>

        {user?.penalties && user.penalties.length > 0 && (
          <div className="flex items-center gap-3 p-4 bg-red-50 border border-red-200 rounded-2xl text-sm text-red-800">
            <ShieldAlert className="w-6 h-6 text-red-600 flex-shrink-0" />
            <div>
              <span className="font-bold">Active Penalty: </span>
              {user.penalties[0].notes || user.penalties[0].reason} (Until:{" "}
              {new Date(user.penalties[0].endDate).toLocaleDateString()})
            </div>
          </div>
        )}
      </div>

      {/* Bookings List */}
      {loading ? (
        <div className="text-center py-24 text-slate-500 text-base font-semibold">Loading your bookings...</div>
      ) : reservations.length === 0 ? (
        <div className="bg-white p-12 sm:p-16 text-center rounded-3xl border border-slate-200 text-slate-600 text-base space-y-4 shadow-sm">
          <p className="font-semibold text-slate-800 text-lg">You have no equipment bookings recorded.</p>
          <a
            href="/booking"
            className="inline-block px-7 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold shadow-md transition"
          >
            Create Your First Booking
          </a>
        </div>
      ) : (
        <div className="space-y-5">
          {reservations.map((res) => {
            const startDate = new Date(res.rentalStartTime);
            const dueDate = new Date(res.returnDueTime);
            const canCancel =
              res.status === "SUBMITTED" ||
              res.status === "PROF_APPROVED" ||
              (res.status === "CONFIRMED" && (startDate.getTime() - Date.now()) / (1000 * 60 * 60) >= 24);

            return (
              <div
                key={res.id}
                className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm hover:shadow-md transition space-y-5"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                  <div>
                    <span className="text-xs font-bold text-blue-700 font-mono bg-blue-50 px-2.5 py-1 rounded-md border border-blue-100">
                      {res.reservationNo}
                    </span>
                    <h3 className="font-extrabold text-xl text-slate-900 mt-1">{res.projectTitle}</h3>
                    <div className="text-xs sm:text-sm text-slate-500 mt-0.5">
                      Type: <span className="font-bold text-slate-700">{res.projectType}</span> • Instructor:{" "}
                      <span className="font-bold text-slate-700">{res.faculty?.fullName || "Assigned Faculty"}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {getStatusBadge(res.status)}
                    {canCancel && (
                      <button
                        onClick={() => handleCancelBooking(res.id)}
                        className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 rounded-xl text-xs sm:text-sm font-bold transition"
                      >
                        Cancel Booking
                      </button>
                    )}
                  </div>
                </div>

                {/* Rental Details with Bigger Font */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-sm bg-slate-50 p-5 rounded-2xl">
                  <div>
                    <span className="text-slate-400 block text-xs font-semibold mb-0.5">Pickup Scheduled:</span>
                    <strong className="text-slate-900">
                      {startDate.toLocaleDateString()} {startDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-xs font-semibold mb-0.5">Return Due Date:</span>
                    <strong className="text-slate-900">
                      {dueDate.toLocaleDateString()} {dueDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-xs font-semibold mb-0.5">Lab Location:</span>
                    <strong className="text-slate-900">CAS 5106 Equipment Lab</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-xs font-semibold mb-0.5">Digital Signatures:</span>
                    <span className="text-slate-900 font-bold">
                      {res.signatureLogs?.length || 0} Recorded
                    </span>
                  </div>
                </div>

                {/* Reserved Items */}
                <div>
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2.5">
                    Reserved Items ({res.items.length})
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {res.items.map((item: any) => (
                      <div
                        key={item.id}
                        className="p-3.5 rounded-2xl border border-slate-200 bg-white text-sm flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-slate-900">{item.model?.modelName}</div>
                          <div className="text-xs text-slate-500">
                            {item.model?.brand} • Quantity: <span className="font-bold text-blue-700">{item.quantity}</span>
                          </div>
                        </div>
                        {item.equipmentItem && (
                          <span className="text-xs px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-mono font-bold">
                            {item.equipmentItem.barcodeId}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Digital Signature Proof Preview if Available */}
                {res.signatureLogs && res.signatureLogs.length > 0 && (
                  <div className="pt-3 border-t text-sm">
                    <span className="text-slate-600 font-bold block mb-2">Electronic Signature Verification:</span>
                    <div className="flex gap-4 flex-wrap">
                      {res.signatureLogs.map((sig: any) => (
                        <div key={sig.id} className="p-3 rounded-2xl border border-slate-200 bg-white inline-block shadow-2xs">
                          <div className="text-xs text-slate-400 mb-1 font-medium">
                            {sig.signatureType === "CHECKOUT" ? "Pickup Signature" : "Return Signature"} (
                            {new Date(sig.signedAt).toLocaleDateString()})
                          </div>
                          <img
                            src={sig.signatureDataUrl}
                            alt="Signature"
                            className="h-12 border-b border-slate-200 object-contain"
                          />
                          <div className="text-xs text-slate-700 font-bold mt-1">{sig.signerName}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
