const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function check() {
  const reservations = await prisma.reservation.findMany({
    include: { user: true, faculty: true },
    orderBy: { createdAt: 'desc' },
    take: 10,
  });
  console.log('=== RESERVATIONS ===');
  for (const r of reservations) {
    console.log({
      id: r.id,
      no: r.reservationNo,
      status: r.status,
      user: r.user?.fullName,
      facultyId: r.facultyId,
      facultyName: r.faculty?.fullName,
      created: r.createdAt,
    });
  }

  const faculties = await prisma.user.findMany({
    where: { role: 'FACULTY' },
  });
  console.log('=== FACULTIES ===');
  console.log(faculties.map((f) => ({ id: f.id, studentId: f.studentId, name: f.fullName })));
}

check().finally(() => prisma.$disconnect());
