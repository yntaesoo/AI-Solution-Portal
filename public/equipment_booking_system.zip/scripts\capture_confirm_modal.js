const puppeteer = require('puppeteer-core');
const path = require('path');

(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
    args: ['--no-sandbox', '--window-size=1280,950']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 950, deviceScaleFactor: 2 });
  
  // Login as Student
  await page.goto('http://localhost:3000/login');
  await page.waitForSelector('input[type="text"]');
  await page.type('input[type="text"]', '20240001');
  await page.type('input[type="password"]', 'student1234');
  await page.click('button[type="submit"]');
  await page.waitForNavigation({ waitUntil: 'networkidle0' });

  await page.goto('http://localhost:3000/booking', { waitUntil: 'networkidle0' });
  await new Promise(r => setTimeout(r, 600));

  // Dismiss terms modal if visible
  await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    const agreeBtn = btns.find(b => b.textContent.includes('동의') || b.textContent.includes('Agree'));
    if (agreeBtn) agreeBtn.click();
  });
  await new Promise(r => setTimeout(r, 600));

  // Set project title, rental date, and add item
  await page.evaluate(() => {
    // 1. Set faculty
    const select = document.querySelector('select');
    if (select && select.options.length > 1) {
      select.selectedIndex = 1;
      select.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // 2. Set title
    const inputs = Array.from(document.querySelectorAll('input'));
    const titleInput = inputs.find(i => i.placeholder && i.placeholder.includes('VFX'));
    if (titleInput) {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
      setter.call(titleInput, '2026 IC Capstone Short Film Project');
      titleInput.dispatchEvent(new Event('input', { bubbles: true }));
      titleInput.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // 3. Set rental date
    const dateInput = inputs.find(i => i.type === 'date');
    if (dateInput) {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const yyyy = tomorrow.getFullYear();
      const mm = String(tomorrow.getMonth() + 1).padStart(2, '0');
      const dd = String(tomorrow.getDate()).padStart(2, '0');
      const dateStr = `${yyyy}-${mm}-${dd}`;
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
      setter.call(dateInput, dateStr);
      dateInput.dispatchEvent(new Event('input', { bubbles: true }));
      dateInput.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // 4. Click Add on first equipment
    const btns = Array.from(document.querySelectorAll('button'));
    const addBtn = btns.find(b => b.textContent.trim().startsWith('Add') || b.textContent.includes('담기'));
    if (addBtn) addBtn.click();
  });
  await new Promise(r => setTimeout(r, 600));

  // Click Submit button to open Confirmation Modal
  const clicked = await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    const submitBtn = btns.find(b => b.textContent.includes('Submit Reservation'));
    if (submitBtn) {
      submitBtn.click();
      return true;
    }
    return false;
  });
  console.log('Submit button clicked:', clicked);
  await new Promise(r => setTimeout(r, 800));

  await page.screenshot({ path: path.join(__dirname, '..', 'manual_screenshots', '06_final_confirm_modal.png') });
  await browser.close();
  console.log('Final confirm modal screenshot captured successfully!');
})().catch(err => {
  console.error(err);
  process.exit(1);
});
