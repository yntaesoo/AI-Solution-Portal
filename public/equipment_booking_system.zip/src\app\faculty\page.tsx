"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  CheckCircle2,
  XCircle,
  Clock,
  User,
  Package,
  Calendar,
  AlertCircle,
  Search,
  Check,
  X,
  FileText,
  RefreshCw,
  GraduationCap,
} from "lucide-react";

export default function FacultyApprovalPage() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [reservations, setReservations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Status Filter: "SUBMITTED" (Pending), "PROF_APPROVED", "ALL"
  const [statusFilter, setStatusFilter] = useState("SUBMITTED");
  // Scope Filter: "ALL" (All Department Requests) or "MINE" (Assigned to Me)
  const [scopeFilter, setScopeFilter] = useState<"ALL" | "MINE">("ALL");

  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState("");

  useEffect(() => {
    fetch("/api/auth/me")
      .then((res) => res.json())
      .then((data) => {
        if (!data.user) {
          router.push("/login");
          return;
        }
        if (data.user.role !== "FACULTY" && data.user.role !== "SUPER_ADMIN" && data.user.role !== "LAB_ASSISTANT") {
          alert("This page is for faculty members and lab administrators.");
          router.push("/booking");
          return;
        }
        setCurrentUser(data.user);
        loadReservations();
      });

    // Auto-polling every 6 seconds to catch newly submitted student requests automatically
    const interval = setInterval(() => {
      loadReservations(true);
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  const loadReservations = (silent = false) => {
    if (!silent) setLoading(true);
    else setRefreshing(true);

    fetch("/api/reservations?all=true")
      .then((res) => res.json())
      .then((data) => {
        if (data.reservations) {
          setReservations(data.reservations);
        }
      })
      .finally(() => {
        setLoading(false);
        setRefreshing(false);
      });
  };

  const handleApprove = async (id: string) => {
    if (!confirm("Approve this student's equipment reservation request? (이 예약을 승인하시겠습니까?)")) return;

    try {
      const res = await fetch("/api/reservations", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, action: "PROF_APPROVE" }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Approval failed");

      alert("✅ Reservation approved! The request is now forwarded to the lab manager for final confirmation.");
      loadReservations();
    } catch (err: any) {
      alert("❌ " + err.message);
    }
  };

  const handleReject = async (id: string) => {
    if (!rejectReason.trim()) {
      alert("Please provide a brief reason for rejection.");
      return;
    }

    try {
      const res = await fetch("/api/reservations", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id,
          action: "REJECT",
          rejectionReason: rejectReason.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Rejection failed");

      alert("Reservation request rejected.");
      setRejectingId(null);
      setRejectReason("");
      loadReservations();
    } catch (err: any) {
      alert("❌ " + err.message);
    }
  };

  if (loading && !currentUser) {
    return (
      <div className="text-center py-24 text-slate-500 text-base font-medium">
        Loading Faculty Approval Portal...
      </div>
    );
  }

  // Filter reservations based on Status and Scope
  const filtered = reservations.filter((r) => {
    // 1. Status Filter
    if (statusFilter !== "ALL" && r.status !== statusFilter) {
      return false;
    }

    // 2. Scope Filter (Mine vs All)
    if (scopeFilter === "MINE") {
      if (r.facultyId && r.facultyId !== currentUser?.id) {
        return false;
      }
    }

    return true;
  });

  const totalPendingCount = reservations.filter((r) => r.status === "SUBMITTED").length;
  const myPendingCount = reservations.filter(
    (r) => r.status === "SUBMITTED" && (!r.facultyId || r.facultyId === currentUser?.id)
  ).length;

  return (
    <div className="space-y-6 max-w-5xl mx-auto py-2 pb-12">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 to-indigo-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-200 text-xs font-semibold mb-2">
            Faculty Verification Portal
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Student Equipment Approval (교수자 예약 승인)
          </h1>
          <p className="text-blue-100 text-sm mt-1">
            Logged in as: <strong>{currentUser?.fullName}</strong> ({currentUser?.studentId})
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => loadReservations()}
            className="px-4 py-2.5 bg-white/10 hover:bg-white/20 rounded-2xl border border-white/20 text-xs sm:text-sm font-bold flex items-center gap-2 transition"
            title="Refresh List"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? "animate-spin" : ""}`} />
            <span>Refresh</span>
          </button>

          <div className="px-5 py-2.5 bg-white/10 rounded-2xl border border-white/20 text-center">
            <span className="block text-2xl font-black">{totalPendingCount}</span>
            <span className="text-xs text-blue-200 uppercase font-bold tracking-wider">Pending Total</span>
          </div>
        </div>
      </div>

      {/* Filter Tabs & Scope Selectors */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
        {/* Status Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => setStatusFilter("SUBMITTED")}
            className={`px-4 py-2.5 rounded-xl text-sm font-bold transition flex items-center gap-2 whitespace-nowrap ${
              statusFilter === "SUBMITTED"
                ? "bg-amber-500 text-white shadow-md shadow-amber-500/20"
                : "bg-white text-slate-700 hover:bg-slate-100 border border-slate-200"
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Pending Approval ({totalPendingCount})</span>
          </button>

          <button
            onClick={() => setStatusFilter("PROF_APPROVED")}
            className={`px-4 py-2.5 rounded-xl text-sm font-bold transition flex items-center gap-2 whitespace-nowrap ${
              statusFilter === "PROF_APPROVED"
                ? "bg-blue-600 text-white shadow-md shadow-blue-500/20"
                : "bg-white text-slate-700 hover:bg-slate-100 border border-slate-200"
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Approved by Faculty</span>
          </button>

          <button
            onClick={() => setStatusFilter("ALL")}
            className={`px-4 py-2.5 rounded-xl text-sm font-bold transition flex items-center gap-2 whitespace-nowrap ${
              statusFilter === "ALL"
                ? "bg-slate-900 text-white"
                : "bg-white text-slate-700 hover:bg-slate-100 border border-slate-200"
            }`}
          >
            <span>All History</span>
          </button>
        </div>

        {/* Scope Selector (All vs Assigned to Me) */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl self-start sm:self-auto text-xs font-bold">
          <button
            onClick={() => setScopeFilter("ALL")}
            className={`px-3 py-1.5 rounded-xl transition ${
              scopeFilter === "ALL" ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-900"
            }`}
          >
            All Students ({reservations.length})
          </button>
          <button
            onClick={() => setScopeFilter("MINE")}
            className={`px-3 py-1.5 rounded-xl transition ${
              scopeFilter === "MINE" ? "bg-white text-blue-700 shadow-sm" : "text-slate-500 hover:text-slate-900"
            }`}
          >
            Assigned to Me
          </button>
        </div>
      </div>

      {/* Reservation Cards */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 sm:p-16 text-center border border-slate-200 shadow-sm space-y-3">
          <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
          <h3 className="text-xl font-bold text-slate-800">No requests in this category</h3>
          <p className="text-sm text-slate-500">
            {statusFilter === "SUBMITTED"
              ? "All student equipment reservation requests have been reviewed!"
              : "No reservation records found matching current filters."}
          </p>
          <button
            onClick={() => loadReservations()}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-bold text-slate-700"
          >
            Refresh List
          </button>
        </div>
      ) : (
        <div className="space-y-5">
          {filtered.map((res) => {
            const startDate = new Date(res.rentalStartTime);
            const dueDate = new Date(res.returnDueTime);
            const isAssignedToMe = res.facultyId === currentUser?.id;

            return (
              <div
                key={res.id}
                className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm hover:shadow-md transition space-y-5"
              >
                {/* Header Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                      <span className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-md border border-blue-100">
                        {res.reservationNo}
                      </span>
                      <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-100 text-slate-700">
                        {res.projectType}
                      </span>
                      {res.faculty ? (
                        <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100">
                          Instructor: {res.faculty.fullName}
                        </span>
                      ) : (
                        <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-100 text-slate-500">
                          Instructor: Unassigned
                        </span>
                      )}
                    </div>
                    <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                      {res.projectTitle}
                    </h2>
                  </div>

                  {/* Status Badge */}
                  <div>
                    {res.status === "SUBMITTED" && (
                      <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
                        <Clock className="w-4 h-4" />
                        Awaiting Faculty Sign-Off
                      </span>
                    )}
                    {res.status === "PROF_APPROVED" && (
                      <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold bg-blue-50 text-blue-800 border border-blue-200">
                        <Check className="w-4 h-4" />
                        Faculty Approved
                      </span>
                    )}
                    {res.status === "CONFIRMED" && (
                      <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                        Confirmed by Admin
                      </span>
                    )}
                    {res.status === "CANCELLED" && (
                      <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold bg-slate-100 text-slate-500">
                        Cancelled
                      </span>
                    )}
                  </div>
                </div>

                {/* Student & Project Details */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 p-5 rounded-2xl text-sm">
                  <div>
                    <span className="text-slate-400 block text-xs font-semibold">Student Applicant:</span>
                    <strong className="text-slate-900 font-bold text-base">
                      {res.user?.fullName} ({res.user?.studentId})
                    </strong>
                    <div className="text-xs text-slate-500 mt-0.5">{res.user?.email} • {res.user?.phone}</div>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-xs font-semibold">Rental Schedule (3 Days):</span>
                    <strong className="text-slate-900 font-bold text-base">
                      {startDate.toLocaleDateString()} ~ {dueDate.toLocaleDateString()}
                    </strong>
                    <div className="text-xs text-slate-500 mt-0.5">
                      Pickup at: {startDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-xs font-semibold">Team Members:</span>
                    {res.teamMembers && res.teamMembers.length > 0 ? (
                      <div className="text-xs text-slate-700 font-bold mt-1">
                        {res.teamMembers.map((tm: any) => `${tm.studentName} (${tm.studentId})`).join(", ")}
                      </div>
                    ) : (
                      <span className="text-xs text-slate-500 font-medium">Individual Assignment</span>
                    )}
                  </div>
                </div>

                {/* Requested Equipment List */}
                <div className="space-y-2.5">
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Requested Equipment Items ({res.items?.length || 0}):
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {res.items?.map((item: any) => (
                      <div
                        key={item.id}
                        className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between"
                      >
                        <div>
                          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                            {item.model?.brand}
                          </div>
                          <div className="text-sm sm:text-base font-bold text-slate-900">
                            {item.model?.modelName}
                          </div>
                        </div>
                        <span className="text-xs font-bold px-2.5 py-1 bg-blue-50 text-blue-700 rounded-lg">
                          x{item.quantity}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons for Pending */}
                {res.status === "SUBMITTED" && (
                  <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-end gap-3">
                    <button
                      onClick={() => setRejectingId(rejectingId === res.id ? null : res.id)}
                      className="px-5 py-3 rounded-xl border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 font-bold text-sm transition"
                    >
                      Reject Request (반려)
                    </button>
                    <button
                      onClick={() => handleApprove(res.id)}
                      className="px-7 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm sm:text-base shadow-lg shadow-blue-500/25 transition flex items-center gap-2"
                    >
                      <Check className="w-5 h-5" />
                      <span>Approve Reservation (교수 승인)</span>
                    </button>
                  </div>
                )}

                {/* Rejection Note Input Box */}
                {rejectingId === res.id && (
                  <div className="p-4 rounded-2xl bg-red-50 border border-red-200 space-y-3 animate-fadeIn">
                    <label className="block text-xs font-bold text-red-900">
                      Reason for Rejection (반려 사유 입력) *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Project proposal incomplete / Please consult during office hours"
                      value={rejectReason}
                      onChange={(e) => setRejectReason(e.target.value)}
                      className="w-full px-4 py-2.5 text-sm bg-white border border-red-300 rounded-xl outline-none"
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => setRejectingId(null)}
                        className="px-4 py-2 bg-slate-200 rounded-xl text-xs font-semibold"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleReject(res.id)}
                        className="px-5 py-2 bg-red-600 text-white rounded-xl text-xs font-bold shadow-md"
                      >
                        Confirm Rejection
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
